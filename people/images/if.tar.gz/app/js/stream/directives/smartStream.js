//(function () {
//    'use strict';
//    angular.module('stream.smartStream.directive', ['app']).directive('smartStream', [
//        '$q', '$http', '$rootScope', '$state', 'jsonRPC', 'channelService', 'socketio', 'streamCodes', 'frontendSettings',
//        function ($q, $http, $rootScope, $state, jsonRPC, channelService, socketio, streamCodes, frontendSettings) {
//
//            var scope = {
//                entity: '='
//            };
//
//            function link(scope, element, attributes, controller) {
//            }
//
//            function Controller($scope) {
//
//                var refreshIntervalID;
//                $scope.streamCodes = streamCodes;
//
//                $scope.$watch('entity', function () {
//                    console.log("active stream watch", $scope.entity);
//                    if ($scope.entity) {
//                        reloadStreams();
//                        listenSocket();
//                    }
//                });
//
//                $scope.$on('$destroy', function () {
//
//                    if (angular.isDefined(refreshIntervalID)) {
//                        clearInterval(refreshIntervalID);
//                    }
//
//                    console.log('destroy!');
//                    if ($scope.channelName) {
//                        channelService.unsubscribe($scope.channelName).sync();
//                        socketio.getSocket().removeListener($scope.channelName, updateData);
//                    }
//                });
//
//                var updateData = function (data) {
//                    console.log('new stream', data.stream);
//                    if (data.stream) {
//                        angular.forEach(data.stream, function (data) {
//                            if (data.id > $scope.last_stream) {
//                                $scope.streams.push(data);
//                                $scope.last_stream = data.id;
//                            }
//                        });
//                    }
//                };
//
//                var subscribeFlagLock = false;
//                var listenSocket = function () {
//                    if (!subscribeFlagLock && $scope.entity.id) {
//                        $scope.channelName = channelService.getChannelName('stream' + $scope.entity.content_type_id, $scope.entity.id);
//                        channelService.subscribe($scope.channelName).sync();
//                        socketio.getSocket().on($scope.channelName, updateData);
//                        subscribeFlagLock = true;
//                    }
//                };
//
//                function reloadStreams() {
//                    var data = {
//                        content_type_id: $scope.entity.content_type_id,
//                        object_id: $scope.entity.id
//                    };
//
//                    jsonRPC.request('streams.get_stream', data).then(
//                        function (data) {
//                            if (data.error) {
//                                if ($scope.isLogicError(data.error)) {
//                                    $scope.$emit("flash", {
//                                        type: "error",
//                                        title: "Get stream data error",
//                                        text: data.error.data.msg
//                                    });
//                                }
//                            }
//                            else {
//                                $scope.streams = data.result;
//                                $scope.last_stream = 0;
//                                angular.forEach($scope.streams, function (stream) {
//                                    if ($scope.last_stream < stream.id) {
//                                        $scope.last_stream = stream.id;
//                                    }
//                                });
//                            }
//                        }
//                    );
//                }
//
//                refreshIntervalID = setInterval(function () {
//                    $scope.$apply(reloadStreams());
//                }, frontendSettings.streamRefreshTimeout);
//
//            }
//
//            Controller.$inject = ['$scope', '$element'];
//
//            return ({
//                controller: Controller,
//                link: link,
//                restrict: "AE",
//                replace: true,
//                scope: scope,
//                template: '<div><div ng-repeat="item in streams" data-ng-include="\'/static/partials/content/stream_obj.html\'"></div></div>'
//            });
//
//        }]);
//
//})();