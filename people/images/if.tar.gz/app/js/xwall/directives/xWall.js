(function () {
    'use strict';
    angular.module('app.directives.xwall', ['app'])
        .config(["$provide", function ($provide) {
            $provide.decorator("fileUploadDirective", [
                "$delegate", "$controller",
                function ($delegate, $controller) {
                    var directive = $delegate[0];
                    var controllerName = directive.controller;
                    directive.controller = ['$scope', '$element', '$attrs', '$window', 'fileUpload',
                        function ($scope, $element, $attrs, $window, fileUpload) {
                            $scope.$parent.fileUpload = $scope;
                            angular.extend(this, $controller(controllerName, {
                                $scope: $scope,
                                $element: $element,
                                $attrs: $attrs,
                                $window: $window,
                                fileUpload: fileUpload
                            }));
                        }
                    ];

                    return $delegate;
                }]);
        }])
        .directive('xWall', [
            '$rootScope', '$q', '$cookies', '$state', '$stateParams', '$templateCache', '$compile', 'tagService',
            'visibilityService', 'VisibilityTypes', 'xPostsService', 'frontendSettings',
            'fileUpload', 'userService', '$filter', 'imagesSettings',
            'socketio', 'channelService', '$timeout', 'jqPaginationSettings', 'Visibility',
            function ($rootScope, $q, $cookies, $state, $stateParams, $templateCache, $compile, tagService,
                      visibilityService, VisibilityTypes, xPostsService, frontendSettings,
                      fileUpload, userService, $filter, imagesSettings,
                      socketio, channelService, $timeout, jqPaginationSettings, Visibility) {

                var scope = {
                    postsLocator: "=",
                    canPost: '=',
                    sourceObject: '=',
                    defaultPostVisibility: '=',
                    isReply: '=',
                    albumMode: '='
                };


                function link(scope, element, attributes) {
                    console.info("Link scope", scope);
                }

                function Controller($scope) {
                    //$scope.queue = [];
                    $scope.replyScope = null;
                    $scope.xPosts = [];
                    $scope.attachableGalleries = [];
                    $scope.selectedToAttachGalleries = [];
                    $scope.tagsEditor = tagService.getTagSelector(null, true);

                    $scope.loaded = false;
                    $scope.limit = jqPaginationSettings.limit;
                    $scope.total = 0;
                    $scope.maxPage = 0;

                    $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

                    // post edit mode by author
                    $scope.postEditMode = false;

                    var visibilityValue = $scope.sourceObject.visibility ? $scope.sourceObject.visibility.value : '';
                    $scope.currentVisibility = Visibility[visibilityValue];

                    $scope.$on('changeVisibility', function (event, visibility) {
                        $scope.currentVisibility = Visibility[visibility.value];
                    });

                    var defaultVisibility = {
                            value: 4,
                            show_for_all: false,
                            indexable: false
                        },
                        refreshIntervalID,
                        attachedToPhoto = angular.isDefined($scope.postsLocator.photo);

                    userService.getUser().then(function (user) {
                        $scope.user = user;
                    });

                    // Allow visibility level <= source object visibility level
                    if ($scope.sourceObject && $scope.sourceObject.visibility) {
                        $scope.allowedXPostVisibilities = _.filter(VisibilityTypes, function (v) {
                            return v <= $scope.sourceObject.visibility.value;
                        });

                        defaultVisibility = $scope.sourceObject.visibility;
                    }
                    else {
                        $scope.allowedXPostVisibilities = _.filter(VisibilityTypes, function (v) {
                            return true;
                        });
                    }

                    $scope.onlyOriginalImages = function (item) {
                        return $filter('onlyOriginalImages')(item);
                    };

                    $scope.initialXPost = {
                        body: '',
                        tags: [],
                        visibility: $scope.defaultPostVisibility  // T556 xpost inherit visibilty from conversation target
                    };

                    // Attach albums is only allowed on event & place wall
                    $scope.allowAttach = false;
                    userService.getUser().then(function (user) {
                        $scope.allowAttach = user.authenticated && angular.isUndefined($scope.postsLocator.username);
                    });

                    $scope.xPost = angular.copy($scope.initialXPost);
                    $scope.attachDialogActive = false;

                    $scope.isDiscussionMode = angular.isDefined($scope.postsLocator.parent) || attachedToPhoto;

                    $scope.createEditScope = function (post) {
                        $scope.postToEdit = post;
                        // 'this' refers to a new child scope
                        this.xPost = post;
                        this.addXPost = $scope.editXPost;
                        this.editPostOrig = post;
                        this.isEditMode = true;
                    };

                    $scope.closeReply = function () {
                        // WARNING! this method will called after xPostService.editPost and $scope.replyScope will equal null
                        // that's will throw TypeError: Cannot read property '$destroy' of null
                        // therefore need check replyScope before destroy
                        if($scope.replyScope !== null) {
                            $scope.replyScope.$destroy();
                        }
                        $scope.replyScope = null;

                        // To see comments above
                        if($scope.replyFormDOM !== null && typeof $scope.replyFormDOM !== 'undefined') {
                            $scope.replyFormDOM.remove();
                        }
                    };

                    $scope.reply = function (parentPost) {
                        console.log("Reply: ", $scope.sourceObject);
                        var replyFormExists = $scope.replyScope !== null;
                        if (replyFormExists) {
                            // Previously created reply form cleanup
                            $scope.closeReply();
                        }

                        var template = $templateCache.get('/static/partials/wall/post_form.html');

                        // Scope
                        $scope.replyScope = $scope.$new();
                        $scope.replyScope.xPost = angular.copy($scope.initialXPost);
                        $scope.replyScope.postsLocator = {parent: parentPost.id};
                        $scope.replyScope.parentPost = parentPost;
                        $scope.replyScope.isReply = true;

                        // DOM
                        $scope.replyFormDOM = angular.element($compile(template)($scope.replyScope));
                        angular.element('#post-' + [
                            [parentPost.id]
                        ]).after($scope.replyFormDOM);
                    };
                    /*
                     $scope.createReplyScope = function(post){
                     // This refers to a new child scope
                     this.xPost = post;
                     this.addXPost = $scope.editXPost;
                     };
                     */
                    $scope.getDiscussionState = function (post) {

                        var p = {
                            post_id: post.id
                        };

                        if (angular.isDefined($scope.postsLocator.event)) {
                            return $state.href('event.post', p);
                        }
                        else if (angular.isDefined($scope.postsLocator.place)) {
                            return $state.href('place.post', p);
                        }
                        else if (angular.isDefined($scope.postsLocator.username)) {
                            return $state.href('user.post', p);
                        }
                        return p;
                    };


                    //function postExists(post) {
                    //    return _.some($scope.xPosts, function (p) {
                    //        return p.id == post.id;
                    //    });
                    //}

                    //// http://stackoverflow.com/a/2117523/258194
                    //$scope.uploadProgressId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                    //    var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
                    //    return v.toString(16);
                    //});
                    //console.log('X-Progress-ID', $scope.uploadProgressId);


                    $scope.generatedThumbnailsCount = 0;
                    $scope.filesCount = 0;
                    $scope.$onRootScope('thumbnail-generated', function (event, args) {
                        $scope.generatedThumbnailsCount++;
                    });

                    function uploadDone(data) {
                        $scope.clearQueue();
                        $scope.xPost = angular.copy($scope.initialXPost);

                        if ($scope.postEditMode) {
                            // close edit form
                            $scope.postEditMode = false;
                            $scope.closeReply();
                        }
                        $scope.updateXPosts();

                        $scope.$emit("flash", {
                            type: "success",
                            title: "Готово",
                            text: "Пост успешно добавлен"
                        });


                        $rootScope.$emit('photosUploaded');

                    }

                    //function checkNameAndReplaceIfNeed(name, source, withoutPrefix, originalName, index) {
                    //    index = index || 2;
                    //    originalName = originalName || name;
                    //
                    //    var itemWithTheSameName = _.find(source, function (x) {
                    //        var nameToCompare = withoutPrefix ? x.name.replace(imagesSettings.PrefixesPatternWithOriginal, '') : x.name;
                    //        return nameToCompare === name;
                    //    });
                    //
                    //    if (itemWithTheSameName) {
                    //        var uniqueName;
                    //        var lastIndexOfDot = originalName.lastIndexOf('.');
                    //        if (lastIndexOfDot) {
                    //            uniqueName = [originalName.slice(0, lastIndexOfDot), '(', index, ')', originalName.slice(lastIndexOfDot)].join('');
                    //        }
                    //        else {
                    //            uniqueName = originalName + '(' + index + ')';
                    //        }
                    //        return checkNameAndReplaceIfNeed(uniqueName, source, withoutPrefix, originalName, ++index);
                    //    }
                    //
                    //    return name;
                    //}

                    //var fileuploadForm = null;
                    //
                    //function dropDone(data) {
                    //    if (!fileuploadForm) {
                    //        fileuploadForm = $('form[name="addXPostForm"]');
                    //    }
                    //
                    //    var previosQueue = $scope.queue.slice(0);
                    //
                    //    if (data && angular.isArray(data.files)) {
                    //        data.files = _.map(data.files, function (item) {
                    //            var name = checkNameAndReplaceIfNeed(item.name, previosQueue, true);
                    //            if (item.name === name) {
                    //                return item;
                    //            }
                    //
                    //            var blob = new Blob([item], {type: item.type});
                    //            angular.extend(blob, item);
                    //            blob.name = name;
                    //            return blob;
                    //        });
                    //    }
                    //
                    //    var watchQueue = $scope.$watchCollection('queue', function (newValue, oldValue) {
                    //        if (angular.isArray(newValue) && angular.isArray(oldValue)) {
                    //            if (newValue.length === 0 && oldValue.length === 0) {
                    //                return;
                    //            }
                    //
                    //            watchQueue();
                    //
                    //            var oldItemsToKeep = _.filter(previosQueue, function (item) {
                    //                return !_.find(newValue, function (x) {
                    //                    return x === item;
                    //                });
                    //            });
                    //
                    //            var items = newValue.concat(oldItemsToKeep);
                    //
                    //            $timeout(function () {
                    //                fileuploadForm.fileupload('add', {
                    //                    files: _.filter(items, function (x) {
                    //                        return x.name.indexOf('original') > -1;
                    //                    })
                    //                });
                    //                $scope.generatedThumbnailsCount = 0;
                    //                $scope.filesCount = items.length;
                    //            }, 0);
                    //        }
                    //    });
                    //}

                    function getPostData() {
                        var data;
                        if ($scope.postToEdit) {
                            data = angular.copy($scope.postToEdit);
                            delete $scope.postToEdit;
                            return data;
                        }
                        data = angular.copy($scope.xPost);
                        if ($scope.albumMode && !data.title) {
                            data.title = "Новый альбом " + moment().format("L h:mm");
                        }
                        return data;
                    }

                    $scope.options = xPostsService.getUploadOptions(
                        $scope.postsLocator, getPostData, uploadDone //, dropDone, dropDone
                    );

                    $scope.startEditPost = function (post) {

                        // Close all other edits
                        angular.forEach($scope.xPosts, function (p, i) {
                            p.isBeingEdited = false;
                        });

                        post.isBeingEdited = true;

                        // set flag for prevent active post closing
                        $scope.postEditMode = true;
                    };

                    $scope.cancelPost = function (post) {

                        $scope.postEditMode = false;
                        $scope.closeReply();

                        if (post) {
                            post.isBeingEdited = false;
                        }
                        else {
                            $scope.xPost = angular.copy($scope.initialXPost);

                            //$scope.queue = [];
                            $scope.clearQueue();
                        }

                    };

                    $scope.cancelFile = function (file) {
                        var name = file.name.split(":")[1];
                        var _clear = [];
                        for (var i = 0; i < $scope.fileUpload.queue.length; i++) {
                            var f = $scope.fileUpload.queue[i];
                            if (f.name.indexOf(name) < 0) {
                                _clear.push(f);
                            }
                        }

                        $scope.fileUpload.queue = _clear;
                    };

                    $scope.clearQueue = function () {
                        $scope.fileUpload.queue = [];
                    };

                    $scope.originals = [];
                    $scope.$watch("fileUpload.queue.length", function () {
                        var unique = {};
                        _.forEach($scope.fileUpload.queue, function (f) {
                            if (!_.has(unique, f.name)) {
                                unique[f.name] = f;
                            }
                        });
                        $scope.fileUpload.queue = _.values(unique);
                        $scope.originals = $filter('onlyOriginalImages')($scope.fileUpload.queue);
                    });

                    function cleanupTree(rootPost) {
                        $scope.xPosts = _.reject($scope.xPosts, function (p) {
                            return p.id == rootPost.id;
                        });
                        var p = _.find($scope.xPosts, function (p) {
                            return p.parent && p.parent.id == rootPost.id;
                        });
                        if (p) {
                            cleanupTree(p);
                        }
                    }

                    $scope.deletePost = function (post) {

                        $rootScope.confirm("Вы уверены, что хотите удалить пост?").then(function () {
                            xPostsService.deletePost(post).then(
                                function (data) {
                                    if (data && data.error) {
                                        if ($rootScope.isLogicError(data.error)) {
                                            $scope.$emit("flash", {
                                                type: "error",
                                                title: "Ошибка",
                                                text: data.error.data.msg
                                            });
                                        }
                                    }

                                    else {
                                        cleanupTree(post);
                                        $scope.$emit("flash", {
                                            type: "success",
                                            title: "Готово",
                                            text: "Пост удален"
                                        });
                                    }

                                },
                                function (data) {
                                    // general RPC error
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка",
                                        text: "Ошибка удаления поста, повторите запрос позже"
                                    });
                                }
                            );
                        });

                    };

                    $scope.isOwnPost = function (post) {
                        return $rootScope.user.authenticated && $rootScope.user.id == post.owner.id;
                    };

                    // T556
                    $scope.isOwnUserWall = function () {
                        return $state.is('user') ? $scope.sourceObject.username == $rootScope.user.username : false;
                    };

                    $scope.isOwnObjectWall = function () {
                        return $state.is('user') ?
                        $scope.sourceObject && $scope.sourceObject.username == $rootScope.user.username :
                        $scope.sourceObject && $scope.sourceObject.owner && $scope.sourceObject.owner.username == $rootScope.user.username;
                    };

                    $scope.detachGallery = function (galleryId) {
                        $scope.selectedToAttachGalleries = _.reject($scope.selectedToAttachGalleries, function (g) {
                            return g.id == galleryId;
                        });
                    };

                    /*$scope.confirmAttach = function () {
                     $scope.selectedToAttachGalleries = _.filter($scope.attachableGalleries, function (g) {
                     return g.selected;
                     });
                     $scope.attachDialogActive = false;
                     };

                     $scope.cancelAttach = function () {
                     $scope.attachDialogActive = false;
                     };

                     $scope.attachAlbumsPrompt = function () {

                     $scope.attachableGalleries = [];
                     xPostsService.getAlbums($rootScope.user.username).then(
                     function (galleries) {
                     $scope.attachDialogActive = true;
                     $scope.attachableGalleries = galleries;
                     }
                     );

                     };
                     */

                    $scope.updateAfterBan = function (data, callback) {
                        if (data.remove_messages) {
                            var bannedUsername = data.banned_value;
                            $scope.xPosts = _.filter($scope.xPosts, function (post) {
                                return post.owner.username != bannedUsername;
                            });
                        }
                        $scope.updateXPosts(callback);
                    };

                    var updatePostsLastTimestamp = null;
                    var minUpdatePostsInterval = moment.duration(300, 'milliseconds').asMilliseconds();

                    $scope.updateXPosts = function (callback) {
                        var nowTimestamp = moment().valueOf();
                        if (updatePostsLastTimestamp && (nowTimestamp - updatePostsLastTimestamp) < minUpdatePostsInterval) return;
                        updatePostsLastTimestamp = nowTimestamp;

                        var afterMS = 0,
                            i;

                        // Load new comments
                        //if (loadNew) {
                        //    if ($scope.xPosts.length) {
                        //        var firstPost = $scope.xPosts[0];
                        //        afterMS = firstPost.ts_published;
                        //    }
                        //}
                        // Load older comments
                        //else {
                        //    if ($scope.xPosts.length) {
                        //        var lastPost = $scope.xPosts.slice(-1)[0];
                        //        afterMS = -1 * lastPost.ts_published;
                        //    }
                        //}

                        var data = {
                            after_ms: afterMS,
                            only_roots: !$scope.isDiscussionMode,
                            page: $scope.currentPage,
                            page_size: $scope.limit
                        };

                        if ($scope.albumMode) {
                            data.only_roots = true;
                            data.only_with_photos = true;
                        }

                        // Skip update new posts if user edit something (God forgive me)
                        if($scope.postEditMode){
                            return;
                        }

                        xPostsService.getPosts($scope.postsLocator, data)
                            .then(function (posts) {

                                if (!posts.length) {
                                    $scope.loaded = true;
                                    return;
                                }
                                $scope.xPosts = posts;
                                $scope.total = posts.total;
                                $scope.loaded = true;

                                $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);

                            },
                            // Error
                            function (response) {
                                $scope.loaded = true;
                            })
                            .finally(function () {
                                if (angular.isFunction(callback)){
                                    callback();
                                }
                            });
                    };

                    $scope.editXPost = function () {
                        var hasPhotosToUpload = $scope.fileUpload.queue && $scope.fileUpload.queue.length > 0,
                            deferred = $q.defer(),
                            post = this.xPost,
                            postLocator = this.postsLocator;

                        post.visibility = visibilityService.convertToRPCData(post.visibility);
                        post.tags = tagService.convertTagsToRPCData(post.tags);

                        if (hasPhotosToUpload) {
                            $timeout(function () {
                                $rootScope.loading = true;
                            }, 0);

                            $scope.fileUpload.submit();
                            deferred.resolve();
                            return deferred.promise;
                        }

                        xPostsService.editPost(postLocator, post).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isFormError(data.error)) {
                                        deferred.reject(data.error.data);
                                    }
                                    else if ($rootScope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка",
                                            text: data.error.data.msg
                                        });
                                        deferred.reject();
                                    }
                                }

                                else {
                                    var srcPost = _.find($scope.xPosts, function (p) {
                                        return p.id === post.id;
                                    });

                                    if (srcPost) {
                                        srcPost.body = data.body;
                                        srcPost.title = data.title;
                                        srcPost.tags = angular.copy(data.tags);
                                        srcPost.visibility = angular.copy(data.visibility);
                                        $scope.cancelPost(srcPost);
                                    }
                                    deferred.resolve();
                                }

                            },
                            function (data) {
                                // general RPC error
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Server error",
                                    text: "Sorry, error occurred while submitting. Please try again later."
                                });
                                deferred.reject();
                            }
                        );
                        return deferred.promise;

                    };

                    $scope.addXPost = function (parentPost) {

                        var hasPhotosToUpload = $scope.fileUpload.queue && $scope.fileUpload.queue.length > 0,
                            deferred = $q.defer(),
                            data = angular.copy(this.xPost),
                            postLocator = this.postsLocator,
                            isReply = angular.isObject(parentPost),
                            postingToUserWall = angular.isDefined(postLocator.username);

                        // Posting to other user's wall deprecated (for now at least)
                        if (postingToUserWall && $rootScope.user.username != postLocator.username) {

                            return {
                                body: "posting_to_anothers_wall"
                            };
                        }

                        if ($scope.albumMode && $scope.fileUpload.queue.length === 0) {
                            return {
                                __all__: ["files_required"]
                            };
                        }

                        if (hasPhotosToUpload) {
                            $timeout(function () {
                                $rootScope.loading = true;
                            }, 0);

                            $scope.fileUpload.submit();
                            deferred.resolve();
                            return deferred.promise;
                        }


                        // T556 xpost inherits visiblity from conversation target
                        data.visibility = $scope.defaultPostVisibility;

                        data.tags = tagService.convertTagsToRPCData(data.tags);
                        data.attach = _.map($scope.selectedToAttachGalleries, function (g) {
                            return g.id;
                        });

                        xPostsService.addPost(postLocator, data).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isFormError(data.error)) {
                                        deferred.reject(data.error.data);
                                    }
                                    else if ($rootScope.isRegularUserRoleRequired(data.error)) {
                                        $rootScope.$emit('checkEmailConfirmation');
                                        deferred.reject();
                                    }
                                    else if ($rootScope.isPermissionDenied(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка добавления поста",
                                            text: "Недостаточно прав для добавления поста, либо Вы были забанены"
                                        });
                                        deferred.reject();
                                    }

                                    else if ($rootScope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка добавления поста",
                                            text: data.error.data.msg
                                        });
                                        deferred.reject();
                                    }
                                }
                                else {
                                    if (isReply) {
                                        $scope.closeReply();
                                    }
                                    else {
                                        $scope.xPost = angular.copy($scope.initialXPost);
                                    }
                                    $scope.updateXPosts(true);

                                    deferred.resolve();

                                    $scope.$emit("flash", {
                                        type: "success",
                                        title: "Готово",
                                        text: "Пост успешно добавлен"
                                    });
                                }
                            },
                            function (response) {

                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка добавления поста",
                                    text: "Попробуйте повторить попытку позже"
                                });

                                deferred.reject();
                            }
                        );

                        return deferred.promise;

                    };
                    $scope.hasPerm = function (perm) {
                        return $rootScope.hasPerm(perm);
                    };

                    $scope.getAlbumParams = function (post) {
                        return angular.extend($scope.postsLocator, {albumID: post.id});
                    };

                    $scope._canPost = function () {
                        var nowT = new Date(),
                            o = $scope.sourceObject,
                            t1 = o.conversation_ts_start,
                            t2 = o.conversation_ts_finish,
                            t1Set = o.conversation_ts_start !== null,
                            t2Set = o.conversation_ts_finish !== null,
                            conversationDateRangeValid = (!t1Set || (t1 <= nowT)) && (!t2Set || (t2 >= nowT));

                        return $scope.canPost() && o.conversation_enabled && conversationDateRangeValid;
                    };


                    function updateData() {
                        $scope.updateXPosts(true);
                    }

                    $scope.$on('$destroy', function () {

                        if (angular.isDefined(refreshIntervalID)) {
                            clearInterval(refreshIntervalID);
                        }

                        if ($scope.channelName) {
                            channelService.unsubscribe($scope.channelName).sync();
                            socketio.getSocket().removeListener($scope.channelName, updateData);
                        }

                    });

                    var listenSocket = function () {
                        $scope.channelName = channelService.getChannelName('user', $scope.sourceObject.id);
                        channelService.subscribe($scope.channelName).sync();
                        socketio.getSocket().on($scope.channelName, updateData);
                    };

                    $scope.$watch('sourceObject', function (val) {
                        if (angular.isDefined($scope.sourceObject.id)) {
                            if (channelService.checkSubscribe('user', $scope.sourceObject.id) === -1) {
                                listenSocket();
                            }
                        }
                    });

                    userService.getUser().then(function (user) {

                        var skipWallUpdates = angular.isDefined($scope.postsLocator.username) && // attached to user wall
                                $scope.postsLocator.username == user.username && // own user wall
                                user.has_verified_email !== true; // email not verified

                        // T1032
                        if(!skipWallUpdates){
                            refreshIntervalID = setInterval(function () {
                                $scope.$apply($scope.updateXPosts());
                            }, frontendSettings.xPostsRefreshTimeout);
                        }

                        $scope.updateXPosts();
                    });

                }

                Controller.$inject = ['$scope'];

                return ({
                    scope: scope,
                    controller: Controller,
                    link: link,
                    restrict: "AE",
                    replace: true,
                    templateUrl: "/static/partials/wall/x-wall.html"
                });
            }]);
})();
