(function () {
    "use strict";
    angular.module('app.xwall.discussion.settings', []).directive('discussionSettings', [
        '$rootScope', '$http', '$templateCache', '$compile', '$q', 'jsonRPC',
        function ($rootScope, $http, $templateCache, $compile, $q, jsonRPC) {

            var scope = {
                discussionObject: '=',
                discussionObjectType: '@',
                discussionSettingsDialogActive: '='
            };

            function link(scope, element) {
                $http.get('/static/partials/wall/discussion_settings.html', {cache: $templateCache})
                    .success(function (template) {
                        scope.modal_form = angular.element($compile(template)(scope));
                        element.after(scope.modal_form);
                    });

                element.bind('click', function () {
                    if (!scope.discussionSettingsDialogActive) {
                        scope.discussionSettingsDialogActive = true;
                    }
                });

            }

            function Controller($scope) {

                $scope.changeCommentSettings = function () {

                    var tm1 = $scope.discussionObject.conversation_ts_start,
                        tm2 = $scope.discussionObject.conversation_ts_finish;

                    if ($scope.discussionObject.conversation_max_depth < 0) {
                        return {
                            max_depth: 'min_value'
                        };
                    }

                    if ((!!tm1 && !!tm2) && (tm1 > tm2)) {
                        return {
                            date2: 'invalid_range'
                        };
                    }

                    // Send to server
                    var deferred = $q.defer();
                    var data = angular.copy($scope.discussionObject);
                    switch ($scope.discussionObjectType) {
                        case 'event':
                            data.event_id = $scope.discussionObject.id;
                            data.place_id = data.photo_id = data.username = null;
                            break;
                        case 'place':
                            data.place_id = $scope.discussionObject.id;
                            data.event_id = data.photo_id = data.username = null;
                            break;
                        case 'photo':
                            data.photo_id = $scope.discussionObject.id;
                            data.event_id = data.place_id = data.username = null;
                            break;
                        case 'user':
                            data.username = $scope.discussionObject.username;
                            data.event_id = data.place_id = data.photo_id = null;
                            break;
                    }
                    jsonRPC.request('xpost.conversation_settings', data).then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isFormError(data.error)) {
                                    deferred.reject(data.error.data);
                                }
                                else if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка изменения настроек",
                                        text: data.error.data.msg
                                    });
                                    deferred.reject();
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Готово",
                                    text: "Настройки обсуждения сохранены"
                                });
                                deferred.resolve();
                                $scope.close();
                            }
                        },
                        function () {
                            // general RPC error
                            deferred.reject();
                        }
                    );
                    return deferred.promise;


                };

                $scope.close = function () {
                    $scope.discussionSettingsDialogActive = false;
                };
            }

            Controller.$inject = ['$scope'];

            return ({
                controller: Controller,
                restrict: "AE",
                replace: true,
                link: link,
                scope: scope
                //templateUrl: "/static/partials/wall/discussion_settings.html"
            });
        }]);
})();