(function(){
angular.module('app.services.xposts', []).
    service('xPostsService', ['$rootScope', 'jsonRPC', 'tagService', 'visibilityService', '$cookies', 'blueimpPhotoProcessQueue', '$state', 'permissionRequired', '$q',
        function ($rootScope, jsonRPC, tagService, visibilityService, $cookies, blueimpPhotoProcessQueue, $state, permissionRequired, $q) {

        var self = this,
            URI = 'rest/v1/';

        this.getResourceTarget = function (locator) {
          var target = {};
          if (locator) {
                if (locator.username) {
                    target.username = locator.username;
                }
                else if (locator.event) {
                    target.event = locator.event;
                }
                else if (locator.place) {
                    target.place = locator.place;
                }
                else if (locator.parent) {
                    target.parent = locator.parent;
                }
                else if (locator.photo) {
                    target.photo = locator.photo;
                }
            }
            return target;
        };

        this.extractData = function (response, isList) {
            var defer = $q.defer();
            response.then(
                function (res) {
                    var data = {};
                    if (isList) {
                        data = res.result.results;
                        data.total = res.result.total;
                    } else if (res.error) {
                        data.error = res.error;
                    } else {
                        data = res.result;
                    }
                    defer.resolve(data);
                },
                defer.reject
            );
            return defer.promise;
        };

        // this.getResourceURL = function (locator, single) {
        //     var url = URI,
        //         p = single ? "post" : "posts";

        //     if (locator) {
        //         if (locator.username) {
        //             url += "users/" + locator.username + "/" + p;
        //         }
        //         else if (locator.event) {
        //             url += "event/" + locator.event + "/" + p;
        //         }
        //         else if (locator.place) {
        //             url += "place/" + locator.place + "/" + p;
        //         }
        //         else if (locator.parent) {
        //             url += "parent/" + locator.parent + "/" + p;
        //         }
        //         else if (locator.photo) {
        //             url += "photo/" + locator.photo + "/" + p;
        //         }
        //     }

        //     return url;
        // };

        this.getPostByID = function (locator, postID) {
            return self.extractData(jsonRPC.request(
                'xpost.get_post',
                {
                  pk: postID,
                  target: self.getResourceTarget(locator),
                  payload: null,
                }
              ),
              false
            );
        };

        this.getPosts = function (locator, data) {
            return self.extractData(jsonRPC.request(
                'xpost.get_conversation',
                {
                  pk: null,
                  target: self.getResourceTarget(locator),
                  payload: data,
                }
              ),
              true
            );
        };

        this.getAlbums = function (locator) {
            var data = {
                only_roots: true,
                only_with_photos: true
            };
            return self.getPosts(locator, data);
        };

        this.getPhotoByID = function (photoID) {
            return self.extractData(jsonRPC.request(
                'xpost.get_photo',
                {
                  pk: photoID,
                  target: null,
                  payload: null
                }
              ),
              false
            );
        };

        this.deletePost = permissionRequired('xpost.delete_xpost', function (post) {
            return self.extractData(jsonRPC.request(
                'xpost.delete_post',
                {
                  pk: post.id,
                  target: null,
                  payload: null
                }
              ),
              false
            );
            // return post.remove(null, {'X-CSRFToken': $cookies.csrftoken});
        });

        this.deletePhoto = permissionRequired('galleries.delete_photo', function (photo) {
            return self.extractData(jsonRPC.request(
                'xpost.delete_photo',
                {
                  pk: photo.id,
                  target: null,
                  payload: null
                }
              ),
              false
            );
            // return photo.remove(null, {'X-CSRFToken': $cookies.csrftoken});
        });

        this.editPost = permissionRequired('xpost.change_xpost', function (locator, post) {
            return self.extractData(jsonRPC.request(
                'xpost.edit_post',
                {
                  pk: post.id,
                  target: self.getResourceTarget(locator),
                  payload: post
                }
              ),
              false
            );
            // return post.put(null, {'X-CSRFToken': $cookies.csrftoken});
        });

        this.editPhoto = permissionRequired('galleries.change_photo', function (photo) {
            return self.extractData(jsonRPC.request(
                'xpost.edit_photo',
                {
                  pk: photo.id,
                  target: null,
                  payload: photo,
                }
              ),
              false
            );
            //return photo.put(null, {'X-CSRFToken': $cookies.csrftoken});
        });

        this.addPost = permissionRequired('xpost.add_xpost', function (locator, data) {
            return self.extractData(jsonRPC.request(
                'xpost.add_post',
                {
                  pk: null,
                  target: self.getResourceTarget(locator),
                  payload: data
                }
              ),
              false
            );
        });

        this.getUploadOptions = function (postsLocator, data, uploadDone, dropDone, change) {
            /*
             Used in xPost form, album creation form
             */

            return {
                // url: RESTANGULAR_BASE_URL + this.getResourceURL(postsLocator) + "/",
                url: RESTANGULAR_BASE_URL + "api/xpost/add_post/",
                xhrFields: {
                    withCredentials: true
                },
                singleFileUploads: false,
                paramName: 'files',
                progressInterval: 10,
                bitrateInterval: 50,
                //dropZone: angular.element('#xPostBody'),
                beforeSend: function (xhr) {
                    console.log("xPost before send: add token: ", $cookies.csrftoken);
                    xhr.setRequestHeader('X-CSRFToken', $cookies.csrftoken);
                },
                formData: function () {

                    var formData = [],
                        payloadData = {},
                        d = angular.isFunction(data) ? data() : data;

                    // angular.forEach(postsLocator, function (v, k) {
                    //     formData.push({name: k, value: v});
                    // });

                    // T565
                    if (d.title) {
                        payloadData.title = d.title;
                        // formData.push({
                        //     name: 'title',
                        //     value: d.title
                        // });
                    }

                    // T565
                    if (d.body) {
                        payloadData.body = d.body;
                        // formData.push({
                        //     name: 'body',
                        //     value: d.body
                        // });
                    }

                    payloadData.tags = d.tags;
                    payloadData.visibility = d.visibility;
                    // formData.push({
                    //     name: 'tags',
                    //     value: angular.toJson(tagService.convertTagsToRPCData(d.tags))
                    // });
                    // formData.push({
                    //     name: 'visibility',
                    //     value: angular.toJson(visibilityService.convertToRPCData(d.visibility))
                    // });
                    //

                    // edit mode
                    if (d.id) {
                        formData.push({
                            name: 'pk',
                            value: d.id
                        });
                    }
                    formData.push({
                        name: 'target',
                        value: angular.toJson(self.getResourceTarget(postsLocator))
                    });
                    formData.push({
                        name: 'payload',
                        value: angular.toJson(payloadData)
                    });

                    return formData;
                },
                done: function (e, data) {
                    if (angular.isFunction(uploadDone)) {
                        uploadDone(data);
                    }
                    $rootScope.loading = false;

                },
                fail: function(e, data){

                    if($rootScope.isRegularUserRoleRequired(data.jqXHR.responseJSON.error)){

                        $rootScope.$emit('checkEmailConfirmation');
                    }
                    $rootScope.loading = false;
                },
                drop: function (e, data) {
                    if (angular.isFunction(dropDone)) {
                        dropDone(data);
                    }
                },
                change: function (e, data) {
                    if (angular.isFunction(change)) {
                        change(data);
                    }
                },
                processQueue: blueimpPhotoProcessQueue
            };

        };

        this.getDiscussionStateByType = function(post, type){
            var p = {
                post_id: post.parent_id ? post.parent_id : post.id
            };
            return $state.href(type + '.post', p);
        };

    }]);

})();
