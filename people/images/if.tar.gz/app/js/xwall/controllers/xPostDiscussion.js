(function(){
'use strict';
angular.module('app.controllers.xpostsdiscussion', [])
.controller('xPostDiscussion', ['$scope', '$state', '$stateParams', '$rootScope', '$filter', 'rootPost', 'xPostsService', 'channelService', 'StreamCode', 'socketio', 'permissionRequired',
 function ($scope, $state, $stateParams, $rootScope, $filter, rootPost, xPostsService, channelService, StreamCode, socketio, permissionRequired) {

    $scope.rootObject = rootPost.object;
    $scope.rootPost = rootPost.post;
    $scope.albumMode = rootPost.post.photos && rootPost.post.photos.length > 0;
    $scope.userAlbums = [];
    $scope.userAlbumsLoaded = false;

    $scope.isMergeModalActive = false;
    $scope.selectedToMerge = null;
    $scope.mergeTarget = null;
    // T1016
    $scope.hidePrivacySetting = $state.includes('user') && angular.isDefined($state.current.data.privacySectionAlias);
     
    $scope.$on('$destroy', function () {
        if ($scope.channelName) {
            channelService.unsubscribe($scope.channelName).sync();
            socketio.getSocket().removeListener($scope.channelName, updateData);
        }
    });

    var listenSocket = function () {
        $scope.channelName = channelService.getChannelName('post', $scope.rootPost.id);
        channelService.subscribe($scope.channelName).sync();
        socketio.getSocket().on($scope.channelName, updateData);
    };

    var updateData = function (data) {
        console.log('update data', data);

        if (data.code === StreamCode.CHANGED) {
            if (data.content.liked_count) {
                $scope.rootPost.liked_count = data.content.liked_count;
            }
        } 
    };

    listenSocket();
    
    $scope.goToPhotoState = function(photo) {

        var p = {
            post_id: $scope.rootPost.id,
            photo_id: photo.id
        };
        if($state.includes('user')){
            $state.go('user.photo', p);
        }
        else if($state.includes('event')){
            $state.go('event.photo', p);
        }
        else if($state.includes('place')){
            $state.href('place.photo', p);
        }
    };

    $scope.isOwnPostDiscussed = function () {
        return $rootScope.user.authenticated && $rootScope.user.id == $scope.rootPost.owner.id;
    };

    $scope.openMergeModal = function(){
        $scope.isMergeModalActive = true;
        $scope.loadAlbums();
    };

    $scope.closeMergeModal = function(){
        
        $scope.isMergeModalActive = false;
        $scope.selectedToMerge = null;
        $scope.mergeTarget = null;
    };


    $scope.editPost = function(){
        $scope.editAlbum = $scope.rootPost;
    };

    $scope.updatePost = function() {
        $scope.rootPost = $scope.editAlbum;
    };

    $scope.editPhoto = permissionRequired('galleries.change_photo', function(photoID){

        xPostsService.getPhotoByID(photoID).then(
            function(photo) {
                $scope.editPhotoInstance = photo;
            },
            function(){
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Ошибка загрузки фотографии"
                });
            }
        );
                
    });

    $scope.updatePhoto = function(photo) {
        var editedPhoto = _.find($scope.rootPost.photos, function(pagePhoto){
            return pagePhoto.id == photo.id;
        });

        if(editedPhoto){
            angular.extend(editedPhoto, photo);
        }
        
        $scope.editPhotoInstance = {};
    };

    $scope.changePhotoVisibility = function(photoIndex){

        xPostsService.getPhotoByID($scope.rootPost.photos[photoIndex].id).then(
            function(photo) {
                photo.visibility = $scope.rootPost.photos[photoIndex].visibility;
                xPostsService.editPhoto(photo).then(

                    function(){
                        $scope.$emit("flash", {
                            type: "success",
                            title: "Готово",
                            text: "Видимость фотографии изменена"
                        });
                        
                    },
                    function(){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Невозможно изменить видимость фотографии, повторите попытку позже"
                        });
                        
                    }
                );
            },
            function(){
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Ошибка загрузки фотографии"
                });
            }
        );
        
    };

    $scope.goToRootObjectAlbums = function(){
        if($state.includes('user')){
            $state.go('user.albums', {username: $scope.rootObject.username});
        }
        else if($state.includes('event')){
            $state.go('event.albums', {event_alias: $scope.rootObject.alias});
        }
        else if($state.includes('place')){
            $state.go('place.albums', {place_alias: $scope.rootObject.alias});
        }
    };

    $scope.goToRootObjectWall = function(){
        if($state.includes('user')){
            $state.go('user.wall', {username: $scope.rootObject.username});
        }
        else if($state.includes('event')){
            $state.go('event.wall', {event_alias: $scope.rootObject.alias});
        }
        else if($state.includes('place')){
            $state.go('place.wall', {place_alias: $scope.rootObject.alias});
        }
    };
    
    var removeOpenAlbum = function(){
        xPostsService.deletePost($scope.rootPost).then(
            function (data) {
                if (data && data.error) {
                    if ($rootScope.isLogicError(data.error)) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: data.error.data.msg
                        });
                    }
                }
                
                else {
                    $scope.$emit("flash", {
                        type: "success",
                        title: "Готово",
                        text: "Альбом '" + $scope.rootPost.title + "' удален"
                    });
                }
                $scope.goToRootObjectAlbums();
            },
            function () {
                // general RPC error
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Ошибка удаления альбома"
                });
                $scope.goToRootObjectAlbums();

            }
            
        );
    };

    $scope.deletePhoto = permissionRequired('galleries.delete_photo', function(photoIndex){

        var removingLastPhoto = $scope.rootPost.photos.length == 1,
            whatToConfirm = removingLastPhoto ? 
                "Удаление последнего фото из альбома приведет к его удалению, действительно удалить фото?":
                "Вы уверены, что хотите удалить фото?";

        $scope.confirm(whatToConfirm).then(function(){

            xPostsService.getPhotoByID($scope.rootPost.photos[photoIndex].id).then(
                function(photo) {
                    xPostsService.deletePhoto(photo).then(
                        function (data) {
                            if (data && data.error) {
                                if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Готово",
                                    text: "Фото удалено"
                                });

                                if(removingLastPhoto){
                                    removeOpenAlbum();
                                }
                                else{
                                    $scope.rootPost.photos.splice(photoIndex, 1);
                                }
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: "Ошибка удаления фото, повторите запрос позже"
                            });
                        }
                    );
                },
                function(){
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Ошибка загрузки фотографии"
                    });
                }
            );
        });
    });

    $scope.changePostVisibility = function(){
        var post = $scope.rootPost;

        xPostsService.editPost(post).then(
            function(data) {
                if(data.error){
                    if($rootScope.isFormError(data.error)){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Попробуйте повторить запрос позже"
                        });

                    }
                    else if($rootScope.isLogicError(data.error)){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: data.error.data.msg
                        });
                    }
                }
                else{
                    $scope.$emit("flash", {
                        type: "success",
                        title: "Готово",
                        text: "Приватность поста успешно обновлена"
                    });
                }
            },
            function() {
                // general RPC error
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Попробуйте повторить запрос позже"
                });
            }

        );
    };

    $scope.goToLastPhotoState = function(stateParams){
        $state.go('user.photo', stateParams);
    };

    $scope.openViewer = function(){

        var options = {
            index: 0
            /*
            onclose: function () {
                var finishedIndex = this.index;
                $scope.$apply(function(){
                    var photo = rootPost.post.photos[finishedIndex];
                    $scope.goToLastPhotoState({albumID: $scope.album.id, photo_id: photo.id});
                });
            }*/
        },
            links = [];

        angular.forEach(rootPost.post.photos, function(p){
            links.push({
                title: p.title,
                href: $filter('imageUrl')(p.image_url, 'large')
            });
        });
        blueimp.Gallery(links, options);
    };

    $scope.canAddXPosts = function(){
        return !$scope.rootPost.readOnly && !$scope.rootObject.user_banned;
    };

     $scope.loadAlbums = function(){
         $scope.userAlbums = [];
         $scope.userAlbumsLoaded = false;

         var locator = {
             username: $scope.userObject.username
         };

         xPostsService.getAlbums(locator).then(
             function(albums) {
                 if(albums.error){
                     if($scope.isLogicError(albums.error)){
                         $scope.$emit("flash", {
                             type: "error",
                             title: "Ошибка",
                             text: albums.error.data.msg
                         });
                     }
                 }
                 else{
                     $scope.userAlbums = _.filter(albums, function(album){
                         return parseInt(album.id)!=parseInt($scope.albumID);
                     });
                     $scope.userAlbumsLoaded = true;

                 }
             },
             function() {
                 $scope.$emit("flash", {
                     type: "error",
                     title: "Ошибка",
                     text: "Невозможно получить список альбомов, попробуйте повторить попытку позже"
                 });
             }
         );
     };

     $scope.moveToAlbum = permissionRequired('galleries.change_photo', function(photo, targetAlbum){

         var confirmationRequired = $scope.rootPost.photos.length == 1;
         function move(removeAlbum){
             xPostsService.getPhotoByID(photo.id).then(
                 function(photo){
                     photo.move_to = targetAlbum.id;
                     xPostsService.editPhoto(photo).then(
                         function(){
                             $scope.$emit("flash", {
                                 type: "success",
                                 title: "Готово",
                                 text: "Фотография перемещена в альбом " + targetAlbum.title
                             });
                             if(removeAlbum){
                                 removeOpenAlbum();
                             }
                             else{
                                 $scope.rootPost.photos = _.filter($scope.rootPost.photos, function(p){
                                     return p.id != photo.id;
                                 });
                                 console.log("PHOTOS: ", $scope.rootPost.photos, photo);
                                 //$scope.reloadGallery();
                             }

                         },
                         function(){
                             $scope.$emit("flash", {
                                 type: "error",
                                 title: "Ошибка",
                                 text: "Ошибка перемещения фотографии"
                             });
                         }
                     );
                 },
                 function(){
                     $scope.$emit("flash", {
                         type: "error",
                         title: "Ошибка",
                         text: "Ошибка загрузки фотографии"
                     });
                 }
             );
         }

         if(confirmationRequired){
             $scope.confirm("Перемещение последней фотографии из альбома приведет к его удалению, действительно переместить фото?").then(function(){
                 move(true);
             });
         }
         else{
             move();
         }

     });

     if( $scope.isOwnPostDiscussed() && $scope.albumMode){
         $scope.loadAlbums();
     }
     
     
}]);

})();
