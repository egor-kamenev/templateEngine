(function(){
'use strict';

angular.module('settings.services', []).
service('userSettingsService',['$rootScope', 'jsonRPC', 'permissionRequired', 'SettingType', 
function($rootScope, jsonRPC, permissionRequired, SettingType){

    var self = this;

    this.getEventsParticipationSettings = function() {
        return self.getSettings(SettingType.SETTING_TYPE_EVENTS_PARTICIPATION);
    };

    this.saveSettings = permissionRequired('users.change_user', function(settings) {
        return jsonRPC.request('settings.save_settings', {settings: settings});
    });

    this.getSettings = function(setting_type) {
        return jsonRPC.request('settings.get_settings', {setting_type: setting_type});
    };
}]);

})();
