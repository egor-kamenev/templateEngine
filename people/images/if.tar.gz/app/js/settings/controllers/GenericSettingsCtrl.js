(function(){
'use strict';

angular.module('settings.controllers.genericsettingsctrl', []).controller('GenericSettingsCtrl', [
    '$scope', '$rootScope', '$state', 'userSettingsService',
    function ($scope, $rootScope, $state, userSettingsService) {

        $scope.settings = {};

        $scope.saveSettings = function () {

            $rootScope.loading = true;

            userSettingsService.saveSettings($scope.settings).then(
                function(data) {
                    if(data.error){
                        if($rootScope.isLogicError(data.error)){
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Ошибка сохранения настроек",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else{
                        $rootScope.$emit("flash", {
                            type: "success",
                            title: "Готово",
                            text: "Настройки сохранены"
                        });
                    }
                },
                function() {
                    // general RPC error
                    $rootScope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Повторите запрос позже"
                    });
                }
            ).finally(function(){
                $rootScope.loading = false;
            });
        };

        $scope.reloadSettings = function() {

            $scope.settings = {};
            $rootScope.loading = true;
            userSettingsService.getSettings( $state.current.data.setting_type).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка загрузки настроек",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        $scope.settings = data.result;
                    }
                },
                function () {
                    // general RPC error
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Повторите запрос позже"
                    });
                }
            ).finally(function(){
                $rootScope.loading = false;
            });
        };

        $scope.$onRootScope('reloadSettings', function () {
            $scope.reloadSettings();
        });

    }]);

})();
