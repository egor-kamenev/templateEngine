(function(){
'use strict';

angular.module('settings.controllers.visiblesettingsctrl', [])
    .controller('VisibleSettingsCtrl',
    ['$scope', '$q', '$stateParams', 'jsonRPC', 'userService', 'visibilityService', 'UserProfile', 'permissionRequired',
        function ($scope, $q, $stateParams, jsonRPC, userService, visibilityService, UserProfile, permissionRequired) {
            var old_discoverable;

            //TODO: get indexable and other from UserProfile after update (T253)
            $scope.settings = {
                sections: UserProfile.profile.sections_visibility,
                is_discoverable: !UserProfile.isDiscoverable,
                indexable: UserProfile.profile.indexable,
                other: UserProfile.profile.other
            };


            $scope.saveSettings = $scope.permissionRequired('users.change_user', function () {

                var deferred = $q.defer(),
                    data = {
                        settings: $scope.settings
                    };

                jsonRPC.request('settings.save_visible_settings', data).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isFormError(data.error)) {
                                deferred.reject(data.error.data);
                            }
                            else if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Settings error",
                                    text: data.error.data.msg
                                });
                                deferred.reject();
                            }
                        }

                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Готово",
                                text: "Настройки сохранены"
                            });
                            reloadProfile();
                        }
                    },
                    function () {
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Sorry, error occurred while submitting. Please try again later."
                        });

                        deferred.reject();
                    }
                );
                return deferred.promise;

            });

            function reloadProfile() {
                userService.getProfileByUsername(
                    $stateParams.username,
                    function (data) {
                        $scope.profile = data;
                        old_discoverable = $scope.settings.is_discoverable;
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Sorry, error occurred while submitting. Please try again later."
                        });
                    });
            }

            $scope.changeIndexable = function () {
                if ($scope.settings.indexable) {
                    old_discoverable = $scope.settings.is_discoverable;
                    $scope.settings.is_discoverable = false;
                }
                else {
                    $scope.settings.is_discoverable = old_discoverable;
                }
            };
        }]);

})();
