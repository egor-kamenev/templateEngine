(function(){
'use strict';

angular.module('settings.controllers.passwordsettingsctrl', [])
  .controller('PasswordSettingsCtrl', ['$scope', '$q', '$stateParams', 'jsonRPC', function ($scope, $q, $stateParams, jsonRPC) {

        $scope.settings = {};

        $scope.change_password = function(){

//            if($scope.passwords.pass1 != $scope.passwords.pass2){
//                return {
//                    password2: "Paswords do not match"
//                };
//            }

            var data= {
                old_password: $scope.passwords.old_pass,
                new_password1: $scope.passwords.pass1,
                new_password2: $scope.passwords.pass2
            };

            // Send to server
            var deferred = $q.defer();
                jsonRPC.request('users.change_password', data).then(
                function(data) {
                    if(data.error){
                        if($scope.isFormError(data.error)){
                            deferred.reject(data.error.data);
                        }
                        else if($scope.isLogicError(data.error)){
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Change password error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }
                    }
                    else{
                        $scope.$emit("flash", {
                            type: "success",
                            title: "Success",
                            text: "You have successfully updated your password"
                        });
                        clearPassword();

                        deferred.resolve();
                    }
                },
                function() {
                    // general RPC error
                    deferred.reject();
                }
            );
            return deferred.promise;
        };

        function clearPassword(){
            $scope.passwords = {
                pass1: '',
                pass2: '',
                old_pass: ''
            };
        }
        clearPassword();

    }]);

})();