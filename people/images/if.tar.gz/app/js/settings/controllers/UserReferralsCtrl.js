(function(){
angular.module('settings.controllers.userreferralsctrl', []).controller('UserReferralsCtrl', [
    '$scope', '$stateParams', 'jsonRPC',
    function ($scope, $stateParams, jsonRPC) {

        $scope.referrals = [];

        $scope.reloadReferrals = function () {

            jsonRPC.request('users.get_referrals').then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Get referrals error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        $scope.referrals = data.result;
                    }
                },
                function () {
                    // general RPC error
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Server error",
                        text: "Sorry, error occurred while submitting. Please try again later."
                    });
                }
            );
        };

        $scope.reloadReferrals();

    }]);

})();