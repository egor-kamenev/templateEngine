(function(){
'use strict';

//angular.module('app.controllers.organizationctrl', [])
angular.module('settings.controllers.organizationctrl', []).controller(
    'OrganizationCtrl', ['$scope', '$q', '$state', 'userService', 'jsonRPC', '$rootScope',
        function ($scope, $q, $state, userService, jsonRPC, $rootScope) {

            if ($state.current.url == '/placeStudy') {
                $scope.org_type = 0;
                $scope.title = 'учебы';
            }
            else if ($state.current.url == '/placeWork') {
                $scope.org_type = 1;
                $scope.title = 'работы';
            }
            else {
                $state.go('404');
            }
            $scope.newOrganizationVisible = false;
            $scope.is_adding = true;
            $scope.orgsEditor = getOrgSelector();
            $scope.year = '1900';

            $scope.$watch("user", function (data) {
                $scope.year = moment(data.date_of_birth).year();
            });

            $scope.addOrEditOrganization = function () {
                if ($scope.is_adding) {
                    return $scope.addOrganization();
                }
                return $scope.editOrganization();
            };

            $scope.editOrganization = function () {

                var deferred = $q.defer(),
                    data = {
                        pk: $scope.new_org.id,
                        name: $scope.new_org.organization.name,
                        org_type: $scope.org_type,
                        period_begin: $scope.new_org.period_begin,
                        period_end: $scope.new_org.period_end
                    };

//            if (!$scope.new_org.to_this_day && $scope.new_org.period_end) {
//                data.period_end = $scope.new_org.period_end;
//            }

                jsonRPC.request('users.edit_organization', data).then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Edit organization error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Success",
                                text: "Organization edited successfully"
                            });
                            $scope.newOrganizationVisible = false;
                            reloadOrganizations();
                            deferred.resolve();
                        }
                    },
                    function () {
                        // general RPC error
                        deferred.reject();
                    }
                );
            };

            $scope.addOrganization = function () {

                var deferred = $q.defer(),
                    data = {
                        name: $scope.new_org.organization.name,
                        org_type: $scope.org_type,
                        period_begin: $scope.new_org.period_begin,
                        period_end: $scope.new_org.period_end
                    };

//            if (!$scope.new_org.to_this_day && $scope.new_org.period_end) {
//                data.period_end = $scope.new_org.period_end;
//            }

                jsonRPC.request('users.add_organization', data).then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Create organization error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Success",
                                text: "Organization created successfully"
                            });
                            $scope.newOrganizationVisible = false;
                            reloadOrganizations();
                            deferred.resolve();
                        }
                    },
                    function () {
                        // general RPC error
                        deferred.reject();
                    }
                );
            };

            $scope.removeOrganization = function (pk) {
                var deferred = $q.defer(),
                    data = {
                        'pk': pk
                    };

                jsonRPC.request('users.remove_organization', data).then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Remove organization error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Success",
                                text: "Organization removed successfully"
                            });
                            reloadOrganizations();
                            deferred.resolve();
                        }
                    },
                    function () {
                        // general RPC error
                        deferred.reject();
                    }
                );
            };

            $scope.openNewOrganization = function () {
                $scope.new_org = {
                    org: null,
                    period_begin: '',
                    period_end: '',
                    to_this_day: false
                };
                $scope.is_adding = true;
                $scope.newOrganizationVisible = true;
            };

            $scope.close = function () {
                $scope.newOrganizationVisible = false;
            };

            $scope.openEditOrganization = function (organization) {
                $scope.new_org = angular.copy(organization);
//            $scope.new_org = {
//                id: organization.id,
//                org: organization.organization,
//                period_begin: ,
//                period_end: organization.period_end
//            };

                $scope.new_org.to_this_day = !organization.period_end;
                $scope.is_adding = false;
                $scope.newOrganizationVisible = true;
            };

            function getOrgSelector() {
                return {
                    choices: [],
                    query: function(searchTerm) {
                        var selector = this;
                        getAllOrganizations(searchTerm).then(
                            function (response) {
                                selector.choices = response.result;
                            }
                        ); 
                    }
                };
            }

            function getAllOrganizations(search_term) {
                var data = {
                    search_term: search_term,
                    org_type: $scope.org_type
                };

                return jsonRPC.request('users.get_all_organizations', data);
            }

            function reloadOrganizations() {
                var deferred = $q.defer();

                $rootScope.loading = true;

                jsonRPC.request('users.get_user_organizations', {org_type: $scope.org_type}).then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Loading organizations error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }
                        else {
                            $scope.organizations = data.result;
                            deferred.resolve();
                        }
                        $rootScope.loading = false;
                    },
                    function () {
                        // general RPC error
                        deferred.reject();
                        $rootScope.loading = false;
                    }
                );
            }

            reloadOrganizations();

        }]);


})();
