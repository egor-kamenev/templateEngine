(function(){
angular.module('settings.controllers.socialsettingsctrl', []).controller('SocialSettingsCtrl', [
    '$scope', '$q', '$stateParams', '$window', 'jsonRPC',
    function ($scope, $q, $stateParams, $window, jsonRPC) {

        $scope.socialPermissions = [];
        $scope.connected_accounts = [];
        $scope.not_connected_accounts = [];

        $scope.saveSettings = function () {
            var data = {
                permissions: $scope.socialPermissions
            };

            jsonRPC.request('users.set_social_permissions', data).then(
                function () {
                    $scope.$emit("flash", {
                        type: "success",
                        title: "Permission set",
                        text: "Settings saved"
                    });
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Server error",
                        text: "Sorry, error occurred while submitting. Please try again later."
                    });
                }
            );

        };

        $scope.reloadSettings = function () {
            jsonRPC.request('users.get_social_permissions').then(
                function (data) {
                    $scope.socialPermissions = data.result.settings;
                    $scope.connected_accounts = data.result.associated;
                    $scope.not_connected_accounts = data.result.not_associated;
                }
            );
        };

//        $scope.reloadSocialAccounts = function(){
//            userService.getAssociatedSocialAccounts().then(
//                function (data) {
//                    $scope.connected_accounts = data;
//                }
//            );

//            userService.getNotAssociatedSocialAccounts().then(
//                function (data) {
//                    $scope.not_connected_accounts = data;
//                }
//            );
//        };

        $scope.socialAuthPopup = function (backend) {

            var url = RESTANGULAR_BASE_URL + backend.associate_url;
            var wnd = $window.open(
                url,
                "Connecting via " + backend.name,
                "width=500, heigth=350, location=0, toolbar=0"
            );
            var timer = setInterval(function () {
                if (wnd.closed) {
                    $scope.reloadSettings();
//                    $scope.reloadSocialAccounts();
                    clearInterval(timer);
                }
            }, 50);
        };

//        $scope.reloadSocialAccounts();
        $scope.reloadSettings();

    }]);

})();