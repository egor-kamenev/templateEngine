(function(){
'use strict';

angular.module('settings.controllers.localesettingsctrl', [])
    .controller('LocaleSettingsCtrl', ['$rootScope', '$scope', '$q', '$stateParams', 'jsonRPC', 'permissionRequired', function ($rootScope, $scope, $q, $stateParams, jsonRPC, permissionRequired) {

        $scope.settings = {};

        $scope.saveSettings = permissionRequired('users.change_user', function () {

            var deferred = $q.defer(),
                data = angular.copy($scope.settings);

            $rootScope.loading = true;

            jsonRPC.request('users.save_locale_settings', data).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isFormError(data.error)) {
                            deferred.reject(data.error.data);
                        }
                        else if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Save settings error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }

                    }
                    else {
                        $scope.$emit("flash", {
                            type: "success",
                            title: "Success",
                            text: "Profile saved successfully"
                        });

                        if ($scope.settings && typeof $scope.settings.preffered_language === 'string') {
                            $rootScope.$emit('changedLanguage', $scope.settings.preffered_language);
                        }

                        reloadSettings();

                        deferred.resolve();
                    }
                    $rootScope.loading = false;
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Save settings error",
                        text: "Save settings error"
                    });
                    deferred.reject();
                    $rootScope.loading = false;
                }
            );
            return deferred.promise;
        });

        function reloadSettings() {
            $scope.settings = {};

            $rootScope.loading = true;

            jsonRPC.request('users.get_locale_settings').then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Get settings error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        //fix for situation when selected language don't displayed
                        data.result.languages.splice(0, 0, {text: "-- выберите язык --"});

                        angular.extend($scope, data.result);
                    }
                    $rootScope.loading = false;
                },
                function () {
                    // general RPC error
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Server error",
                        text: "Sorry, error occurred while submitting. Please try again later."
                    });
                    $rootScope.loading = false;
                }
            );
        }

        reloadSettings();
    }]);

})();
