(function () {
    'use strict';

    angular.module('settings.controllers.profilectrl', [])
        .constant('profileOptions', {
            GenderTypes: [
                {id: 'M', text: 'Male'},
                {id: 'F', text: 'Female'}
            ],
            MaritalTypes: [
                {id: 'M', text: 'Married'},
                {id: 'S', text: 'Single'},
                {id: 'C', text: 'Cohabitation'}
            ],
            SexPreferenceTypes: [
                {id: 'M', text: 'Males'},
                {id: 'F', text: 'Females'},
                {id: 'MF', text: 'Both'}
            ],
            TargetTypes: [
                {id: 'I', text: 'Interests'},
                {id: 'R', text: 'Relationships'},
                {id: 'S', text: 'Sex'},
                {id: 'F', text: 'Flirtation'}
            ]
        })
        .controller('ProfileCtrl', [
            '$scope', '$q', 'jsonRPC', 'tagTypes', 'contactsService', 'userService', 'profileOptions', '$stateParams', '$rootScope', 'permissionRequired',
            function ($scope, $q, jsonRPC, tagTypes, contactsService, userService, profileOptions, $stateParams, $rootScope, permissionRequired) {

                $scope.profile = userService.user;

                $scope.options = angular.copy(profileOptions);
                console.log($scope.options);

                console.log($rootScope.show_confirm_message);
                /* show notify if user was signup  */
                if ($rootScope.show_confirm_message) {
                    $scope.$emit('flash', {
                        type: 'success',
                        title: 'Регистрация завершена',
                        text: 'Вам отправлено письмо с кодом подтвеждения.'
                    });

                    /* some logic from origin SignupCompleteCtrl */
                    if ($rootScope.reg_complete) {
                        delete $rootScope.reg_complete;
                    } // else @state.go('404');
                }
                $scope.saveProfile = permissionRequired('users.change_user', function () {

                    var deferred = $q.defer();
                    var data = angular.copy($scope.profile);
                    data.email = ($scope.profile.email) ? $scope.profile.email : "";

                    if ($scope.profile.phone.value) {
                        data.phone = $scope.profile.phone.value[0] === '+' ? $scope.profile.phone.value : '+' + $scope.profile.phone.value;
                    } else {
                        data.phone = '';
                    }

                    if (typeof data.date_of_birth === 'number') {
                        data.date_of_birth = moment.unix(Math.floor(data.date_of_birth / 1000)).format("YYYY-M-D");
                    }

                    $rootScope.loading = true;

                    jsonRPC.request('users.save_profile', data).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isFormError(data.error)) {
                                    deferred.reject(data.error.data);
                                }
                                else if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Save profile error",
                                        text: data.error.data.msg
                                    });
                                    deferred.reject();
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Profile saved successfully"
                                });
                                reloadProfile();
                                userService.getUser(true);

                                deferred.resolve();
                            }
                            $rootScope.loading = false;
                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Change profile error",
                                text: "Change profile error"
                            });
                            deferred.reject();
                            $rootScope.loading = false;
                        }
                    );
                    return deferred.promise;
                });


                function reloadProfile() {

                    $rootScope.loading = true;

                    userService.getProfileByUsername(
                        $stateParams.username,
                        function (data) {
                            $scope.profile = data;
                            if ($scope.profile.phone && $scope.profile.phone.value) {
                                $scope.profile.phone.old_value = $scope.profile.phone.value;
                            }
                            $rootScope.loading = false;
                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                            $rootScope.loading = false;
                        });
                }

                $scope.resendVerification = function (contact) {

                    if (angular.isObject(contact)) {
                        $scope.verifyContact = contact;
                    }

                    contactsService.resendVerification($scope.verifyContact.id).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Error",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Done",
                                    text: "Contact verification sent"
                                });
                            }
                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });

                        }
                    );

                };

                $scope.checkVerification = function () {
                    console.log("checkVerification", $scope.verifyContact);
                    contactsService.checkVerification($scope.verifyContact.id, $scope.verifyContact.verification_code).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Error",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Готово",
                                    text: "Контакт верифицирован"
                                });
                            }

                            // Reload premissions
                            userService.getUser(true);//checkLogin();
                            //userService.checkLogin();

                            $scope.verifyContactVisible = false;
                            reloadProfile();

                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });

                        }
                    );
                };

                $scope.showVerifyForm = function (contact) {
                    if (!contact.old_value || contact.value != contact.old_value) {
                        if (contact.contact_type === 1) {
                            contact.value = contact.value[0] === '+' ? contact.value : '+' + contact.value;
                        }
                        var data = {
                            contact_type: contact.contact_type,
                            contact_value: contact.value
                        };

                        jsonRPC.request('users.add_contact', data).then(
                            function (data) {
                                if (data.error) {
                                    if ($scope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: " Verification error",
                                            text: data.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    contact.old_value = null;
                                    contact.verified = 1;
                                    $scope.verifyContact = angular.copy(contact);
                                    $scope.verifyContactVisible = true;
                                }
                            },
                            function () {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Verification error",
                                    text: "Verification error"
                                });
                            }
                        );
                    }
                    else {
                        $scope.verifyContact = angular.copy(contact);
                        $scope.verifyContactVisible = true;
                    }
                };

                reloadProfile();

                // T1045
                var emailIsOk = function () {
                    return $scope.profile.email && ($scope.profile.email.verified == 3 && !($scope.profile.email.old_value && $scope.profile.email.old_value != $scope.profile.email.value));
                };
                $scope.emailIsOK = emailIsOk();
                $scope.$onRootScope('userProfileChanged', function (e, user) {
                    $scope.$apply(function() {
                        // if email became to be verified
                        if ($scope.profile.email && user.email) {
                            if ($scope.profile.email.verified !== 3 && user.email.verified == 3) {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Email verification success",
                                    text: "Спасибо за подтверждение email"
                                });
                            }
                        }
                        $scope.profile = user;
                        $scope.emailIsOK = emailIsOk();
                    });
                });

            }]);

})();
