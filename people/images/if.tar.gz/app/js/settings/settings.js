(function(){
'use strict';

angular.module('app.settings', [
    'settings.controllers.socialsettingsctrl',
    'settings.controllers.visiblesettingsctrl',
    'settings.controllers.localesettingsctrl',
    'settings.controllers.passwordsettingsctrl',
    'settings.controllers.profilectrl',
    'settings.controllers.userreferralsctrl',
    'settings.controllers.organizationctrl',
    'settings.controllers.genericsettingsctrl',
    'settings.services'
]).constant('SettingType', {
    SETTING_TYPE_REMINDERS: 4,
    SETTING_TYPE_NOTIFICATIONS: 5,
    SETTING_TYPE_EVENTS_PARTICIPATION: 0
}).config([
    "$stateProvider",
    function ($stateProvider) {
        $stateProvider
            .state('userSettings', {
                url: '/settings',
                abstract: true,
                parent: "userPrivate",
                //parent: 'user',
                //onEnter: ['$state', '$stateParams', '$rootScope', function ($state, $stateParams, $rootScope) {
                //    // Copy of app.js 'enterPrivate'
                //    if (!$rootScope.user.authenticated || $rootScope.user.username != $stateParams.username) {
                //        $state.go('403');
                //    }
                //}],
                title: 'PAGE_TITLE_USER_SETTINGS',
                data: {
                    breadcrumbParentState: 'user',
                    breadcrumbSiblings: [
                        'userSettings.profile',
                        'userSettings.placeStudy',
                        'userSettings.placeWork',
                        'userSettings.social',
                        'userSettings.visible',
                        'genericSettings.remind',
                        'userSettings.locale',
                        'userSettings.password',
                        'genericSettings.notice',
                        'userSettings.display',
                        'genericSettings.eventsParticipation'
                    ]
                }
            })
            .state('genericSettings', {
                parent: 'userSettings',
                abstract: true,
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/generic_settings.html',
                        controller: 'GenericSettingsCtrl'
                    }
                }
            })
            .state('userSettings.profile', {
                url: '/profile',
                title: 'PAGE_TITLE_USER_ACCOUNT_PROFILE',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/profile.html',
                        controller: 'ProfileCtrl'
                    }
                }
            })
            .state('userSettings.referrals', {
                url: '/referrals',
                title: 'PAGE_TITLE_USER_REFERRALS',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/referrals.html',
                        controller: 'UserReferralsCtrl'
                    }
                }
            })
            .state('userSettings.placeStudy', {
                url: '/placeStudy',
                title: 'PAGE_TITLE_USER_ACCOUNT_PLACESTUDY',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/organization.html',
                        controller: 'OrganizationCtrl'
                    }
                }
            })
            .state('userSettings.placeWork', {
                url: '/placeWork',
                title: 'PAGE_TITLE_USER_ACCOUNT_PLACEWORK',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/organization.html',
                        controller: 'OrganizationCtrl'
                    }
                }
            })
            .state('userSettings.social', {
                url: '/social',
                title: 'PAGE_TITLE_USER_SOCIAL_ACCOUNTS',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/social_settings.html',
                        controller: 'SocialSettingsCtrl'
                    }
                }
            })
            .state('userSettings.visible', {
                url: '/visible',
                title: 'PAGE_TITLE_USER_PRIVACY_SETTINGS',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/visible_settings.html',
                        controller: 'VisibleSettingsCtrl'
                    }
                }
            })
            .state('userSettings.remind', {
                url: '/remind',
                title: 'PAGE_TITLE_USER_REMINDER_SETTINGS',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/remind_settings.html',
                        controller: 'RemindSettingsCtrl'
                    }
                }
            })
            .state('userSettings.locale', {
                url: '/locale',
                title: 'PAGE_TITLE_USER_LOCALIZATION_SETTINGS',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/locale_settings.html',
                        controller: 'LocaleSettingsCtrl'
                    }
                }
            })
            .state('userSettings.password', {
                url: '/password',
                title: 'PAGE_TITLE_USER_PASSWORD_SETTINGS',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/settings/partials/password_settings.html',
                        controller: 'PasswordSettingsCtrl'
                    }
                }
            })
            .state('genericSettings.remind', {
                url: '/remind',
                title: 'PAGE_TITLE_USER_REMINDER_SETTINGS',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadSettings');
                    }, 0);
                }],
                data:{
                    setting_type: 4 //SETTING_TYPE_REMINDERS
                }
            })
            .state('genericSettings.notice', {
                url: '/notice',
                title: 'PAGE_TITLE_USER_NOTIFICATION_SETTINGS',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadSettings');
                    }, 0);
                }],
                data:{
                    setting_type: 5 //SETTING_TYPE_NOTIFICATIONS
                }
            })
            .state('genericSettings.eventsParticipation', {
                url: '/events_participation',
                title: 'PAGE_TITLE_EVENTS_PARTICIPATION_SETTINGS',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadSettings');
                    }, 0);
                }],
                data:{
                    setting_type: 0 //SETTING_TYPE_EVENTS_PARTICIPATION
                }
                
            });
    }]);
})();
