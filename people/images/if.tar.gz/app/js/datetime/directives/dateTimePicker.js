(function () {
    'use strict';
    angular.module('app.directives.dateTimePicker', ['app']).directive('dateTimePicker', [
        '$filter', '$timeout',
        function ($filter, $timeout) {

            function link(scope, element, attrs, ngModel) {

                function setMinMax(v){
                    if (scope.minPickerID) {
                        $timeout(function () {
                            angular.element("#" + scope.minPickerID + "_date")
                                .datepicker('option', 'maxDate', v);
                        });
                    }
                    if (scope.maxPickerID) {
                        $timeout(function () {
                            angular.element("#" + scope.maxPickerID + "_date")
                                .datepicker('option', 'minDate', v);
                        });
                    }

                }

                // ui-date ID must be unique
                scope.id = attrs.id || attrs.ngModel;
                scope.placeholder = attrs.placeholder || '';
                scope.name = attrs.name || 'dttm_picker_date';
                scope.showReset = attrs.showReset != 'false';
                scope.minPickerID = attrs.minPicker || null;
                scope.maxPickerID = attrs.maxPicker || null;
                scope.field = ngModel;

                attrs.$observe('required', function (value) {
                    scope.required = angular.isDefined(value);
                });

                var year = attrs.year ? attrs.year : moment().year();

                if (attrs.onlyDate) {
                    scope.onlyDate = true;
                }

                scope.dateOptions = {
                    minDate: attrs.blockPast === 'true' ? moment().toDate() : null,
                    changeYear: true,
                    changeMonth: true,
                    yearRange: year + ':+1',
                    dateFormat: 'dd.mm.yy',
                    prevText: '<i class="fa fa-chevron-left"></i>',
                    nextText: '<i class="fa fa-chevron-right"></i>',
                    onSelect: function (selectedDate) {
                        setMinMax(selectedDate);
                    }
                };

                var h = 0,
                    m = 0,
                    pad = function (n) {
                        return (n < 10 ? "0" + n : n);
                    };

                scope.hours = [];
                scope.minutes = [];
                while (h < 24) scope.hours.push({id: h, name: "" + pad(h++)});
                while (m < 60) scope.minutes.push({id: m, name: "" + pad(m++)});

                // Called on ngModel change
                ngModel.$render = function () {

                    // ngModel defined:
                    // split it to date, hours and minutes
                    if (ngModel.$viewValue) {
                        var mmnt = moment(ngModel.$viewValue);
                        scope.dttmPickerDate = mmnt.toDate();
                        scope.dttmPickerHour = mmnt.hour();
                        scope.dttmPickerMinute = mmnt.minute();

                        setMinMax(mmnt.toDate());

                    }
                    // ngModel undefined - set minutes and hours to default values
                    else {
                        scope.dttmPickerDate = scope.dttmPickerHour = scope.dttmPickerMinute = null;
                        //scope.dttmPickerHour = 0;
                        //scope.dttmPickerMinute = 0;

                    }
                };

                // Update date and time on model change
                scope.$watch(attrs.ngModel, function (e,b) {
                    ngModel.$render();

                }, true);

                // If one of the date components chages
                // we have to check that date selection is completed (all three components - date, minutes and hours are set)
                // and update ngModel value
                scope.$watchCollection('[dttmPickerDate, dttmPickerHour, dttmPickerMinute]', function (v, oldVal) {
                    var d = v[0],
                        h = v[1],
                        m = v[2],
                        dateSet = angular.isDefined(d) && d !== null,
                        hoursSet = angular.isDefined(h) && h !== null,
                        minutesSet = angular.isDefined(m) && m !== null,
                        isDateSelectionComplete = scope.onlyDate ? dateSet : dateSet && hoursSet && minutesSet,
                        atleastSomethingSet = dateSet || hoursSet || minutesSet,
                        nothingSet = !dateSet && !hoursSet && !minutesSet,
                        valueChanged = !angular.equals(v, oldVal);

                    if (!valueChanged) return;
                    if (isDateSelectionComplete) {
                        if (scope.onlyDate) {
                            ngModel.$setViewValue($filter('date')(d, "yyyy-MM-dd"));
                        }
                        else {
                            var mt = moment(d);
                            mt.set('hour', h);
                            mt.set('minute', m);
                            ngModel.$setViewValue(mt.toDate());
                        }
                        // $setPristine is not enough
                        ngModel.$setValidity('date_required', dateSet);
                        ngModel.$setValidity('hours_required', true);
                        ngModel.$setValidity('minutes_required', true);

                        ngModel.$setPristine();
                    }
                    else {
                        if (scope.required || atleastSomethingSet) {
                            ngModel.$setValidity('date_required', dateSet);
                            ngModel.$setValidity('hours_required', hoursSet || !!scope.onlyDate);
                            ngModel.$setValidity('minutes_required', minutesSet || !!scope.onlyDate);
                        }

                        if (nothingSet) {
                            ngModel.$setValidity('date_required', true);
                            ngModel.$setValidity('hours_required', true);
                            ngModel.$setValidity('minutes_required', true);
                        }
                        ngModel.$setViewValue(null);

                        if (scope.minPickerID) {
                            angular.element("#" + scope.minPickerID + "_date").datepicker('option', 'maxDate', null);
                        }
                        if (scope.maxPickerID) {
                            angular.element("#" + scope.maxPickerID + "_date").datepicker('option', 'minDate', null);
                        }
                    }
                });

            }

            function Controller($scope) {
                $scope.resetDate = function () {
                    $scope.dttmPickerDate = $scope.dttmPickerHour = $scope.dttmPickerMinute = null;
                };

            }

            Controller.$inject = ['$scope', '$element'];

            return ({
                controller: Controller,
                link: link,
                restrict: "EA",
                require: 'ngModel',
                replace: true,
                scope: {},
                templateUrl: '/static/partials/datetimepicker/datetimepicker.html'
            });

        }]);

})();
