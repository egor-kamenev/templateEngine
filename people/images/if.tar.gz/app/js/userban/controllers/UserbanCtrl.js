(function () {
    'use strict';

    angular.module('app.controllers.userbanctrl', []).controller('UserbanCtrl', [
        '$scope', '$q', 'userbanService', 'bansFrom', 'jqPaginationSettings', '$stateParams', '$rootScope',
        function ($scope, $q, userbanService, bansFrom, jqPaginationSettings, $stateParams, $rootScope) {

            $scope.userBansFrom = bansFrom === true;
            $scope.userBans = null;
            $scope.banFilter = 'ban';
            $scope.expire_days = null;

            $scope.loaded = false;
            $scope.limit = jqPaginationSettings.limit;
            $scope.total = 0;
            $scope.maxPage = 0;

            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            userbanService.getExpireDays().then(
                function (data) {
                    $scope.expire_days = data;
                }
            );


            $scope.removeBan = function (pk) {
                $rootScope.loading = true;
                userbanService.setActive(pk, false).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Done",
                                text: ""
                            });

                            $scope.$emit('userban__updated');
                            $scope.reloadBans();
                        }
                        $rootScope.loading = false;
                    },
                    function () {
                        $rootScope.loading = false;
                    }
                );
            };

            $scope.setActive = function (item, active) {
                userbanService.setActive(item.id, active).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Готово",
                                text: ""
                            });
                            item.active = active;
                        }
                    }
                );
            };

            $scope.startChangeBan = function (ban) {

                angular.forEach($scope.userBansFrom, function (ub) {
                    ub.is_change_ban = false;
                });
                ban.new_ban_expire = ban.expire_days;
                ban.is_change_ban = true;
            };

            $scope.cancelChangeBan = function (ban) {
                ban.is_change_ban = false;
                delete ban.new_ban_expire;
            };

            $scope.changeBan = function (ban) {
                userbanService.changeBan(ban.id, ban.new_ban_expire).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Done",
                                text: ""
                            });
                            $scope.reloadBans();
                        }
                    }
                );
            };

            $scope.openNewBan = function () {
                $scope.newBanVisible = true;
            };

            $scope.reloadBans = function () {

                var itemsSource = $scope.userBansFrom ?
                    userbanService.getBansFrom : userbanService.getBansTo;

                itemsSource($scope.currentPage).then(function (data) {

                    $scope.userBans = [];

                    if (!data.items.length) {
                        $scope.loaded = true;
                        return;
                    }

                    $scope.total = data.total;
                    $scope.loaded = true;

                    if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);

                    $scope.userBans = data.items;

                });
            };

            $scope.reloadBans();
        }]);


})();
