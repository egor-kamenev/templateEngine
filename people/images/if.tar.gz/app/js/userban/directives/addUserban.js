(function () {
    'use strict';
    angular.module('userban.addUserban.directive', ['app']).directive('addUserban', [
        '$q', '$http', '$rootScope', '$state', 'userbanService', 'userService', 'banTypes', 'banExpireDays', '$compile', '$templateCache',
        function ($q, $http, $rootScope, $state, userbanService, userService, banTypes, banExpireDays, $compile, $templateCache) {

            var scope = {
                entity: '=',
                bannedUsername: '=',
                user: '=',
                callback: '&'
            };

            function link(scope, element) {

                function preventClosingDialog() {
                    var megamenuParent = angular.element(element).parents('.megamenu__item--with-submenu');
                    if (scope.modal_form && scope.modal_form.hasClass('active')) {
                        megamenuParent.addClass('active');
                    }
                    else if (megamenuParent.hasClass('active')) {
                        megamenuParent.removeClass('active');
                        megamenuParent.click();
                    }
                }

                element.bind('click', function () {
                    scope.openNewBan();
                });


                angular.element(document).bind('click', preventClosingDialog);

                scope.$on('$destroy', function () {
                    angular.element(document).unbind('click', preventClosingDialog);
                });

                $http.get('/static/partials/userban/add-userban.html', {cache: $templateCache}).success(function (template) {
                    scope.modal_form = angular.element($compile(template)(scope));
                    element.after(scope.modal_form);
                });
            }

            function Controller($scope) {

                $scope.banTypes = banTypes;
                $scope.expireDays = banExpireDays;

                userService.getUser().then(function (user) {

                    var banDirectivePointsOnMe = user.username == $scope.bannedUsername;

                    // This should not happen - user ban directive should not ban viewer.
                    if (banDirectivePointsOnMe) {
                        console.log("Warning: user ban directive with entity:", $scope.entity, " targets viewer");
                    }
                });

                $scope.initialBan = {
                    banned_value: '',
                    banned_type: banTypes.NAME,
                    comment: '',
                    expire_days: 0,
                    type_object: 0
                };

                $scope.newBan = angular.copy($scope.initialBan);

                $scope.banUser = function () {
                    var data = {
                        comment: $scope.newBan.comment,
                        expire_days: $scope.newBan.expire_days,
                        remove_messages: $scope.newBan.remove_user_messages
                    },
                        deferred = $q.defer();

                    if (!$scope.newBan.type_object) {
                        data.object_type_id = $scope.entity.content_type_id;
                        data.object_id = $scope.entity.id;
                    }
                    else if ($scope.newBan.type_object == 1) {
                        data.object_type_id = $scope.entity.parent.content_type_id;
                        data.object_id = $scope.entity.parent.id;
                    }
                    else if ($scope.newBan.type_object == 2) {
                        data.object_type_id = $scope.user.content_type_id;
                        data.object_id = $scope.user.id;
                    }

                    if ($scope.bannedUsername) {
                        data.banned_value = $scope.bannedUsername;
                        data.banned_type = banTypes.NAME;
                    }
                    else {
                        data.banned_value = $scope.newBan.banned_value;
                        data.banned_type = $scope.newBan.banned_type;
                    }

                    userbanService.banUser(data).then(
                        function (response) {
                            if (response.error) {
                                if ($rootScope.isLogicError(response.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Error",
                                        text: response.error.data.msg
                                    });
                                }
                                else if ($rootScope.isPermissionDenied(response.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Error",
                                        text: response.error.data.msg
                                    });
                                }
                                deferred.reject();
                            }
                            else {

                                $rootScope.$emit('event:userBanned');

                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Готово",
                                    text: ""
                                });
                                $scope.closeNewBan();
                                if ($scope.callback) {
                                    $scope.callback({data: data});
                                }
                                deferred.resolve();

                            }
                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Add ban error",
                                text: "Add ban error"
                            });
                            deferred.reject();
                        }
                    );
                    return deferred.promise;
                };

                $scope.openNewBan = function () {
                    $scope.modal_form.addClass('active');
                };

                $scope.closeNewBan = function () {
                    $scope.modal_form.removeClass('active');
                    $scope.newBan = angular.copy($scope.initialBan);
                };
            }

            Controller.$inject = ['$scope', '$element'];

            return ({
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                scope: scope
//        templateUrl: '/static/partials/userban/add-userban.html'
            });

        }
    ]);

})();
