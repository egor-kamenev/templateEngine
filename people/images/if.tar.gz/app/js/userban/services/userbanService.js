(function(){
angular.module('userban.services', [])
.constant('banTypes', {
    EMAIL: 0,
    PHONE: 1,
    NAME: 9
})
.constant('banExpireDays', [1, 3, 7, 21] )
.service('userbanService',['$state', 'jsonRPC', 'jqPaginationSettings', function($state, jsonRPC, jqPaginationSettings){

    var self = this;

    this.getBansFrom = function(page){
        var data = {
            page: page,
            page_size: jqPaginationSettings.limit,
            with_total: true
        };

        return jsonRPC.request('userban.get_bans_from', data).then(
            function (data) {
                angular.forEach(data.result.items, function(ban, i) {
                    ban.url = self.getObjectUrl(ban);
                });
                return data.result;
            },
            function (){
                return [];
            }
        );
    };

    this.ignoreUser = function (username) {
        return jsonRPC.request('users.ignore', {username: username});
    };
    
    this.getBansTo = function(page){
        var data = {
            page: page,
            page_size: jqPaginationSettings.limit,
            with_total: true
        };

        return jsonRPC.request('userban.get_bans_to', data).then(
            function (data) {
                angular.forEach(data.result.items, function(ban) {
                    ban.url = self.getObjectUrl(ban);
                });
                return data.result;
            },
            function (){
                return [];
            }
        );
    };

    this.setActive = function(pk, active){
        var data = {
            pk: pk,
            active: active
        };
        return jsonRPC.request('userban.change_active', data);
    };

    this.removeBan = function(pk){
        var data = {
            pk: pk
        };
        return jsonRPC.request('userban.remove_ban', data);
    };

    this.banUser = function(newBan) {
        return jsonRPC.request('userban.ban_user', newBan);
    };
    
    this.removeUserMessages = function(username, thread_pk) {
        var data = {
            username: username,
            thread_pk: thread_pk
        };
        return jsonRPC.request('userban.remove_user_messages', data);
    };

    this.isBanned = function(object_type_id, object_id) {
        var data = {
            object_type_id: object_type_id,
            object_id: object_id
        };
        return jsonRPC.request('userban.is_banned', data);
    };

    this.isBannerUser = function(user_pk, username) {
        var data = {
            user_pk: user_pk,
            username: username
        };
        return jsonRPC.request('userban.is_banner_user', data);
    };

    this.getExpireDays = function() {
        return jsonRPC.request('userban.get_expire_days').then(
            function (data) {
                return data.result;
            },
            function (){
                return [];
            }
        );
    };

    this.getBanTypes = function(){
        return jsonRPC.request('userban.get_ban_types').then(
            // Success
            function (data) {
                return data.result;
            },
            // Error 
            function (){
                return [];
            }
        );
    };

    this.changeBan = function(pk, expire_days) {
        var data = {
            pk: pk,
            expire_days: expire_days
        };
        return jsonRPC.request('userban.change_ban', data);
    };

    this.getObjectBannedUsers = function(objectType, objectID, page) {
        var data = {
            object_type_id: objectType,
            object_id: objectID,
            page: page,
            page_size: jqPaginationSettings.limit,
            with_total: true
        };
        return jsonRPC.request('userban.get_object_banned_users', data);

    };

    this.getObjectUrl = function (ban) {
        if (ban.class_name == 'Event'){
            return $state.href('event', {event_alias: ban.object_name});
        }
        if (ban.class_name == 'UserPlace'){
            return $state.href('place', {place_alias: ban.object_name});
        }
        if (ban.class_name == 'Photo'){
            return $state.href('photo', {photo_id: ban.object_id});
        }
        return;
    };

}]);

})();