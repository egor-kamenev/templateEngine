(function () {
    'use strict';

    angular.module('bookmarks.controllers.bookmarksctrl', []).constant('bookmarkType', {
        EVENT: 0,
        PLACE: 1,
        USER: 2
    }).controller('BookmarksCtrl', [
        '$scope', '$state', 'bookmarksService', 'bookmarkType', '$stateParams', 'jqPaginationSettings', '$rootScope',
        function ($scope, $state, bookmarksService, bookmarkType, $stateParams, jqPaginationSettings, $rootScope) {

            $scope.limit = jqPaginationSettings.limit;
            $scope.total = 0;
            $scope.maxPage = 0;
            $scope.loaded = false;
            $scope.userBookmarks = [];

            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            if ($state.current.url == '/events') {
                $scope.type_bookmark = bookmarkType.EVENT;
                $scope.template = '/static/partials/content/events.html';
            }
            else if ($state.current.url == '/places') {
                $scope.type_bookmark = bookmarkType.PLACE;
                $scope.template = '/static/partials/content/places.html';
            }
            else if ($state.current.url == '/users') {
                $scope.type_bookmark = bookmarkType.USER;
                $scope.template = '/static/partials/content/users.html';
            }

            function delBookmark(book) {
                if (_.contains(_.pluck($scope.userBookmarks, 'id'), book.id)) {
                    $scope.userBookmarks = _.reject($scope.userBookmarks, function (e) {
                        return e.id === book.id;
                    });
                    $scope.$apply();
                }
            }

            $scope.loadBookmarks = function () {
                $rootScope.loading = true;
                bookmarksService.getBookmarks($scope.type_bookmark, $scope.currentPage).then(
                    function (data) {
                        $scope.userBookmarks = [];

                        if (!data.result.items.length) {
                            $scope.loaded = true;
                            $rootScope.loading = false;
                            return;
                        }
                        angular.forEach(data.result.items, function (bookmark) {
                            $scope.userBookmarks.push(bookmark.object);
                        });

                        $scope.total = data.result.total;
                        $scope.loaded = true;

                        if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);
                        $rootScope.loading = false;

                    },
                    function (error) {
                        console.error('Error fetch data', error);
                        $rootScope.loading = false;
                    }
                );
            };

            $scope.$onRootScope('event:bookmark.removed', function (e, bookmarkedObject) {
                var removedBookmark = _.find($scope.userBookmarks, function (b) {
                    return angular.equals(b, bookmarkedObject);
                });
                if (angular.isDefined(removedBookmark)) {
                    delBookmark(removedBookmark);
                }

            });

            $scope.loadBookmarks();
        }]);

})();