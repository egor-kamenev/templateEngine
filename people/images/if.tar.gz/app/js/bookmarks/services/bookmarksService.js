(function(){
angular.module('bookmarks.services', [])
    .factory('bookmarksService', ['$rootScope', 'jsonRPC', 'contentType', 'jqPaginationSettings',
     function ($rootScope, jsonRPC, contentType, jqPaginationSettings) {
        function onError(msg) {
            $rootScope.$emit("flash", {
                type: "error",
                title: "Remove bookmark error",
                text: msg
            });
        }

        return {
            getBookmarks: function (type_bookmark, page) {
                console.log("getBookmarks");
                var data = {
                    type_bookmark: type_bookmark,
                    page: page,
                    page_size: jqPaginationSettings.limit,
                    with_total: true
                };
                return jsonRPC.request('bookmarks.get_bookmarks', data);
            },
            removeBookmark: function (item) {
                return jsonRPC.request('bookmarks.remove_bookmark', contentType(item)).then(
                    function (data) {
                        if (data.error) {
                            onError(data.error.data.msg);
                        }
                        else {
                            item.bookmarked = false;
                            $rootScope.$emit('event:bookmark.removed', item);
                        }
                    }
                );
            },
            addBookmark: function (item) {
                return jsonRPC.request('bookmarks.add_bookmark', contentType(item)).then(
                    function (data) {
                        if (data.error) {
                            onError(data.error.data.msg);
                        }
                        else {
                            item.bookmarked = true;
                            $rootScope.$emit('event:bookmark.added', item);
                        }
                    }
                );
            },
            toggleBookmark: function (item) {
                return (item.bookmarked) ? this.removeBookmark(item) : this.addBookmark(item);
            }
        };
    }])
    .factory("toggleBookmark", ["bookmarksService", function (bookmarksService) {
        return function () {
            return bookmarksService.toggleBookmark(this);
        };
    }]);

})();