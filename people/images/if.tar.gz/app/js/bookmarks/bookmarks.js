(function(){
'use strict';

angular.module('bookmarks', [
    'bookmarks.controllers.bookmarksctrl'
]).config([
      "$stateProvider",
      function ($stateProvider) {

          $stateProvider
              .state('userBookmarks', {
                  url: '/bookmarks',
                  parent: "userPrivate",
                  //onEnter:
                  //// Copy of app.js 'enterPrivate'
                  //['$state', '$stateParams', '$rootScope', function ($state, $stateParams, $rootScope) {
                  //
                  //    var accessedByOwner = $rootScope.user.authenticated &&
                  //            $rootScope.user.username == $stateParams.username;
                  //
                  //    if (!accessedByOwner) {
                  //        $state.go('403');
                  //    }
                  //}],

                  template: '<div data-ui-view></div>',
                  //parent: 'user',
                  title: 'PAGE_TITLE_USER_BOOKMARKS',
                  data: {
                      breadcrumbParentState: 'user'
                  }
              })
              .state('userBookmarks.events', {
                  url: '/events',
                  templateUrl: '/static/partials/bookmarks/bookmarks_events.html',
                  controller: 'BookmarksCtrl',
                  title: 'PAGE_TITLE_USER_BOOKMARKS_EVENTS',
                  data: {
                      breadcrumbParentState: 'userBookmarks',
                      breadcrumbSiblings: [
                        'userBookmarks.events',
                        'userBookmarks.places',
                        'userBookmarks.users'
                    ]
                  }
              })
              .state('userBookmarks.places', {
                  url: '/places',
                  templateUrl: '/static/partials/bookmarks/bookmarks_places.html',
                  controller: 'BookmarksCtrl',
                  title: 'PAGE_TITLE_USER_BOOKMARKS_PLACES',
                  data: {
                      breadcrumbParentState: 'userBookmarks',
                      breadcrumbSiblings: [
                        'userBookmarks.events',
                        'userBookmarks.places',
                        'userBookmarks.users'
                    ]
                  }
              })
              .state('userBookmarks.users', {
                  url: '/users',
                  templateUrl: '/static/partials/bookmarks/bookmarks_users.html',
                  controller: 'BookmarksCtrl',
                  title: 'PAGE_TITLE_USER_BOOKMARKS_USERS',
                  data: {
                      breadcrumbParentState: 'userBookmarks',
                      breadcrumbSiblings: [
                        'userBookmarks.events',
                        'userBookmarks.places',
                        'userBookmarks.users'
                    ]
                  }
              });
      }]);

})();