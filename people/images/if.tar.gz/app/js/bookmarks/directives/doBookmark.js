(function(){
angular.module('bookmarks.doBookmark', ['app']).
    directive('doBookmark', ['$rootScope', 'bookmarksService', "$parse",
        function ($rootScope, bookmarksService, $parse) {
            var loading = false;
            return {
                restrict: "AC",
                scope: false,
                link: function (scope, element, attrs) {
                    element.on('click', function () {
                        var entity = $parse(attrs.doBookmark)(scope);
                        if (!entity) {
                            console.error("cant get item");
                            return;
                        }

                        function setLoadingState() {
                            element.addClass("loading");
                            loading = true;
                        }

                        function resetLoadingState() {
                            element.removeClass("loading");
                            loading = false;
                        }

                        if ((angular.isUndefined(entity.owner) && entity.username !== $rootScope.user.username ) || !(angular.isUndefined(entity.owner) && entity.owner.username !== $rootScope.user.username)) {
                            if (!loading) {
                                setLoadingState();
                                bookmarksService.toggleBookmark(entity).then(resetLoadingState, resetLoadingState);
                            } else {
                                $rootScope.$emit("flash", {
                                    type: "info",
                                    title: "Сохранение закладки",
                                    text: "Пожалуйста, подождите завершения предыдущей операции"
                                });
                            }
                        }
                    });
                }
            };
        }]);

})();
