(function(){
angular.module('app.controllers.translatectrl', ['app', 'pascalprecht.translate']).controller('TranslateCtrl', [
    '$scope', '$rootScope', '$translate', '$cookies',
    function ($scope, $rootScope, $translate, $cookies) {
        $scope.changeLanguage = function (langKey) {
            if ($translate.use() !== langKey) {
                $translate.use(langKey).then(function () {
                    $scope.langId = $translate.use();

                    $cookies.django_language = langKey;
                    $rootScope.language = langKey;

                    $rootScope.$emit('changedLanguage', langKey);
                });
            }
        };

        $scope.langId = $translate.use();
    }]);
})();