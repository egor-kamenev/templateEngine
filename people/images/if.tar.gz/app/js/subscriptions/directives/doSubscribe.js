(function(){
angular.module('subscriptions.doSubscribe', ['app']).
    directive('doSubscribe', ['$rootScope', '$parse', 'subscriptionsService',
        function ($rootScope, $parse, subscriptionsService) {
            var loading = false;
            return {
                restrict: "AC",
                scope: false,
                link: function (scope, element, attrs) {
                    element.on('click', function() {
                        var entity = $parse(attrs.doSubscribe)(scope);

                        if (!entity) {
                            console.error("cant get item");
                            return;
                        }

                        // not allow subscription for user himself
                        var entity_is_user = entity.username && $rootScope.user && (entity.username == $rootScope.user.username);

                        // Can't subscribe to own objects
                        var is_owner = entity.owner && entity.owner.id && (entity.owner.id == $rootScope.id);

                        if (is_owner || entity_is_user) {
                            console.error("owner can subscribe to own object");
                            return;
                        }

                        var setLoadingState = function () {
                            element.addClass("loading");
                            loading = true;
                        };
                        var resetLoadingState = function () {
                            element.removeClass("loading");
                            loading = false;
                        };

                        if ((angular.isUndefined(entity.owner) && entity.username !== $rootScope.user.username ) || !(angular.isUndefined(entity.owner) && entity.owner.username !== $rootScope.user.username)) {
                            if (!loading) {
                                setLoadingState();
                                subscriptionsService.toggleSubscription(entity).then(resetLoadingState, resetLoadingState);
                            } else {
                                $rootScope.$emit("flash", {
                                    type: "info",
                                    title: "Подписка",
                                    text: "Пожалуйста, подождите завершения предыдущей операции"
                                });
                            }
                        }
                    });
                }
            };
        }]);


//function Controller($scope, $element) {

//$scope.$on("event_subscriptionToggled", function (e, content_obj, is_subscribed) {
//
//    var signal_belongs_to_my_entity = content_obj.id &&
//        content_obj.content_type_id &&
//        (content_obj.id == $scope.entity.id) &&
//        (content_obj.content_type_id == $scope.entity.content_type_id);
//
//    if (signal_belongs_to_my_entity) {
//        $scope.entity.is_subscribed = is_subscribed;
//    }
//});

//$scope.addSubscription = function () {
//    if (!$scope.recieve_notifications && !$scope.use_in_filter) {
//        $scope.show_selection_error = true;
//        return;
//    }
//
//    $scope.show_selection_error = false;
//
//    subscriptionsService.toggleSubscription($scope.entity, false, $scope.recieve_notifications, $scope.use_in_filter).then(
//        function (data) {
//            $scope.entity.is_subscribed = data;
//            $scope.closeSubscriptionForm();
//        }
//    );
//};

//$scope.removeSubscription = function () {
//    subscriptionsService.toggleSubscription($scope.entity, true).then(
//        function (data) {
//            $scope.entity.is_subscribed = data;
//        }
//    );
//};

//$scope.openSubscriptionForm = function () {
//    $scope.modal_form.addClass('active');
//};
//
//$scope.closeSubscriptionForm = function () {
//    $scope.modal_form.removeClass('active');
//};
//
//$scope.hasPerm = function (perm) {
//    return $rootScope.hasPerm(perm);
//};
//}

//Controller['$inject'] = ['$scope', '$element'];

//            return ({
//                controller: Controller,
//                restrict: "AE",
//                replace: true,
//                scope: false,
//                link: function (scope, element, attributes, controller) {
//                    scope.can_subscribe = false;
//                    scope.recieve_notifications = true;
//                    scope.use_in_filter = true;
//                    scope.show_selection_error = false;
//
//                    scope.$watch('entity', function (val) {
//                        if (val) {
//                            scope.entity = val;
//                            var e = scope.entity;
//                            // Check that entity ojbject has all moderation properties we need for subscribing
//                            var object_is_valid = e.content_type_id && e.id;
//                            var user = $rootScope.user;
//
//                            // Entity object is authenticated user himself
//                            var entity_is_me = e.username && user && (e.username == user.username);
//
//                            // Can't subscribe to own objects
//                            var ownObject = e.owner && e.owner.id && (e.owner.id == user.id);
//
//                            if (entity_is_me || ownObject) {
//                                scope.can_subscribe = false;
//                                return;
//                            }
//
//                            if (object_is_valid && user && user.authenticated) {
//                                scope.can_subscribe = true;
//                                if (e.hasOwnProperty('is_subscribed')) {
////                            scope.is_subscribed = e.is_subscribed;
//                                }
//                                else {
//                                    subscriptionsService.isUserAlreadySubscribed(e).then(
//                                        function (data) {
//                                            scope.entity.is_subscribed = data;
//                                        },
//                                        function () {
//                                            scope.entity.is_subscribed = false;
//                                        }
//                                    );
//                                }
//                            }
//                        }
//                    });
//
//                    //element.bind('click', function () {
//                    //    if (!scope.entity.is_subscribed) {
//                    //        if ($rootScope.hasPerm('subscriptions.add_subscription')) {
//                    //            scope.openSubscriptionForm();
//                    //        }
//                    //
//                    //        scope.$emit('checkEmailConfirmation', {
//                    //            permission: 'subscriptions.add_subscription',
//                    //            warningMessage: 'У вас недостаточно прав для подписки'
//                    //        });
//                    //    }
//                    //    else {
//                    //        scope.removeSubscription();
//                    //    }
//                    //});
//                    //
//                    //$http.get('/static/partials/subscriptions/do_subscribe.html', {cache: $templateCache}).success(function (template) {
//                    //    scope.modal_form = angular.element($compile(template)(scope));
//                    //    element.after(scope.modal_form);
//                    //});
//                }
//
////        templateUrl: '/static/partials/subscriptions/do_subscribe.html'
//            });

//angular.module('subscriptions.doSubscribe', ['app']).
//    directive('doSubscribe', ['$http', '$state', '$rootScope', '$compile', '$templateCache', 'subscriptionsService',
//    function ($http, $state, $rootScope, $compile, $templateCache, subscriptionsService) {
//
//        var scope = {
//            entity: '='
//        };
//
//        function link(scope, element, attributes, controller) {
//            scope.can_subscribe = false;
////            scope.is_subscribed = false;
//            scope.recieve_notifications = true;
//            scope.use_in_filter = true;
//            scope.show_selection_error = false;
//
//            scope.$watch('entity', function (val) {
//                if (val) {
//                    scope.entity = val;
//                    var e = scope.entity;
//                    // Check that entity ojbject has all moderation properties we need for subscribing
//                    var object_is_valid = e.content_type_id && e.id;
//                    var user = $rootScope.user;
//
//                    // Entity object is authenticated user himself
//                    var entity_is_me = e.username && user && (e.username == user.username);
//
//                    // Can't subscribe to own objects
//                    var ownObject = e.owner && e.owner.id && (e.owner.id == user.id);
//
//                    /*
//                    console.log("object_is_valid:", object_is_valid, e.content_type_id, e.id);
//                    console.log("entity_is_me:", entity_is_me);
//                    console.log("ownObject:", ownObject, e.owner.id);
//                    console.log("entity:", e);
//                     */
//
//                    if (entity_is_me || ownObject) {
//                        scope.can_subscribe = false;
//                        return;
//                    }
//
//                    if (object_is_valid && user && user.authenticated) {
//                        scope.can_subscribe = true;
//                        if (e.hasOwnProperty('is_subscribed')) {
////                            scope.is_subscribed = e.is_subscribed;
//                        }
//                        else {
//                            subscriptionsService.isUserAlreadySubscribed(e).then(
//                                function (data) {
//                                    scope.entity.is_subscribed = data;
//                                },
//                                function () {
//                                    scope.entity.is_subscribed = false;
//                                }
//                            );
//                        }
//                    }
//                }
//            });
//
//            element.bind('click', function () {
//                if (!scope.entity.is_subscribed) {
//                    if ($rootScope.hasPerm('subscriptions.add_subscription')) {
//                        scope.openSubscriptionForm();
//                    }
//
//                    scope.$emit('checkEmailConfirmation', {
//                        permission: 'subscriptions.add_subscription',
//                        warningMessage: 'У вас недостаточно прав для подписки'
//                    });
//                }
//                else {
//                    scope.removeSubscription();
//                }
//            });
//
//            $http.get('/static/partials/subscriptions/do_subscribe.html', {cache: $templateCache}).success(function (template) {
//                scope.modal_form = angular.element($compile(template)(scope));
//                element.after(scope.modal_form);
//            });
//        };
//
//        function Controller($scope, $element) {
//
//            $scope.$on("event_subscriptionToggled", function (e, content_obj, is_subscribed) {
//
//                var signal_belongs_to_my_entity = content_obj.id &&
//                    content_obj.content_type_id &&
//                    (content_obj.id == $scope.entity.id) &&
//                    (content_obj.content_type_id == $scope.entity.content_type_id);
//
//                if (signal_belongs_to_my_entity) {
//                    $scope.entity.is_subscribed = is_subscribed;
//                }
//            });
//
//            $scope.addSubscription = function () {
//                if (!$scope.recieve_notifications && !$scope.use_in_filter) {
//                    $scope.show_selection_error = true;
//                    return;
//                }
//
//                $scope.show_selection_error = false;
//
//                subscriptionsService.toggleSubscription($scope.entity, false, $scope.recieve_notifications, $scope.use_in_filter).then(
//                    function (data) {
//                        $scope.entity.is_subscribed = data;
//                        $scope.closeSubscriptionForm();
//                    }
//                );
//            };
//
//            $scope.removeSubscription = function () {
//                subscriptionsService.toggleSubscription($scope.entity, true).then(
//                    function (data) {
//                        $scope.entity.is_subscribed = data;
//                    }
//                );
//            };
//
//            $scope.openSubscriptionForm = function(){
//                $scope.modal_form.addClass('active');
//            };
//
//            $scope.closeSubscriptionForm = function(){
//                $scope.modal_form.removeClass('active');
//            };
//
//            $scope.hasPerm = function(perm){
//                return $rootScope.hasPerm(perm);
//            };
//      }
//
//      Controller['$inject'] = ['$scope', '$element'];
//
//      return({
//        controller: Controller,
//        link: link,
//        restrict: "AE",
//        replace: true,
//        scope: scope
////        templateUrl: '/static/partials/subscriptions/do_subscribe.html'
//      });
//
//    }]);

})();
