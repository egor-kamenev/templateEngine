(function(){
angular.module('subscriptions.service', [])
    .factory('subscriptionsService', ['$rootScope', 'jsonRPC', 'userService', 'jqPaginationSettings', '$q', 'permissionRequired',
        function ($rootScope, jsonRPC, userService, jqPaginationSettings, $q, permissionRequired) {


            function onError(msg) {
                $rootScope.$emit("flash", {
                    type: "error",
                    title: "Error",
                    text: msg || "Request failed, try again later."
                });
            }

            function getSubscriptions(params) {
                var deferred = $q.defer();

                jsonRPC.request('subscriptions.get_subscriptions', params).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isLogicError(data.error)) {
                                onError(data.error.data.msg);
                            }
                            deferred.resolve([]);
                        }
                        else {
                            deferred.resolve(data.result);
                        }
                    },
                    function () {
                        deferred.resolve([]);
                    }
                );

                return deferred.promise;
            }

            function getSubscribers(params) {
                var deferred = $q.defer();

                jsonRPC.request('subscriptions.get_subscribers', params).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isLogicError(data.error)) {
                                onError(data.error.data.msg);
                            }
                            deferred.resolve([]);
                        }
                        else {
                            deferred.resolve(data.result);
                        }
                    },
                    function () {
                        deferred.resolve([]);
                    }
                );

                return deferred.promise;
            }

            return {
                cancelByID: permissionRequired('subscriptions.change_subscription', function (subscription_id) {
                    return jsonRPC.request('subscriptions.cancel_by_id', {
                        subscription_id: subscription_id
                    });
                }),
                getSubscriptions: getSubscriptions,
                getSubscribersByParams: getSubscribers,
                getSubscribers: function (page, content_type, content_id) {
                    return jsonRPC.request('subscriptions.get_subscribers', {
                        content_type: content_type,
                        content_id: content_id,
                        page: page,
                        page_size: jqPaginationSettings.limit,
                        with_total: true
                    });
                },
                toggleSubscription: permissionRequired('subscriptions.add_subscription', function (item) {

                    if ($rootScope.user.authenticated) {

                        var data = {
                            ct_pk: item.content_type_id,
                            pk: item.id
                        };

                        if (!item.is_subscribed && userService.hasPerm("subscriptions.add_subscription")) {
                            data.recieve_notifications = true;// recieve_notifications;
                            data.use_in_filter = true; //use_in_filter;
                        }

                        return jsonRPC.request('subscriptions.toggle_subscription', data).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isLogicError(data.error)) {
                                        onError(data.error.data.msg);
                                    }
                                }
                                else {
                                    item.is_subscribed = data.result;
                                }
                            }
                        );
                    }
                    else {
                        return $q.reject();
                    }
                })
            };
        }])
    .factory("toggleSubscription", ["subscriptionsService", function (subscriptionsService) {
        return function () {
            return subscriptionsService.toggleSubscription(this, true, true);
        };
    }]);

})();