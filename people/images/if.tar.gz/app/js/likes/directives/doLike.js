(function(){
angular.module('likes.doLike', ['app']).
    directive('doLike', ['$rootScope', 'likesService', '$parse', 'userService', function ($rootScope, likesService, $parse, userService) {
        var loading = false;
        return {
            restrict: "AC",
            scope: false,
            link: function (scope, element, attrs) {
                element.on('click', function () {

                    var entity = $parse(attrs.doLike)(scope);

                    if (!entity) {
                        console.error("cant get item");
                        return;
                    }

                    function setLoadingState() {
                        element.addClass("loading");
                        loading = true;
                    }

                    function resetLoadingState() {
                        element.removeClass("loading");
                        loading = false;
                    }

                    userService.getUser().then(function(user){
                        if(!user.authenticated){
                            $rootScope.$emit('needLogin');
                            return;
                        }
                        if (!loading) {
                            setLoadingState();
                            likesService.toggleLike(entity).then(resetLoadingState,resetLoadingState);
                        } else {
                            $rootScope.$emit("flash", {
                                type: "info",
                                title: "Нравится",
                                text: "Пожалуйста, подождите завершения предыдущей операции"
                            });
                        }
                    });
                });
            }
        };
    }]);

})();
