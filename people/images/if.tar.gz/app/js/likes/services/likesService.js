(function(){
angular.module('likes.services', [])
    .factory('likesService', ['$rootScope', '$q', 'jsonRPC', 'contentType', 'permissionRequired',
        function ($rootScope, $q, jsonRPC, contentType, permissionRequired) {
            function onError(msg) {
                $rootScope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: msg || "Ошибка, попробуйте повторить запрос позже."
                });
            }

            return {
                like: permissionRequired('likes.add_userlike', function (item) {
                    return jsonRPC.request('likes.add_like', contentType(item)).then(
                        function (data) {
                            if (data.error) {
                                
                                if ($rootScope.isLogicError(data.error)) {
                                    onError(data.error.data.msg);
                                }
                            }
                            else {
                                item.liked = data.result.liked;
                                item.liked_count = data.result.total;
                            }
                        }
                    );
                }),
                dislike: permissionRequired('likes.delete_userlike', function (item) {
                    return jsonRPC.request('likes.remove_like', contentType(item)).then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isLogicError(data.error)) {
                                    onError(data.error.data.msg);
                                }
                            }
                            else {
                                item.liked = data.result.liked;
                                item.liked_count = data.result.total;
                            }
                        }
                    );
                }),
                toggleLike: function (item) {
                    return (item.liked) ? this.dislike(item) : this.like(item);
                }
            };
        }])
    .factory("toggleLike", ["likesService", function (likesService) {
        return function () {
            return likesService.toggleLike(this);
        };
    }]);

})();