(function(){
angular.module('complains.doComplain', ['app'])
    .directive('doComplain', ['$rootScope', 'complainsService', '$parse', 'userService',
        function ($rootScope, complainsService, $parse, userService) {
            var loading = false;
            return {
                restrict: "AC",
                scope: false,
                link: function (scope, element, attrs) {
                    var entity = $parse(attrs.doComplain)(scope);

                    if (!entity) {
                        console.error("cant get item");
                        return;
                    }

                    function setDirectiveData() {
                        var title,
                            isDisabled = true;
                        
                        switch(entity.can_complain) {
                            case false:
                                title = 'Уже есть активная жалоба';
                                break;
                            case null:
                                title = 'Вы не имеете права жаловаться или объект прошел ручную модерацию';
				element.attr('data-protractor-id', 'noPermissionToComplain');
                                isDisabled = false;
                                break;
                            case true:
                                title = 'пожаловаться';
                                isDisabled = false;
                                break;
                        }
                        
                        element.attr('title', title);

                        if(isDisabled) element.attr('disabled', 'disabled');
                    }
                    

                    function setLoadingState() {
                        element.addClass("loading");
                        loading = true;
                    }


                    function resetLoadingState() {
                        element.removeClass("loading");
                        loading = false;
                        setDirectiveData();
                    }

                    setDirectiveData();

                    element.on('click', function () {

                        userService.getUser().then(function(user){
                            if(!user.authenticated){
                                $rootScope.$emit('needLogin');
                                return;
                            }

                            if (!loading) {
                                setLoadingState();
                                complainsService.addComplain(entity).then(resetLoadingState, resetLoadingState);
                            } else {
                                $rootScope.$emit("flash", {
                                    type: "info",
                                    title: "Участие",
                                    text: "Пожалуйста, подождите завершения предыдущей операции"
                                });
                            }
                        });

                    });
                    
                }

            };
    }]);

})();
