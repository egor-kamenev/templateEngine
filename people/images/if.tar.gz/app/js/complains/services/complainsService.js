(function(){
angular.module('complains.service', [])
    .factory('complainsService', [
        '$rootScope', '$q', 'jsonRPC', 'contentType', 'permissionRequired', 'userService', 'UserPhoneVerifyState',
        function ($rootScope, $q, jsonRPC, contentType, permissionRequired, userService, UserPhoneVerifyState) {
            return {
                addComplain: permissionRequired('complains.add_complain', function (item) {
                    if (item.can_complain === true) {
                        return jsonRPC.request('complains.add_complain', contentType(item)).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isLogicError(data.error)) {
                                        $rootScope.$emit("flash", {
                                            type: "error",
                                            title: "Error",
                                            text: data.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    item.can_complain = false;
                                    $rootScope.$emit("flash", {
                                        type: "success",
                                        title: "Готово",
                                        text: "Жалоба принята"
                                    });
                                }
                            },
                            function () {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Ошибка, повторите запрос позже"
                                });
                            }
                        );
                    }
                    else {
                        return $q.reject();
                    }
                }, function(){
                     userService.getInterests(userService.user.username).then(
                        function(res){
                            var tpl = _.template(
                                "Для того что бы пожаловаться, вам нужно:" +
                                "<ul>" +
                                    "<li><%= email %></li>" +
                                    "<li><%= phone %></li>" +
                                    "<li><%= interests %></li>" +
                                "</ul>"
                            );

                            var email = userService.user.has_verified_email === true,
                                phone = userService.user.phone.contact_type == UserPhoneVerifyState.SUCCESS,
                                interests = res.result.length > 0;

                            var reasons = {
                                email: email ? '' : '- подтвердить e-mail',
                                phone: phone ? '' : '- подтвердить телефон',
                                interests: interests ? '' : ' - заполнить интересы'
                            };
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: tpl(reasons)
                            });
                        });
                })
            };
        }])
    .factory("addComplain", [
        "complainsService",
        function (complainsService) {
            return function () {
                return complainsService.addComplain(this);
            };
        }]);


})();
