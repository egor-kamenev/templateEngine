(function(){
'use strict';

angular.module('map.services', [])
    .service('mapService',
    [
        '$q', '$rootScope', 'userService', 'filtersService', 'mapSettings', 'placesService', 'userLocationService',
        function ($q, $rootScope, userService, filtersService, mapSettings, placesService, userLocationService) {

            // <editor-fold desc="Module Properties">
            this._selectedPlace = null;
            var self = this;

            var defaultMap = {
                markers: {},
                layers: {
                    baselayers: {}
                },
                events: {
                    map: {
                        enable: ['zoomstart', 'drag', 'click', 'dblclick', 'moveend', 'dragend', 'zoomend'],
                        logic: 'broadcast'
                    },
                    marker: {
                        enable: ['click', 'dragend']
                    }

                },
                /*defaults: {
                    scrollWheelZoom: false
                },*/
                leafletDefaults: mapSettings.LeafletDefaults
            };

            var defaultLayer = 'mapbox';

            var mapsLayers = {
                google: {
                    googleTerrain: {
                        name: 'Google Terrain',
                        layerType: 'TERRAIN',
                        type: 'google'
                    },
                    googleHybrid: {
                        name: 'Google Hybrid',
                        layerType: 'HYBRID',
                        type: 'google'
                    },
                    googleRoadmap: {
                        name: 'Google Streets',
                        layerType: 'ROADMAP',
                        type: 'google'
                    }
                },
                osm: {
                    osm: {
                        name: 'OpenStreetMap',
                        url: '//{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                        type: 'xyz'
                    }
                },
                cloudmade: {
                    cloudmade2: {
                        name: 'Cloudmade Tourist',
                        type: 'xyz',
                        url: '//{s}.tile.cloudmade.com/{key}/{styleId}/256/{z}/{x}/{y}.png',
                        layerParams: {
                            key: '007b9471b4c74da4a6ec7ff43552b16f',
                            styleId: 7
                        }
                    }
                },
                mapbox: {
                    mapbox: {
                        name: 'Mapbox',
                        type: 'xyz',
                        url: '//{s}.tiles.mapbox.com/v3/' + MAPBOX_ID + '/{z}/{x}/{y}.png'
                    }
                }
            };

            // </editor-fold>

            function initializeMapLayers(layers, map) {
                if (angular.isArray(layers)) {
                    layers.forEach(function (item) {
                        if (mapsLayers[item] !== undefined) {
                            angular.extend(map.layers.baselayers, mapsLayers[item]);
                        }
                    });
                } else if (mapsLayers[layers] !== undefined) {
                    map.layers.baselayers = mapsLayers[layers];
                } else {
                    map.layers.baselayers = mapsLayers[defaultLayer];
                }
            }

            this.getDefaultMapCenter = function () {
                //TODO: implement additional logic
                return {
                    lat: mapSettings.MapDefaultPosition.center.latitude,
                    lng: mapSettings.MapDefaultPosition.center.longitude,
                    zoom: mapSettings.DefaultPlaceZoom
                };
            };

            function initializeMapCenter(mapCenter, map) {

                // If mapCenter not provided - fall back to filters center, 
                // finnaly DefaultMapCenter will be used if everything else fails

                var validCenterProvided = mapCenter && mapCenter.center,
                    center = validCenterProvided ? mapCenter : filtersService.getCenterPlace();

                if(center){
                    map.center = {
                        lat: center.center.latitude,
                        lng: center.center.longitude,
                        zoom: center.zoom || mapSettings.DefaultPlaceZoom
                    };

                    map.bounds = center.bounds ? center.bounds : null;
                }
                else {
                    map.center = self.getDefaultMapCenter();
                    map.bounds = mapSettings.MapDefaultPosition.bounds;
                }

            }

            this.getDefaultMap = function (layers, mapCenter, isClustered) {
                var map = angular.extend({}, defaultMap);
                map.layers.overlays = {
                    objects: {
                        name: 'objects',
                        type: isClustered ? 'markercluster' : 'group',
                        visible: true
                    }
                };

                initializeMapLayers(layers, map);
                initializeMapCenter(mapCenter, map);
                 
                return map;
            };

            this.getDefaultLocation = function () {

                var deferred = $q.defer();

                if (mapSettings.MapDefaultLocationAddress) {
                    placesService.getAddressSuggest(mapSettings.MapDefaultLocationAddress)
                        .then(
                        function (results) {
                            if (results && results[0] && results[0].geometry) {
                                deferred.resolve(results[0].geometry);
                            } else {
                                deferred.reject();
                            }
                        });
                }
                else {
                    return userLocationService.getUserLocation().then(function (location) {
                        deferred.resolve({
                            center: location
                        });
                    });
                }

                return deferred.promise;
            };

            this.saveSelectedPlace = function (v) {
                self._selectedPlace = v;
            };

            this.getSelectedPlace = function () {
                return self._selectedPlace;
            };

            this.resetSelectedPlace = function () {
                self._selectedPlace = null;
            };
        }])
    .constant('mapSettings', {
        DefaultMapBaselayer: {
            mapbox: {
                name: 'Mapbox',
                type: 'xyz',
                url: '//{s}.tiles.mapbox.com/v3/whiteteam.ik5208ka/{z}/{x}/{y}.png'
            }
        },
        DefaultPlaceZoom: 8,
        DefaultMapLayers: ['mapbox'],
        MaxZoom: 18,
        LeafletDefaults: {
            maxZoom: 18,
            doubleClickZoom: false,
            scrollWheelZoom: true,
            zoomControlPosition: 'bottomright',
            attributionControl: false,
            touchZoom: true
            
        },
        MarkerUserLocation: {
            type: 'div',
            iconSize: [28, 70],
            className: "pin pin--user-location"
        },
        MarkerEvent: {
            type: 'div',
            iconSize: [28, 70]
        },
        MarkerUser: {
            type: 'div',
            iconSize: [38, 70]
        },
        MarkerPlace: {
            type: 'div',
            iconSize: [28, 70]
        },
        DefaultLocateControlSettings: {
            position: 'bottomright',  // set the location of the control
            drawCircle: true,  // controls whether a circle is drawn that shows the uncertainty about the location
            follow: true,  // follow the user's location
            setView: true, // automatically sets the map view to the user's location, enabled if `follow` is true
            keepCurrentZoomLevel: true, // keep the current map zoom level when displaying the user's location. (if `false`, use maxZoom)
            stopFollowingOnDrag: false, // stop following when the map is dragged if `follow` is true (deprecated, see below)
            markerClass: L.circleMarker, // L.circleMarker or L.marker
            circleStyle: { // change the style of the circle around the user's location
                color: '#3A92C8',
                fillColor: '#ffffff',
                fillOpacity: 0.0,
                weight: 1,
                opacity: 0.5
            },
            markerStyle: {},
            followCircleStyle: {},  // set difference for the style of the circle around the user's location while following
            followMarkerStyle: {},
//            icon: '',  // `icon-location` or `icon-direction`
//            iconLoading: '',  // class for loading icon
//            icon: 'icon-location',  // `icon-location` or `icon-direction`
//            iconLoading: 'icon-spinner  animate-spin',  // class for loading icon
            circlePadding: [0, 0], // padding around accuracy circle, value is passed to setBounds
            metric: true,  // use metric or imperial units
            //onLocationError: function (err) {
            //    console.log(err);
            //},  // define an error callback function
            //onLocationOutsideMapBounds: function (context) {
            //}, // called when outside map boundaries
            strings: {
                title: "Определить местоположение",  // title of the locate control
                popup: "Вы находитесь в пределах {distance} {unit} от этого места",  // text to appear if user clicks on circle
                outsideMapBoundsMsg: "Вы находитесь за пределами текущей карты" // default message for onLocationOutsideMapBounds
            },
            locateOptions: { // define location options e.g enableHighAccuracy: true or maxZoom: 10
                maxZoom: 18
            }
        },
        MapDefaultLocationAddress: 'Москва, Российская Федерация',
        MapDefaultPosition: {
            "center": {"latitude": 55.75697, "longitude": 37.61502},
            "bounds": {
                "northEast": {"lat": 56.02122, "lng": 36.80157},
                "southWest": {"lat": 55.1524, "lng": 37.96699}
            }
        },
        //'<div class="content-object__published-info">'+
        //    '<div class="avatar avatar--small" data-ng-class="{online: obj.owner.online}" style="background-image: url([[(obj.owner.avatar | imageUrl:\'large\') || \'/static/i/default.jpg\']]);">'+
        //'<a data-ui-sref="user.wall({username: obj.owner.username})"></a>'+
        //'</div>'+
        //'<div class="meta owner">'+
        //'<a data-ui-sref="user.wall({username: obj.owner.username})" title="[[ obj.owner.username]]">[[obj.owner.username]]</a><br/>[[obj.ts_published | toDate: \'DD MMM, YY\']]'+
        //'</div>'+
        //'<div class="meta age" data-ng-class="{adult: obj.age_restriction > 18}">[[obj.age_restriction]]</div>'+
        //'<div data-ng-if="obj.is_being_moderated || obj.is_banned" class="meta moderation" data-ng-class="{\'pending-moderation\': obj.is_being_moderated, banned: obj.is_banned}" data-protractor-id="isBeingModerated"></div>'+
        //'</div>'+

        //'<ul class="content-object__info__tags tags"><li class="tag" data-ng-repeat="tag in obj.tags"><a href="?tags=^[[::tag.name]]">[[::tag.name]]</a></li></ul>'+
        MapPopupEvents: ''+
        '<div class="content-object content-object--map-entry event [[obj|typeByTags]]">' +
            '<div class="content-object__info__top">'+
                '<div class="content-object__info__title">'+
                    '<h1><a data-ui-sref="event({event_alias: obj.alias})" data-protractor-id="sidebarEventLink">[[obj.name]]</a></h1>'+
                '</div>'+
            '</div>'+
            '<div class="content-object__info">'+
                '<div class="content-object__info__alfa">'+
                    '<div class="content-object__info__event-dates"><span class="label">Начнется:</span>[[obj.ts_start | toDate: \'DD MMM, YY HH:mm\']]<span data-ng-if="obj.ts_finish">&nbsp;&ndash;&nbsp;[[obj.ts_finish | toDate: \'DD MMM HH:mm\']]</span></div>'+
                    '<div class="content-object__info__event-place" data-ng-if="obj.place"><span class="label">Место проведения:</span><a data-ui-sref="place({place_alias: obj.place.alias})">[[obj.place.name]]</a><span class="address" data-ng-if="obj.place.formatted_address">([[obj.place.formatted_address ]])</span></div>'+
                    '<div class="content-object__info__event-place" data-ng-if="!obj.place"><span class="label">Место проведения:</span>еще не определено</div>'+
                    '<div class="content-object__info__description" data-ng-if="obj.description">[[obj.description]]</div>'+
                '</div>'+
                '<div class="content-object__info__beta">'+
                    '<div class="content-object__info__participate" data-ng-if="user.authenticated && !obj.readOnly && (!((obj.is_finished && obj.by_invitation && obj.invite_request.state != states.accepted && obj.bun_request.state != states.sent) || (obj.is_going && obj.by_invitation && obj.invite_request.state != states.accepted && obj.bun_request.state != states.sent)) || (obj.owner.username == user.username))">'+
                        '<div data-check-in-out="obj"></div>'+
                    '</div>'+
                    '<div class="content-object__info__participate" data-ng-if="obj.is_going && obj.user_state.state == eventUserStates.intended">' + 
                        '<div data-cancel-visit="obj"></div>' + 
                    '</div>' +
                    '<ul class="content-object__info__participants" data-ng-if="obj.participants.length">'+
                        '<li class="label">Участвуют:</li>'+
                        '<li class="avatar" data-ng-repeat="user in obj.participants" data-ng-hide="$index==5" style="background-image: url([[ (user.avatar | imageUrl:\'small\') || \'/static/i/no-avatar.gif\' ]]);">'+
                            '<a data-ui-sref="user.wall({username: user.username})" title="[[ user | fullName]]"></a>'+
                        '</li>'+
                    '</ul>'+
                '</div>'+
            '</div>'+
        '</div>',

        MapPopupPlaces: ''+
        '<div class="content-object content-object--map-entry place [[obj|typeByTags]]">' +
            '<div class="content-object__info__top">'+
                '<div class="content-object__info__title">'+
                    '<h1><a data-ui-sref="place({place_alias: obj.alias})" data-protractor-id="sidebarPlaceLink">[[obj.name]]</a></h1>'+
                '</div>'+
            '</div>'+
            '<div class="content-object__info">'+
                '<div class="content-object__info__alfa">'+
                    '<div class="content-object__info__map map-field"><p class="map-hint" data-ng-if="obj.formatted_address" data-protractor-id="formattedAddress">[[obj.formatted_address ]]</p></div>'+
                    '<div class="content-object__info__description" data-ng-if="obj.description">[[obj.description]]</div>'+
                '</div>'+
                '<div class="content-object__info__beta">'+
                    '<div class="content-object__info__event-here" data-ng-if="!obj.readOnly && user.authenticated">'+
                        '<button class="button make-event" data-host-event place="obj" data-protractor-id="makeEventHere">Провести мероприятие</button>'+
                    '</div>'+
                    '<div class="content-object__info__participate" data-ng-if="!obj.readOnly && user.authenticated">'+
                        '<div data-place-check-in-out="obj"></div>'+
                    '</div>'+
                    '<ul class="content-object__info__participants" data-ng-if="obj.visitors.length"><li class="label">Сейчас здесь:</li><li class="avatar" data-ng-repeat="user in obj.visitors" style="background-image: url([[ (user.avatar | imageUrl:\'small\') || \'/static/i/no-avatar.gif\' ]]);"><a data-ui-sref="user.wall({username: user.username})" title="[[ user | fullName]]"></a></li></ul>' +
                '</div>'+
            '</div>'+
        '</div>',

        MapPopupUsers: '' +
        '<div class="content-object content-object--map-entry user">'+
            '<div class="content-object__info__top">'+
                '<div class="content-object__info__title">'+
                    '<div data-user-avatar data-entity="obj" data-picturesize="\'big\'"></div>' +
                    '<h1><a data-ui-sref="user.wall({username: obj.username})" title="[[ obj | fullName]]">[[ obj | fullName]]</a></h1>'+
                '</div>'+
            '</div>'+
            '<div class="content-object__info">'+
                '<div class="content-object__info__alfa">'+
                    '<div class="content-object__info__user-place" data-ng-if="obj.last_location.place">' + 
                        '<span class="label">Местонахождение:</span>' + 
                        '<a data-ui-sref="place({place_alias: obj.last_location.place.alias})" title="[[obj.last_location.place.name]]">[[obj.last_location.place.name]]</a>' +
                        '<div class="address">[[obj.last_location.place.formatted_address]]</div>' +
                    '</div>' + 
                    '<div class="content-object__info__description">'+
                        '<p data-ng-if="obj.last_online_ts" class="last-visit">Последний визит: [[obj.last_online_ts | fromNow]]</p>'+
                        '<p data-ng-if="obj.status">[[obj.status]]</p>'+
                    '</div>'+
                '</div>'+
            '</div>'+
        '</div>',
        
        //'<div class="content-object content-object--map-entry user">' +
        //'<div class="content-object__avatar avatar avatar--big" data-ng-class="{online:obj.online===true}" style="background-image: url([[ (obj.avatar | imageUrl:\'medium\') || \'/static/i/no-avatar.gif\']])">' +
        //'<a data-ui-sref="user.wall({username: obj.username})">' +
        //'</div>' +
        //'<div class="content-object__info">' +
        //'<h3 class="content-object__info__title"><a data-ui-sref="user.wall({username: obj.username})">[[ obj | fullName ]]</a></h3>' +
        //'</div>' +
        //'</div>',
        MapPopupCreatePlace: '<div class="content-object content-object--map-entry">' +
        '<div class="content-object__info">' +
        '<h3 class="content-object__info__title">[[place.formatted_address]]</h3>' +
        '</div>' +
        '<ul class="megamenu megamenu--dropline content-object__action-menu">' +
        '</ul>' +
        '</div>',
        MapPopupPlaceAddress: '<div class="content-object content-object--map-entry">' +
        '<div class="content-object__info">' +
        '<h3 class="content-object__info__title">[[place.formatted_address]]</h3>' +
        '</div>' +
        '</div>',
        MapMarkerPopup: '<div class="content-object content-object--map-entry">' +
        '<div class="content-object__info">' +
        '<h3 class="content-object__info__title">[[newEventData.formatted_address]]</h3>' +
        '</div>' +
        '<ul class="megamenu megamenu--dropline content-object__action-menu">' +
        '<li class="megamenu__item__wrap">' +
        '<button data-ng-click="switchToCreate(\'new_event\')" class="megamenu__item button new-event" type="button">' +
        '<span class="megamenu__item__text">[[\'MAP_POPUP_CREATE_EVENT\' | translate]]</span>' +
        '</button>' +
        '</li>' +
        '<li class="megamenu__item__wrap">' +
        '<button data-ng-click="switchToCreate(\'new_place\')" class="megamenu__item button new-place" type="button">' +
        '<span class="megamenu__item__text">[[\'MAP_POPUP_CREATE_PLACE\' | translate]]</span>' +
        '</button>' +
        '</li>' +
        '<li class="megamenu__item__wrap">' +
        '<button data-ng-click="removeNewPlaceMarker()" class="megamenu__item button cancel" type="button">' +
        '<span class="megamenu__item__text">[[\'MAP_POPUP_CANCEL\' | translate]]</span>' +
        '</button>' +
        '</li>' +
        '</ul>' +
        '</div>'
    });



})();
