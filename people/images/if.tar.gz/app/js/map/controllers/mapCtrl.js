(function () {
    'use strict';

    angular.module('map.controllers', ['app', 'map.services']).constant('mapEvents', {
        SIDEBAR_SWITCHED: 'map__sidebarSwitched',
        INITIALIZING: 'map__initializing',
        OBJECTS_CHANGED: 'map__objectsChanged',
        LOAD_ADDRESS_COMPLETED: 'map__loadAddressComplete',
        TYPEAHEAD_SELECTED: 'map__typeaheadSelected',
        HIGHLIGHT_OBJECT: 'map__highlightObject',
        SCROLL_TO_OBJECT: 'map__scrollToObject',
        INVALIDATE_LAYOUT: 'map__layout'
    }).controller('MapCtrl', [
        '$q', '$rootScope', '$scope', '$state', 'contentSettings', 'mapService', 'mapSettings', 'eventsService',
        'filtersService', 'placesService', 'placesSettings', 'userService', 'leafletData', 'frontendSettings',
        '$compile', '$interpolate', '$timeout', 'filtersEvents', 'userLocationService', 'xStates', 'typeByTags',
        'mapEvents', 'contentSettingsService', 'contentItemsSourceService', 'eventUserStates',
        function ($q, $rootScope, $scope, $state, contentSettings, mapService, mapSettings, eventsService,
                  filtersService, placesService, placesSettings, userService, leafletData, frontendSettings,
                  $compile, $interpolate, $timeout, filtersEvents, userLocationService, xStates, typeByTags,
                  mapEvents, contentSettingsService, contentItemsSourceService, eventUserStates) {

            // <editor-fold desc="Module Properties">
            $scope.states = xStates;
            $scope.eventUserStates = eventUserStates;
            $scope.needUpdateFilter = true;

            $rootScope.mapCurrentPage = 1;
            $rootScope.mapMaxPage = 1;


            $scope.isModeMap = function () {
                return $rootScope.currentFilterMode === contentSettings.MODE.MAP;
            };

            var extendLocationSettings = {
                currentAccuracyLevel: 0,
                maxAccuracyLevel: 0,
                cachedBounds: null
            };

            extendLocationSettings.reset = function () {
                this.currentAccuracyLevel = placesSettings.GEOACCURACY_LEVELS.AREA;
                this.maxAccuracyLevel = placesSettings.GEOACCURACY_LEVELS.STATE;
                this.cachedBounds = null;
            };
            extendLocationSettings.reset();

            var objectMarkerIdPrefix = 'objectMarker';
            var mapID = "map_canvas";

            var locateControlProperties = {
                locateControlLayerID: null,
                addingLocateControlInProgress: false
            };

            $scope.isMapInitDone = false;
            $scope.isMapLoaded = false;
            $scope.isMapMode = false;

            $scope.skipMapEvents = 0;

            $scope.defaultCenter = angular.copy(mapSettings.MapDefaultPosition);
            $scope.defaultBounds = angular.copy(mapSettings.MapDefaultPosition.bounds);

            $scope.userLocation = null;

            var markersIcons = {
                userLocation: mapSettings.MarkerUserLocation
            };
            var popupRenders = [];
            markersIcons[contentSettings.CONTENT_TYPES.USERS] = mapSettings.MarkerUser;
            markersIcons[contentSettings.CONTENT_TYPES.EVENTS] = mapSettings.MarkerEvent;
            markersIcons[contentSettings.CONTENT_TYPES.PLACES] = mapSettings.MarkerPlace;
            var defaultMapMarker = {
                lat: null,
                lng: null,
                message: null,
                focus: false,
                draggable: false,
                layer: "objects"
            };

            $scope.init = function (currentMode, loadedLocation) {
                if (loadedLocation) {
                    $scope.userLocation = loadedLocation;
                }
                if (currentMode && currentMode === contentSettings.MODE.MAP && !$scope.isMapMode) {
                    $scope.isMapMode = true;
                    $scope.$emit(mapEvents.INITIALIZING);
                }
            };

            var savedFilters = {};

            // </editor-fold>

            // <editor-fold desc="HTML Popups">

            var userMarkerHtml = '<img src="[[ (item.avatar | imageUrl:\'micro\') || \'/static/i/no-avatar.gif\' ]]"' +
                'alt="[[item.username]]" title="[[item.username]]"/>';

            var htmlPopups = [];

            htmlPopups[contentSettings.CONTENT_TYPES.EVENTS] = mapSettings.MapPopupEvents;
            htmlPopups[contentSettings.CONTENT_TYPES.PLACES] = mapSettings.MapPopupPlaces;
            htmlPopups[contentSettings.CONTENT_TYPES.USERS] = mapSettings.MapPopupUsers;

            function toggleObjectInfoWindow(o, show) {
                console.info("HARLEM opened PopUp");
                $q.all({
                    markers: leafletData.getMarkers(mapID),
                    layers: leafletData.getLayers(mapID)
                })
                    .then(function (values) {

                        // Visible parent is a container that popup attches to.
                        // If our map uses clusters uncomment the following line.
                        // var visibleParent = values.layers.overlays.getVisibleParent(values.markers[objectMarkerIdPrefix + o.id]);
                        // Common map without clusters
                        var visibleParent = values.markers[objectMarkerIdPrefix + o.id];

                        if (visibleParent) {
                            if (show) {
                                visibleParent.bindPopup(getPopupHTML(o));
                                $timeout(function () {
                                    visibleParent.openPopup();
                                }, 0, false);
                            } else {
                                visibleParent.closePopup();
                            }
                        }

                    });
            }

            function getPopupHTML(o) {
                $scope.obj = o;
                if( typeof popupRenders[$rootScope.currentFilterContentType] === 'undefined'){
                    popupRenders[$rootScope.currentFilterContentType] = $compile(htmlPopups[$rootScope.currentFilterContentType]);
                }
                return popupRenders[$rootScope.currentFilterContentType]($scope)[0];
            }

            // </editor-fold>

            // <editor-fold desc="Events">

            function initializeMapEvents() {
                $scope.$on('leafletDirectiveMarkersClick', function (event, marker) {
                    console.log("Marker click: ", marker);

                    if (!contentSettingsService.mapSettings.showPopupsOnMarkersClick) {
                        return;
                    }

                    var clickedObject = _.find($scope.objects, function (o) {
                        return objectMarkerIdPrefix + o.id === marker;
                    });

                    if (contentSettingsService.mapSettings.scrollSidebarOnMarkersClick) {
                        $scope.$emit(mapEvents.SCROLL_TO_OBJECT, {obj: clickedObject});
                    }

                    if (clickedObject) {
                        toggleObjectInfoWindow(clickedObject, true);
                    }
                });

                $scope.$on('leafletDirectiveMarker.dragend', function (event, e) {
                    var pos = e.leafletEvent.target.getLatLng();
                    $scope.updateAddress(pos.lat, pos.lng);
                    $scope.showPlaceMarkerPopup();
                });

                $scope.$on('leafletDirectiveMap.dblclick', function (event, e) {
                    var pos = e.leafletEvent.latlng;
                    $scope.createPlaceMarker(pos.lat, pos.lng);
                    $scope.showPlaceMarkerPopup(pos.lat, pos.lng);

                });

                $scope.$on('leafletDirectiveMap.moveend', function () {
                    if ($scope.skipMapEvents > 0) {
                        $scope.skipMapEvents -= 1;
                        return;
                    }
                    leafletData.getMap(mapID).then(function (map) {
                        updateFiltersCenterPlace(map);
                    });
                });

                $scope.$on('leafletDirectiveMap.zoomend', function () {
                    if ($scope.skipMapEvents) {
                        $scope.skipMapEvents -= 1;
                        return;
                    }
                    leafletData.getMap(mapID).then(function (map) {
                        updateFiltersCenterPlace(map);
                    });
                });

                // User is going (or not going) to event - change event state
                $scope.$onRootScope('event_changeGoingState', function (event, data) {
                    if (!$scope.isModeMap()) {
                        return;
                    }

                    var event_id = parseInt(data.event_id);
                    for (var i in $scope.markers) {
                        for (var j in $scope.markers[i].place.events) {
                            var e = $scope.markers[i].place.events[j];
                            if (e.id === event_id) {
                                e.going = data.going;
                                if (data.going) {
                                    e.participants_num += 1;
                                } else {
                                    e.participants_num -= 1;
                                }
                                break;
                            }
                        }
                    }
                });
            }

            function initializeScopeEvents() {
                $scope.$onRootScope(mapEvents.HIGHLIGHT_OBJECT, function (event, args) {
                    if ($scope.isModeMap() && args && args.element && contentSettingsService.mapSettings.showPopupsOnHover) {
                        toggleObjectInfoWindow(args.element, args.value);
                    }
                });

                $scope.$onRootScope(mapEvents.INITIALIZING, function (event, args) {
                    if (!$scope.isModeMap()) {
                        return;
                    }

                    var filtersLoaded = (!args || args.filtersLoaded === undefined) ? filtersService.isLoadComplete() : args.filtersLoaded;

                    if (filtersLoaded) {
                        initializeMap();
                    } else {
                        $scope.$onRootScope(filtersEvents.LOAD_COMPLETE, function () {
                            initializeMap();
                        });
                    }
                });

                $scope.$onRootScope(mapEvents.TYPEAHEAD_SELECTED, function (event, center) {
                    if (!$scope.isModeMap()) {
                        return;
                    }
                    updateMapCenter(center);
                    filtersService.setCenterPlace(center);
                    filtersService.updateURL();

                });

                var lazyFiltersUpdated = _.throttle(function (event, args) {
                    if (!$scope.isModeMap()) {
                        return;
                    }

                    console.log("ON filtersEvents.UPDATED: MAP");

                    if (args) {
                        onFiltersUpdated(args.value, args.old);
                    }
                    else {
                        reloadObjectsFromService();
                    }
                }, 500, {leading: false, trailing: true});

                $scope.$onRootScope(filtersEvents.UPDATED, lazyFiltersUpdated);
            }

            function onFiltersUpdated(fVal, fValOld) {
                if (fVal === undefined || fValOld === undefined || !$scope.isModeMap()) {
                    return;
                }

                leafletData.getMap(mapID).then(function (map) {
                    var mapCenter = map.getCenter();

                    var mapCenterUpdated = fVal.centerPlace && fVal.centerPlace.center &&
                        (!angular.equals(fVal.centerPlace, fValOld.centerPlace) ||
                        fVal.centerPlace.center.latitude !== mapCenter.lat ||
                        fVal.centerPlace.center.longitude !== mapCenter.lng);

                    if (mapCenterUpdated) {
                        updateMapCenter(fVal.centerPlace, map);
                    }
                    reloadObjectsFromService(null, false, true);
                });
            }

            function updateMapCenter(center, map) {
                var setMapPosition = function (m) {
                    var mapCenter = m.getCenter(),
                    // Center may be a place or just a point
                        centerPoint = angular.isDefined(center.center) ? center.center : center,
                        updateCenter = (mapCenter.lat != centerPoint.latitude) || (mapCenter.lng != centerPoint.longitude);

                    if (updateCenter) {
                        $scope.skipMapEvents += 1;

                        if (center.bounds) {
                            mapFitToBounds(center.bounds, m);
                        }
                        else {
                            m.panTo(
                                L.latLng(
                                    centerPoint.latitude,
                                    centerPoint.longitude
                                ), {animate: true}
                            );
                        }
                    }

                };

                if (map) {
                    setMapPosition(map);
                }
                else {
                    leafletData.getMap(mapID).then(setMapPosition);
                }
            }

            // </editor-fold>

            // <editor-fold desc="Markers">

            $scope.switchToCreate = function (state) {
                $scope.$destroy();
                $state.transitionTo(state);
            };

            var geoPlaceCB = function (geoplace) {
                if (geoplace) {
                    mapService.saveSelectedPlace(geoplace);
                    $scope.newEventData.formatted_address = geoplace.formatted_address;
                    $rootScope.$emit(mapEvents.LOAD_ADDRESS_COMPLETED, geoplace.formatted_address);
                }
                else {
                    mapService.resetSelectedPlace(geoplace);
                    $scope.newEventData.formatted_address = "Ошибка, попробуйте переместить маркер";
                }
            };

            $scope.updateAddress = function (lat, lng) {
                if (!lat) {
                    $scope.newEventData.formatted_address = '';
                    return;
                }
                if ($scope.markers.newPlaceMarker) {
                    placesService.getGeoPlace(lat, lng).then(function (geoPlace) {
                        geoPlaceCB(geoPlace);
                    });
                }

            };

            $scope.removeNewPlaceMarker = function () {
                delete $scope.markers.newPlaceMarker;
                $scope.updateAddress();
            };

            var newContentMarkerIcon = {};
            angular.extend(newContentMarkerIcon, markersIcons[contentSettings.CONTENT_TYPES.PLACES], {className: "pin pin--new"});

            $scope.createPlaceMarker = function (lat, lng) {
                $scope.removeNewPlaceMarker();
                $scope.markers.newPlaceMarker = {
                    lat: lat,
                    lng: lng,
                    focus: true,
                    draggable: true,
                    icon: newContentMarkerIcon
                };

                $scope.updateAddress(lat, lng);
            };

            $scope.showPlaceMarkerPopup = function () {

                var unreg_watch = $scope.$watch('markers', function (new_markers) {

                    if (angular.isDefined(new_markers.newPlaceMarker)) {
                        leafletData.getMarkers(mapID).then(function (markers) {

                            var m = markers.newPlaceMarker;
                            if (angular.isDefined(m)) {
                                var popupHTML = $compile(mapSettings.MapMarkerPopup)($scope);
                                m.bindPopup(popupHTML[0], {className: 'new-content'}).openPopup();
                            }
                        });

                    }
                    unreg_watch();
                });
            };

            function buildMapMarker(item, contentType) {
                var marker = {
                    lat: item.lat,
                    lng: item.lng,
                    message: item.message,
                    icon: _.clone(markersIcons[contentType])
                };
                _.defaults(marker, defaultMapMarker);

                if (contentType == contentSettings.CONTENT_TYPES.USERS) {
                    marker.icon.className = "pin pin--user";
                    marker.icon.html = $interpolate(userMarkerHtml)($rootScope);
                } else if (contentType == contentSettings.CONTENT_TYPES.PLACES) {
                    marker.icon.className = "pin pin--place " + typeByTags(item);
                } else if (contentType == contentSettings.CONTENT_TYPES.EVENTS) {
                    marker.icon.className = "pin pin--event " + typeByTags(item);
                }

                return marker;
            }


            function addUserMarker(userLocation, map) {
                if (userLocation) {
                    map.markers.userMarker = {
                        lat: userLocation.latitude,
                        lng: userLocation.longitude,
                        focus: false,
                        draggable: false,
                        icon: markersIcons.userLocation
                    };
                }
                return map;
            }

            //function removeAllObjectMarkers() {
            //    if ($scope.markers && Object.keys($scope.markers).length > 0) {
            //        $scope.markers = $scope.filterObjectProperties($scope.markers, function (item) {
            //            return item.layer !== 'objects';
            //        });
            //    }
            //}

            // Remove markers for removed objects
            function removeRedundantMarkers(leaveUserMarker) {
                if ($scope.markers && Object.keys($scope.markers).length > 0) {
                    $scope.markers = $scope.filterObjectProperties($scope.markers, function (marker, index) {
                        if (index === 'userMarker' && leaveUserMarker) {
                            return true;
                        }
                        if (marker && marker.layer === 'objects') {
                            var objId = parseInt(index.replace(objectMarkerIdPrefix, ''));

                            return !isNaN(objId) && _.find($scope.objects, function (o) {
                                    return o.id == objId;
                                });
                        }
                        return false;
                    });
                }
            }

            function prepareObjectsForMap() {
                var defer = $q.defer();

                leafletData.getMap(mapID).then(function (map) {
                    var resultObjects = [];
                    var leafletBounds = getLeafletBounds(map);
                    var contentType = $rootScope.currentFilterContentType;

                    removeRedundantMarkers(true);

                    angular.forEach($scope.objects, function (o) {

                        var markerName = objectMarkerIdPrefix + o.id;
                        var isValid = true;

                        if (contentType === contentSettings.CONTENT_TYPES.PLACES) {
                            o.lat = o.latitude;
                            o.lng = o.longitude;
                            o.text = o.name;
                        } else if (contentType === contentSettings.CONTENT_TYPES.EVENTS && !isVirtualEvent(o)) {
                            o.lat = o.place.latitude;
                            o.lng = o.place.longitude;
                            o.text = o.place.name;
                        } else if (contentType === contentSettings.CONTENT_TYPES.USERS && userHasLocation(o)) {
                            o.lat = o.last_location.place.latitude;
                            o.lng = o.last_location.place.longitude;
                            o.text = o.username;
                        } else {
                            isValid = false;
                        }

                        if (isValid) {
                            var point = new L.Point(o.lat, o.lng);
                            if (leafletBounds.contains(point)) {
                                o.contentType = contentType;
                                resultObjects.push(o);
                                return;
                            }
                        }

                        var hasMarker = $scope.markers && angular.isDefined($scope.markers[markerName]);
                        if (hasMarker) {
                            delete $scope.markers[markerName];
                        }
                    });

                    defer.resolve(resultObjects);
                });

                return defer.promise;
            }

            function showObjectsOnMap() {
                prepareObjectsForMap().then(function (mapObjects) {
                    if (mapObjects && mapObjects.length) {

                        var contentType = $rootScope.currentFilterContentType;
                        var markers = {};

                        angular.forEach(mapObjects, function (obj) {
                            var markerId = objectMarkerIdPrefix + obj.id;
                            markers[markerId] = buildMapMarker(obj, contentType);
                        });

                        angular.extend($scope.markers, markers);
                    }

                    //$rootScope.$emit(mapEvents.OBJECTS_CHANGED, {mapObjects: mapObjects}); commented for T1099
                    console.log("Objects total: ", $scope.objects ? $scope.objects.length : 0, ",  displayed on map: ", mapObjects.length);
                    $rootScope.loading = false;

                });
            }

            // </editor-fold>

            // <editor-fold desc="Helpers">

            $scope.filterObjectProperties = function (obj, predicate) {
                var result = {};
                var key;

                for (key in obj) {
                    if (obj.hasOwnProperty(key) && predicate(obj[key], key, obj)) {
                        result[key] = obj[key];
                    }
                }
                return result;
            };

            function getLeafletBounds(map) {
                if (!map) {
                    return null;
                }
                var bounds = map.getBounds();
                var northEast = bounds.getNorthEast();
                var southWest = bounds.getSouthWest();
                var point1 = new L.Point(northEast.lat, northEast.lng);
                var point2 = new L.Point(southWest.lat, southWest.lng);
                return new L.Bounds(point1, point2);
            }

            function isVirtualEvent(event) {
                return !event || !event.place || !event.place.latitude || !event.place.longitude;
            }

            function userHasLocation(user) {
                return user && user.last_location && user.last_location.place &&
                    user.last_location.place.latitude && user.last_location.place.longitude;
            }

            // </editor-fold>

            $scope.$onRootScope(filtersEvents.RESETED, function () {
                if ($scope.isModeMap()) {
                    resetMapcentrator();
                }
            });

            function resetMapcentrator() {
                var mapCentrator = angular.element('#center_place_address');
                mapCentrator.typeahead('val', '');
            }

            var debouncedSearch = _.debounce(function (query, cb) {

                var data = [];
                placesService.getAddressSuggest(query).then(
                    function (results) {

                        if (results && angular.isArray(results)) {
                            angular.forEach(results, function (place) {
                                var lat = place.geometry.center.latitude;
                                var lng = place.geometry.center.longitude;
                                var bounds = place.geometry.bounds || placesService.createPlaceBounds(lat, lng);

                                data.push({
                                    'text': place.formatted_address,
                                    'latitude': lat,
                                    'longitude': lng,
                                    'bounds': bounds
                                });
                            });
                        }

                        userLocationService.getUserLocation().then(function (loc) {
                            loc = loc ? loc : {latitude: null, longitude: null};
                            placesService.suggestPlace(query, loc.latitude, loc.longitude).then(
                                function (response) {
                                    if (response.result.length) {
                                        for (var index = 0; index < response.result.length; index++) {
                                            var place = response.result[index];
                                            data.push({
                                                'text': place.distance ? place.name + " (" + place.distance.toFixed(2) + " km)" : place.name,
                                                'latitude': place.latitude,
                                                'longitude': place.longitude,
                                                'bounds': placesService.createPlaceBounds(place.latitude, place.longitude)
                                            });
                                        }
                                    }
                                    cb(data);
                                },
                                function () {
                                    cb(data);
                                }
                            );

                        });
                    },
                    function () {
                        cb(data);
                    }
                );

            }, 300);

            function initMapCentrator() {

                // Typeahead element helps centering the map on address or place
                var mapCentrator = angular.element('#center_place_address'),
                    addrTypeahead = mapCentrator.typeahead(
                        {
                            hint: true,
                            highlight: true,
                            minLength: 3
                            // https://github.com/twitter/typeahead.js/pull/719
                        },
                        {
                            displayKey: 'text',
                            source: function (query, cb) {
                                
                                var data = [];
                                if (query) {
                                    
                                    debouncedSearch(query, cb);
                                }
                                // empty query
                                else {
                                    
                                    var favPlaces = $rootScope.user.userFavorites.items;
                                    angular.forEach(favPlaces, function (place, k) {
                                        data.push({
                                            'text': place.name,
                                            'latitude': place.latitude,
                                            'longitude': place.longitude,
                                            'bounds': placesService.createPlaceBounds(place.latitude, place.longitude)
                                        });
                                    });
                                    
                                    cb(data);
                                }
                            }
                        }
                    );

                mapCentrator.on('typeahead:selected', function (e, centerPlace) {

                    var center = {
                        bounds: centerPlace.bounds,
                        center: {
                            latitude: centerPlace.latitude,
                            longitude: centerPlace.longitude
                        }

                    };

                    $scope.$apply(function () {
                        $rootScope.$emit(mapEvents.TYPEAHEAD_SELECTED, center);
                    });

                });
            }

            function updateFiltersCenterPlace(map) {
                map.whenReady(function () {
                    if (!$scope.isMapInitDone) {
                        return;
                    }

                    var mapCenter = map.getCenter();
                    var mapBounds = map.getBounds();

                    var mapMoved = !$scope.lastCenter || !$scope.lastBounds ||
                         !angular.equals($scope.lastCenter, mapCenter) ||
                         !angular.equals($scope.lastBounds, mapBounds);

                    if (mapMoved) {
                        $scope.lastCenter = mapCenter;
                        $scope.lastBounds = mapBounds;


                        var bounds = {
                            northEast: {
                                lat: mapBounds.getNorthEast().lat,
                                lng: mapBounds.getNorthEast().lng
                            },
                            southWest: {
                                lat: mapBounds.getSouthWest().lat,
                                lng: mapBounds.getSouthWest().lng
                            }
                        };
                        var center = {
                            center: {
                                latitude: mapCenter.lat,
                                longitude: mapCenter.lng
                            },
                            bounds: bounds
                        };

                        filtersService.setCenterPlace(center);
                        filtersService.updateURL();
                    }
                });
            }

            function updateUserLocation(moveCenter, force) {
                userLocationService.getUserLocation(force).then(
                    function (location) {
                        if (location) {
                            var centeredOnLocation = $scope.center && ($scope.center.lat == location.latitude) && ($scope.center.lng == location.longitude);

                            if (moveCenter && !centeredOnLocation && !filtersService.getCenterPlace()) {
                                leafletData.getMap(mapID).then(function (map) {
                                    map.panTo(L.latLng(location.latitude, location.longitude));
                                });
                            }
                        }

                        $scope.userLocation = location;
                        addUserMarker($scope.userLocation, $scope);
                    });
            }

            function getObjectsFromItemsSource(filters, skipExtendSearchLocation, centerPlace) {
                var options = {
                    filters: filters,
                    pageSize: frontendSettings.mapMaxObjects,
                    withTotal: true,
                    appendObjects: false
                };

                options.filters.page = 1;
                options.lightFormat = true;

                // update map via map_filter_events
                contentItemsSourceService.update(options).then(function (data) {

                    var extendLocationIfNeed = !skipExtendSearchLocation &&
                        angular.isNumber(extendLocationSettings.currentAccuracyLevel) &&
                        extendLocationSettings.currentAccuracyLevel <= extendLocationSettings.maxAccuracyLevel;

                    var count = angular.isArray(data) ? data.length : data.items.length;

                    $rootScope.mapMaxPage = Math.ceil(count / frontendSettings.pageLimitMap);

                    if (count === 0 && $scope.needUpdateFilter) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ничего не найдено",
                            text: "Уточните условие поиска."
                        });
                        $scope.needUpdateFilter = false;
                    } else if (count > 0 && !$scope.needUpdateFilter) {
                        $scope.needUpdateFilter = true;
                    }

                    processMapObjects(data.items, filters, extendLocationIfNeed, centerPlace);
                });
                // update sidebar via filter_events
                options.lightFormat = false;
                contentItemsSourceService.update(options).then(function(response){
                    var mapObjects = [];
                    if (response && response.items) {
                        mapObjects = response.items;
                    }
                    $rootScope.$emit(mapEvents.OBJECTS_CHANGED, {mapObjects: mapObjects});
                });
            }

            function reloadObjectsFromService(centerPlace, preventResetLocation, skipExtendSearchLocation) {
                if (!$scope.isModeMap()) {
                    return;
                }

                var filters = angular.copy(filtersService.getContentFilters($rootScope.currentFilterContentType));

                if (centerPlace) {
                    filters.centerPlace = centerPlace;
                } else if (!preventResetLocation) {
                    extendLocationSettings.reset();
                }

                if (!filters.centerPlace) {
                    filters.centerPlace = {};
                }

                //remove this properties from request for preventing filtering by center place - T308
                var center = {
                    lat: filters.centerPlace.latitude,
                    lng: filters.centerPlace.longitude
                };

                filters.centerPlace.latitude = null;
                filters.centerPlace.longitude = null;

                angular.extend(filters, {'with_location': true});
                angular.extend(filters, {'ordering': $scope.ordering});

                if (filters.centerPlace.bounds && filters.centerPlace.bounds.northEast && filters.centerPlace.bounds.southWest) {
                    getObjectsFromItemsSource(filters, skipExtendSearchLocation, center);
                }
                else {
                    leafletData.getMap(mapID).then(function (map) {
                        var mapBounds = map.getBounds();
                        var sw = mapBounds.getSouthWest();
                        var ne = mapBounds.getNorthEast();
                        filters.centerPlace.bounds = {
                            southWest: {
                                lat: sw.lat,
                                lng: sw.lng
                            },
                            northEast: {
                                lat: ne.lat,
                                lng: ne.lng
                            }
                        };
                        getObjectsFromItemsSource(filters, skipExtendSearchLocation, centerPlace);
                    });
                }
            }

            function processMapObjects(items, filters, extendLocationIfNeed, centerPlace) {
                if (!items) {
                    $rootScope.loading = false;
                    return;
                }

                var count = items.length;
                console.log('Objects updated, total: ', count);

                if (count === 0 && extendLocationIfNeed) {
                    var center = {
                        lat: (filters.centerPlace && filters.centerPlace.latitude) || (centerPlace && centerPlace.lat),
                        lng: (filters.centerPlace && filters.centerPlace.longitude) || (centerPlace && centerPlace.lng)
                    };
                    placesService.getGeoPlace(center.lat, center.lng, extendLocationSettings.currentAccuracyLevel)
                        .then(
                        function (result) {
                            extendLocationSettings.currentAccuracyLevel += 1;

                            if (result && result.geometry) {
                                extendLocationSettings.cachedBounds = result.geometry.bounds;
                                //mapFitToBounds(extendLocationSettings.cachedBounds);

                                centerPlace = result.geometry.center;
                                centerPlace.bounds = result.geometry.bounds;
                            }

                            var skipExtendLocation = extendLocationSettings.currentAccuracyLevel > extendLocationSettings.maxAccuracyLevel;
                            reloadObjectsFromService(centerPlace, true, skipExtendLocation);
                        },
                        function () {
                            extendLocationSettings.reset();
                            processMapObjects(items, filters, false);
                        });
                } else {
                    $scope.objects = items;
                    if (extendLocationSettings.cachedBounds && count > 0) {
                        mapFitToBounds(extendLocationSettings.cachedBounds);
                    }

                    extendLocationSettings.reset();
                    showObjectsOnMap();
                }
            }

            function toLeafletBounds(bounds) {
                var southWest = L.latLng(bounds.southWest.lat, bounds.southWest.lng);
                var northEast = L.latLng(bounds.northEast.lat, bounds.northEast.lng);
                return L.latLngBounds(southWest, northEast);
            }

            function mapFitToBounds(bounds, map) {
                if (!bounds) {
                    return;
                }

                var fitToBounds = function (m) {
                    m.fitBounds(toLeafletBounds(bounds), {maxZoom: mapSettings.MaxZoom});
                };

                if (map) {
                    fitToBounds(map);
                }
                else {
                    leafletData.getMap(mapID).then(fitToBounds);
                }
            }

            function saveLocateControlLayer(map) {
                var mapLayers = Object.keys(map._layers);
                if (mapLayers.length > 0) {
                    var locateControlIndex = mapLayers[mapLayers.length - 1];
                    locateControlProperties.locateControlLayerID = locateControlIndex;
                    map._layers[locateControlIndex].is_locate_control = true;
                }
            }

            function mapHasLayer(map, layerID) {
                if (layerID && map && map._layers) {
                    var hasLayer = false;
                    angular.forEach(map._layers, function (item) {
                        if (item.is_locate_control) {
                            hasLayer = true;
                        }
                    });
                    return hasLayer;
                }
                return false;
            }

            function addLocateControl(map) {
                if (locateControlProperties.addingLocateControlInProgress) {
                    return;
                }

                locateControlProperties.addingLocateControlInProgress = true;
                var settings = angular.extend(mapSettings.DefaultLocateControlSettings, {
                    OnLocationError: userLocationService.showWarningIfGeolocationNotAvailable
                });
                if (map) {
                    L.control.locate(settings).addTo(map);
                    saveLocateControlLayer(map);
                    locateControlProperties.addingLocateControlInProgress = false;
                }
                else {
                    leafletData.getMap(mapID).then(function (m) {
                        L.control.locate(settings).addTo(m);
                        saveLocateControlLayer(m);
                        locateControlProperties.addingLocateControlInProgress = false;
                    });
                }
            }

            $scope.layoutMap = function () {
                leafletData.getMap(mapID).then(function (map) {
                    map.invalidateSize({debounceMoveend: true, animate: true});
                });
            };

            $scope.$onRootScope(mapEvents.INVALIDATE_LAYOUT, $scope.layoutMap);

            function getCenterPlace(location) {
                var centerPlace = angular.copy(filtersService.getCenterPlace());
                if (!centerPlace) {
                    centerPlace = (savedFilters && savedFilters.centerPlace) ? angular.copy(savedFilters.centerPlace) : location;
                }
                else if (!centerPlace.center) {
                    centerPlace.center = {
                        latitude: centerPlace.latitude,
                        longitude: centerPlace.longitude
                    };
                }
                return centerPlace;
            }

            var mapInitInProgress = false;

            function initializeMap() {
                if ($scope.isMapInitDone || mapInitInProgress === true) {
                    return;
                }

                mapInitInProgress = true;
                mapService.getDefaultLocation().then(function (location) {
                    var centerPlace = getCenterPlace(location);
                    savedFilters = {};

                    var map = mapService.getDefaultMap(mapSettings.DefaultMapLayers, centerPlace, true);


                    initMapCentrator();
                    angular.extend($scope, map);

                    $scope.isMapLoaded = true;


                    leafletData.getMap(mapID).then(function (map) {

                        if (!map.hasEventListeners('startfollowing')) {
                            map.on('startfollowing', function () {
                                userLocationService.showWarningIfGeolocationNotAvailable();
                                updateUserLocation(false, true);
                            });
                        }

                        if (!map.hasEventListeners('autopanstart')) {
                            map.on('autopanstart', _.debounce(function () {
                                $scope.skipMapEvents += 1;
                            }, 500, {leading: true, trailing: false}));
                        }

                        if (!$scope.isMapInitDone) {

                            if (!mapHasLayer(map, locateControlProperties.locateControlLayerID)) {
                                addLocateControl(map);
                            }

                            updateMapCenter(centerPlace, map);
                            updateUserLocation(false);

                            filtersService.setCenterPlace(centerPlace);
                            filtersService.updateURL();
                            /* 
                             var filtersStopWatch = $scope.$watch(filtersService.getCenterPlace, function (value, old) {
                             if (value === null && old !== null) {
                             filtersStopWatch();
                             filtersService.setCenterPlace(old);
                             filtersService.updateURL();
                             }
                             });
                             */
                            if ($scope.objects !== undefined && $scope.objects.length > 0) {
                                showObjectsOnMap();
                            }

                        }

                        $scope.isMapInitDone = true;
                    });
                }).finally(function () {
                    mapInitInProgress = false;
                });
            }

            $rootScope.$watch('currentFilterMode', function (value, old) {

                var switchingToMap = contentSettings.MODE.MAP === value,
                    switchingFromMap = contentSettings.MODE.MAP === old;

                $scope.skipMapEvents += 1;
                $rootScope.loading = true;

                if (!switchingToMap && switchingFromMap) {
                    savedFilters.centerPlace = angular.copy(filtersService.getCenterPlace());
                }

                if (switchingToMap && !$scope.isMapInitDone) {
                    initializeMap();
                }

                if (switchingToMap && !switchingFromMap) {

                    console.log("Current MODE changed! MAP", value, old);

                    leafletData.getMap(mapID).then(function (map) {
                        if (!mapHasLayer(map, locateControlProperties.locateControlLayerID)) {
                            addLocateControl(map);
                        }

                        mapService.getDefaultLocation().then(function (location) {
                            var centerPlace = getCenterPlace(location);

                            filtersService.setCenterPlace(centerPlace);
                            filtersService.updateURL();
                            $rootScope.loading = false;


                        });
                    });
                }
            });

            $scope.$watch('currentFilterContentType', function () {
                if (!$scope.isMapInitDone) {
                    return;
                }
                reloadObjectsFromService(null, null, true);
            });

            $scope.onSwitchSidebar = function (state, isActive) {
                $scope.$emit(mapEvents.SIDEBAR_SWITCHED, {state: state, isOpened: !isActive});
                leafletData.getMap(mapID).then(function (map) {
                    map.invalidateSize(false);
                });

            };

            initializeMapEvents();
            initializeScopeEvents();
        }

    ]);

})();
