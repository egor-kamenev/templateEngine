(function(){
'use strict';

angular.module('auth', [
        'auth.login',
        'auth.logout',
        'auth.recovery'
    ]).config([
        "$stateProvider",
        function ($stateProvider) {
            $stateProvider.state('auth', {
                url: '/auth',
                parent: "root",
                abstract: true,
                templateUrl: '/static/partials/auth/partials/auth.html',
                title: 'PAGE_TITLE_AUTH_LOGIN',
                data: {
                    breadcrumbParent: 'home'
                }
            });
        }]);

})();