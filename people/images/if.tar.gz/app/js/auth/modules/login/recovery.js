(function(){
'use strict';

angular.module('auth.recovery', [
        'auth.recovery.controllers'
]).config([
        "$stateProvider",
        function ($stateProvider) {
            $stateProvider.state('auth.recovery', {
                url: '/recovery',
                controller: "RecoveryCtrl",
                templateUrl: '/static/partials/auth/modules/login/partials/recovery.html'
            })
            .state('auth.recovery2',{
                url: '/recovery/:token',
                controller: 'RecoveryPwdCtrl',
                templateUrl: '/static/partials/auth/modules/login/partials/recovery_pwd.html'
            });
        }]);

})();

/*
*
* */