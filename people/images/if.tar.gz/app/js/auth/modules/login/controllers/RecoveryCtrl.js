(function () {
    'use strict';

    angular.module('auth.recovery.controllers', []).controller("RecoveryCtrl", [
        '$scope', '$q', '$state', '$stateParams', 'userService', 'contactsService',
        function ($scope, $q, $state, $stateParams, userService, contactsService) {

            contactsService.getTypes({'is_password_recovery': true}).then(
                function (data) {
                    $scope.contactTypes = data;
                    if (data.length > 0) {
                        $scope.initPswRestore = data[0].id || 0;
                    }
                },
                function () {
                    $scope.contactTypes = [];
                }
            );

            $scope.contact_value = $scope.contact_type = null;
            // #953
            $scope.initPswRestore = {
                username: '',
                code: '',
                password: '',
                password2: '',
                value: '',
                type: 0
            };
            $scope.pswrestore = angular.copy($scope.initPswRestore);

            if ($stateParams.token) {
                getEmailByToken($stateParams.token);
            }

            $scope.sendPswRestoreCode = function () {
                console.log("sendPswRestoreCode", $scope.pswrestore);
                console.log(userService.sendPasswordRestoreCode);
                userService.sendPasswordRestoreCode($scope.pswrestore.value, $scope.pswrestore.type).then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Error",
                                text: data.error.data.msg
                            });
                        } else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Done",
                                text: "Код восстановления пароля был отправлен"
                            });
                        }
                    },
                    function () {
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Error",
                            text: "Server error"
                        });
                    }
                );
            };
        }
    ]);

})();