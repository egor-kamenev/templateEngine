(function(){
    'use strict';
    /**
     * Controller of input new passwords state
     * REF: T953
     * @package auth.recovery.controllers
     */
    angular.module('auth.recovery.controllers')
        .controller('RecoveryPwdCtrl', [
            '$scope', '$q', '$state', '$stateParams', 'userService',
            'contactsService', 'jsonRPC', 'Service404',
            function($scope, $q, $state, $stateParams, userService,
                     contactsService, jsonRPC, Service404) {

                /**
                 * Internal function
                 * Return clean pwsrestore model
                 * This function used instead of $scope.pswrestore = angular.copy($scope.initPswRestore);
                 */
                var getInitialData = function() {
                    return {
                        username: '',
                        password: '',
                        password2: '',
                        value: '',
                        code: '',
                        type: ''
                    };
                };

                /* model */
                $scope.pswrestore = getInitialData();

                /**
                 * Submit form
                 */
                $scope.changePassword = function () {
                    console.log("changePassword for ", $scope.pswrestore.value);

                    var deferred = $q.defer();

                    userService.changePasswordByContact(
                        $scope.pswrestore.code,
                        $scope.pswrestore.password,
                        $scope.pswrestore.password2,
                        $scope.pswrestore.value,
                        $scope.pswrestore.type
                    ).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isFormError(data.error)) {
                                    deferred.reject(data.error.data);
                                }
                                else if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Error",
                                        text: data.error.data.msg
                                    });
                                    deferred.reject();
                                }
                            } else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Done",
                                    text: "Password changed"
                                });
                                deferred.resolve();
                                $scope.pswrestore = angular.copy($scope.initPswRestore);
                                $scope.isChangePasswordDialogOpen = false;
                                $state.go('auth.login');
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Error",
                                text: "Server error"
                            });
                            deferred.reject();
                        }
                    );
                    return deferred.promise;
                };

                /**
                 * if token is wrong...
                 * D.R.Y.
                 */
                var open404 = function() {
                    Service404.setMessage('Код восстановления пароля указан не верно или срок его использования истек.');
                    $state.go('404');
                };

                /**
                 * Cancel button click handler
                 * If user want to cancel input data, then his will redirected to login state
                 */
                $scope.cancelSetNewPwd = function() {
                    $state.go('auth.login');
                };

                /**
                 * Get user email by token via backend API
                 * @param token received from state params
                 */
                function getEmailByToken(token) {
                    var data = {
                        token: token
                    };

                    jsonRPC.request('users.get_email_by_token', data).then(
                        function (data) {
                            if (data.error) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Sign up error",
                                    text: data.error.data.msg
                                });
                                open404();
                            }
                            else {
                                $scope.pswrestore.code = token;
                                $scope.pswrestore.value = data.result;
                                $scope.pswrestore.type = 0;

                            }
                        }
                    );
                }

                if ($stateParams.token) {
                    getEmailByToken($stateParams.token);
                } else {
                    // noob opened the page from email without any token...
                    open404();
                }
            }
        ]);
})();
