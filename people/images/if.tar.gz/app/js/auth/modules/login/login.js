(function(){
'use strict';

angular.module('auth.login', ['auth.login.controllers']).config([
    "$stateProvider",
        function ($stateProvider) {
            $stateProvider.state('auth.login', {
                url: '/login',
                controller: "LoginCtrl",
                templateUrl: '/static/partials/auth/modules/login/partials/login.html'
            });
        }]);

})();