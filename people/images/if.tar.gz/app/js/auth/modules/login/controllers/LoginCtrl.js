(function () {
    'use strict';

    angular.module('auth.login.controllers', [])
        .controller("LoginCtrl", [
            '$scope', '$rootScope', '$q', '$state', '$timeout', 'userService', 'contactsService',
            function ($scope, $rootScope, $q, $state, $timeout, userService, contactsService) {

                angular.element('#id_username').focus();

                contactsService.getTypes().then(function (data) {
                    $scope.contactTypes = data;
                });

                $scope.contactTypes = [];
                $scope.contact_value = $scope.contact_type = null;
                $scope.credentials = {
                    username: '',
                    password: '',
                    confirmation_code: ''
                };
                $scope.show_conf_code = false;
                $scope.errorsShown = false;

                $scope.sendLoginConfCode = function () {
                    userService.sendLoginConfirmationCode($scope.credentials.username, $scope.contact_type).then(
                        function (data) {
                            if (data.error) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            } else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Done",
                                    text: "Confirmation code sent"
                                });
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Error",
                                text: "Server error"
                            });
                        }
                    );
                };

                $scope.login = function () {

                    var deferred = $q.defer();

                    var onSuccess = function (data) {
                        if (data.error) {

                            if (data.error.data.__all__[0] == 'inactive') {
                                $state.go('401');
                            }

                            deferred.reject(data.error.data);
                        }
                        else {
                            if (data.result.success) {
                                // Everything is ok
                                userService.setUserData(data.result);
                                userService.setFriends(data.result.friends);
                                userService.initialSubscribe();
                                $scope.credentials = {
                                    username: '',
                                    password: '',
                                    confirmation_code: ''
                                };

                                $rootScope.$emit("event:user.loggedIn", data.result);

                                // IMPORTANT: force reload of all states from parent to child
                                // and resolve again all resolved data
                                // we can renew authenticatedUser resolve dependency only this way
                                $state.transitionTo(
                                    "user.wall",
                                    {username: data.result.user.username},
                                    {reload: true, inherit: true, notify: true}
                                );

                                deferred.resolve();
                            }
                            else {
                                $scope.show_conf_code = data.result.confirmation_required;
                                console.log($scope.show_conf_code);
                            }
                        }
                    };


                    var onError = function (response) {
                        var isBanned = response.status == 403 && response.data.indexOf("You are banned") > 0;
                        if (isBanned) {
                            var errors = {
                                __all__: ['banned']
                            };
                            deferred.reject(errors);
                        }
                        else {
                            deferred.reject();
                        }

                    };

                    // Send to server
                    userService.login($scope.credentials).then(onSuccess, onError);
                    return deferred.promise;
                };

                $scope.passwordAutofillCheck = function () {

                    $timeout(function () {
                        var modelValue = $scope.credentials.password,
                            fieldValue = angular.element('#id_password').val();
                        if (fieldValue && modelValue != fieldValue) {
                            $scope.credentials.password = fieldValue;
                        }
                    }, 500);
                };

            }]);

})();
