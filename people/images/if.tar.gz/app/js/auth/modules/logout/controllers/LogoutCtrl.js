(function(){
angular.module('auth.logout.controllers', []).controller("LogoutCtrl", [
    '$scope', '$q', '$rootScope', '$state', '$cookies', 'userService', 'contactsService', 'socketio', 'channelService',
    function ($scope, $q, $rootScope, $state, $cookies, userService, contactsService, socketio, channelService) {
        channelService.reset();

        userService.logout().then(
            function (response) {
                if (response.error) {
                    console.log("Logout error");
                    $scope.logoutDone = false;
                }
                else {
                    delete $cookies.csrftoken;
                    delete $cookies.sessionid;
                    $rootScope.$emit("event:user.loggedOut", {});
                    userService.setUserData(response.result);
                    
                    $scope.logoutDone = true;
                    $state.go("content");//response.result.url_redirect);
                }
            },
            function () {
                console.log("Logout rpc error");
                $scope.logoutDone = false;
            }
        );

    }]);

})();