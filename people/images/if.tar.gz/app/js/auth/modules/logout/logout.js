(function(){
'use strict';

angular.module('auth.logout', [
        'auth.logout.controllers'
]).config([
        "$stateProvider",
        function ($stateProvider) {
            $stateProvider.state('auth.logout', {
                url: '/logout',
                controller: "LogoutCtrl",
                templateUrl: '/static/partials/auth/modules/logout/partials/logout.html'
            });
        }]);

})();