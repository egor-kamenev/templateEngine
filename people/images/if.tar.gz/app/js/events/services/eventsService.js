(function(){
angular.module('events.services', []).
    service('eventsService', ['$rootScope', 'jsonRPC', 'userbanService', '$q', 'jqPaginationSettings', 'permissionRequired', function ($rootScope, jsonRPC, userbanService, $q, jqPaginationSettings, permissionRequired) {

        var self = this;
        //self._events = [];
        //self._needs_loading = true;

        this._lastUsedFilter = null;
        this._cachedEvents = [];
        this._cachedStreamEvents = [];
        this._clibboardEvent = null;

        this.EVENT_TYPE_VIRTUAL = 101;
        this.RESOURCE_TYPES = {
            INVITATION: 0,
            OTHER: 1
        };

        // initial filter parameters
        // moment.js is nice, dude!
        //var today = moment();

        // initial daterange
        /*
         var initial_daterange = {
         start_ts: today.startOf('day').unix(),
         end_ts: today.endOf('day').unix(),
         str: today.format('MM/DD/YYYY') + ' - ' + today.format('MM/DD/YYYY'),
         start_time_str: '00:00',
         end_time_str: '23:59'
         };

         var initial_filter = {
         daterange: initial_daterange,
         authors: [],
         participants: [],
         tags: [],
         bounds: null,
         do_filter_my: false,
         do_filter_friends: false
         };

         self.filter = angular.copy(initial_filter);

         this.isFilterSet = function(){
         var filter = self.filter;
         return self.filter.text || filter.tags.length || filter.authors.length || filter.participants.length || filter.daterange || filter.do_filter_my || filter.do_filter_friends;
         };
         */

        //function toUTC(t) {
        //    return new Date(t.getTime() + t.getTimezoneOffset() * 60000);
        //}

        /*
         this.setFilterMapBounds = function(b){

         // This is for the center
         var southWest = new L.LatLng(b.southWest.lat, b.southWest.lng);
         var northEast = new L.LatLng(b.northEast.lat, b.northEast.lng);
         var leafletBounds = new L.LatLngBounds(southWest, northEast);

         self.filter.bounds = {
         ne: {
         lat: b.northEast.lat,
         lng: b.northEast.lng
         },
         sw: {
         lat: b.southWest.lat,
         lng: b.southWest.lng
         },
         bounds: b,
         center: leafletBounds.getCenter()
         };
         };

         this.setFilterDaterange = function(start_date, end_date){
         var m1 = moment(start_date);
         var m2 = moment(end_date);
         self.filter.daterange.start_ts = m1.unix();
         self.filter.daterange.end_ts = m2.unix();
         self.filter.daterange.str = m1.format('MM/DD/YYYY') + ' - ' + m2.format('MM/DD/YYYY');
         };

         this.debug = function(){
         console.log("INITIAL: ", initial_filter);
         console.log("CURRENT: ", self.filter);
         };

         this.resetDaterange = function(){
         self.filter.daterange = angular.copy(initial_daterange);
         return self.filter;
         };

         this.resetMapBounds = function(){
         self.filter.bounds = null;
         return self.filter;
         };

         this.getDaysRangeNumber = function(){
         var m1 = moment.unix(self.filter.daterange.start_ts);
         var m2 = moment.unix(self.filter.daterange.end_ts);
         return Math.abs(m1.diff(m2, 'days'));
         };

         this.resetFilter = function(){
         self.filter = angular.copy(initial_filter);
         return self.filter;
         };
         */

        this.isVirtual = function (event) {
            return event == self.EVENT_TYPE_VIRTUAL;
        };

        this.copyToClipboard = function (event) {
            self._clibboardEvent = angular.copy(event);
            if (!self._clibboardEvent.place) {
                self._clibboardEvent.place = self.EVENT_TYPE_VIRTUAL;
            }
        };

        this.getClipboard = function () {
            return self._clibboardEvent;
        };

        this.resetClipboard = function () {
            self._clibboardEvent = null;
        };

        this.acceptInviteByToken = function (token) {
            return jsonRPC.request('events.accept_bun_request', {token: token});
        };

        this.rejectInviteByToken = function (token) {
            return jsonRPC.request('events.reject_bun_request', {token: token});
        };

        this.eventPlaceChangesHistory = function (event_alias, page) {
            var data = {
                event_alias: event_alias,
                page: page,
                page_size: jqPaginationSettings.limit,
                with_total: true
            };
            return jsonRPC.request('events.get_event_place_changes', data);
        };

        this.processEventForFrontend = function (e) {
            // Add 'title' property - for calendar
            e.title = e.name;
            //e.allDay = e.all_day_long;
            //delete e.url;

            // Convert timestamp strings to Date objects
            e.ts_start = new Date(e.ts_start);
            //e.ts_start_utc = toUTC(e.ts_start);

            if (e.ts_finish) {
                e.ts_finish = new Date(e.ts_finish);
                //e.ts_finish_utc = toUTC(e.ts_finish);
            }

            // Add 'start' and 'end' properties (for the calendar widget)
            // they are not dates, they are timestamps (int)
            e.start = e.ts_start.getTime() / 1000;
            if (e.ts_finish) {
                e.end = e.ts_finish.getTime() / 1000;
            }
            else {
                // For events without end date we set finish date to now() + 1 year,
                // so they become visible in the calendar
                var yearFromStart = new Date(new Date(e.ts_start).setMonth(e.ts_start.getMonth() + 12));
                e.end = yearFromStart.getTime() / 1000;
                //e.end = yearFromStart.getTime()/1000 - o;
            }
            return e;
        };

        this.processEventsForFrontend = function (events) {
            // Post process events
            angular.forEach(events, function (e) {
                self.processEventForFrontend(e);
            });
            return events;
        };

        this.needsReloading = function (f) {
            return !angular.equals(self._lastUsedFilter, f);
        };

        this.saveCache = function (events) {
            self._cachedEvents = angular.copy(events);
        };

        this.getCache = function () {
            return self._cachedEvents;
        };

        this.saveStreamCache = function (events) {
            self._cachedStreamEvents = angular.copy(events);
        };

        this.getStreamCache = function () {
            return self._cachedStreamEvents;
        };

        this.getObjectsByParams = function (params, useLightFormat) {
            // @deprecated events.filter_events
            return jsonRPC.request(!!useLightFormat && 'events.map_filter_events' || 'events.filter_events');
        };

        this.getObjects = function (filters, forceReload, page, pageSize, withTotal, useLightFormat) {
            var data = {
                filters: filters,
                page: page,
                page_size: pageSize,
                with_total: withTotal
            };
            data.filters.page = page;

            if (self.needsReloading(filters) || forceReload) {
                self._lastUsedFilter = angular.copy(filters);
                return self.getObjectsByParams(data, useLightFormat);
            }

            var deferred = $q.defer();
            deferred.resolve({result: self.getCache()});
            return deferred.promise;
        };

        this.getStream = function (filters, forceReload, page, pageSize, withTotal) {

            var data = {
                filters: filters,
                page: page,
                page_size: pageSize,
                with_total: withTotal
            };

            if (self.needsReloading(filters) || forceReload) {
                self._lastUsedFilter = angular.copy(filters);
                return jsonRPC.request('events.stream_events', data);
            }

            var deferred = $q.defer();
            deferred.resolve({result: self.getStreamCache()});
            return deferred.promise;
        };
        /*
         this.setFilter = function(filter){
         self.filter = filter;
         };

         this.getFilter = function(){
         return self.filter;
         };

         this.getEvents = function(){
         return self._events;
         };

         this.needsLoading = function(){
         return self._needs_loading && self._events.length == 0;
         };

         this.reloadEvent = function(){
         };
         */

        this.getEvent = function (a) {

            var data = {
                event_alias: a
            };

            return jsonRPC.request('events.get_event', data);
        };

        this.editEvent = permissionRequired('events.change_event', function (event_id, event_data) {
            var data = {
                event_id: event_id
            };
            angular.extend(data, event_data);
            return jsonRPC.request('events.edit_event', data);
        });

//        this.reloadEvents = function (inplace_filter_params, callback) {
//
//            self._needs_loading = false;
//
//            // inplace_filters is a special filter parameters
//            // they aren't stored in the service's filter
////    var data = self.filter;
//            var data = {};
//            if (inplace_filter_params) {
//                data = angular.copy(inplace_filter_params);
////        angular.extend(data, inplace_filter_params);
//            }
//            jsonRPC.request('events.top_events', data).then(
//                function (data) {
//                    if (data.error) {
//                        self._events = [];
//                    }
//                    else {
//                        self._events = self.processEventsForFrontend(data.result);
//                        if (callback) {
//                            callback(self._events);
//                        }
//                    }
//                    $rootScope.$emit('event_eventsChanged');
//                },
//                function (data) {
//                    console.log("eventsService: load failed");
//                }
//            );
//        };

        //this.asyncUnreadBunRequests = function () {
        //    return jsonRPC.request('events.get_unread_bun_requests');
        //};

        this.changeVisibility = function (data) {
            return jsonRPC.request('events.set_event_visibility', data);
        };

        this.addEvent = permissionRequired('events.add_event', function (data) {
            return jsonRPC.request('events.add_event', data);
        });

        this.deleteEvent = permissionRequired('events.delete_event', function (event_id) {
            var data = {event_id: event_id};
            return jsonRPC.request('events.delete_event', data);
        });

        this.disableEvent = function (event_id) {
            var data = {event_id: event_id};
            return jsonRPC.request('events.disable_event', data);
        };

        this.finishEvent = function (event_id) {
            var data = {event_id: event_id};
            return jsonRPC.request('events.finish_event', data);
        };

        this.getResources = function (event_alias) {
            var data = {event_alias: event_alias};
            return jsonRPC.request('events.get_event_buns', data);
        };

        this.addResource = function (data) {

            // To support old API where 'resources' are 'buns'
            if (data.resource_type) {
                data.bun_type = data.resource_type.value;
                delete data.resource_type;
            }

            return jsonRPC.request('events.add_event_bun', data);
        };

        this.removeResource = function (resourceID) {
            return jsonRPC.request('events.delete_event_bun', {event_bun_id: resourceID});
        };

        this.isInvitationResource = function (resource) {
            return resource.bun_type == self.RESOURCE_TYPES.INVITATION;
        };

        this.getResourcesRecipients = function (data) {
            return jsonRPC.request('events.get_users_for_buns', data);
        };

        this.createResourceOffers = function (data) {
            return jsonRPC.request('events.add_new_event_bun_requests', data);
        };

        this.sendResourceOffers = function (resourceID, offers) {

            var data = {
                bun_id: resourceID,
                bun_requests: angular.copy(offers)
            };

            return jsonRPC.request('events.send_event_bun_requests', data);
        };

        this.getInvitableUsers = function (query, resourceId) {
            var data = {
                text: query,
                bun_id: resourceId
            };
            return jsonRPC.request('events.get_invitable_users', data);
        };

        this.getResourceOffers = function (resourceID) {
            return jsonRPC.request('events.get_event_bun_requests', {bun_id: resourceID});
        };

        this.removeResourceOffer = function (offerID) {
            return jsonRPC.request('events.delete_event_bun_request', {id: offerID});
        };

        this.rejectResourceRequest = function (requestId) {
            return jsonRPC.request('events.reject_invite_request', {request_id: requestId});
        };

        this.acceptResourceRequest = function (request) {
            var data = {
                request_id: request.id,
                amount: request.amount,
                text: request.text
            };
            return jsonRPC.request('events.accept_invite_request', data);
        };

        this.getResourceRequests = function (eventAlias, resourceID, page) {

            // TODO: now it always returns invite requests only
            var data = {
                event_alias: eventAlias,
                page: page,
                page_size: jqPaginationSettings.limit,
                with_total: true

                //resource_id: resourceID
            };
            return jsonRPC.request('events.get_invite_requests', data);
        };

        this.getEventParticipants = function (eventID, page) {
            var data = {
                event_id: eventID,
                page: page,
                page_size: jqPaginationSettings.limit,
                with_total: true
            };
            return jsonRPC.request('events.get_participants_list', data);
        };

        this.getPlaceParticipants = function (PlaceID, page) {
            var data = {
                place_id: PlaceID,
                page: page,
                page_size: jqPaginationSettings.limit,
                with_total: true
            };
            return jsonRPC.request('places.get_participants_list', data);
        };


        /*
         this.acceptResourceOffer = function(resourceOffer){
         var data = {
         request_id: resourceOffer.bun_id,
         amount: resourceOffer.amount,
         text: resourceOffer.text
         };

         return jsonRPC.request('events.accept_invite_request', data);

         };
         */

        this.getUserSelectorForResource = function (resourceId) {
            return {
                choices: [],
                query: function (searchTerm) {
                    var selector = this;
                    self.getInvitableUsers(searchTerm, resourceId).then(
                        function (response) {
                            if (response.error) {
                                if ($rootScope.isLogicError(response.error)) {
                                    $rootScope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка запроса пользователей",
                                        text: response.error.data.msg
                                    });
                                }
                                selector.choices = [];
                            }
                            else {
                                selector.choices = angular.copy(response.result);
                            }
                        },
                        function () {
                            selector.choices = [];
                        }
                    );
                }
            };
        };

    }]);

})();
