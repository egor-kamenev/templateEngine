(function () {
    'use strict';
    angular.module('event.checkInOutService', []).service('checkInOutService', [
        '$rootScope', '$q', 'jsonRPC', 'eventUserStates', 'xStates', 'userLocationService', 'userService', '$stateParams', 'verifiedEmailRequired', '$state', 'userSettingsService',
        function ($rootScope, $q, jsonRPC, eventUserStates, xStates, userLocationService, userService, $stateParams, verifiedEmailRequired, $state, userSettingsService) {

            var latitude = null,
                longitude = null,
                currentUser = null;

            userLocationService.getUserLocation().then(function (location) {
                latitude = location.latitude;
                longitude = location.longitude;
            });

            userService.getUser().then(function (user) {
                currentUser = user;
            });

            function onError() {
                $rootScope.$emit("flash", {
                    type: "error",
                    title: "Server error",
                    text: "Sorry, error occurred while submitting. Please try again later."
                });
            }

            function eventMakeCheckIn(item, latitude, longitude) {
                return jsonRPC.request('events.check_in', {
                    event_id: item.id,
                    latitude: latitude,
                    longitude: longitude
                }).then(
                    function (response) {
                        if (response.error) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.error.data.msg
                            });
                        } else {
                            if (!item.user_state) {
                                item.user_state = {};
                            }
                            item.user_state.state = eventUserStates.checkedIn;

                            if ($state.current.name === 'content') {
                                $rootScope.$emit('objectChanged'); // update react list!
                            } else {
                                $rootScope.$emit('needUpdateButtons');
                            }
                            addParticipent(item);
                        }
                    },
                    onError
                );
            }

            function eventMakeCheckOut(item) {
                return jsonRPC.request('events.check_out', {event_id: item.id}).then(
                    function (response) {
                        if (response.error) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.error.data.msg
                            });
                        } else {
                            item.user_state.state = eventUserStates.checkedOut;
                            deleteParticipent(item);
                        }
                    },
                    onError
                );
            }

            function placeMakeCheckIn(item) {
                return jsonRPC.request('events.check_in', {
                    place_id: item.id,
                    visibility: item.visibility
                }).then(
                    function (response) {
                        if (response.error) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.error.data.msg
                            });
                        } else {
                            if (angular.isUndefined($rootScope.user.last_location)) {
                                $rootScope.user.last_location = {};
                            }
                            if (angular.isUndefined($rootScope.user.last_location.place)) {
                                $rootScope.user.last_location.place = {};
                            }
                            $rootScope.user.last_location.place.alias = item.alias;
                            $rootScope.user.last_location.place.formatted_address = item.formatted_address;
                            $rootScope.user.last_location.place.latitude = item.latitude;
                            $rootScope.user.last_location.place.longitude = item.longitude;
                            $rootScope.user.last_location.place.name = item.name;
                            $rootScope.user.last_location.place.id = item.id;
                            addVisitor(item);
                        }
                    },
                    onError
                );
            }

            function placeMakeCheckOut(item) {
                return jsonRPC.request('events.check_out', {place_id: item.id}).then(
                    function (response) {
                        if (response.error) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.error.data.msg
                            });
                        } else {
                            delete $rootScope.user.last_location.place;
                            deleteVisitor(item);
                        }
                    },
                    onError
                );
            }

            function goToEvent(item, latitude, longitude) {
                var data = {
                    event_id: item.id,
                    latitude: latitude,
                    longitude: longitude
                };

                return jsonRPC.request('events.go_to_event', data).then(
                    function (response) {
                        if (response.error) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.error.data.msg
                            });
                        } else {
                            if (!item.user_state) {
                                item.user_state = {};
                            }
                            item.user_state.state = eventUserStates.intended;
                            addParticipent(item);
                            $rootScope.$emit('goToEvent', item.id);
                            if ($state.current.name === 'content') {
                                $rootScope.$emit('objectChanged'); // update react list!
                            } else {
                                $rootScope.$emit('needUpdateButtons');
                            }
                        }
                    },
                    onError
                );
            }

            function iWasNotThere(item) {
                return jsonRPC.request('events.was_not_there', {event_id: item.id}).then(
                    function (response) {
                        if (response.errors) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.errors
                            });
                        } else {
                            delete item.user_state;
                            deleteParticipent(item);
                            $rootScope.$emit('cancelVisit', item.id);
                        }
                    },
                    onError
                );
            }

            function askInvite(item) {
                return jsonRPC.request('events.ask_invite', {event_id: item.id}).then(
                    function (response) {
                        if (response.error) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.error.data.msg
                            });
                        } else {
                            item.invite_request = {state: xStates.sent};
                        }
                    },
                    onError
                );
            }

            function iNotGoingThere(item) {
                return jsonRPC.request('events.not_going_there', {event_id: item.id}).then(
                    function (response) {
                        if (response.error) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Request failed",
                                text: response.error.data.msg
                            });
                        } else {
                            item.user_state.state = eventUserStates.wasNotThere;
                            deleteParticipent(item);
                        }
                    },
                    onError
                );
            }

            function deleteParticipent(item) {
                if (!angular.isUndefined($stateParams.event_alias)) return;

                if (item.participants.length === 1) {
                    item.participants = null;
                    return;
                }

                if (item.is_going) {
                    item.participants_now = --item.participants_now;
                }

                for (var i = 0; i < item.participants.length; i++) {
                    if (item.participants[i].id == currentUser.id) {
                        item.participants.splice(i, 1);
                        item.participants_num = --item.participants_num;
                        break;
                    }
                }
            }

            function deleteVisitor(item) {
                if (!angular.isUndefined($stateParams.place_alias)) return;

                if (item.visitors.length === 1) {
                    item.visitors = null;
                    return;
                }

                for (var i = 0; i < item.visitors.length; i++) {
                    if (item.visitors[i].id == currentUser.id) {
                        item.visitors.splice(i, 1);
                        break;
                    }
                }
            }

            function addParticipent(item) {
                if (!angular.isUndefined($stateParams.event_alias)) return;

                var user = {
                    id: currentUser.id,
                    username: currentUser.username,
                    avatar: currentUser.avatar,
                    user: {
                        username: currentUser.username,
                        first_name: currentUser.first_name,
                        last_name: currentUser.last_name,
                        middle_name: currentUser.middle_name
                    }
                };

                if (!item.participants) {
                    item.participants = [];
                } else {
                    for (var i = 0; i < item.participants.length; i++) {
                        if (item.participants[i].id == currentUser.id) return;
                    }
                }

                if (item.is_going) {
                    item.participants_now = ++item.participants_now;
                }

                item.participants_num = ++item.participants_num;

                item.participants.push(user);
            }

            function addVisitor(item) {
                if (!angular.isUndefined($stateParams.place_alias)) return;

                var user = {
                    id: currentUser.id,
                    username: currentUser.username,
                    avatar: currentUser.avatar,
                    user: {
                        username: currentUser.username,
                        first_name: currentUser.first_name,
                        last_name: currentUser.last_name,
                        middle_name: currentUser.middle_name
                    }
                };

                if (!item.visitors) {
                    item.visitors = [];
                } else {
                    for (var i = 0; i < item.visitors.length; i++) {
                        if (item.visitors[i].id == currentUser.id) return;
                    }
                }

                item.visitors.push(user);
            }

            return {
                cancelVisit: verifiedEmailRequired(function (item) {
                    return cancelVisit(item);
                }),
                placeHandler: verifiedEmailRequired(function (item) {
                    if ($rootScope.user.last_location && $rootScope.user.last_location.place && ($rootScope.user.last_location.place.id === item.id)) {
                        return placeMakeCheckOut(item);
                    } else {
                        return placeMakeCheckIn(item);
                    }
                }),
                handler: verifiedEmailRequired(function (item, action) {
                    switch (action) {
                        case 'eventMakeCheckIn':
                            return eventMakeCheckIn(item, latitude, longitude);
                        case 'eventMakeCheckOut':
                            return eventMakeCheckOut(item);
                        case 'askInvite':
                            return askInvite(item);
                        case 'iWasNotThere':
                            return iWasNotThere(item);
                        case 'iNotGoingThere':
                            return iNotGoingThere(item);
                        case 'goToEvent':
                            // if event is going and user have not state
                            // user must have choice dot checkin or `go to event`
                            if (item.is_going && !item.user_state) {
                                userSettingsService.getEventsParticipationSettings().then(
                                    function(settings){

                                        var autoCheckIn = angular.isObject(settings.result) &&
                                                angular.isObject(settings.result.enable_auto_check_in) &&
                                                settings.result.enable_auto_check_in.value === true,
                                            promise = autoCheckIn ?
                                                $q.defer():
                                                $rootScope.confirm("Мероприятие уже началось, хотите сразу зачекиниться?");

                                        if(autoCheckIn){
                                            promise.resolve();
                                            promise = promise.promise;
                                        }
                                        promise.then(
                                            function () {
                                                return eventMakeCheckIn(item, latitude, longitude);
                                            },
                                            function () {
                                                return goToEvent(item, latitude, longitude);
                                            }
                                        );
                                    },
                                    function(){
                                        return goToEvent(item, latitude, longitude);
                                    }
                                );
                            } else {
                                return goToEvent(item);
                            }
                            break;
                        default:
                            console.log('unknown action:', action);
                    }
                }),
                // T968
                getButtons: function (viewer, eventState, eirState, ebrState, userState) {
                        // viewr - user
                        // eventState - event entity
                        // eirState - event invite request state or null
                        // ebrState - event bun request state or null
                        // userState - user state to this event or null

                        var stateToResultMap = [

                            // вас не позвали
                            // по приглашениям
                            // не закочилось
                            // просил приглос, но не дали
                            {
                                userHaveState: function (userState) {
                                    return !userState;
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return eventState.by_invitation;
                                },
                                userHaveEbr: null,
                                userHaveEir: function(eir) {
                                    return eir && eir.state == xStates.rejected;
                                },
                                result: [
                                    {
                                        btnDisabled: true,
                                        btnText: 'Вас не позвали'
                                    },
                                ]
                            },

                            // запросить приглашение
                            // по приглашениям
                            // не закочилось
                            // нету приглоса
                            // еще не просил
                            {
                                userHaveState: function (userState) {
                                    return !userState;
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return eventState.by_invitation;
                                },
                                userHaveEbr: function(ebr, viewer, eventState) {
                                    return !ebr && viewer.username != eventState.owner.username;
                                },
                                userHaveEir: function(eir) {
                                    return !eir;
                                },
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Запросить приглашение',
                                        btnCss: 'checkin-get-invitation',
                                        btnAction: 'askInvite'
                                    },
                                ]
                            },

                            // ожидание приглашения
                            // по приглашениям
                            // не закончилось
                            // приглоса еще нет
                            // просил приглос
                            {
                                userHaveState: function (userState) {
                                    return !userState;
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return eventState.by_invitation;
                                },
                                userHaveEbr: function(ebr, viewer, eventState) {
                                    return !ebr && viewer.username != eventState.owner.username;
                                },
                                userHaveEir: function(eir) {
                                    return eir && eir.state == xStates.sent;
                                },
                                result: [
                                    {
                                        btnDisabled: true,
                                        btnText: 'Ожидание приглашения',
                                    },
                                ]
                            },

                            // принять участие - "я пойду"
                            // открытое
                            // не закончилось
                            // еще не участвовал или не говорил что "я пойду"
                            // все равно есть ли приглос
                            // все равно просил ли (хотя нельзя просить приглос на открытое мероприятие)
                            {
                                userHaveState: function (userState) {
                                    return !userState || (
                                        userState &&
                                        userState.state != eventUserStates.intended &&
                                        userState.state != eventUserStates.checkedIn &&
                                        userState.state != eventUserStates.checkedOut
                                    );
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return !eventState.by_invitation;
                                },
                                userHaveEbr: null,
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я пойду',
                                        btnCss: 'checkin-will-go',
                                        btnAction: 'goToEvent'
                                    },
                                ]
                            },

                            // принять участие - "я пойду"
                            // по приглашениям
                            // не закончилось
                            // для владельца, который сказал что не пойдет или не имеет стейта
                            {
                                userHaveState: function (userState) {
                                    return !userState || (
                                        userState && 
                                        userState.state == eventUserStates.wasNotThere
                                    );
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return eventState.by_invitation;
                                },
                                userHaveEbr: function (ebr, viewer, eventState) {
                                    return viewer.username == eventState.owner.username;
                                },
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я пойду',
                                        btnCss: 'checkin-will-go',
                                        btnAction: 'goToEvent'
                                    },
                                ]
                            },
 
                            // принять участие - "я пойду", "я не пойду"
                            // по приглашениям
                            // не закончилось
                            // если есть приглос и он не отклонен и не принят
                            // я пойду - принять приглос автоматом
                            // я не пойду - отклонить приглос
                            {
                                userHaveState: function (userState) {
                                    return !userState || (
                                        userState &&  (
                                            userState.state == eventUserStates.unreadBunRequest ||
                                            userState.state == eventUserStates.readBunRequest
                                        )
                                    );
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return eventState.by_invitation;
                                },
                                userHaveEbr: function (ebr) {
                                    return ebr && ebr.state == xStates.sent;
                                },
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я пойду (принять приглашение)',
                                        btnCss: 'checkin-will-go',
                                        btnAction: 'goToEvent'
                                    },
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я не пойду (отказаться от приглашения)',
                                        btnCss: 'checkin-will-not-go',
                                        btnAction: 'iNotGoingThere'
                                    },
                                ]
                            },

                            // закончилось - "я там был"
                            // открытое
                            // если не говорил еще что он там был
                            {
                                userHaveState: function (userState) {
                                    return !userState || (
                                       userState &&
                                       userState.state != eventUserStates.intended
                                    );
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return !eventState.by_invitation;
                                },
                                userHaveEbr: null,
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я там был',
                                        btnCss: 'checkin-was-there',
                                        btnAction: 'goToEvent'
                                    },
                                ]
                            },

                            // принять участие - "я не пойду"
                            // любое
                            // не началось
                            // говорил что "я пойду"
                            // все равно есть ли приглос
                            // все равно просил ли (хотя нельзя просить приглос на открытое мероприятие)
                            {
                                userHaveState: function (userState) {
                                    return userState &&
                                        userState.state == eventUserStates.intended;
                                },
                                eventIsStarted: function (eventState) {
                                    return !eventState.is_going;
                                },
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                userHaveEbr: null,
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я не пойду',
                                        btnCss: 'checkin-will-not-go',
                                        btnAction: 'iNotGoingThere'
                                    },
                                ]
                            },

                            // принять участие - "я не пойду"
                            // любое
                            // началось
                            // говорил что "я пойду"
                            // все равно есть ли приглос
                            // все равно просил ли (хотя нельзя просить приглос на открытое мероприятие)
                            {
                                userHaveState: function (userState) {
                                    return userState &&
                                        userState.state == eventUserStates.intended;
                                },
                                eventIsStarted: function (eventState) {
                                    return eventState.is_going;
                                },
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                userHaveEbr: null,
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я не пойду',
                                        btnCss: 'checkin-will-not-go',
                                        btnAction: 'iNotGoingThere'
                                    },
                                    {
                                        btnDisabled: false,
                                        btnText: 'Чекин',
                                        btnCss: 'checkin-check-in',
                                        btnAction: 'eventMakeCheckIn'
                                    },
                                ]
                            },

                            // закончилось - "я там был"
                            // по приглашениям
                            // если есть приглос
                            {
                                userHaveState: null,
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return eventState.is_finished;
                                },
                                eventByInvitation: function (eventState) {
                                    return eventState.by_invitation;
                                },
                                userHaveEbr: function (ebr) {
                                    return ebr && ebr.state != xStates.rejected;
                                },
                                userHaveEir: null, // any
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я там был',
                                        btnCss: 'checkin-was-there',
                                        btnAction: 'goToEvent'
                                    },
                                ]
                            },

                            // началось - "чекин"
                            // любое
                            // уже говорил что пойдет или чекаутился
                            {
                                userHaveState: function (userState) {
                                    return userState && (
                                        userState.state == eventUserStates.intended ||
                                        userState.state == eventUserStates.checkedOut
                                    );
                                },
                                eventIsStarted: function (eventState) {
                                    return eventState.is_going;
                                },
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: null,
                                userHaveEbr: null,
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Чекин',
                                        btnCss: 'checkin-check-in',
                                        btnAction: 'eventMakeCheckIn'
                                    },
                                ]
                            },

                            // началось - "чекоут"
                            // любое
                            // чекинился
                            {
                                userHaveState: function (userState) {
                                    return userState &&
                                        userState.state == eventUserStates.checkedIn;
                                },
                                eventIsStarted: function (eventState) {
                                    return eventState.is_going;
                                },
                                eventIsFinished: function (eventState) {
                                    return !eventState.is_finished;
                                },
                                eventByInvitation: null,
                                userHaveEbr: null,
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Чекоут',
                                        btnCss: 'checkin-checkout',
                                        btnAction: 'eventMakeCheckOut'
                                    },
                                ]
                            },

                            // закончилось - "я там не был"
                            // не говорил что "я там не был"
                            {
                                userHaveState: function (userState) {
                                    return userState &&
                                        userState.state &&
                                        userState.state != eventUserStates.wasNotThere;
                                },
                                eventIsStarted: null,
                                eventIsFinished: function (eventState) {
                                    return eventState.is_finished;
                                },
                                eventByInvitation: null,
                                userHaveEbr: null,
                                userHaveEir: null,
                                result: [
                                    {
                                        btnDisabled: false,
                                        btnText: 'Я там не был',
                                        btnCss: 'checkin-was-not-there',
                                        btnAction: 'iWasNotThere'
                                    },
                                ]
                            }

                        ];

                        var result;
                        var checkers = {
                            'userHaveState': userState,
                            'eventIsStarted': eventState,
                            'eventIsFinished': eventState,
                            'eventByInvitation': eventState,
                            'userHaveEbr': ebrState,
                            'userHaveEir': eirState
                        };

                        angular.forEach(stateToResultMap, function(item) {
                            if (result) {
                                return;
                            }
                            console.log('For', item.result);

                            var passed = true;
                            angular.forEach(checkers, function(value, key) {
                                if (!passed) {
                                    return;
                                }
                                var checker = item[key];
                                if (angular.isFunction(checker)) {
                                    passed = checker(value, viewer, eventState);
                                }
                                console.log('check', key, passed, value);
                            });

                            if (passed) {
                                result = item.result;
                            }
                        });
                        return result;
                    }
            };
        }]);

})();
