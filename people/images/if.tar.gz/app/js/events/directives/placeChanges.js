(function () {
    'use strict';
    angular.module('events.placeChanges', ['app']).directive('placeChanges', [
        '$rootScope', '$compile', '$http', '$templateCache', 'jsonRPC', 'eventsService', 'placesService',
        function ($rootScope, $compile, $http, $templateCache, jsonRPC, eventsService, placesService) {
            var scope = {
                entity: '='
            };

            function link(scope, element) {
                element.bind('click', function () {
                    scope.openPlaceChangeForm();
                });
                $http.get('/static/partials/events/placeChanges.html', {cache: $templateCache}).success(function (template) {
                    scope.modal_form = angular.element($compile(template)(scope));
                    element.after(scope.modal_form);
                });
            }

            function Controller($scope) {

                $scope.userPlaceSelector = placesService.getPlaceSelectorWithFavorites();

                $scope.address_type = 0;

                $scope.openPlaceChangeForm = function () {
                    $scope.modal_form.addClass('active');
                };

                $scope.closePlaceChangeForm = function () {
                    $scope.modal_form.removeClass('active');
                };

                $scope.savePlaceChange = function () {
                    var new_place_id = 0;
                    if (!$scope.address_type) {
                        new_place_id = $scope.place.id;
                    }
                    var rdata = {
                        event_alias: $scope.entity.alias,
                        new_place_id: new_place_id
                    };
                    jsonRPC.request('events.change_event_place', rdata).then(
                        function (data) {
                            if (data.error) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Place change error",
                                    text: data.error.data.msg
                                });
                                //deferred.reject();
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Place changed"
                                });
//                          updateHistory($scope, $scope.entity.alias);
                                $rootScope.$emit('event_place_changed', null);
                                $scope.closePlaceChangeForm();
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                            //deferred.reject();
                        }
                    );
                };
            }

            Controller.$inject = ['$scope'];

            return ({
                scope: scope,
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true
            });
        }]);

})();