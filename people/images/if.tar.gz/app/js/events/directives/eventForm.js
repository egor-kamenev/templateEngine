(function () {
    'use strict';
    angular.module('events.eventForm', []).directive('eventForm', [
        '$rootScope', '$state', '$stateParams', '$q', 'tagService', 'visibilityService', 'mapService', 'placesService', 'userService',
        'settingsService', 'eventsService', 'userLocationService', 'Visibility', 'permissionRequired',
        function ($rootScope, $state, $stateParams, $q, tagService, visibilityService, mapService, placesService, userService,
                  settingsService, eventsService, userLocationService, Visibility, permissionRequired) {

            var scope = {
                event: '=',
                visible: '=',
                userLocation: '=',
                editMode: '='
            };

            function link(scope, element, attributes, controller) {
            }

            function Controller($scope, $state) {

                $scope.isEditMode = !!$scope.editMode;
                $scope.placeSelect = {};
                if (!$scope.isEditMode && $scope.event) {
                    $scope.event.tags = [];
                }
                $scope.tagsEditor = tagService.getTagSelector('event_tags');
                $scope.showNewPlaceForm = false;
                $scope.currentVisibility = '';

                $scope.mapPlace = mapService.getSelectedPlace();
                $scope.placeTypeVirtual = -1;
                $scope.placeTypeCreate = -2;
                var addrTypeCreate = {id: $scope.placeTypeCreate, name: "Создать новое место"},
                    addrTypeVirtual = {id: $scope.placeTypeVirtual, name: "Виртуальное событие"};

                // Place from clipboard
                $scope.placeSelect.place = angular.isObject(placesService.getClipboard()) ? placesService.getClipboard() : addrTypeVirtual;

                settingsService.get(function (settings) {
                    $scope.ageRestrictions = settings.ALL_AGE_RESTRICTIONS;
                });

                $scope.$on('changeVisibility', function (event, visibility) {
                    $scope.currentVisibility = Visibility[visibility.value];
                });

                $scope.placeTypeSelector = {
                    choices: [],
                    query: function(searchTerm) {
                        var selector = this,
                            createTypes = [addrTypeCreate];
                        if (searchTerm.length < 3) {
                            selector.choices = createTypes;
                        }
                        else {
                            placesService.getUserAccessiblePlaces(searchTerm, null, $scope.event.visibility).then(
                                function (response) {
                                    if (response.error) {
                                        if ($rootScope.isLogicError(response.error)) {
                                            $rootScope.$emit("flash", {
                                                type: "error",
                                                title: "Ошибка запроса списка мест",
                                                text: response.error.data.msg
                                            });
                                            return;
                                        }
                                    }
                                    selector.choices = response.result;
                                }
                            );
                        }
                    }
                };

                if ($scope.isEditMode) {

                    userLocationService.getUserLocation(function (loc) {
                        $scope.userLocation = loc;
                    });

                    $scope.$watch('event.place', function (p) {
                        if (p) {
                            $scope.placeSelect.place = p;
                        }
                        else {
                            $scope.placeSelect.place = addrTypeVirtual;
                        }
                    });
                }
                else {

                    settingsService.get(function (settings) {
                        $scope.event.age_restriction = settings.DEFAULT_AGE_RESTRICTION;
                    });

                    if ($scope.event.place) {
                        if (eventsService.isVirtual($scope.event.place)) {
                            $scope.placeSelect.place = addrTypeVirtual;
                            $scope.event.place = null;
                        }
                        else {
                            $scope.placeSelect.place = $scope.event.place;
                        }
                    }
                    else if ($scope.mapPlace) {
                        $scope.placeSelect.place = addrTypeCreate;
                    }
                }

                $scope.submitEvent = permissionRequired(
                    $scope.isEditMode ? 'events.change_event' : 'events.add_event', 
                function () {
                    // Compare start and finish dates
                    var d1 = $scope.event.ts_start,
                        d2 = $scope.event.ts_finish,
                        m1 = d1 ? moment(d1) : null,
                        m2 = d2 ? moment(d2) : null;

                    if (m1) {

                        var today = moment();

                        if (m1 < today) {
                            return {
                                date1: 'starts_in_past'
                            };
                        }

                    }

                    if ((m1 && m2) && (m1 >= m2)) {
                        return {
                            date2: 'invalid_range'
                        };
                    }

                    // Check partipants limits
                    var n_p_min = parseInt($scope.event.participants_min),
                        n_p_max = parseInt($scope.event.participants_max);

                    if (n_p_min < 0) {
                        return {
                            participants_min: 'min_value'
                        };
                    }

                    // Min < Max !
                    if ($scope.event.participants_max) {

                        if (isNaN(n_p_max)) {
                            return {
                                participants_max: 'number'
                            };
                        }
                        else if (n_p_max < 0) {
                            return {
                                participants_max: 'min_value'
                            };
                        }

                        if ((n_p_min > n_p_max) || (!n_p_min && !n_p_max)) {
                            return {
                                participants_max: 'invalid_max'
                            };
                        }
                    }

                    // Event tags must be set
                    if (!(angular.isArray($scope.event.tags) && $scope.event.tags.length > 0)) {
                        return {
                            tags: 'setTags'
                        };
                    }

                    var placeTypeID = $scope.placeSelect.place.id,
                        isExistingPlace = placeTypeID > 0,
                        isMapPlace = placeTypeID == $scope.placeTypeCreate,
                        isVirtualPlace = placeTypeID == $scope.placeTypeVirtual;
                    //eventHasPlace = isExistingPlace || isMapPlace;

                    if (!(isExistingPlace || isMapPlace || isVirtualPlace)) {
                        return {
                            place: 'selectPlaceType'
                        };
                    }

                    var timezone,
                        eventPlaceID = null;

                    // Select existing place
                    if (isExistingPlace) {
                        eventPlaceID = $scope.placeSelect.place.id;
                    }
                    else if (isMapPlace) {
                        // place from map
                        if (!$scope.mapPlace.id) {
                            return {
                                place: 'setMapPlace'
                            };
                        }
                        eventPlaceID = $scope.mapPlace.id;
                    }

                    // Send to server
                    var deferred = $q.defer();
                    var data = angular.copy($scope.event);

                    data.place_id = eventPlaceID;
                    delete data.place;

                    data.ts_start = m1.seconds(0).milliseconds(0).toDate();
                    if (m2) {
                        data.ts_finish = m2.seconds(59).toDate();
                    }

                    data.visibility = visibilityService.convertToRPCData(data.visibility);
                    data.tags = tagService.convertTagsToRPCData(data.tags);

                    console.log("new event data", data);

                    var datePlusTZ = function (date, tz) {
                        var dateFormat = "YYYY-MM-DD HH:mm:ss",
                            tzFormat = " Z";
                        var dateStr = moment(date).format(dateFormat) + moment().tz(tz).format(tzFormat);
                        var dateMoment = moment(dateStr, dateFormat + tzFormat);
                        return dateMoment.toDate();
                    };

                    var getTimezoneByLocation = function (latitude, longitude) {
                        console.log('requested to google', latitude, longitude);
                        var timezone = null;
                        jQuery.ajax({
                            async: false,
                            type: "GET",
                            url: "https://maps.googleapis.com/maps/api/timezone/json",
                            data: {
                                "location": latitude + ',' + longitude,
                                "timestamp": (new Date().getTime() / 1000).toFixed(0),
                                "sensor": false
                            },
                            error: function (data) {
                                console.log('error', data);
                            },
                            success: function (data) {
                                console.log('google response', data);
                                if (data.status === "OK") {
                                    timezone = data.timeZoneId;
                                }
                            }
                        });
                        return timezone;
                    };

                    var fetchTimezoneFromPlace = function () {
                        var d = $q.defer();
                        placesService.getPlaceByID(eventPlaceID).then(
                            function (data) {
                                if (data.error) {
                                    deferred.reject();
                                }
                                else {
                                    var place = data.result;
                                    timezone = getTimezoneByLocation(place.latitude, place.longitude);
                                    d.resolve(timezone);
                                }
                            },
                            function () {
                                // general RPC error
                                d.reject();
                            }
                        );

                        return d.promise;
                    };

                    var fetchTimezoneFromUser = function () {
                        return userService.getUser().then(function (user) {

                            if (user.hasOwnProperty('timezone')) {
                                return user.timezone;
                            }
                            return null;
                        });
                    };

                    var timezonePromise = isVirtualPlace ? fetchTimezoneFromUser : fetchTimezoneFromPlace;

                    timezonePromise().then(
                        function (timezone) {

                            console.log('timezone: ', timezone);
                            if (timezone) {
                                data.ts_start = datePlusTZ(data.ts_start, timezone);
                                if (data.ts_finish) {
                                    data.ts_finish = datePlusTZ(data.ts_finish, timezone);
                                }
                            }

                            var method = $scope.isEditMode ?
                                eventsService.editEvent($scope.event.id, data) :
                                eventsService.addEvent(data);

                            method.then(
                                function (data) {
                                    if (data.error) {
                                        if ($rootScope.isFormError(data.error)) {
                                            deferred.reject(data.error.data);
                                        }
                                        else if ($rootScope.isLogicError(data.error)) {
                                            $scope.$emit("flash", {
                                                type: "error",
                                                title: "Ошибка сохранения мероприятия",
                                                text: data.error.data.msg
                                            });
                                            deferred.reject();
                                        }
                                        else{
                                            deferred.reject();
                                        }

                                    }
                                    else {
                                        $scope.$emit("flash", {
                                            type: "success",
                                            title: "Готово",
                                            text: "Мероприятие сохранено"
                                        });

                                        eventsService.resetClipboard();
                                        if ($scope.isEditMode) {
                                            eventsService.getEvent($scope.event.id).then(function (data) {
                                                $scope.event = data.result;
                                                deferred.resolve();
                                                var alias = data.result.alias;
                                                $state.go(
                                                    $state.current, 
                                                    $stateParams,
                                                    {
                                                        reload: true,
                                                    }
                                                );
                                                $scope.visible = false;
                                            });
                                        }
                                        else {
                                            // Server returns new event in response
                                            deferred.resolve();
                                            var newEvent = data.result;
                                            mapService.resetSelectedPlace();
                                            $state.go('event.wall', {event_alias: newEvent.alias});
                                        }

                                    }
                                },
                                function () {
                                    // general RPC error
                                    deferred.reject();
                                }
                            );

                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: "Ошибка определения временной зоны"
                            });
                            deferred.reject();
                        }
                    );

                    return deferred.promise;
                });

                $scope.canGoBack = function () {
                    return $state.previous && $state.previous.name;
                };

                $scope.closeForm = function () {
                    if ($scope.isEditMode) {
                        $scope.visible = false;
                        $scope.$emit('closeEventForm', null);
                    }
                    else {
                        $state.go($state.previous.name, $state.previous.params);
                    }

                };

                $scope.openPlaceModal = function () {
                    $scope.showNewPlaceForm = true;
                };

                $scope.closePlaceModal = function () {
                    $scope.showNewPlaceForm = false;
                };

                $scope.$watch('showNewPlaceForm', function (val, oldVal) {
                    var becomesHidden = !val && (val != oldVal);
                    if (becomesHidden) {
                        if (!$scope.mapPlace) {
                            $scope.placeSelect.place = addrTypeVirtual;
                        }
                    }
                });

                $scope.$watch('placeSelect.place', function (v) {

                    var createNewPlaceSelected = angular.isObject(v) && v.id == $scope.placeTypeCreate;

                    if (createNewPlaceSelected) {
                        $scope.openPlaceModal();
                    }
                    else {
                        $scope.closePlaceModal();
                    }
                });

                $scope.$watch('mapPlace', function (v) {

                    var newPlaceWasCreatedInModal = angular.isObject(v) && v.id > 0;

                    if (newPlaceWasCreatedInModal) {
                        $scope.placeSelect.place = v;
                    }

                });

            }

            Controller.$inject = ['$scope', '$state'];

            return ({
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                scope: scope,
                templateUrl: '/static/partials/events/event_form.html'
            });

        }]);

})();
