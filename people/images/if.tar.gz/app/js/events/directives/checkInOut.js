(function () {
    'use strict';

    angular.module('event.checkInOut', ['app']).directive('checkInOut', [
        '$q', '$rootScope', 'eventUserStates', 'xStates', 'checkInOutService','$parse',
        function ($q, $rootScope, eventUserStates, xStates, checkInOutService, $parse) {
            var loading = false;
            return {
                restrict: "AC",
                scope: false,
                templateUrl: '/static/partials/checkinout/check_in_out.html',
                link: function (scope, element, attrs) {
                    scope.entity = $parse(attrs.checkInOut)(scope);

                    function setLoadingState() {
                        element.addClass("loading");
                        loading = true;
                    }

                    function resetLoadingState() {
                        element.removeClass("loading");
                        loading = false;
                        updateButton();
                    }

                    element.on('click', function (e) {
                        if (!loading) {
                            setLoadingState();
                            checkInOutService.handler(scope.entity, $(e.target).data('btnAction')).then(resetLoadingState, resetLoadingState);
                        } else {
                            $rootScope.$emit("flash", {
                                type: "info",
                                title: "Участие",
                                text: "Пожалуйста, подождите завершения предыдущей операции"
                            });
                        }
                    });

                    function updateButton() {
                        scope.buttons = checkInOutService.getButtons(
                            $rootScope.user, scope.entity, scope.entity.invite_request, scope.entity.bun_request, scope.entity.user_state
                        );
                    }

                    $rootScope.$on('needUpdateButtons', function () {
                        updateButton();
                    });

                    updateButton();
                }
            };
        }]);
})();
