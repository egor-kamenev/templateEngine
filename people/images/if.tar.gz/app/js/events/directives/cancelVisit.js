(function(){
angular.module('event.cancelVisit', ['app']).directive('cancelVisit', [
    '$q', 'jsonRPC', 'eventUserStates', "xStates", '$compile', '$parse', 'checkInOutService',
    function ($q, jsonRPC, eventUserStates, xStates, $compile, $parse, checkInOutService) {
        var loading = false;
        return {
            restrict: "AC",
            scope: false,
            template: '' +
            '<button data-protractor-id="cancelVisit" class="button checkin-will-not-go" type="button"><span>Я не пойду</span></button>',
            link: function (scope, element, attrs) {

                var entity = $parse(attrs.cancelVisit)(scope);

                if (!entity) {
                    console.error("cant get item");
                    return;
                }

                //function onError(error) {
                //    scope.$emit("flash", {
                //        type: "error",
                //        title: "Server error",
                //        text: "Sorry, error occurred while submitting. Please try again later."
                //    });
                //}
                //
                //function deleteParticipent(entity) {
                //    for(var i = 0; i < entity.participants.length; i++) {
                //        if(entity.participants[i].id == $scope.$parent.user.id) {
                //            entity.participants.splice(i, 1);
                //            break;
                //        }
                //    }
                //}

                function setLoadingState() {
                    element.addClass("loading");
                    loading = true;
                }

                function resetLoadingState() {
                    element.removeClass("loading");
                    loading = false;
                }

                element.bind('click', function () {
                    if (!loading) {
                        setLoadingState();
                        checkInOutService.cancelVisit(entity).then(resetLoadingState, resetLoadingState);
                    } else {
                        $rootScope.$emit("flash", {
                            type: "info",
                            title: "Участие",
                            text: "Пожалуйста, подождите завершения предыдущей операции"
                        });
                    }
                });

            }
        };
    }]);

})();