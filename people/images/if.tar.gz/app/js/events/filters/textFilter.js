(function(){
angular.module('events.filters', []).
filter('text', function(){
    return function (events, text) {
        var filtered = [];
        var s = text.toLowerCase();

        angular.forEach(events, function(e) {

            if( (e.name.toLowerCase().indexOf(s) >= 0) ||
                (e.place.name.toLowerCase().indexOf(s) >= 0) ||
                (e.description.toLowerCase().indexOf(s) >= 0 ) ||
                (e.place.description.toLowerCase().indexOf(s) >= 0)
              ){
                  filtered.push(e);
              }
        });
        return filtered;
    };
});
})();