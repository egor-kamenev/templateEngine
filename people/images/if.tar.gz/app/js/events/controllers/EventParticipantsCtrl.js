(function () {
    'use strict';
    angular.module('app.controllers.eventparticipantsctrl', []).controller('EventParticipantsCtrl', [
        '$scope', '$stateParams', '$rootScope', 'eventsService', 'jqPaginationSettings',
        function ($scope, $stateParams, $rootScope, eventsService, jqPaginationSettings) {

            $scope.limit = jqPaginationSettings.limit_tile;
            $scope.total = 0;
            $scope.maxPage = 0;
            $scope.loaded = true;
            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            $scope.getParticipants = function (update) {
                if (!update) $scope.dataSource = [];

                eventsService.getEventParticipants($stateParams.event_alias, $scope.currentPage).then(
                    function (data) {

                        if (!data.result.items.length) {
                            $scope.loaded = true;
                            return;
                        }

                        $scope.dataSource = data.result.items;

                        $scope.total = data.result.total;
                        $scope.loaded = true;

                        if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);

                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Please try again later."
                        });
                    }
                );
            };


            $scope.$onRootScope('cancelVisit', function (e, eventID) {

                var signalAboutCurrentEvent = eventID == $scope.event.id;

                if (signalAboutCurrentEvent) {
                    $scope.dataSource = _.filter($scope.dataSource, function (p) {
                        return $rootScope.username == p.username;
                    });
                    $scope.reloadEventData();
                }

            });

            $scope.$onRootScope('goToEvent', function (e, eventID) {

                var signalAboutCurrentEvent = eventID == $scope.event.id;

                if (signalAboutCurrentEvent) {
                    $scope.dataSource.push($rootScope.user);
                    $scope.reloadEventData();
                }

            });

            $scope.$onRootScope('eventParticipantsChanged', function () {
                $scope.getParticipants(true);
            });

            $scope.getParticipants(false);

        }]);

})();