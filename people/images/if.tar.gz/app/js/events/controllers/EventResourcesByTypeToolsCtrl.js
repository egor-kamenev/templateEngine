(function () {
    'use strict';

    angular.module('app.controllers.eventresourcesbytypetoolsctrl', []).controller('EventResourcesByTypeToolsCtrl', [
        '$rootScope', '$scope', '$q', '$state', '$stateParams', '$filter', 'Service404', 'tagService', 'eventsService', 'xStates',
        function ($rootScope, $scope, $q, $state, $stateParams, $filter, Service404, tagService, eventsService, xStates) {

            var resType = $stateParams.resource_type,
                initialTargetUsers = {
                    interestTags: [],
                    friendshipTags: [],
                    specifiedUsers: [],
                    invitedEmails: ''
                };

            $scope.sendingInProgress = false;
            $scope.interestTagsEditor = tagService.getTagSelector();
            $scope.friendshipTagsEditor = tagService.getTagSelector('friendship_tags');
            $scope.targetUsers = angular.copy(initialTargetUsers);
            //$scope.defaultAmount = 1;
            $scope.defaultComment = '';
            $scope.malformedEmails = [];
            $scope.show_send_all = false;

            // This state is accessible by the owner only
            var doneWatch = $scope.$parent.$watch('event_loaded', function (loadComplete) {
                if (loadComplete) {
                    if (!$scope.$parent.isOwner) {
                        $state.go('403');
                    }

                    $scope.selectedResource = _.find($scope.$parent.event.resources, function (r) {
                        return r.id == resType;
                    });

                    if (!$scope.selectedResource) {
                        Service404.setMessage($filter('translate')('EVENT_RESOURCE_NOT_FOUND'));
                        $state.go('404');
                    }

                    $scope.userSelector = eventsService.getUserSelectorForResource($scope.selectedResource.id);

                    doneWatch();
                }
            });

            $scope.openSendModal = function () {
                $scope.isSendModalOpen = true;
            };

            $scope.closeSendModal = function () {
                $scope.isSendModalOpen = false;
            };

            var getResourcesRecipients = function () {

                var data = angular.copy($scope.targetUsers),
                    deferred = $q.defer();

                data.bun_id = $scope.selectedResource.id;
                data.event_id = $scope.event.id;
                data.interestTags = tagService.convertTagsToRPCData(data.interestTags);
                data.friendshipTags = tagService.convertTagsToRPCData(data.friendshipTags);

                eventsService.getResourcesRecipients(data).then(
                    function (response) {
                        $scope.targetUsers = angular.copy(initialTargetUsers);

                        if (response.error) {
                            if ($rootScope.isLogicError(response.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: response.error.data.msg
                                });
                            }
                            deferred.reject();
                        }
                        else {
                            if (response.result.violated_restriction) {
                                $scope.$emit("flash", {
                                    type: "warning",
                                    title: "Внимание",
                                    text: "В список получателей попали пользователи, не подходящие по возрастному ограничению, они были исключены"
                                });
                            }
                            if (response.result.invalid_emails.length > 0) {
                                $scope.$emit("flash", {
                                    type: "warning",
                                    title: "Внимание",
                                    text: "В списке email адресов найдены не корректные адреса (\"" + response.result.invalid_emails[0] +
                                    "\", ...), они были исключены"
                                });
                            }
                            deferred.resolve(response.result.users);
                        }
                    },
                    function () {
                        deferred.reject();
                    }
                );
                return deferred.promise;
            };

            $scope.createResourceOffers = function () {

                var emailsTxt = $scope.targetUsers.invitedEmails.trim();
                $scope.malformedEmails = [];

                if (emailsTxt !== "") {

                    var emailsArray = _.map(emailsTxt.split('\n'), function (e) {
                            return e.trim();
                        }),
                        EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;

                    if (emailsArray.length > 0) {
                        angular.forEach(emailsArray, function (e) {
                            if (e) {
                                if (!EMAIL_REGEXP.test(e)) {
                                    $scope.malformedEmails.push(e);
                                }
                            }
                        });

                        if ($scope.malformedEmails.length > 0) {
                            return {
                                invitedEmails: 'invalid'
                            };
                        }
                    }
                }

                getResourcesRecipients().then(
                    function (recipients) {

                        var data = {
                            bun_id: $scope.selectedResource.id,
                            users: recipients,
                            //default_amount: $scope.defaultAmount,
                            emails: angular.copy($scope.invitedEmails),
                            default_comment: $scope.defaultComment
                        };

                        eventsService.createResourceOffers(data).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Error",
                                            text: data.error.data.msg
                                        });
                                    }
                                }
                                else {

                                    var offers = _.pluck(data.result, 'object');
                                    $scope.$emit('refreshEventResourceOffers', offers);

                                    if (!_.some(offers, {state: xStates.new})) {
                                        $scope.$emit("flash", {
                                            type: "warning",
                                            title: "Приглашения не отправлены",
                                            text: "Не найдено пользователей, удовлетворяющих условиям поиска, попробуйте их изменить."
                                        });
                                    }

                                    $scope.invitedEmails = '';
                                    //$scope.defaultAmount = 1;
                                    $scope.defaultComment = '';
                                    $scope.closeSendModal();
                                }

                            },
                            function () {
                                // general RPC error
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Ошибка отправки приглашений, повторите запрос позже."
                                });
                            }
                        );

                    },
                    function () {
                    }
                );
            };

            $scope.sendResourceOffers = function () {
                $scope.sendingInProgress = true;
                $scope.$emit('sendResourceOffers', null);
            };

            if ($stateParams.openModal) {
                $scope.openSendModal();
            }

            $rootScope.$on('show_send_all_button', function (event, data) {
                $scope.show_send_all = data;
            });

            $rootScope.$on('ResourceSent', function () {
                $scope.sendingInProgress = false;
            });

        }]);

})();
