(function () {
    'use strict';

    angular.module('app.controllers.resourcerequestsctrl', []).controller('ResourceRequestsCtrl', [
        '$rootScope', '$scope', '$state', '$q', '$stateParams', 'eventsService', 'tagService', 'tagTypes', 'socketio', 'xStates', 'jqPaginationSettings',
        function ($rootScope, $scope, $state, $q, $stateParams, eventsService, tagService, tagTypes, socketio, xStates, jqPaginationSettings) {

            $scope.dataSource = [];
            $scope.eventAlias = $stateParams.event_alias;
            $scope.states = xStates;

            $scope.limit = jqPaginationSettings.limit_tile;
            $scope.total = 0;
            $scope.maxPage = 0;
            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;


            // This state is accessible by the owner only
            var doneWatch = $scope.$parent.$watch('event_loaded', function (loadComplete) {
                if (loadComplete) {
                    if (!$scope.$parent.isOwner) {
                        $state.go('403');
                    }
                    doneWatch();
                }
            });


            var reloadRequests = function () {
                $scope.dataSource = [];
                eventsService.getResourceRequests($scope.eventAlias, null, $scope.currentPage).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                            }
                        } else {
                            $scope.total = data.result.total;
                            $scope.dataSource = _.pluck(data.result.items, 'object');
                            if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);
                        }

                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Попробуйте повторить попытку позже"
                        });
                    }
                );
            };

            $scope.accept = function (request) {
                eventsService.acceptResourceRequest(request).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            reloadRequests();
                        }
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Попробуйте повторить попытку позже"
                        });
                    }
                );
            };

            $scope.reject = function (requestId) {
                eventsService.rejectResourceRequest(requestId).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            reloadRequests();
                        }
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Попробуйте повторить попытку позже"
                        });
                    }
                );
            };

            reloadRequests();
        }]);

})();