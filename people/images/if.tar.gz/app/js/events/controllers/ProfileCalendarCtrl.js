(function(){
//'use strict';
//
//angular.module('app.controllers.profilecalendarctrl', [])
//  .controller('ProfileCalendarCtrl', ['$window', '$scope', '$rootScope', '$stateParams', '$compile', 'jsonRPC', 'eventsService', 'friendsService', 'tagService', 'tagTypes', function ($window, $scope, $rootScope, $stateParams, $compile, jsonRPC, eventsService, friendsService, tagService, tagTypes) {
//
//
//        $scope.calendar_owner = $stateParams.username;
//        $scope.isEventsSidebarEnabled = true;
//
//        $scope.tagFilterEditor = tagService.getTagSelector();
//
//        $scope.friendsFilterEditor = friendsService.getFriendsEditor();
//        $scope.participantsFilterEditor = friendsService.getFriendsEditor();
//        $scope.eventPopupActive = false;
//
//
//        $scope.eventSources = [[]];
////        $scope.do_filter_my = true;
////        $scope.do_filter_with_me = true;
////        $scope.do_filter_friends = true;
////        $scope.do_filter_interests = true;
//
//        $scope.newEvent = {};
//        $scope.newEventData = {};
//        function removeURL(e){
//            delete e.url;
//            return e;
//        }
//
//        $scope.doFilters = {
//            'Мои мероприятия': 'do_filter_my',
//            'Дни рождения друзей': 'do_filter_birthday',
//            'Куда приглашен': 'do_filter_event_invited',
//            'Принимаю участие': 'do_filter_event_part',
//            'Подписки': 'do_filter_event_subscribe',
//            'Закладки': 'do_filter_event_bookmark'
//        };
//
//        $scope.selectFilters = {
//            'multiple': true,
//            'simple_tags': true,
//            'tags': Object.keys($scope.doFilters)
//        };
//
//        $scope.do_filters_text = Object.keys($scope.doFilters);
//
//        $scope.calendarConfig = {
//            header: {
//	            left: 'prev,next today',
//	            center: 'title',
//	            right: 'month,agendaWeek,agendaDay'
//	        },
//            defaultView:'agendaWeek',
//            editable:false,
//	        selectable: true,
//	        selectHelper: true,
//            dayRender: function( date, cell ){
//                if(date.getTime() < new Date().getTime() - 86400000){
//                    cell.css('background-color','grey');
//                }
//            },
//            eventRender: function(calev, elt, view) {
//                if (calev.end && (calev.end.getTime() < new Date().getTime()))
//                    elt.addClass("calendar_event_finished");
//            },
////            select: function(start, end, allDay) {
////                $scope.$apply(function(){
////                    if($scope.accessRequired('events.add_event','/calendar')) return;
////
////                    var start_end_same_day = start.getDate() === end.getDate();
////                    var view_mode_month = $('#events_calendar').fullCalendar('getView').name === "month";
////                    if( start_end_same_day && view_mode_month){
////                        $('#events_calendar')
////                            .fullCalendar( 'changeView', 'basicDay' )
////                            .fullCalendar('gotoDate',
////                                          start.getFullYear(),
////                                          start.getMonth(),
////                                          start.getDate());
////                        return;
////                    }
////
////                    if (start.getTime() < new Date().getTime()){
////                        $scope.$emit("flash", {
////                            type: "error",
////                            title: "Incorrect start date",
////                            text: "You cannot create an event in the past"
////                        });
////                        return;
////                    }
////
////
////                    $scope.newEvent.ts_start = start;
////                    $scope.newEvent.ts_finish = end;
////                    $scope.isNewEventDialogOpen = true;
////
////                });
////
////	        },
//            eventClick: function(event, jsEvent, view){
//                $scope.$apply(
//                    function(){
//                        $scope.setSelectedEvent(event);
//
////                        // Same event clicked - close popup
////                        if(angular.equals($scope.selectedEvent, event)){
////                            $scope.selectedEvent = null;
////                            $scope.eventPopupActive = false;
////                        }
////                        else{
////                            $scope.selectedEvent = event;
////                            $scope.eventPopupActive = true;
////                        }
//                    }
//                );
//                return false;
//            },
//            viewDisplay: function (element) {
//                $scope.s_tmstamp = Math.round(+element.start / 1000);
//                $scope.e_tmstamp = Math.round(+element.end / 1000);
//                $scope.reloadEvents();
//            }
//        };
//
//        $scope.setSelectedEvent = function (event) {
//            $scope.selectedEvent = event;
//            $scope.eventPopupActive = !!event;
//        };
//
//        function eventsCallback( events ){
//
//            // Post process events
//            angular.forEach(events, function(e, i){
//
//                // Add 'title' property - for calendar
//                e.title = e.name;
//
//                // Timezone fix:
//                // Add 'start' and 'end' properties (for the calendar widget)
//                // Convert UTC server-side time to local time
//                var s = new Date(e.ts_start),
//                    f = new Date(e.ts_finish),
//                    o = s.getTimezoneOffset()*60;
//
//                e.start = s.getTime()/1000 - o;
//                if(e.ts_finish){
//                    e.end = f.getTime()/1000 - o;
//                }
//                else{
//                    // For events without end date we set finish date to now() + 1 year,
//                    // so they become visible in the calendar
//                    var yearFromStart = new Date(new Date(s).setMonth(s.getMonth()+12));
//                    e.end = yearFromStart.getTime()/1000 - o;
//                }
//            });
//            $rootScope.$emit('event_eventsChanged', events);
//        }
//
//        function friendsCallback(friends){
//            angular.forEach(friends, function(f, i){
//
//                f.title = f.username;
//
//                var s = new Date(f.date_of_birth);
//                f.start = s.getTime()/1000 - s.getTimezoneOffset()*60;
//            });
//            $rootScope.$emit('event_friendsChanged', friends);
//        }
//
//        $scope.reloadEvents = function(){
////            var tag_ids = [];
////            if($scope.tagFilter){
////                for(var tag in $scope.tagFilter){
////                    tag_ids.push($scope.tagFilter[tag].id);
////                }
////            }
////            var author_ids = [];
////            if($scope.authorFilter){
////                for(var author in $scope.authorFilter){
////                    author_ids.push($scope.authorFilter[author].id);
////                }
////            }
////            var participant_ids = [];
////            if($scope.participantsFilter){
////                for(var participant in $scope.participantsFilter){
////                    participant_ids.push($scope.participantsFilter[participant].id);
////                }
////            }
//
//
//            var filter = {
//                start: $scope.s_tmstamp,
//                end: $scope.e_tmstamp,
//                owner: $scope.calendar_owner,
//                do_filters: $scope.do_filters
////                do_filter_my: $scope.do_filter_my,
////                do_filter_with_me: $scope.do_filter_with_me,
////                do_filter_friends: $scope.do_filter_friends,
////                do_filter_interests: $scope.do_filter_interests,
////                text: $scope.textFilter,
////                tags: tag_ids.join(','),
////                authors: author_ids.join(','),
////                participants: participant_ids.join(','),
//            };
//            var data = angular.copy(filter);
//            jsonRPC.request('users.get_calendar', data).then(
//                function(data){
//                    if(data.error){
//                        if($rootScope.isLogicError(data.error)){
//                            $scope.$emit("flash", {
//                                type: "error",
//                                title: "Error",
//                                text: data.error.data.msg
//                            });
//                        }
//                    }
//                    else{
//                        console.log('data', data.result);
//
//                        var events = _.map(data.result[0], removeURL),
//                            friendsEvents = _.map(data.result[1], removeURL);
//
//                        eventsCallback(events);
//                        friendsCallback(friendsEvents);
//                    }
//
//                },
//                function(data){
//                    // general RPC error
//                    $scope.$emit("flash", {
//                        type: "error",
//                        title: "Server error",
//                        text: "Sorry, error occurred while submitting. Please try again later."
//                    });
//                }
//            );
//
////            eventsService.reloadEvents(filter, eventsCallback );
//        };
//
//        function updateEvents(event, events){
//            if (events) {
//                $scope.eventSources[0] = [];
//                for(var e in events){
//                    $scope.eventSources[0].push(events[e]);
//                }
//            }
//        }
//        function updateFriends(event, friends){
//            if (friends) {
//                $scope.eventSources[1] = [];
//                for(var f in friends){
//                    $scope.eventSources[1].push(friends[f]);
//                }
//            }
//        }
//        $scope.applyFilter = function(){
//
//            clearTimeout($scope.tm);
//            $scope.tm = setTimeout( function(){
//                $scope.$apply(
//                    $scope.reloadEvents()
//                );
//            }, 300);
//
//        };
//
//        $scope.$onRootScope('event_eventAdded', function (event, added_event){
//            $scope.eventSources[0].push(added_event);
//            $scope.reloadEvents();
//
//        });
//
//        $scope.$onRootScope('event_eventsChanged', updateEvents);
//
//        $scope.$onRootScope('event_friendsChanged', updateFriends);
//
//        // Close all popup windows on calendar leave
//        $scope.$on('$routeChangeStart', function(next, current) {
//            $('.fc-event').popover('destroy');
//        });
//
//        $scope.updateFilters = function () {
//            $scope.do_filters = [];
//            angular.forEach($scope.do_filters_text, function (text) {
//                $scope.do_filters.push($scope.doFilters[text]);
//            });
//            $scope.reloadEvents();
//        };
//
//        $scope.updateFilters();
//
//    }]);

})();