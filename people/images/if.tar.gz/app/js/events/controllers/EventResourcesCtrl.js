(function () {
    'use strict';

    angular.module('app.controllers.eventresourcesctrl', []).controller('EventResourcesCtrl', [
        '$rootScope', '$scope', '$q', '$state', '$stateParams', 'eventsService', 'tagService',
        function ($rootScope, $scope, $q, $state, $stateParams, eventsService, tagService) {

            $scope.eventAlias = $stateParams.event_alias;
            //$scope.xStates = xStates;
            //$scope.isNewEventBunDialogOpen = false;

            // This state is accessible by the owner only
            var doneWatch = $scope.$watch('event_loaded', function (loadComplete) {
                if (loadComplete) {
                    if (!$scope.isOwner) {
                        $state.go('403');
                    }
                    doneWatch();
                }
            });

            $scope.resourceTypes = [
                {
                    name: 'Приглашение',
                    value: eventsService.RESOURCE_TYPES.INVITATION
                }, {
                    name: 'Другое',
                    value: eventsService.RESOURCE_TYPES.OTHER
                }
            ];

            var initialEventResource = {
                //amount: 100,
                //description: '',
                name: '',
                event_alias: $stateParams.event_alias
            };

            $scope.eventResource = angular.copy(initialEventResource);
            //$scope.defaultAmount = 1;
            $scope.defaultComment = '';

            $scope.addEventResource = function () {
                // Send to server
                var deferred = $q.defer();
                var data = angular.copy($scope.eventResource);

                eventsService.addResource(data).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isFormError(data.error)) {
                                deferred.reject(data.error.data);
                            }
                            else if ($rootScope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                                deferred.reject();
                            }
                        }
                        else {
                            //$scope.isNewEventBunDialogOpen = false;
                            $scope.eventResource = angular.copy(initialEventResource);

                            $scope.$emit("flash", {
                                type: "success",
                                title: "Ресурс содан"
                            });
                            reloadEventResources();
                            deferred.resolve();
                        }
                    },
                    function () {

                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Невозможно добавить ресурс, попробуйте повторить запрос позже"
                        });

                        // general RPC error
                        deferred.reject();
                    }
                );
                return deferred.promise;
            };


            var reloadEventResources = function () {
                eventsService.getResources($scope.eventAlias).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.event.resources = data.result;
                        }
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Невозможно получить список ресурсов этого мероприятия, попробуйте повторить запрос позже"
                        });

                    }
                );
            };


            $scope.removeResource = function (resourceID) {

                $scope.confirm("Вы действительно хотите удалить этот ресурс ?").then(function () {

                    eventsService.removeResource(resourceID).then(
                        function () {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Ресурс удален"
                            });
                            $scope.event.resources = _.reject($scope.event.resources, function (r) {
                                return r.id == resourceID;
                            });
                        },

                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: "Невозможно удалить ресурс, попробуйте повторить запрос позже"
                            });

                        }
                    );
                });
            };


            $scope.refreshEventBunRequests = function () {
                eventsService.getResourceOffers($scope.activeBun.id).then(
                    function (data) {
                        $scope.eventBunRequests = data.result;
                        refreshAmount();
                        if (!data.result.length) {
                            // if there are no users then show window
                            $scope.isAddUsersToSendListDialogOpen = true;
                        }
                    }
                );
            };


            var refreshAmount = function () {
                $scope.allocatedAmount = _.reduce($scope.eventBunRequests, function (m, i) {
                    return m + i.amount;
                }, 0);
            };


            var addEventBunRequests = function (users) {
                var data = {
                    bun_id: $scope.activeBun.id,
                    users: users,
                    //default_amount: angular.copy($scope.defaultAmount),
                    emails: angular.copy($scope.invitedEmails),
                    default_comment: angular.copy($scope.defaultComment)
                };

                jsonRPC.request('events.add_new_event_bun_requests', data).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            console.log('added new event');
                            $scope.eventBunRequests = data.result;
                            $scope.invitedEmails = '';
                            //$scope.defaultAmount = 1;
                            $scope.defaultComment = '';
                            $scope.isAddUsersToSendListDialogOpen = false;
                            refreshAmount();
                        }

                    },
                    function () {
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Sorry, error occurred while submitting. Please try again later."
                        });
                    }
                );
            };

            $scope.removeEventBunRequest = function (id) {
                jsonRPC.request('events.delete_event_bun_request', {id: id});
                $scope.eventBunRequests = _.filter($scope.eventBunRequests, function (item) {
                    return item.id != id;
                });
                refreshAmount();
            };

            $scope.sendEventBunRequests = function () {
                if ($scope.allocatedAmount > $scope.activeBun.amount) {
                    console.log('Allocated amount is greater than total amount');
                    return;
                }

                var data = {
                    bun_id: $scope.activeBun.id,
                    bun_requests: angular.copy($scope.eventBunRequests)
                };

                jsonRPC.request('events.send_event_bun_requests', data).then(
                    function (data) {
                        console.log('send event');
                        $scope.eventBunRequests = data.result;
                    }
                );
            };

            $scope.showAddUsersDialog = function () {
                $scope.isAddUsersToSendListDialogOpen = true;
            };

            $scope.closeAddUsersDialog = function () {
                $scope.isAddUsersToSendListDialogOpen = false;
            };

            var initialAddingListUsers = {
                interestTags: [],
                friendshipTags: [],
                specifiedUsers: []
            };

            $scope.addingListUsers = angular.copy(initialAddingListUsers);

            $scope.addUsers = function () {
                var data = angular.copy($scope.addingListUsers);
                data.bun_id =  $scope.activeBun.id;
                data.event_id = $scope.activeBun.event_id;
                data.interestTags = tagService.convertTagsToRPCData(data.interestTags);
                data.friendshipTags = tagService.convertTagsToRPCData(data.friendshipTags);

                jsonRPC.request('events.get_users_for_buns', data).then(
                    function (data) {
                        $scope.addingListUsers = angular.copy(initialAddingListUsers);
                        addEventBunRequests(data.result.users);

                        if (data.result.violated_restriction) {
                            $scope.$emit("flash", {
                                type: "warning",
                                title: "Warning",
                                text: "There are the users who don't meet age restrictions."
                            });
                        }
                    }
                );
            };

            $scope.changeBunRequest = function (id) {
                var bunRequest = _.find($scope.eventBunRequests, function (item) {
                    return item.id == id;
                });
                if (bunRequest.status != $scope.states.new) {
                    bunRequest.status = $scope.states.changed;
                }
                if (bunRequest.amount < 0) {
                    bunRequest.amount = 0;
                }
                refreshAmount();
            };

        }]);

})();
