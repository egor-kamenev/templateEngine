(function () {
    'use strict';
    angular.module('app.controllers.eventctrl', []).controller('EventWallCtrl', [
        '$scope', '$rootScope', '$state',
        function ($scope, $rootScope, $state) {
            $scope.isCurrentStateHasXWall = function () {
                //var state = $state.current;
                return $state.current.name === 'event.wall';
            };

            $scope.canAddXPosts = function () {
                return $rootScope.user.authenticated && !$scope.event.user_banned && !$scope.event.readOnly;
            };
        }]).controller('EventAlbumsCtrl', [
        '$scope', '$rootScope',
        function ($scope, $rootScope) {
            $scope.canAddXPosts = function () {
                return $rootScope.user.authenticated && !$scope.event.user_banned && !$scope.event.readOnly;
            };
        }])
        .controller('EventCtrl', [
            '$scope', '$q', '$state', '$stateParams', '$location', '$filter', 'jsonRPC', 'userService',
            '$rootScope', 'channelService', 'placesService', 'eventsService', 'visibilityService', 'userbanService',
            'socketio', 'StreamCode', 'Service404', 'eventUserStates', 'xStates', 'eventStateCodes',
            function ($scope, $q, $state, $stateParams, $location, $filter, jsonRPC, userService, $rootScope, channelService,
                      placesService, eventsService, visibilityService, userbanService, socketio, StreamCode, Service404,
                      eventUserStates, xStates, eventStateCodes) {
                $scope.eventName = '';
                $scope.eventParticipants = [];
                //$scope.friendParticipants = [];
                //$scope.eventParticipantsCount = 0;
                //$scope.friendParticipantsCount = 0;
                //$scope.userPlaceSelector = placesService.getPlaceSelector();
                $scope.discussionSettingsDialogActive = false;
                $scope.bannedUsers = [];
                $scope.isOwner = false;
                $rootScope.isOwner = true;

                // For inline edit
                $scope.isBeingEdited = false;
                $scope.addressType = 0;

                $scope.tsStartOptions = {
                    changeYear: true,
                    changeMonth: true,
                    yearRange: '2013:-0',
                    dateFormat: 'dd.mm.yy',
                    prevText: '<i class="fa fa-chevron-left"></i>',
                    nextText: '<i class="fa fa-chevron-right"></i>',
                    onSelect: function (selectedDate) {
//                $('#ts_finish').datepicker('option', 'minDate', selectedDate);
                        angular.element("#ts_finish").datepicker('option', 'minDate', selectedDate);
                    }
                };

                $scope.tsFinishOptions = {
                    changeYear: true,
                    changeMonth: true,
                    yearRange: '2013:-0',
                    dateFormat: 'dd.mm.yy',
                    prevText: '<i class="fa fa-chevron-left"></i>',
                    nextText: '<i class="fa fa-chevron-right"></i>',
                    onSelect: function (selectedDate) {
//                $('#ts_start').datepicker('option', 'maxDate', selectedDate);
                        angular.element("#ts_start").datepicker('option', 'maxDate', selectedDate);
                    }
                };

                $scope.isOwner = !!($scope.event && $scope.event.owner && ($scope.user.id == $scope.event.owner.id));

                $scope.checkIns = [];

                $scope.checkInStates = {
                    unconfirmed: 0,
                    confirmed: 1,
                    proved: 2
                };
                $scope.states = xStates;
                $scope.eventUserStates = eventUserStates;

                // Used in resource stats
                $scope.getStatsTotal = function (stats) {
                    var ret = 0,
                        counts = [$scope.states.sent, $scope.states.accepted, $scope.states.rejected];

                    for (var s in stats) {
                        if (_.contains(counts, stats[s].state)) {
                            ret += stats[s].amount;
                        }
                    }
                    return ret;
                };

                $scope.setEventParticipants = function (eventParticipants) {
                    var //fp = [],
                        ep = [];
                    //participants_were = 0,
                    //participants_now = 0;

                    _.each(eventParticipants, function (p) {
                        if (p.state == 'sent') return;

                        //if (userService.isFriend(p.id)) {
                        //    fp.push(p);
                        //} else {
                        ep.push(p);
                        //}
                        //if (p.state === 'checked-in') participants_now++;
                        //if (p.state === 'checked-out') {
                        //    participants_now++;
                        //    participants_were++;
                        //}

                    });

                    ep = _.sortBy(ep, function (p) {
                        return p.creation_date;
                    });

                    //fp = _.sortBy(fp, function (p) {
                    //    return p.creation_date;
                    //});

                    $scope.eventParticipants = ep;
                    //$scope.eventParticipants = ep.slice(0, 25);
                    //$scope.friendParticipants = fp.slice(0, 25);

                    //$scope.event.participants_now = participants_now;
                    //$scope.event.participants_were = participants_were;
                };

                $scope.isOwner = !!($scope.event && $scope.event.owner && ($scope.user.id == $scope.event.owner.id));

                //$rootScope.$watch('user', function (value) {
                //    $scope.isOwner = !!($scope.event && $scope.event.owner && (value.id == $scope.event.owner.id));
                //});

                $scope.$on('$destroy', function () {
                    if ($scope.channelName) {
                        channelService.unsubscribe($scope.channelName).sync();
                        socketio.getSocket().removeListener($scope.channelName, updateData);
                    }
                    if ($scope.channelUserPrivate) {
                        channelService.unsubscribe($scope.channelUserPrivate).sync();
                        socketio.getSocket().removeListener($scope.channelUserPrivate, updateUserPrivateData);
                    }
                });

                var updateData = function (data) {
                    console.log('event channel', data);

                    if (data.code === StreamCode.CHANGED && data.stream) {
                        if (data.stream.object.entity_type === 'event') {
                            if (data.stream.visibility_changed) {
                                console.log('visibility changed');
                                visibilityService.checkEventsViewable($scope.event.id).then(function (data) {
                                    if (!data.error) {
                                        console.log(data.result);
                                        var viewableHash = data.result;
                                        var redir = (viewableHash.hasOwnProperty($scope.event.id)) ? !viewableHash[$scope.event.id] : false;
                                        if (redir) {
                                            redirectToList("Доступ к мероприятию закрыт.");
                                        }
                                    }
                                });
                            }
                            $scope.$apply(function () {
                                var needUpdateTags = false;
                                if ($scope.event.tags.length != data.content.tags.length) {
                                    needUpdateTags = true;
                                } else {
                                    needUpdateTags = _.any($scope.event.tags, function (value, index) {
                                        return $scope.event.tags[index].id === data.content.tags[index].id;
                                    });
                                }
                                angular.extend($scope.event, eventsService.processEventForFrontend(data.content));
                                if (needUpdateTags) $scope.$broadcast('tagsChanged', $scope.event.tags);
                            });
                        } else if (data.stream.object.entity_type === 'userlike') {
                            $scope.$apply(function () {
                                $scope.event.liked_count = data.content.liked_count;
                            });
                        } else if (data.stream.object.entity_type === 'event_user_state') {
                            $scope.$apply(function () {
                                $scope.event.participants = data.content.participants;
                                $scope.event.participants_num = data.content.participants_num;
                                $scope.event.participants_num_not_registered = data.content.participants_num_not_registered;
                                $scope.event.participants_intended = data.content.participants_intended;
                                $scope.event.participants_now = data.content.participants_now;
                                $scope.event.participants_were = data.content.participants_were;
                                $scope.$emit('eventParticipantsChanged');
                            });
                        }
                    } else if (data.code === StreamCode.DELETED) {
                        redirectToList("Данное мероприятие было удалено!");
                    }
                };

                var updateUserPrivateData = function (data) {
                    console.log('user private channel', data);

                    if (data.code === StreamCode.CREATED) {
                        $scope.$apply(function () {
                            $scope.event.bun_request = data.content.state.bun_request;
                            $scope.event.user_state = data.content.state.user_state;
                        });
                    } else if (data.code === StreamCode.ACCEPTED) {
                        $scope.$apply(function () {
                            $scope.event.bun_request = data.content.state.bun_request;
                            $scope.event.invite_request = data.content.state.invite_request;
                            $scope.event.user_state = data.content.state.user_state;
                        });
                    } else if (data.code === StreamCode.DECLINED) {
                        $scope.$apply(function () {
                            $scope.event.invite_request = data.content.state.invite_request;
                        });
                    }
                    $rootScope.$emit('needUpdateButtons');
                };

                var redirectToList = function (msg) {
                    alert(msg);
                    $state.go('content', {content: 'events'});
                };

                var listenSocket = function () {
                    $scope.channelName = channelService.getChannelName('event', $scope.event.id);
                    channelService.subscribe($scope.channelName).sync();
                    socketio.getSocket().on($scope.channelName, updateData);

                    $scope.channelUserPrivate = channelService.getChannelName('user');
                    channelService.subscribe($scope.channelUserPrivate).sync();
                    socketio.getSocket().on($scope.channelUserPrivate, updateUserPrivateData);
                };

                /*
                 $scope.removeBan = function (banID) {
                 userbanService.removeBan(banID).then(
                 function (reponse) {
                 $scope.loadBannedUsers();
                 },
                 function () {
                 }
                 );
                 };

                 $scope.loadBannedUsers = function () {

                 $scope.bannedUsers = [];

                 userbanService.getObjectBannedUsers($scope.event.content_type_id, $scope.event.id).then(
                 function (response) {
                 if (angular.isArray(response.result)) {
                 $scope.bannedUsers = response.result;
                 }
                 },
                 function () {
                 }
                 );

                 };
                 */

                $scope.$watch('event', function (value) {
                    if ($scope.event) {
                        if (channelService.checkSubscribe('event', $scope.event.id) === -1) {
                            listenSocket();
                        }
                        $scope.invitationResource = _.find(value.resources, function (r) {
                            return eventsService.isInvitationResource(r);
                        });
                        $scope.setEventParticipants($scope.event.participants);

                        userService.getUser().then(function (user) {
                            $scope.isOwner = $scope.event.owner && user.id == $scope.event.owner.id;
                            if ($scope.isOwner) {
                                //$scope.loadBannedUsers();
                            }
                            $scope.event_loaded = true;
                        });

                        $scope.xPostsLocator = {event: value.id};

                    }
                    /*
                     if ($scope.event && $scope.event.owner && $rootScope.user.id == $scope.event.owner) {
                     $scope.isOwner = true;
                     $scope.loadBannedUsers();
                     }
                     */

                });
                /*
                 $rootScope.$onRootScope('event_eventChanged', function (arg1, changed_event) {
                 console.log("event_eventChanged", arg1, changed_event);
                 if (changed_event.id == $scope.event.id) {
                 $scope.reloadEventData();
                 }
                 });
                 */
                $scope.changeEventVisibility = function (event_id, visibility) {

                    var data = {
                        event_id: event_id
                    };

                    eventsService.changeVisibility(data).then(function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Unable to set place visibility",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Success",
                                text: "Place visibility was successfully set"
                            });
                        }

                    });

                };

                $scope.deleteEvent = function () {

                    $scope.confirm("Вы уверены, что хотите удалить событие?").then(function () {
                        eventsService.deleteEvent($scope.event.id).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка",
                                            text: data.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    // location
                                    $location.path('/events');
                                    //$location.replace('/events');

                                    $scope.$emit("flash", {
                                        type: "success",
                                        title: "Удалено",
                                        text: "Вы удалили мероприятие " + $scope.event.name
                                    });

                                }

                            },
                            function () {
                                // general RPC error
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Server error",
                                    text: "Sorry, error occurred while submitting. Please try again later."
                                });
                            }
                        );
                    });
                };

                $scope.startEditEvent = function () {

                    $scope.isBeingEdited = true;
                    $scope.editEvent = angular.copy($scope.event);
                };

                $scope.cancelEditEvent = function () {
                    $scope.isBeingEdited = false;
                };

                $scope.editEvent = function () {

                    // Compare start and finish dates
                    var d1 = $scope.event.edit_ts_start || {};
                    var d2 = $scope.event.edit_ts_finish || {};

                    if (d1 && d2 && d1 >= d2) {
                        return {
                            ts_finish: 'invalid_range'
                        };
                    }

                    if (d1 && d1 < new Date()) {

                        return {
                            ts_start: 'starts_in_past'
                        };
                    }

                    // Select existing place
                    if ($scope.event.addressType === 0 && !$scope.event.edit_place) {
                        return {
                            edit_place: 'Please select event place'
                        };
                    }

                    var deferred = $q.defer();
                    var data = angular.copy($scope.event.visibility);
                    data.name = $scope.event.edit_name;
                    data.ts_start = $scope.event.edit_ts_start;
                    data.ts_finish = $scope.event.edit_ts_finish;
                    data.description = $scope.event.edit_description;
                    data.place_id = ($scope.event.addressType === 0) ? $scope.event.edit_place.id : null;

                    eventsService.editEvent($scope.event.id, data).then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isFormError(data.error)) {
                                    deferred.reject(data.error.data);
                                }
                                else if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Edit event error",
                                        text: data.error.data.msg
                                    });
                                    deferred.reject();
                                }
                            }

                            else {

                                $scope.reloadEventData();
                                $scope.cancelEditEvent();

                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Event saved"
                                });

                            }

                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                            deferred.reject();
                        }
                    );
                    return deferred.promise;

                };


                $scope.reloadEventData = function () {

                    eventsService.getEvent($stateParams.event_alias).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    Service404.setMessage(data.error.message);
                                    $state.go('404');
                                }
                                else if ($scope.isPermissionDenied(data.error)) {
                                    Service404.setMessage($filter('translate')('EXCEPT_EVENT_NO_PERMISSION'));
                                    $state.go('403');
                                }
                                else if ($scope.isContentBanned(data.error)) {
                                    Service404.setMessage($filter('translate')('EXCEPT_EVENT_BANNED'));
                                    $state.go('403');
                                }
                                else if ($scope.isContentOnModeration(data.error)) {
                                    Service404.setMessage($filter('translate')('EXCEPT_EVENT_WAITING_MODERATION'));
                                    $state.go('403');
                                }
                            }

                            else {
                                $scope.event = data.result;
                                $scope.event = eventsService.processEventForFrontend($scope.event);

                                if ($scope.event && $scope.eventName !== $scope.event.name) {
                                    $scope.eventName = $scope.event.name;
                                    $rootScope.$emit('breadcrumbDataUpdated');
                                }
                                else {
                                    $scope.eventName = $scope.event ? $scope.event.name : null;
                                }

                                // If event had already started - disable it's edit
                                $scope.event.started = $scope.event.ts_start <= new Date();
                                $scope.event.finished = $scope.event.ts_finish && $scope.event.ts_finish <= new Date();
                                reloadFriendsStates();
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                            $state.go('404');
                        }
                    );

                };

                $scope.isStarted = function (e) {
                    return e.ts_start <= new Date();
                };

                $scope.isFinished = function (e) {
                    return e.ts_finish && e.ts_finish <= new Date();
                };

                $scope.canBeCanceled = function () {
                    return $scope.event_loaded &&
                        $scope.event.state !== eventStateCodes.CANCELED;
                };

                $scope.canBeFinished = function () {
                    return $scope.event_loaded &&
                        $scope.isStarted($scope.event) && !$scope.isFinished($scope.event) &&
                        $scope.event.state !== eventStateCodes.CANCELED;
                };

                $scope.placeCanBeSet = function () {
                    return $scope.event_loaded &&
                        $scope.isOwner && !$scope.isFinished($scope.event) &&
                        $scope.event.state !== eventStateCodes.CANCELED;
                };

                $scope.copyEvent = function () {
                    eventsService.copyToClipboard($scope.event);
                    $state.go('new_event');
                };

                $scope.disableEvent = function () {
                    $scope.confirm("Вы уверены, что хотите отменить событие?").then(function () {
                        eventsService.disableEvent($scope.event.id).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Disable event error",
                                            text: data.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    $scope.$emit("flash", {
                                        type: "success",
                                        title: "Мероприятие отменено"
                                    });
                                    $scope.reloadEventData();
                                }

                            },
                            function () {
                                // general RPC error
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Ошибка отмены мероприятия"
                                });
                            }
                        );
                    });
                };

                $scope.finishEvent = function () {

                    $scope.confirm("Вы уверены, что хотите завершить событие?").then(function () {
                        eventsService.finishEvent($scope.event.id).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка завершения мероприятия",
                                            text: data.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    $scope.$emit("flash", {
                                        type: "success",
                                        title: "Мероприятие завершено"
                                    });
                                    $scope.reloadEventData();
                                }

                            },
                            function () {
                                // general RPC error
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Ошибка завершения мероприятия"
                                });
                            }
                        );
                    });
                };

                $scope.isInvitationResource = function (r) {
                    return eventsService.isInvitationResource(r);
                };


                function reloadFriendsStates() {

                    if (!$rootScope.user.authenticated) {
                        $scope.friends_states = [[], [], []];
                        return;
                    }
                    var data = {
                        event_alias: $scope.event.alias
                    };

                    jsonRPC.request('events.get_friends_states', data).then(
                        function (data) {
                            $scope.friends_states = data.result;
                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                        }
                    );

                }

                $scope.reloadEventData();

                $scope.$onRootScope("photosUploaded", function () {
                    $scope.reloadEventData();
                });

                $scope.$on("closeEventForm", function () {
                    $scope.event = $scope.editEvent;
                });

                //$scope.$onRootScope('event:userBanned', function () {
                //    $scope.loadBannedUsers();
                //});

                //$scope.canAddXPosts = function () {
                //    return $rootScope.user.authenticated && !$scope.event.user_banned && !$scope.event.readOnly;
                //};

            }]);

})();
