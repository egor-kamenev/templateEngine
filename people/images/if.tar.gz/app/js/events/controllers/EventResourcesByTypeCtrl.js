(function(){
'use strict';

angular.module('app.controllers.eventresourcesbytypectrl', [])
.controller('EventResourcesByTypeCtrl', ['$rootScope', '$scope', '$q', '$state', '$stateParams', '$filter', 'Service404', 'tagService', 'eventsService', 'xStates', 'channelService', 'socketio',
 function ($rootScope, $scope, $q, $state, $stateParams, $filter, Service404, tagService, eventsService, xStates, channelService, socketio) {

    var resType = $stateParams.resource_type,
        initialTargetUsers = {
            interestTags: [],
            friendshipTags: [],
            specifiedUsers: [],
            invitedEmails: ''
        };
    $scope.sendingInProgress = false;
    $scope.interestTagsEditor = tagService.getTagSelector();
    $scope.friendshipTagsEditor = tagService.getTagSelector('friendship_tags'); 
    $scope.targetUsers = angular.copy(initialTargetUsers);
    $scope.defaultAmount = 1;
    $scope.defaultComment = '';
    $scope.malformedEmails = [];
    $scope.dataSource = [];

    var updateData = function (data) {
        console.log('resource channel', data);
        updateUserState(data.code, data.content.object.user.username);
    };

    var listenSocket = function () {
        $scope.channelName = channelService.getChannelName('resource', $stateParams.resource_type);
        channelService.subscribe($scope.channelName).sync();
        socketio.getSocket().on($scope.channelName, updateData);
    };

    function toggleSend(){
        $scope.$emit('show_send_all_button', _.some($scope.dataSource, {state: xStates.new}) );
    }

    function updateUserState(code, username) {
        var newState = code === 3 ? xStates.accepted : xStates.rejected;

        angular.forEach($scope.dataSource, function(value, key){
            if(value.username === username) {
                $scope.$apply(function(){
                    $scope.dataSource[key].current_state = newState;
                });
            }
        });
    }

    // This state is accessible by the owner only
    var doneWatch = $scope.$parent.$watch('event_loaded', function(loadComplete){
        if(loadComplete){
            if(!$scope.$parent.isOwner){
                $state.go('403');
            }

            $scope.selectedResource = _.find($scope.$parent.event.resources, function(r){
                return r.id == resType;
            });

            if(!$scope.selectedResource){
                Service404.setMessage($filter('translate')('EVENT_RESOURCE_NOT_FOUND'));
                $state.go('404');
            }

            $scope.userSelector = eventsService.getUserSelectorForResource($scope.selectedResource.id);

            refreshEventResourceOffers();
            listenSocket();
            doneWatch();
        }
    });

    $scope.canBeRemoved = function(resourceOffer){
        // Only new, not sent resource offers and invites can be removed by the owner
        return resourceOffer.state == xStates.new;
    };

    $scope.removeResourceOffer = function (offerID) {
        $scope.confirm("Вы действительно хотите удалить это предложение?").then(function(){
            $rootScope.loading = true;
            eventsService.removeResourceOffer(offerID).then(
                function(){
                    $scope.dataSource = _.filter($scope.dataSource, function(item) {
                        return item.id != offerID;
                    });
                    toggleSend();
                },
                function(){
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Попробуйте повторить попытку позже"
                    });
                }
            ).finally(function () {
                $rootScope.loading = false;
            });
        });
    };

    function refreshEventResourceOffers() {
        console.log("refreshEventResourceOffers!!");
        $rootScope.loading = true;
        eventsService.getResourceOffers($scope.selectedResource.id).then(
            function(data) {
                if(data.error){
                    if($rootScope.isLogicError(data.error)){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Error",
                            text: data.error.data.msg
                        });
                    }
                } else{
                    $rootScope.loading = false;
                    $scope.dataSource = _.pluck(data.result, 'object');
                    toggleSend();
                }
            },
            function(){
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Попробуйте повторить попытку позже"
                });
                $rootScope.loading = false;
            }
        );
    }
     /*
    var getResourcesRecipients = function() {

        var data = angular.copy($scope.targetUsers),
            deferred = $q.defer();

        data.event_id = $scope.event.id;
        data.interestTags = tagService.convertTagsToRPCData(data.interestTags);
        data.friendshipTags = tagService.convertTagsToRPCData(data.friendshipTags);

        eventsService.getResourcesRecipients(data).then(
            function(response) {
                $scope.targetUsers = angular.copy(initialTargetUsers);

                if(response.error){
                    if($rootScope.isLogicError(response.error)){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Error",
                            text: response.error.data.msg
                        });
                    }
                    deferred.reject();
                }
                else{
                    if (response.result.violated_restriction) {
                        $scope.$emit("flash", {
                            type: "warning",
                            title: "Внимание",
                            text: "В список получателей попали пользователи, не подходящие по возрастному ограничению, они были исключены"
                        });
                    }
                    if (response.result.invalid_emails.length > 0) {
                        $scope.$emit("flash", {
                            type: "warning",
                            title: "Внимание",
                            text: "В списке email адресов найдены не корректные адреса (\""
                                + response.result.invalid_emails[0] +
                                "\", ...), они были исключены"
                        });
                    }
                    deferred.resolve(response.result.users);
                }
            },
            function(response){
                deferred.reject();
            }
        );
        return deferred.promise;
    };
     */

    /*$scope.createResourceOffers = function(){

        var emailsTxt = $scope.targetUsers.invitedEmails.trim();
        $scope.malformedEmails = [];

        if( emailsTxt != "" ){

            var emailsArray = _.map(emailsTxt.split('\n'), function(e){return e.trim();}),
                EMAIL_REGEXP = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;

            if(emailsArray.length > 0){
                angular.forEach(emailsArray, function(e){
                    if(e){
                        if(!EMAIL_REGEXP.test(e)){
                            $scope.malformedEmails.push(e);
                        }
                    }
                });

                if($scope.malformedEmails.length > 0){
                    var errors = {
                        invitedEmails: 'invalid'
                    };
                    return errors;
                }
            }
        }

        $rootScope.loading = true;
        getResourcesRecipients().then(
            function(recipients){

                // Show warning if recipients list is empty
                if(recipients.length === 0){
                    $scope.$emit("flash", {
                        type: "warning",
                        title: "Приглашения не отправлены",
                        text: "Не найдено пользователей, удовлетворяющих условиям поиска, попробуйте их изменить."
                    });
                }

                var data = {
                    bun_id: $scope.selectedResource.id,
                    users: recipients,
                    default_amount: $scope.defaultAmount,
                    emails: angular.copy($scope.invitedEmails),
                    default_comment: $scope.defaultComment
                };

                eventsService.createResourceOffers(data).then(
                    function(data){
                        if(data.error){
                            if($rootScope.isLogicError(data.error)){
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else{
                            $scope.dataSource = data.result;
                            $scope.invitedEmails = '';
                            $scope.defaultAmount = 1;
                            $scope.defaultComment = '';
                            $scope.closeSendModal();
                            //$scope.isAddUsersToSendListDialogOpen = false;
                            //refreshAmount();
                        }
                        $rootScope.loading = false;
                    },
                    function(data){
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Ошибка отправки приглашений, повторите запрос позже."
                        });
                        $rootScope.loading = false;
                    }
                );

            },
            function(){
                $rootScope.loading = false;
            }
        );
    };
     */

    function recalculateStats(){

        // Zero stats
        _.map($scope.selectedResource.stats, function(o){
            o.amount = 0;
        });

        angular.forEach($scope.dataSource, function(rOffer){
            var state = rOffer.state,
                s = _.find($scope.selectedResource.stats, function(st){
                    return st.state == state;
                });

            if(s){
                s.amount += 1;
            }
            else{
                $scope.selectedResource.stats.push({state: state, amount: 1});
            }

        });
    }

    $rootScope.$on('refreshEventResourceOffers', function(event, data){
        if(data.length) {
            $scope.dataSource = data;
            toggleSend();
        } else {
            refreshEventResourceOffers();
        }
    });

    $scope.sendResourceOffers = function () {
        $rootScope.loading = true;
        eventsService.sendResourceOffers($scope.selectedResource.id, $scope.dataSource).then(
            function(data) {
                if(data.error){
                    if($rootScope.isLogicError(data.error)){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Error",
                            text: data.error.data.msg
                        });
                        $rootScope.loading = false;
                    }
                } else{
                    $rootScope.loading = false;
                    //$scope.dataSource =  data.result;
                    $scope.dataSource = _.pluck(data.result, 'object');
                    recalculateStats();
                    $scope.$emit('ResourceSent', null);
                    toggleSend();
                }
            });
    };

    $rootScope.$on('sendResourceOffers', function(){
        $scope.sendResourceOffers();
    });

    $scope.$on('$destroy', function () {
        if ($scope.channelName) {
            channelService.unsubscribe($scope.channelName).sync();
            socketio.getSocket().removeListener($scope.channelName, updateData);
        }
    });


}]);

})();
