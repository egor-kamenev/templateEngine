(function () {
    'use strict';
    angular.module('app.controllers.invitesctrl', []).controller('InvitesCtrl', [
        '$scope', '$state', '$stateParams', 'eventsService',
        function ($scope, $state, $stateParams, eventsService) {

            var acceptInvite = $stateParams.action == 'accept';
            //rejectInvite = $stateParams.action == 'reject';

            $scope.isValidToken = angular.isDefined($stateParams.token) && $stateParams.token.trim() !== '';
            $scope.accepted = $scope.rejected = undefined;

            if ($scope.isValidToken) {
                if (acceptInvite) {
                    eventsService.acceptInviteByToken($stateParams.token).then(
                        function (response) {
                            $scope.accepted = response.error ? false : !!response.result.success;
                        },
                        function () {
                            $scope.accepted = false;
                        }
                    );
                }
                else {
                    eventsService.rejectInviteByToken($stateParams.token).then(
                        function (response) {
                            $scope.rejected = response.error ? false : !!response.result.success;
                        },
                        function () {
                            $scope.rejected = false;
                        }
                    );
                }
            }
        }
    ]);
})();