(function () {
    'use strict';
    angular.module('app.controllers.eventplaceshistoryctrl', []).controller('EventPlacesHistoryCtrl', [
        '$scope', '$stateParams', '$rootScope', 'eventsService', 'jqPaginationSettings', '$location',
        function ($scope, $stateParams, $rootScope, eventsService, jqPaginationSettings, $location) {

            $scope.limit = jqPaginationSettings.limit;
            $scope.total = 0;
            $scope.maxPage = 0;
            $scope.loaded = false;
            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            $scope.places = [];

            $scope.getPlaces = function () {
                eventsService.eventPlaceChangesHistory($stateParams.event_alias, $scope.currentPage).then(
                    function (data) {

                        if (!data.result.items.length) {
                            $scope.loaded = true;
                            return;
                        }

                        $scope.places = data.result.items;
                        $scope.total = data.result.total;
                        $scope.loaded = true;

                        if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);

                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Please try again later."
                        });
                    });
            };

            $rootScope.$onRootScope('event_place_changed', function () {
                $location.search('page', 1);
                $scope.getPlaces();
            });

            $scope.getPlaces();

        }]);

})();