(function(){
'use strict';

angular.module('app.controllers.eventcreatectrl', [])
    .controller('EventCreateCtrl',
    [
        '$scope', '$state', 'eventsService', 'placesService', 'userLocationService',
        function ($scope, $state, eventsService, placesService, userLocationService) {

            userLocationService.getUserLocation().then(function (location) {
                $scope.userLocation = location;
            });

            var clipboadEvent = eventsService.getClipboard();

            if (clipboadEvent) {
                $scope.event = angular.copy(clipboadEvent);
                // Fix copied event start and finish dates
                // set start to today + 1 hour from now
                $scope.event.ts_start = moment().add('hours', 1).toDate();

                if (clipboadEvent.ts_finish && clipboadEvent.ts_start) {

                    var now = moment(),
                        duration = moment(clipboadEvent.ts_finish) - moment(clipboadEvent.ts_start);

                    $scope.event.ts_finish = moment(now + duration).toDate();

                }

            }
            else {
                $scope.event = {};
                $scope.event.ts_start = moment().add(1, 'hours').toDate();
                $scope.event.visibility = {
                    value: 4,
                    show_for_all: true,
                    indexable: true
                };
            }

            $scope.$on('$destroy', function () {
                eventsService.resetClipboard();
                placesService.resetClipboard();
            });


        }
    ]);

})();
