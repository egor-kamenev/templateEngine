(function(){
'use strict';

angular.module('app.controllers.verifyemailctrl', [])
  .controller('VerifyEmailCtrl', ['$scope', '$stateParams', '$q', 'contactsService', 'userService', function ($scope, $stateParams, $q, contactsService, userService) {

    console.log($stateParams);
    $scope.verifResult = {};

    contactsService.verificationEmail($stateParams.email, $stateParams.key).then(
        function (data) {
            $scope.verifResult = data.result;
            if($scope.verifResult.is_valid){
                // Reload premissions
                userService.getUser(true);//checkLogin();
            }
        },
        function () {
            $scope.$emit("flash", {
                type: "error",
                title: "Server error",
                text: "Sorry, error occurred while submitting. Please try again later."
            });
        }
    );

}]);

})();