(function(){
angular.module('contacts.service', []).
service('contactsService',['jsonRPC', function(jsonRPC){

    //var self = this;

    //this.getContacts = function(){
    //
    //    return jsonRPC.request('contacts.get_contacts').then(
    //        // Success
    //        function (data) {
    //            return data.result;
    //        },
    //        // Error
    //        function (){
    //            return [];
    //        }
    //    );
    //};

    this.getTypes = function(data){

        return jsonRPC.request('contacts.get_types', data).then(
            // Success
            function (data) {
                return data.result;
            },
            // Error
            function (){
                return [];
            }
        );
    };

    //this.addContact = function(val, type){
    //    var data = {
    //        contact_value: val,
    //        contact_type: type
    //    };
    //    return jsonRPC.request('contacts.add_contact', data);
    //};
    //
    //this.deleteContact = function(id){
    //    var data = {
    //        contact_id: id
    //    };
    //    return jsonRPC.request('contacts.delete_contact', data);
    //};
    //
    //this.setSearchable = function(id, val){
    //    var data = {
    //        contact_id: id,
    //        searchable: val
    //    };
    //    return jsonRPC.request('contacts.set_searchable', data);
    //};

    //this.setAdministrative = function(id){
    //    var data = {
    //        contact_id: id
    //    };
    //    return jsonRPC.request('contacts.set_administrative', data);
    //};
    //
    //this.editContact = function(id, val){
    //    var data = {
    //        contact_id: id,
    //        value: val
    //    };
    //    return jsonRPC.request('contacts.edit_contact', data);
    //};

    this.resendVerification = function(id){
        var data = {
            contact_id: id
        };
        return jsonRPC.request('contacts.resend_verification', data);
    };

    this.checkVerification = function(id,code){
        var data = {
            contact_id: id,
            user_verification_code: code
        };
        return jsonRPC.request('contacts.check_verification', data);
    };

    this.verificationEmail = function(email, key) {
        var data = {"email": email, "key": key};
        return jsonRPC.request('contacts.verify_email', data);
    };

}]);

})();