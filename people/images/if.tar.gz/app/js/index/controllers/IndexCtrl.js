(function(){
'use strict';

angular.module('app.controllers.indexctrl', [])
  .controller('IndexCtrl', ['$scope', '$compile', '$window', '$location', 'userService', function ($scope, $compile, $window, $location, userService) {


        $scope.twitter_login_check_hack = "";
      
        $scope.socialAuthPopup = function(backend){

            var url = 'signup/social/login/' + backend;
            var wnd = $window.open(
                url,
                "Connecting via " + backend,
                "width=500, heigth=350, location=0, toolbar=0"
            );

            var timer = setInterval(function () {
                if (wnd.closed) {
                    try {
                        $scope.$apply(
                            $location.path('/signup')
                        );
                        
                    } 
                    finally {
                        clearInterval(timer);
                    }
                    
                }
            }, 50);

        };

        $scope.socialAssociationPopup = function(backend){

            var url = 'signup/social/login/' + backend;
            var wnd = $window.open(
                url,
                "Connecting via " + backend,
                "width=500, heigth=350, location=0, toolbar=0"
            );

            var timer = setInterval(function () {
                if (wnd.closed) {
                        clearInterval(timer);
                }
            }, 50);

        };

        $scope.showTwitterPnotify = function(){

            $.pnotify({
                title: 'You are currently logged in to Twitter',
                text: 'You can use your Twitter account to <button class="btn" ng-click="socialAuthPopup(\'twitter\')">register</button>', 
                type: 'success',
                addclass: 'angularjs_compilation_required'
            });
            var element = $('.angularjs_compilation_required');
            $compile(element)($scope);
        };


        // Show 'connect social accounts' pnotifies
        if(userService.isAuthenticated() && !userService.social_association_notifications_shown){
            userService.getNotAssociatedSocialAccounts(
                function(accounts){
                    angular.forEach(accounts, function (social_account) {

                        $scope.$emit("flash", {
                            type: "success",
                            title: "Connect social account",
                            text: 'Connect your <button ng-click="socialAssociationPopup(\'' + social_account.title +'\')">' +
                                social_account.title + '</button> account to profile'
                        }, $scope);
                    });
                    userService.social_association_notifications_shown = true;
                },
                function(){
                    // Error callback
                }
            );

        }
        else{
            

            if(!userService.social_registration_notifications_shown){
                // Check FB login status and show reg pnotify
                window.fbAsyncInit = function() {
                    FB.init({
                        appId      : '1381661515385188',
                        status     : true // Check Facebook Login status
                    });

                    FB.getLoginStatus(function(response) {
                        if (response.status === 'connected' || response.status === 'not_authorized') {
                            $.pnotify({
                                type: 'success',
                                title: 'You are currently logged in to Facebook',
                                text: 'You can use your Facebook account to  <button class="btn" ng-click="socialAuthPopup(\'facebook\')">register</button>', 
                                addclass: 'angularjs_compilation_required'
                                
                            });
                            var element = $('.angularjs_compilation_required');
                            $compile(element)($scope);

                        }
                        else {
                        }
                    });


                };
                (function(d, s, id){
                    var js, fjs = d.getElementsByTagName(s)[0];
                    if (d.getElementById(id)) {return;}
                    js = d.createElement(s); js.id = id;
                    js.src = "//connect.facebook.net/en_US/all.js";
                    fjs.parentNode.insertBefore(js, fjs);
                }(document, 'script', 'facebook-jssdk'));

                // Show "register with twitter" pnotify if user is currently logged in Twitter
                var twitter_img_html = '<img style="display:none;" src="https://twitter.com/login?redirect_after_login=%2Fimages%2Fspinner.gif" />';

                var element = $compile(twitter_img_html)($scope);
                element.bind("load" , function(){
                    $scope.$apply(
                        function(){
                            if(!userService.isAuthenticated()){
                                $scope.showTwitterPnotify();
                            }
                        }
                        
                    );
                });
                userService.social_registration_notifications_shown = true;
            }
        }
    }]);

})();