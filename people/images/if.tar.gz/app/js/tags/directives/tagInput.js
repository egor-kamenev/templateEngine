(function () {
    angular.module('tag.input', ['ui.select']).directive("tagInput", function ($parse) {
        return {
            scope: {
                tags: '=',
                selector: '=',
                placeholder: '@'
            },
            templateUrl: '/static/partials/tags/tag_input.html',
        };
    });
})();
