(function () {
    /** @jsx React.DOM */

    angular.module('tag.widget', []).directive('tagWidget', [
        '$rootScope', '$state', 'filtersService', 'rTagsWidget',
        function ($rootScope, $state, filtersService, rTagsWidget) {
            return {
                restrict: "A",
                replace: true,
                scope: {
                    tags: '=',
                    contentType: '@'
                },
                templateUrl: '/static/partials/tags/tag_widget.html',
                link: function (scope, element) {

                    //var tagWidget = React.createFactory(rTagsWidget);
                    var tagWidget = rTagsWidget;


                    function renderTags(new_tags) {
                        React.render(
                            React.createElement(tagWidget, {
                                tags: new_tags || scope.tags,
                                contentType: scope.contentType ? scope.contentType : ''
                            }),
                            element[0]
                        );

                    }

                    renderTags();

                    scope.$on('tagsChanged', function (event, tags) {
                        renderTags(tags);
                    });

                    /*
                     angular.element(el).delegate(".tag", 'click', function (e) {
                     var inContentState = $state.includes('content');
                     var tag = scope.tags[angular.element(e.target).index()];
                     filtersService.searchByTag(tag);
                     if (!inContentState) {
                     if (angular.isDefined(scope.contentType)) {
                     $rootScope.switchFilterContentType(scope.contentType);
                     }
                     $state.go('content', filtersService.toParams());
                     }
                     });
                     */
                }
            };
        }
    ]);

})();