(function () {
    'use strict';
    angular.module('tag.services', []).service('tagService', [
        '$rootScope', 'tagTypeLabels', 'jsonRPC', 'predefinedFilters',
        function ($rootScope, tagTypeLabels, jsonRPC, predefinedFilters) {

            var self = this;
            this.convertTagsToRPCData = function (tags) {

                return _.map(tags, function (tag) {
                    return tag.name;
                });

            };
 
            this.getTagSelector = function (tagType, allowCustom) {
                return {
                    choices: [],
                    query: function(searchTerm) {
                        var selector = this;
                        searchTerm = searchTerm || '';
                        console.log("SearchTerm ", searchTerm);

                        // Custom tags allowed by default
                        allowCustom = !angular.isDefined(allowCustom) ? true : !!allowCustom;

                        // Method returns all tags by default
                        var data = {results: []},
                            method = self.getAllTags,
                            args = [searchTerm],
                            getTyped = tagType && searchTerm.length < 3,
                            getEmpty = !tagType && searchTerm.length < 3;

                        // But, in case we need type tags:
                        if (getTyped) {
                            selector.choices = self.getTypeTags(tagType);
                            return;
                        }
                        // tag type is not set, we show empty dropdown untill user enters 3 or more letters
                        if (getEmpty) {
                            selector.choices = data.results;
                            return;
                        }

                        method(args).then(
                            function (response) {
                                if (response.error) {
                                    if ($rootScope.isLogicError(response.error)) {
                                        $rootScope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка запроса тэгов",
                                            text: response.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    if (allowCustom) {
                                        var res = [];
                                        if (response.result.length === 0) {
                                            res.push({
                                                name: searchTerm,
                                            }); 
                                        } else {
                                            var inResponse = false;
                                            angular.forEach(response.result, function (item) {
                                                res.push(item);
                                                if (item.name === searchTerm) {
                                                    inResponse = true;
                                                }
                                            });
                                            if (!inResponse) {
                                                res.splice(0, 0, {name: searchTerm});
                                            }
                                        }
                                        selector.choices = res;
                                    } else {
                                        selector.choices = response.result;
                                    }
                                }
                            },
                            // RPC request error
                            function () {
                            }
                        );
                    }
                };
            };

            this.getTypeTags = function (tagType) {

                for (var i in predefinedFilters) {
                    for (var j = 0; j < predefinedFilters[i].length; j++) {
                        if (angular.isDefined(predefinedFilters[i][j].useForTags) && predefinedFilters[i][j].useForTags === tagType) {
                            return predefinedFilters[i][j].children;
                        }
                    }
                }
                return [];
            };


            this.getAllTags = function (search_term) {
                return jsonRPC.request('esearch.tags', {search_term: search_term});
            };

            //this.getUsedFriendshipTags = function(){
            //    /*
            //     Returns a list of tags that user used in his friendship relations.
            //     */
            //    return jsonRPC.request('tags.get_used_friendship_tags');
            //
            //};
        }]);

})();
