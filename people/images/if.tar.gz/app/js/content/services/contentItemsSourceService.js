(function () {
    'use strict';
    angular.module('app.services.contentitemssourceservice', ['app']).value('LoadItemsMode', {
        'PREPEND': 0,
        'APPEND': 1
    }).service('contentItemsSourceService', [
        '$q', '$rootScope', '$cacheFactory', 'contentSettings', 'userService', 'placesService', 'eventsService',
        'frontendSettings', 'imageUrl', 'fullName', 'typeByTags', 'xStates', 'filtersService', '$stateParams',
        'LoadItemsMode',
        function ($q, $rootScope, $cacheFactory, contentSettings, userService, placesService, eventsService,
                  frontendSettings, imageUrl, fullName, typeByTags, xStates, filtersService, $stateParams,
                  LoadItemsMode) {

            var itemsSources = {};

            function clearItemsSources(){
                itemsSources = {};
                itemsSources[contentSettings.CONTENT_TYPES.EVENTS] = {page: 0, total: 0};
                itemsSources[contentSettings.CONTENT_TYPES.PLACES] = {page: 0, total: 0};
                itemsSources[contentSettings.CONTENT_TYPES.USERS] = {page: 0, total: 0};
                itemsSources[contentSettings.CONTENT_TYPES.FRIENDS] = {page: 0, total: 0};

                itemsSources[contentSettings.CONTENT_TYPES.EVENTS][contentSettings.MODE.MAP] = [];
                itemsSources[contentSettings.CONTENT_TYPES.EVENTS][contentSettings.MODE.LIST] = [];
                itemsSources[contentSettings.CONTENT_TYPES.EVENTS][contentSettings.MODE.STREAM] = [];

                itemsSources[contentSettings.CONTENT_TYPES.USERS][contentSettings.MODE.MAP] = [];
                itemsSources[contentSettings.CONTENT_TYPES.USERS][contentSettings.MODE.LIST] = [];
                itemsSources[contentSettings.CONTENT_TYPES.USERS][contentSettings.MODE.STREAM] = [];

                itemsSources[contentSettings.CONTENT_TYPES.PLACES][contentSettings.MODE.MAP] = [];
                itemsSources[contentSettings.CONTENT_TYPES.PLACES][contentSettings.MODE.LIST] = [];
                itemsSources[contentSettings.CONTENT_TYPES.PLACES][contentSettings.MODE.STREAM] = [];
            }

            clearItemsSources();

            var currentItemsSource = getCurrentItemsSource();

            var sourceServices = {};
            sourceServices[contentSettings.CONTENT_TYPES.USERS] = userService;
            sourceServices[contentSettings.CONTENT_TYPES.PLACES] = placesService;
            sourceServices[contentSettings.CONTENT_TYPES.EVENTS] = eventsService;

            var forceReload = {};
            forceReload[contentSettings.CONTENT_TYPES.USERS] = true;
            forceReload[contentSettings.CONTENT_TYPES.PLACES] = true;
            forceReload[contentSettings.CONTENT_TYPES.EVENTS] = true;

            var defaultOptions = {
                filters: null,
                pageSize: 20,
                appendObjects: true,
                withTotal: true,
                force: false
            };

            var itemsSourceFilterParameters = {};
            var defaultItemsFilterParameters = {
                timestamp: null,
                parameters: {
                    filters: null,
                    force: null,
                    withTotal: null
                }
            };

            var minUpdateInterval = 10000;

            var mapWarningAlreadyShow = false;

            function itemsSourceShouldBeUpdated(options, skipForce, ct, fm) {
                var timestampNow = moment().valueOf();

                ct = ct || $rootScope.currentFilterContentType;
                fm = fm || $rootScope.currentFilterMode;

                if (!itemsSourceFilterParameters[ct]) {
                    itemsSourceFilterParameters[ct] = {};
                }
                if (!itemsSourceFilterParameters[ct][fm]) {
                    itemsSourceFilterParameters[ct][fm] = angular.copy(defaultItemsFilterParameters);
                }

                if (!itemsSourceFilterParameters[ct][fm].timestamp || !angular.equals(itemsSourceFilterParameters[ct][fm].parameters, options) ||
                    (timestampNow - itemsSourceFilterParameters[ct][fm].timestamp) >= minUpdateInterval ||
                    (!skipForce && forceReload[ct])) {

                    itemsSourceFilterParameters[ct][fm] = {
                        timestamp: timestampNow,
                        parameters: angular.copy(options)
                    };

                    return true;
                }
                return false;
            }

            //function optimizeEventDataEntry(item) {
            //    item._typeByTags = typeByTags(item);
            //    item._bg = "background-image: url('" + (imageUrl(item.background, "micro") || '/static/i/default.jpg') + "');";
            //    item._owner_avatar = "background-image: url('" + (imageUrl(item.owner.avatar, "small") || '/static/i/no-avatar.gif') + "');";
            //    item._owner_href = "/users/" + item.owner.username;
            //    item._owner_name = fullName(item.owner);
            //    item._href = "/events/" + item.alias;
            //    item._place_href = (item.place) ? ("/places/" + item.place.alias) : "#";
            //    item._ts_published = moment(item.ts_published).format('DD MMM/YY');
            //    item._age_class = item.age_restriction > 18 ? "adult" : "default";
            //
            //    item._not_published = item.is_being_moderated || item.is_banned;
            //    item._state_class = "";
            //    if (item.is_being_moderated) {
            //        item._state_class += "pending-moderation";
            //    }
            //
            //    if (item.is_banned) {
            //        item._state_class += " banned";
            //    }
            //
            //    item._ts_range = moment(item.ts_start).format('DD MMM HH:mm');
            //    if (item.ts_finish) {
            //        item._ts_range += " - " + moment(item.ts_finish).format('DD MMM HH:mm');
            //    }
            //
            //    if (item.participants) {
            //        for (var i = 0; i < item.participants.length; i++) {
            //            var member = item.participants[i];
            //            member._bg = "background-image: url('" + (imageUrl(member.avatar, "small") || '/static/i/no-avatar.gif') + "');";
            //            member._href = "/users/" + member.username;
            //            member._name = fullName(member);
            //        }
            //    }
            //
            //    item._show_go_button =
            //        //!item.participants &&
            //        !item.readOnly &&
            //        $rootScope.user.authenticated &&
            //        $rootScope.user.username != item.owner.username && !(
            //        (item.is_finished && ((item.by_invitation && item.invite_request && item.invite_request.state != xStates.accepted) ||
            //        (item.bun_request && item.bun_request.state == xStates.sent))) ||
            //        (item.is_going && ((item.by_invitation && item.invite_request && item.invite_request.state != xStates.accepted) ||
            //        (item.bun_request && item.bun_request.state == xStates.sent)))
            //        );
            //
            //    item._show_go_hint = item._show_go_button && !(item.participants && item.participants.length);
            //    //console.warn("_ITEM: ", item);
            //    return item;
            //}
            //
            //function optimizedEventDataLoader(filters, force, page, pageSize, withTotal) {
            //    var contentType = $rootScope.currentFilterContentType;
            //    var source = sourceServices[contentType];
            //    var backend = source.getObjects(filters, force, page, pageSize, withTotal);
            //    if ($rootScope.currentFilterMode === contentSettings.MODE.STREAM
            //        || $rootScope.currentFilterContentType !== contentSettings.CONTENT_TYPES.EVENTS) {
            //        return backend;
            //    }
            //
            //    var d = $q.defer();
            //    backend.then(function (response) {
            //        if (response && response.result && response.result.items) {
            //            _.forEach(response.result.items, optimizeEventDataEntry);
            //            d.resolve(response);
            //        } else {
            //            d.reject();
            //        }
            //    }, function () {
            //        d.reject();
            //    });
            //
            //    return d.promise;
            //}

            function getObjectsSource(contentType, filterMode, byParams) {
                var sourceService = sourceServices[contentType];
                if (!sourceService) {
                    console.error("Error: unknown content type: ", contentType);
                    return null;
                }

                switch (filterMode) {
                    case contentSettings.MODE.STREAM:
                        return {
                            fetcher: sourceService.getStream,
                            cacheSaver: sourceService.saveStreamCache
                        };
                    case contentSettings.MODE.LIST:
                    case contentSettings.MODE.MAP:
                        return {
                            fetcher: byParams ? sourceService.getObjectsByParams : sourceService.getObjects,
                            cacheSaver: sourceService.saveCache
                        };
                    default:
                        console.error("Error: unknown filter mode: ", filterMode);
                        return null;
                }
            }

            function mergeObjects(objects, source, mergeByProperty, keepOld, mode) {
                if (!objects) {
                    objects = [];
                }

                if (angular.isArray(source)) {
                    angular.forEach(source, function (item) {
                        if (angular.isUndefined(item[mergeByProperty])) {
                            return;
                        }

                        var existItem = _.find(objects, function (obj) {
                            return obj[mergeByProperty] === item[mergeByProperty];
                        });

                        if (existItem) {
                            if (!keepOld) {
                                angular.extend(existItem, item);
                            }
                        }
                        else {
                            if (mode === LoadItemsMode.PREPEND) {
                                objects.splice(0, 0, item);
                            }
                            else {
                                objects.push(item);
                            }
                        }
                    });
                }
                return objects;
            }

            function getCurrentPage(contentType) {
                if (!itemsSources || Object.keys(itemsSources).length <= 0) {
                    return null;
                }

                var ct = contentType || $rootScope.currentFilterContentType;
                return itemsSources[ct].page;
            }

            function setCurentTotal(total, contentType) {
                if (!itemsSources || Object.keys(itemsSources).length <= 0) {
                    return null;
                }
                var ct = contentType || $rootScope.currentFilterContentType;

                itemsSources[ct].total = total;
            }

            function getCurentTotal(contentType) {
                if (!itemsSources || Object.keys(itemsSources).length <= 0) {
                    return null;
                }
                var ct = contentType || $rootScope.currentFilterContentType;

                return itemsSources[ct].total;
            }

            function getCurrentItemsSource(contentType, filterMode) {
                if (!itemsSources || Object.keys(itemsSources).length <= 0) {
                    return null;
                }

                var ct = contentType || $rootScope.currentFilterContentType;
                var fm = filterMode || $rootScope.currentFilterMode;

                if (!itemsSources[ct]) {
                    itemsSources[ct] = {};
                }
                if (!itemsSources[ct][fm]) {
                    itemsSources[ct][fm] = [];
                }

                currentItemsSource = itemsSources[ct][fm];

                return currentItemsSource;
            }


            function setCurrentItemsSource(items, isAppendObjects, contentType, filterMode) {
                var ct = contentType || $rootScope.currentFilterContentType;
                var fm = filterMode || $rootScope.currentFilterMode;

                if (isAppendObjects) {
                    mergeObjects(itemsSources[ct][fm], items, 'id');
                }
                else {
                    //itemsSources[ct].page = 1; // now current page in $rootScope
                    itemsSources[ct][fm] = items;
                }

                currentItemsSource = itemsSources[ct][fm];
            }


            $rootScope.$watch('currentFilterMode', function (value) {
                setCurrentItemsSource([], false, $rootScope.currentFilterContentType, value);
                //getCurrentItemsSource($rootScope.currentFilterContentType, value);
                forceReload[$rootScope.currentFilterContentType] = true;
            });

            $rootScope.$watch('currentFilterContentType', function (value) {
                setCurrentItemsSource([], false, value, $rootScope.currentFilterMode);
                //getCurrentItemsSource(value, $rootScope.currentFilterMode);
                forceReload[value] = true;
            });

            $rootScope.$on("event:user.loggedOut", function(){
                clearItemsSources();
            });

            return {
                /*
                 Load items from the service and merge them with existing objects.
                 options:
                 * offset_from - start offset for load items (from 0)
                 * count - count of the items to download
                 * itemsCount - count of the items after download
                 * ts - timestamp to indicate start of the items
                 * mode - prepend/append
                 * filters - current filters from filtersService
                 * force - replace current items source

                 return value:
                 * items - merged items
                 * offset - top offset of the updated items
                 * total - total amount of the items on the service
                 * count - count of the new loaded items
                 */
                loadItems: function (options, previousOptions, loadedItemsCount) {
                    var deferred = $q.defer();

                    loadedItemsCount = loadedItemsCount || 0;

                    var self = this;

                    var contentType = options.contentType || $rootScope.currentFilterContentType;
                    var filterMode = options.filterMode || $rootScope.currentFilterMode;
                    var source = options.source || getObjectsSource(contentType, filterMode, true);

                    var downloadCount = options.count;

                    var downloadOffset = options.offset_from;
                    var currentItemsLength = getCurrentItemsSource(contentType, filterMode).length;
                    //var downloadOffset = options.offset_from + (options.mode === LoadItemsMode.APPEND ? (options.itemsCount - options.count) : 0);
                    //
                    //var currentItemsLength = getCurrentItemsSource(contentType, filterMode).length;
                    //if (currentItemsLength < downloadCount && options.mode === LoadItemsMode.APPEND && !options.force) {
                    //    downloadOffset = options.offset_from + currentItemsLength;
                    //}

                    if ((currentItemsLength + downloadCount) < options.itemsCount) {
                        options.count = options.itemsCount - currentItemsLength;
                    }

                    if (!options.force && itemsSources[contentType].force === true){
                        options.force = true;
                        itemsSources[contentType].force = false;
                    }

                    var params = {
                        filters: options.filters,
                        ts: options.ts,
                        offset: downloadOffset,
                        count: options.count,
                        with_total: true
                    };

                    if (options.fetcherParams) {
                        angular.forEach(options.fetcherParams, function (value, key) {
                            params[key] = value;
                        });
                    }

                    console.log('load items params', params);

                    if (options.force !== true && !itemsSourceShouldBeUpdated(params, true, contentType, filterMode)) {
                        console.log('resolve by current items source');

                        deferred.resolve({
                            items: getCurrentItemsSource(contentType, filterMode),
                            offset: null,
                            total: getCurentTotal(contentType),
                            count: 0
                        });

                        return deferred.promise;
                    }

                    source.fetcher(params).then(
                        function (response) {

                            console.log('load items response:', response);

                            var result = response.result || response;
                            var total = result.total;
                            setCurentTotal(total);

                            if (options.source && angular.isFunction(options.source.itemSelector) && result.items.length > 0) {
                                result.items = _.map(result.items, options.source.itemSelector);
                            }

                            var currentItems = options.force ? [] : getCurrentItemsSource(contentType, filterMode);

                            if (result.items.length === 0) {
                                var previousOffset = previousOptions ? previousOptions.offset_from : null;
                                var previousCount = previousOptions ? (previousOptions.count - options.count) : 0;
                                setCurrentItemsSource(currentItems, false, contentType, filterMode);
                                deferred.resolve({
                                    items: currentItems,
                                    offset: previousOffset,
                                    total: total,
                                    count: previousCount
                                });
                            }
                            else if (result.items.length === options.count) {
                                var spliceFromIndex = 0;

                                var countOfItemsToRemove = currentItems.length > options.itemsCount ?
                                    Math.max(0, options.count + (currentItems.length - options.itemsCount))
                                    : options.count;

                                var items = result.items;
                                if (options.mode === LoadItemsMode.PREPEND) {
                                    spliceFromIndex = currentItems.length - countOfItemsToRemove;
                                    items = items.reverse();
                                }
                                var removedItems = currentItems.splice(spliceFromIndex, countOfItemsToRemove);

                                var countBeforeMerge = currentItems.length;
                                var mergedItems = mergeObjects(currentItems, items, 'id', true, options.mode);
                                var newItemsCount = mergedItems.length - countBeforeMerge + loadedItemsCount;

                                var offset = options.MODE === LoadItemsMode.PREPEND ? 0 : options.offset_from;

                                if (mergedItems.length >= options.itemsCount) {
                                    console.log('new items:', newItemsCount, options);
                                    setCurrentItemsSource(mergedItems, false, contentType, filterMode);
                                    deferred.resolve({
                                        items: getCurrentItemsSource(contentType, filterMode),
                                        offset: offset,
                                        total: getCurentTotal(contentType),
                                        count: newItemsCount
                                    });
                                }
                                else {
                                    var mergeMode = options.mode === LoadItemsMode.APPEND ? LoadItemsMode.PREPEND : LoadItemsMode.APPEND;
                                    mergedItems = mergeObjects(mergedItems, removedItems, 'id', false, mergeMode);
                                    setCurrentItemsSource(mergedItems, false, contentType, filterMode);

                                    if (options.mode === LoadItemsMode.PREPEND && offset === options.offset_from) {
                                        newItemsCount = mergedItems.length - currentItemsLength;
                                        console.log('new items:', newItemsCount, options);
                                        deferred.resolve({
                                            items: getCurrentItemsSource(contentType, filterMode),
                                            offset: offset,
                                            total: getCurentTotal(contentType),
                                            count: newItemsCount
                                        });
                                    }
                                    else {
                                        //TODO: check
                                        var countToDownload = options.count - newItemsCount;
                                        offset += options.count - countToDownload;
                                        var opt = angular.extend({}, options, {
                                            count: countToDownload,
                                            offset_from: offset
                                        });
                                        console.log('try load next items', opt);

                                        self.loadItems(opt, options, newItemsCount).then(function (data) {
                                            deferred.resolve(data);
                                        }, function (data) {
                                            deferred.resolve(data);
                                        });
                                    }
                                }
                            }
                            else {
                                //just merge them with exists items
                                var newItemsSource = mergeObjects(currentItems, result.items, 'id', true, options.mode);
                                setCurrentItemsSource(newItemsSource, false, contentType, filterMode);

                                deferred.resolve({
                                    items: getCurrentItemsSource(contentType, filterMode),
                                    offset: null,
                                    total: getCurentTotal(contentType),
                                    count: result.items.length
                                });
                            }
                        },
                        function (error) {
                            console.error('an error occurred during loading items', error);
                            deferred.resolve({
                                items: getCurrentItemsSource(contentType, filterMode),
                                offset: options.offset_from,
                                total: getCurentTotal(contentType),
                                count: 0
                            });
                        }
                    );

                    return deferred.promise;
                },

                /**
                 * Update via new API (in T1099 context)
                 * @param opt
                 * @returns {*}
                 */
                update: function (opt) {

                    var deferred = $q.defer();
                    var options = angular.extend({}, defaultOptions, opt);

                    var contentType = $rootScope.currentFilterContentType;
                    var filterMode = $rootScope.currentFilterMode;

                    //var currentPage = itemsSources[contentType].page;
                    var currentPage = options.filters.page;

                    //var previousFilters = itemsSourceFilterParameters[contentType]
                    //    && itemsSourceFilterParameters[contentType][filterMode]
                    //    && itemsSourceFilterParameters[contentType][filterMode].parameters;

                    //if (previousFilters) {
                    //    options.filters.page = previousFilters.filters.page;
                    //    if (!angular.equals(options.filters, previousFilters.filters)) {
                    //        currentPage = 0;
                    //    }
                    //}

                    //options.filters.page = currentPage;

                    if (!itemsSourceShouldBeUpdated(options)) {
                        deferred.resolve(getCurrentItemsSource());
                        return deferred.promise;
                    } else {
                        options.force = true;
                    }

                    var source = getObjectsSource(contentType, filterMode);
                    var force = forceReload[contentType] || options.force;

                    forceReload[contentType] = false;

                    console.log('Reload objects', options);
                    $rootScope.loading = true;

                    /**
                     * Method bellow update the map.
                     * pass true as last parameter for use light format API (see T1099 for more info)
                     */
                    source.fetcher(options.filters, force, currentPage, options.pageSize, options.withTotal, options.lightFormat)
                        .then(function (response) {
                            var items = null;
                            var total = 0;
                            if (response && response.result && response.result.items) {
                                items = response.result.items;
                                total = response.result.total; // total items for pagination
                            }
                            else {
                                items = [];
                            }

                            var contentNotSwitchedYet = $rootScope.currentFilterContentType === contentType;
                            if (contentNotSwitchedYet) {
                                //forceReload[contentType] = false;
                                //var appendObjects = options.appendObjects && !!currentPage;
                                setCurrentItemsSource(items, options.appendObjects !== false, contentType, filterMode); // ставлю false всегда на appendObjects для пагинации, аргумент не убирал чтоб не поломать ничего с картой
                                source.cacheSaver(response.result);

                                //if (options.appendObjects && items.length > 0) {
                                //    itemsSources[contentType].page = currentPage + 1;
                                //}
                            }

                            //var currentItemsSource = getCurrentItemsSource();
                            getCurrentItemsSource();

                            if (filterMode === contentSettings.MODE.MAP) {
                                var mapCantFitAll = response.result.total > options.pageSize;
                                if (mapCantFitAll && !mapWarningAlreadyShow) {
                                    $rootScope.$emit("flash", {
                                        type: "success",
                                        title: "Найдено более " + options.pageSize + " результатов",
                                        text: 'Попробуйте уточнить условия и географию поиска'
                                    });
                                    mapWarningAlreadyShow = true;
                                }
                            }

                            var resolveData = {items: currentItemsSource, total: total, page: response.result.page};

                            deferred.resolve(resolveData);

                        }, function (error) {
                            forceReload[contentType] = true;
                            console.error('Error update objects', error);
                            deferred.reject(null);
                            $rootScope.loading = false;
                        });

                    return deferred.promise;
                },
                get itemsSource() {
                    return getCurrentItemsSource();
                },
                getCurrentItemsSource: getCurrentItemsSource,
                get currentPage() {
                    return getCurrentPage();
                },
                setForceFlag: function(force, ct){
                    ct = ct || $rootScope.currentFilterContentType;
                    if (typeof itemsSources[ct] !== 'undefined'){
                        itemsSources[ct].force = force === true;
                    }
                }
            };
        }
    ]);

})();