(function(){
angular.module('app.services.contentsettingsservice', []).factory('contentSettingsService', [
    '$window', '$rootScope', 'mapEvents', 'contentSettings',
    function ($window, $rootScope, mapEvents, contentSettings) {

        var settings = {
            map: {
                showPopupsOnHover: true,
                showPopupsOnMarkersClick: true,
                scrollSidebarOnMarkersClick: false
            }
        };

        var isInitialized = false;

        //var isSidebarOpened = true;

        var windowHeight = null;
        var windowWidth = null;

        //var minWindowSize = 768;

        function initializeSettings() {
            initializeWindowSize();
            //initializeMapSettings();
            isInitialized = true;
        }

        function initializeWindowSize() {
            windowHeight = $window.innerHeight;
            windowWidth = $window.innerWidth;
        }

        //function initializeMapSettings() {
        //if (windowHeight < minWindowSize || windowWidth < minWindowSize) {
        //    settings.map.showPopupsOnHover = false;
        //    settings.map.showPopupsOnMarkersClick = true;
        //    settings.map.scrollSidebarOnMarkersClick = isSidebarOpened;
        //}
        //else {
        //    settings.map.showPopupsOnHover = isSidebarOpened;
        //    settings.map.showPopupsOnMarkersClick = true;
        //    settings.map.scrollSidebarOnMarkersClick = isSidebarOpened;
        //}
        //console.log('mapSettings', settings.map);
        //}

        //function updateMapSettings(sidebarOpened) {
        //    isSidebarOpened = sidebarOpened;
        //    initializeMapSettings();
        //}

        //$rootScope.$onRootScope(mapEvents.SIDEBAR_SWITCHED, function (event, args) {
        //    updateMapSettings(args['isOpened']);
        //});

        var lazyLayout = _.debounce(function () {
            if ($rootScope.currentFilterMode === contentSettings.MODE.MAP) {
                initializeWindowSize();
                //initializeMapSettings();
            }
        }, 200);

        angular.element($window).bind('resize', lazyLayout);

        $rootScope.$watch('currentFilterMode', lazyLayout);

        return {
            get mapSettings() {
                if (!isInitialized) {
                    initializeSettings();
                }
                return settings.map;
            }
        };
    }]);
})();