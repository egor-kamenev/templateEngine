(function () {
    'use strict';

    angular.module('app.controllers.contentctrl', ['app', 'map.controllers']).constant('contentSettings', {
        CONTENT_TYPES: {
            EVENTS: 'events',
            USERS: 'users',
            PLACES: 'places',
            FRIENDS: 'friends'
        },
        MODE: {
            STREAM: 'stream',
            LIST: 'list',
            MAP: 'map'
        }
    }).constant('contentEvents', {
        OBJECTS_LOADED: 'content__objectsLoaded',
        OBJECTS_RELOADED: 'content__objectsReloaded',
        OBJECTS_CHANGED: 'content__objectsChanged'
    }).controller('ContentCtrl', [
        '$scope', '$state', '$stateParams', '$rootScope', '$q', 'contentSettings', 'tagService', 'userService',
        'filtersService', 'favoritesService',
        'predefinedFilters', 'visibilityService', 'VisibilityTypes', 'streamCodes', 'StreamGroup',
        'filtersEvents', '$timeout', 'frontendSettings', 'xStates', 'mapEvents', 'contentItemsSourceService',
        'eventUserStates', '$location', 'LoadItemsMode', 'contentEvents', 'rEventListItem', 'rPlaceListItem', 'rUserListItem',
        function ($scope, $state, $stateParams, $rootScope, $q, contentSettings, tagService, userService,
                  filtersService, favoritesService, predefinedFilters, visibilityService,
                  VisibilityTypes, streamCodes, StreamGroup, filtersEvents, $timeout, frontendSettings,
                  xStates, mapEvents, contentItemsSourceService, eventUserStates, $location, LoadItemsMode, contentEvents,
                  rEventListItem, rPlaceListItem, rUserListItem) {

            // <editor-fold desc="Content type">
            $scope.states = xStates;
            $scope.eventUserStates = eventUserStates;
            $rootScope.currentFilterContentType = $stateParams.content || contentSettings.CONTENT_TYPES.EVENTS;
            $rootScope.currentFilterMode = $stateParams.show || contentSettings.MODE.MAP;

            $scope.total = 0;
            $scope.limit = frontendSettings.pageLimitList;
            $scope.maxPage = 0;

            $scope.dataSource = [];

            $scope.isContentEvents = function () {
                return $rootScope.currentFilterContentType === contentSettings.CONTENT_TYPES.EVENTS;
            };

            $scope.isContentUsers = function () {
                return $rootScope.currentFilterContentType === contentSettings.CONTENT_TYPES.USERS;
            };

            $scope.isContentPlaces = function () {
                return $rootScope.currentFilterContentType === contentSettings.CONTENT_TYPES.PLACES;
            };

            $scope.isModeStream = function () {
                return $rootScope.currentFilterMode === contentSettings.MODE.STREAM;
            };

            $scope.isModeList = function () {
                return $rootScope.currentFilterMode === contentSettings.MODE.LIST;
            };

            $scope.isModeMap = function () {
                return $rootScope.currentFilterMode === contentSettings.MODE.MAP;
            };

            // </ editor-fold>

            var itemsTemplates = {};
            itemsTemplates[contentSettings.CONTENT_TYPES.EVENTS] = rEventListItem;
            itemsTemplates[contentSettings.CONTENT_TYPES.PLACES] = rPlaceListItem;
            itemsTemplates[contentSettings.CONTENT_TYPES.USERS] = rUserListItem;

            var request_timestamp = null;
            var updateInterval = 10000;

            function getRequestTimestamp() {
                var now = moment().valueOf();
                if (request_timestamp === null || (now - request_timestamp) >= updateInterval) {
                    request_timestamp = now;
                }
                return request_timestamp;
            }

            //options: {offsetFrom, count, ts, mode, filters, force}
            $scope.loadItems = function (options) {
                var deferred = $q.defer();

                if (!options.ts) {
                    options.ts = getRequestTimestamp();
                }

                var filters = angular.copy(options.filters || filtersService.getContentFilters($rootScope.currentFilterContentType));
                angular.extend(filters, {'with_location': false});

                var params = {
                    itemsCount: $scope.listViewOptions.visibleItemsCount,
                    mode: options.mode,
                    force: options.force,
                    offset_from: options.offsetFrom,
                    count: options.count,
                    filters: filters,
                    ts: options.ts
                };

                console.log('load items:',
                    options.offsetFrom + '-' + (options.offsetFrom + $scope.listViewOptions.visibleItemsCount) + '; ts:',
                    options.ts, 'ms;',
                    params.mode === LoadItemsMode.APPEND ? 'APPEND' : 'PREPEND');

                contentItemsSourceService.loadItems(params).then(
                    function (data) {
                        $scope.dataSource = contentItemsSourceService.itemsSource;
                        $scope.listViewOptions.totalItems = data.total;

                        if (options.force) {
                            $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.dataSource});
                        }
                        else {
                            $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.dataSource});
                        }

                        deferred.resolve(data);
                    },
                    function () {
                        deferred.reject();
                    });

                return deferred.promise;
            };

            $scope.listViewOptions = {
                totalItems: 0,
                maxColumns: 3,
                appendItemsCount: 50,
                visibleItemsCount: 100,
                //itemComponentName: itemsTemplates[$rootScope.currentFilterContentType],
                itemComponent: itemsTemplates[$rootScope.currentFilterContentType],
                scrollContainerId: $scope.isModeList() ? 'outer-wrap' : 'sidebar-wrapper',
                loadItems: $scope.loadItems
            };

            $scope.buildContentViewUrl = function () {
                return '/static/partials/content/' + ($scope.isModeStream() && 'stream' || $rootScope.currentFilterContentType) + '.html';
            };

            $scope.newEventData = {};
            $scope.loadMoreBusy = false;

            // For the user location save dialog
            $rootScope.isUserLocationFormOpen = false;
            $scope.allowed_visibility_types = [
                VisibilityTypes.FRIENDS_1C,
                VisibilityTypes.FRIENDS_2C,
                VisibilityTypes.ALL
            ];

            $scope.streamCodes = streamCodes;
            $scope.StreamGroup = StreamGroup;

            $scope.dataSource = contentItemsSourceService.itemsSource;

            // For saving user location
            $scope.address_type = "1";


            $scope.activeObjectValue = null;
            $scope.getObjectValue = function (elementScope) {
                if (elementScope && elementScope.item) {
                    return elementScope.item.id;
                }
                return null;
            };

            $scope.toggleMap = function () {
                $scope.$rootScope(mapEvents.INVALIDATE_LAYOUT);
            };

            function reloadObjects(filters) {
                if ($scope.isModeMap()) {
                    return;
                }

                if ($scope.isModeList()) {
                    var params = {
                        offsetFrom: 0,
                        count: $scope.listViewOptions.visibleItemsCount,
                        mode: LoadItemsMode.APPEND,
                        filters: filters,
                        force: true
                    };
                    $rootScope.loading = true;
                    $scope.loadItems(params).finally(function () {
                        $rootScope.loading = false;
                    });
                    return;
                }

                $rootScope.loading = true;

                filters = angular.copy(filters || filtersService.getContentFilters($rootScope.currentFilterContentType));
                angular.extend(filters, {'with_location': false});
                angular.extend(filters, {'ordering': $scope.ordering});

                var options = {
                    filters: filters
                };

                options.filters.page = $scope.currentPage;

                contentItemsSourceService.update(options).then(function (data) {

                    $scope.dataSource = data.items;

                    if (data.total) {
                        $scope.total = data.total;
                        $scope.limit = frontendSettings.pageLimitList;
                        $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);
                        $rootScope.loading = false;
                    }
                });
            }

            $rootScope.$watch('currentFilterContentType', function (ct, ct_old) {
                if (ct != ct_old) {
                    //$rootScope.loading = true;
                    $scope.currentPage = 1; // when change type set current page 1
                    $scope.maxPage = 0;
                    $scope.dataSource = [];
                    $rootScope.mapCurrentPage = 1; // for map
                    $location.search('page', $scope.currentPage); // set new page in url
                    $scope.$emit('filterCurrentPageChanged', $scope.currentPage);

                    //$scope.listViewOptions.itemComponentName = itemsTemplates[ct];
                    $scope.listViewOptions.itemComponent = itemsTemplates[ct];

                    reloadObjects();
                }
            });

            // Switch state to create an object - event or place
            $scope.switchToCreate = function (newState) {
                $scope.$destroy();
                $state.transitionTo(newState);
            };


            // --------------------- EVENTS -----------------------------------------
            $rootScope.$onRootScope(mapEvents.OBJECTS_CHANGED, function (event, args) {
                $scope.dataSource = args.mapObjects; //contentItemsSourceService.itemsSource;

                var objectsWereChanged = false;
                if (args.mapObjects !== undefined && angular.isArray(args.mapObjects) && !angular.equals($scope.dataSource, args.mapObjects)) {
                    objectsWereChanged = ($scope.dataSource && $scope.dataSource.length !== args.mapObjects.length) || !!_.find($scope.dataSource, function (item) {
                        return !_.find(args.mapObjects, function (x) {
                            return item.id === x.id;
                        });
                    });

                    // зачем ?
                    $scope.dataSource = angular.copy(args.mapObjects);
                }

                //$rootScope.$emit("contentListUpdated", $scope.dataSource || []);
                $rootScope.$emit("contentListUpdated", {
                    data: $scope.dataSource || [],
                    mapMode: true
                });

                if (!$scope.dataSource.length && objectsWereChanged) {
                    $scope.$emit("flash", {
                        type: "success",
                        title: "ОК",
                        text: 'Уточните условия для п;оиска'
                    });
                }
            });

            //$scope.$watch('dataSource', function (value, old) {
            //    if (!angular.equals(value, old)) {
            //        $timeout(function () {
            //            $rootScope.$emit('masonry.reload');
            //        }, 200);
            //    }
            //});

            $scope.$onRootScope(filtersEvents.UPDATED, function (event, args) {
                var filters = args && args.value;
                if (filters) {
                    $scope.currentPage = args.value.currentPage;
                    $scope.$emit('filterCurrentPageChanged', $scope.currentPage);
                }
                reloadObjects(filters);
            });

            $rootScope.$watch('currentFilterMode', function (value) {
                $scope.listViewOptions.maxColumns = value === contentSettings.MODE.MAP ? 1 : 3;
                $scope.dataSource = null;
                $scope.currentPage = 1;

                $scope.listViewOptions.scrollContainerId = $scope.isModeList() ? 'outer-wrap' : 'sidebar-wrapper';

                $location.search('page', $scope.currentPage); // set new page in url

                if (value !== contentSettings.MODE.MAP) {
                    //$rootScope.loading = true;
                    reloadObjects();
                }

                //$rootScope.$emit('masonry.reload');
            });

            $scope.highlightObject = function (o, val) {
                if ($scope.isModeMap()) {
                    $rootScope.$emit(mapEvents.HIGHLIGHT_OBJECT, {element: o, value: val});
                }
            };

            function loadUserFavorites() {
                if (userService.isAuthenticated()) {
                    favoritesService.getFavorites().then(
                        function (data) {
                            $rootScope.user.userFavorites = data.result;
                        },
                        function (error) {
                            console.log(error);
                        }
                    );
                }
            }

            loadUserFavorites();
        }
    ]);

})();
