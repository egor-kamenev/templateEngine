(function(){
angular.module('socketio', []).provider('socketio', [
    function () {
        console.log('from socketio provider');

        var settings;
        var socket;

        this.setup = function (sets) {
            settings = sets;
        };

        this.$get = ["$window", "jsonRPC", "$cookies", "$rootScope", function ($window, jsonRPC, $cookies, $rootScope) {
            $window.WEB_SOCKET_SWF_LOCATION = settings.webSocketSwfLocation;
            $window.WEB_SOCKET_DEBUG = settings.webSocketDebug;

            console.log("Connect. WA Backend: ", WEBSOCKET_ENDPOINT);
            socket = io.connect(WEBSOCKET_ENDPOINT);
            socket.on('connect', function () {
                $rootScope.$emit('event:socketio.connected');
                console.log('socketio connected');
            });


            function getSocket() {
                if (!socket) {
                    throw new Error('Socket didnt init yet');
                }
                return socket;
            }

            function reconnect() {
                console.log("Reconnect. WA Backend: ", WEBSOCKET_ENDPOINT);
                //getSocket().socket.reconnect();
                getSocket().socket.disconnect();
                getSocket().socket.connect(WEBSOCKET_ENDPOINT);
            }

            $rootScope.$onRootScope("event:user.loggedOut", function () {
                reconnect();
            });

            $rootScope.$onRootScope("event:user.loggedIn", function () {
                reconnect();
            });

            return {
                getSocket: getSocket,
                reconnect: reconnect
            };
        }];

    }]);

})();
