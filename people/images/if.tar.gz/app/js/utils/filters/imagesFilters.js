(function(){
angular.module('app.utils.imagesfilters', [])
    .constant('imagesSettings', {
        PrefixesPattern: /^(large|big|medium|small|micro):/,
        PrefixesPatternWithOriginal: /^(original|large|big|medium|small|micro):/
    })
    .filter('onlyOriginalImages',
    [
        'imagesSettings',
        function (imagesSettings) {
            return function (input) {
                if (angular.isArray(input)) {
                    return _.filter(input, function (item) {
                        return !item.name.match(imagesSettings.PrefixesPattern);
                    });
                }
                else {
                    return !input.name.match(imagesSettings.PrefixesPattern);
                }
            };
        }
    ]);
})();