(function () {
    "use strict";
    angular.module('app.utils.xmlhttpservice', []).service('xmlHttpService', [
        '$q', '$cookies',
        function ($q, $cookies) {

            var defaultOptions = {
                method: 'GET',
                credentials: true,
                csrf: true,
                async: true,

                onSuccess: null,
                onError: null,
                onUpdateProgress: null,
                onAbort: null
            };

            function getXhr(url, options) {
                var xhr = null;

                if (angular.isDefined(XMLHttpRequest)) {
                    xhr = new XMLHttpRequest();
                }
                else if (angular.isDefined(ActiveXObject)) {
                    try {
                        xhr = new ActiveXObject("Msxml2.XMLHTTP");
                    }
                    catch (e) {
                        try {
                            xhr = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                        catch (error) {}
                    }
                }

                if (!xhr) {
                    console.log('Cannot create an XMLHTTP instance');
                }

                if (angular.isDefined(url)) {
                    xhr.open(options.method, url, options.async !== false);
                }

                if (options.credentials !== false) {
                    xhr.withCredentials = true;
                }

                if (options.csrf !== false) {
                    xhr.setRequestHeader('X-CSRFToken', $cookies.csrftoken);
                }

                return xhr;
            }

            function applyEventsHandlers(xhr, options) {
                if (angular.isFunction(options.onUpdateProgress)) {
                    xhr.upload.onprogress = function (oEvent) {
                        updateProgress(oEvent, options.onUpdateProgress);
                    };
                }

                if (angular.isFunction(options.onSuccess)) {
                    xhr.addEventListener("load", function (oEvent) {
                        transferComplete(oEvent, options.onSuccess);
                    }, false);
                }

                if (angular.isFunction(options.onError)) {
                    xhr.addEventListener("error", options.onError, false);
                }

                if (angular.isFunction(options.onAbort)) {
                    xhr.addEventListener("abort", options.onAbort, false);
                }
            }

            function updateProgress(oEvent, callback) {
                if (oEvent.lengthComputable && angular.isFunction(callback)) {
                    var progress = Math.round((oEvent.loaded / oEvent.total) * 100);
                    callback(progress, oEvent);
                }
                else {
                    // Unable to compute progress information since the total size is unknown
                }
            }

            function transferComplete(oEvent, callback) {
                var data = null;
                if (oEvent.target) {
                    var contentType = oEvent.target.getResponseHeader('Content-Type');
                    if (contentType.indexOf('application/json') === 0) {
                        data = angular.fromJson(oEvent.target.response);
                    }
                    else {
                        data = oEvent.target.response;
                    }
                }
                if (angular.isFunction(callback)) {
                    callback(data, oEvent);
                }
            }

            this.request = function (url, data, options) {
                if (options.method === 'POST') {
                    this.post(url, data, options);
                }
                else {
                    this.get(url, options);
                }
            };

            this.post = function (url, data, options) {
                var opt = angular.extend({}, defaultOptions, options);
                opt.method = 'POST';

                var xhr = getXhr(url, opt);
                applyEventsHandlers(xhr, opt);

                xhr.send(data);
            };

            this.get = function (url, options) {
                var opt = angular.extend({}, defaultOptions, options);
                opt.method = 'GET';

                var xhr = getXhr(url, opt);
                applyEventsHandlers(xhr, opt);

                xhr.send(null);
            };
        }
    ]);
})();