//(function () {
//    "use strict";
//    angular.module('deferred.services', []).service('deferredService', [
//        '$rootScope', 'channelService', 'socketio',
//        function ($rootScope, channelService, socketio) {
//            // TODO watchdog
//            var channelName = channelService.getChannelName('deferred');
//            var callbacks = {};
//
//            // register callback for deferred task
//            var deferDone = function (done) {
//                console.log('deferredService - task done:', done.id);
//                if (done.id in callbacks) {
//                    callbacks[done.id](done);
//                    delete callbacks[done.id];
//                } else {
//                    console.log('no callbacks registred for:', done.id);
//                }
//            };
//
//            // on defer task done call regitered callback
//            this.onTaskResult = function (taskId, callback) {
//                console.log('deferredService - register callback for:', taskId);
//                if (taskId in callbacks) {
//                    console.log('callback already registred for:', taskId);
//                } else {
//                    callbacks[taskId] = callback;
//                }
//            };
//
//            this.subscribe = function () {
//                console.log('deferredService - subscribe to the channel');
//                channelService.subscribe(channelName).sync();
//                socketio.getSocket().on(channelName, deferDone);
//            };
//
//            this.unsubscribe = function () {
//                console.log('deferredService - unsubscribe to the channel');
//                channelService.unsubscribe(channelName).sync();
//                socketio.getSocket().removeListener(channelName, deferDone);
//            };
//        }]);
//
//})();