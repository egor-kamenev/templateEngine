(function(){
angular.module('app.utils.breadcrumb.service', ['ui.router.state'])
    .service('breadcrumbService', ['$state', '$rootScope', '$injector', '$parse', function ($state, $rootScope, $injector, $parse) {

        var hasExplicitParentPattern = /^(.+)\.[^.]+$/;

        this.hasOwnDataProperty = function () {
            //NOTE: did so because ui-router data property inheritance wanted
            return true;
        };

        this.realHasOwnDataProperty = function (state, scope, property) {
            //NOTE: did so because caption resolving still requires the check of own property
            if (!state.data || !state.data[property]) {
                return false;
            }

            var parentState = this.getBreadcrumbParentState(state, scope);
            return !(parentState && parentState.data && parentState.data[property] && state.data[property] === parentState.data[property]);
        };

        this.getBreadcrumbParentState = function (state, scope) {
            if (state.data.breadcrumbParentState) {
                var parentStateName = angular.isFunction(state.data.breadcrumbParentState) ?
                    state.data.breadcrumbParentState(state, $rootScope, scope, $injector, state.data)
                    : state.data.breadcrumbParentState;

                return $state.get(parentStateName);
            }

            //get parent state
            var name = state.parent || (hasExplicitParentPattern.exec(state.name) || [])[1];
            return name !== undefined && $state.get(name);
        };

        this.isScopeOlderThan = function (scopeA, scopeB) {
            if (angular.equals(scopeA.length, scopeB.length)) {
                return scopeA > scopeB;
            } else {
                return scopeA.length > scopeB.length;
            }
        };

        this.getStateCaption = function (state, viewScope, useTranslate, lookForTitleFirst) {
            var caption;
            var isTitleDefined = state.title ? true : false;
            var isCaptionDefined = state.data && this.realHasOwnDataProperty(state, viewScope, 'breadcrumbCaption');
            //var isCaptionDefined = state.data && this.hasOwnDataProperty(state, viewScope, 'breadcrumbCaption');

            if (isTitleDefined && (lookForTitleFirst || !isCaptionDefined)) {
                caption = useTranslate === true ? $parse('"' + state.title + '" | translate')(viewScope) : state.title;
            }
            else if (isCaptionDefined) {
                if (angular.isFunction(state.data.breadcrumbCaption)) {
                    caption = state.data.breadcrumbCaption(state, $rootScope, viewScope, $injector, state.data);
                }
                else {
                    caption = useTranslate === true ?
                        $parse('"' + state.data.breadcrumbCaption + '" | translate')(viewScope)
                        : state.data.breadcrumbCaption;
                }
            }

            return caption;
        };

        this.buildBreadcrumbData = function (state, viewScope, useTranslate, preventSiblings) {
            var data = {
                active: false,
                caption: null,
                link: $state.href(state.name),
                siblings: [],
                name: state.name,
                shortName: state.name.split('.').pop()
            };

            data.caption = this.getStateCaption(state, viewScope, useTranslate);
            //data.caption = this.getStateCaption(state, viewScope, false);

            if (!data.caption) {
                data.caption = state.name;
            }

            if (!preventSiblings && state.data && this.hasOwnDataProperty(state, viewScope, 'breadcrumbSiblings')) {
                var siblings;
                if (angular.isArray(state.data.breadcrumbSiblings)) {
                   siblings = state.data.breadcrumbSiblings;
                }
                else if (angular.isFunction(state.data.breadcrumbSiblings)){
                    siblings = state.data.breadcrumbSiblings(state, $rootScope, viewScope, $injector, state.data);
                }
                var self = this;
                if (angular.isArray(siblings)) {
                    angular.forEach(siblings, function (item) {
                        var sibling = $state.get(item);
                        if (sibling) {
                            var siblingData = self.buildBreadcrumbData(sibling, viewScope, useTranslate, true);
                            data.siblings.push({data: siblingData});
                        }
                    });
                }
            }

            return data;
        };

        this.currentState = function (viewScope, useTranslate) {
            var state = $state.$current;
            console.info("S: ", state);
            var data = {
                caption: null,
                link: $state.href(state.name),
                name: state.name
            };

            if (state.parent) {
                var parent_link = $state.href(state.parent.name);
                if (parent_link) {
                    data.parent = {
                        link: parent_link,
                        //caption: this.getStateCaption(state.parent, viewScope, false)
                        caption: this.getStateCaption(state.parent, viewScope, true)
                    };
                }
            }

            data.caption = this.getStateCaption(state, viewScope, true);
            //data.caption = this.getStateCaption(state, viewScope, false);
            if (!data.caption) {
                data.caption = state.name;
            }

            if (state.data && this.hasOwnDataProperty(state, viewScope, 'breadcrumbSiblings')) {
                var siblings;
                if (angular.isArray(state.data.breadcrumbSiblings)) {
                   siblings = state.data.breadcrumbSiblings;
                }
                else if (angular.isFunction(state.data.breadcrumbSiblings)){
                    siblings = state.data.breadcrumbSiblings(state, $rootScope, viewScope, $injector, state.data);
                }

                var self = this;
                if (angular.isArray(siblings) && siblings.length) {
                    var res = [];

                    angular.forEach(siblings, function (item) {
                        var sibling = $state.get(item);
                        if (sibling) {
                            res.push(self.buildBreadcrumbData(sibling, viewScope, useTranslate || true, true));
                        }
                    });

                    if (res.length) {
                        data.siblings = res;
                    }
                }
            }

            return data;
        };
    }]);
})();