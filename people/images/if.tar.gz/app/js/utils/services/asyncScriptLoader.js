(function(){
angular.module('app.utils.asyncscriptloader', [])
    .constant('scriptsSettings', {
        scripts: {
            PIXASTIC: '//cdn.jsdelivr.net/pixastic/0.1.3/pixastic.all.js',
            NOKIA_API: '//js.api.here.com/se/2.5.3/jsl.js?blank=true'
        }
    })
    .service('asyncScriptLoader', [
        '$q', '$timeout',
        function ($q, $timeout) {

            function asyncLoad(url, callback) {
                $timeout(function () {
                    var oScript = document.createElement("script");
                    oScript.type = "text/javascript";
                    oScript.src = url;
                    document.getElementsByTagName("head")[0].appendChild(oScript);

                    if (angular.isFunction(callback)) {
                        oScript.onload = callback;
                    }
                }, 0);
            }

            function waitForScriptInit(predicate, callback) {
                if (!angular.isFunction(predicate) || predicate()) {
                    callback();
                }
                else {
                    $timeout(function () {
                        waitForScriptInit(predicate, callback);
                    }, 10);
                }
            }

            this.load = function (url, callback, useCurrentProtocol, checkScriptPredicate) {
                var deferred = $q.defer();

                var currentProtocol = document.location.protocol;
                if (useCurrentProtocol) {
                    var pathArray = url.split('/');
                    var urlProtocol = pathArray[0];
                    if (currentProtocol !== urlProtocol) {
                        url = currentProtocol + url.slice(urlProtocol.length);
                    }
                }

                if (url.indexOf(currentProtocol) !== 0) {
                    url = currentProtocol + url;
                }

                asyncLoad(url, callback);

                if (angular.isFunction(checkScriptPredicate)) {
                    waitForScriptInit(checkScriptPredicate, deferred.resolve);
                }
                else {
                    deferred.resolve();
                }

                return deferred.promise;
            };

        }
    ]);
})();