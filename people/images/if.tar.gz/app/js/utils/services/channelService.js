(function(){
    angular.module('channel.services', []).
        service('channelService',['$rootScope', 'socketio', function($rootScope, socketio) {
            //var channels = {};
            var self = this;
            var channelList = [];

            //this.getCurrentChannels = function () {
            //    return channelList;
            //};
            //
            this.reset = function () {
                //console.log('from channel service reset');
                //channels = {};
                channelList = [];
            };

            //this.deleteChannel = function (channel) {
            //    delete channels[channel];
            //    return self;
            //};

            //this.addChannel = function(channel, ids) {
            //    channels[channel] = ids;
            //    return self;
            //};

            this.getChannelName = function (chName, objID) {
                var channelName;
                if (chName && objID) {
                    channelName = chName + ":" + objID;
                } else if (chName.indexOf(":") === -1) {
                    channelName = chName + ":" + "private";
                } else {
                    channelName = chName;
                }
                return channelName;
            };

            this.checkSubscribe = function (chName, objID) {
                return channelList.indexOf(self.getChannelName(chName, objID));
            };

            this.subscribe = function(chName, objID) {
                var channelName = self.getChannelName(chName, objID);
                console.log('subscribe', channelName);
                if (!_.contains(channelList, channelName)) {
                    channelList.push(channelName);
                }
                return self;
            };

            this.unsubscribe = function(chName, objID) {
                var channelName = self.getChannelName(chName, objID);
                console.log('unsubscribe', channelName);
                var idx = self.checkSubscribe(channelName);
                if (idx !== -1) {
                    channelList.splice(idx, 1);
                }
                return self;
            };

            //this.getChannels = function () {
            //    return channelList;
            //};
            //
            this.sync = function () {
                console.log('channelList', channelList);
                socketio.getSocket().emit('sync_channels', {channels: channelList});
            };

            //$rootScope.$on("$routeChangeStart", function(scope, next, current) {
            //    this.reset();
            //});

        }]);

})();