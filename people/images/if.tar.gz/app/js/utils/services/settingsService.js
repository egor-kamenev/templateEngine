(function(){
angular.module('utils.settings', [])
    .service('settingsService',
    [
        'jsonRPC', '$q',
        function (jsonRPC, $q) {
            var self = this;
            self.settings = {};

            var getSettingsPromise = null;

            this.get = function (callback) {
                if (getSettingsPromise === null) {
                    var deferred = $q.defer();

                    jsonRPC.request('utils.get_settings').then(
                        function (data) {
                            if (data.error) {
                                //
                            }
                            else {
                                angular.extend(self.settings, data.result);
                                self.loaded = true;
                                deferred.resolve(self.settings);
                            }
                        },
                        function () {
                            console.log("settingsService: load failed");
                        }
                    );

                    getSettingsPromise = deferred.promise;
                }

                if (getSettingsPromise !== null) {
                    getSettingsPromise.then(function (settings) {
                        callback(settings);
                    });
                }
            };
        }])
    .constant('frontendSettings', {
        commentsRefreshTimeout: 15000, // ms,
        xPostsRefreshTimeout: 15000, // ms,
        streamRefreshTimeout: 15000, // ms,
        mapMaxObjects: 100, // The maximum number of objects to display on map
        pageLimitList: 20,
        pageLimitMap: 5
    });

})();