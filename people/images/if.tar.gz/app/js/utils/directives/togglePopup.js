(function () {
    'use strict';
    angular.module('app.togglePopup', [])
        .service("uiCalcPosition", ["$window", function ($window) {
            return function (el) {
                var offset = el.offset();
                if (offset) {
                    var left = offset.left,
                        width = el.width();
                    //top = offset.top,
                    //height = el.height();


                    var lr_pos = (left + width > $window.innerWidth) ? "right" : "left";
                    //tb_pos = (top + height > $window.innerHeight) ? "bottom" : "top";

                    return lr_pos + "_top";
                }
            };
        }])
        .directive('dropdown', ['$document', 'uiCalcPosition', function ($document, uiCalcPosition) {
            return {
                restrict: 'C',
                link: function (scope, el) {
                    var element = angular.element(el);
                    var cnt = element.children(".dropdown-container");
                    if (!cnt || !cnt.length) return;
                    var pos;
                    var toggle = element.children(".dropdown-toggle");
                    if (!toggle.length) {
                        toggle = element.children("button");
                    }

                    if (!toggle.length) {
                        toggle = element;
                    }

                    $document.bind('click', function (e) {
                        var has = element.hasClass('active');
                        var x = e.target;
                        if (x == toggle[0] && !has) {
                            element.addClass('active');
                            pos = uiCalcPosition(cnt);
                            cnt.addClass(pos);
                        } else if (
                            (x == toggle[0] && has) || (x != toggle[0] && !element.find(x).length && has) ||
                            (angular.element(x).parents('a').length > 0)
                        ) {
                            element.removeClass('active');
                            cnt.removeClass(pos);
                        }
                    });
                }
            };
        }])
        .directive('megamenu', ['$rootScope', '$timeout', '$document', 'uiCalcPosition', function ($rootScope, $timeout, $document, uiCalcPosition) {

            var $menuCnt = null;
            var needClose = false;

            function reset(e) {
                if (needClose && $menuCnt && $menuCnt.hasClass('active')) {

                    //var child = $(e.target).is($menuCnt);
                    var child = $(e.target).closest('.megamenu__submenu').length;
                    console.debug("CLICK: ", child, e.target.nodeType, e.target.tagName);
                    if (!child || (child && e.target.nodeType == 1 && e.target.tagName.toLocaleLowerCase() == "a")) {
                        __reset();
                    }
                }

            }

            function __reset() {
                $menuCnt.removeClass("active");
                $menuCnt.children('.megamenu__submenu').removeClass("left_top").removeClass("right_top");
                $menuCnt = null;
                needClose = false;
            }

            $document.delegate(".megamenu .megamenu__item--with-submenu .megamenu__submenu__toggle", 'click', function (e) {
                var hasOpenedPopup = $menuCnt !== undefined;
                var newPopup = $(e.currentTarget).parent();

                if (newPopup && newPopup.is($menuCnt)) {
                    // clicked same menu -> reset will close it
                    return;
                }

                if (hasOpenedPopup && $menuCnt) {
                    // clicked other menu and already has opened menu -> reset previous opened menu manually
                    __reset();
                }

                $menuCnt = newPopup;
                if (!$menuCnt.hasClass('active')) {
                    $menuCnt.addClass('active');
                    var $menu = $menuCnt.children('.megamenu__submenu');
                    var pos = uiCalcPosition($menu);
                    $menu.addClass(pos);

                    if (hasOpenedPopup) {
                        e.stopPropagation();
                    }
                    needClose = true;
                }
            });

            $document.bind('click', reset);

            return {
                restrict: "C",
                link: function (scope, el) {
                    function setEmptyState() {
                        $timeout(function () {
                            _.forEach($('.megamenu__submenu:not(.overflow-container)', $(el)), function (e) {
                                e = $(e);
                                var children = e.children();
                                if (_.every(children, function (child) {
                                        return $(child).is(":empty");
                                    })) {
                                    e.addClass("empty");
                                }
                            });
                        });
                    }

                    $rootScope.$on('$locationChangeSuccess', setEmptyState);
                    setEmptyState();
                }
            };
        }])
        .directive('overflowBag', ["$window", '$timeout', function ($window, $timeout) {
            return function (scope, el, attrs) {
                $timeout(function () {
                    var selector = attrs.overflowBag;
                    if (!selector)
                        return;

                    //console.info("OVERFLOW-BAG raw: ", el);

                    var element = angular.element(el);
                    var bag = element.find(".overflow-container");
                    var widthStack = [];
                    var bag_item = element.children(".overflow-expander");
                    bag_item.addClass("empty");

                    function onresize() {
                        var overflow = element.children(selector + ":not(.overflow-expander)");
                        var w = bag_item.outerWidth(true);

                        angular.forEach(overflow, function (e) {
                            w += angular.element(e).outerWidth(true);
                        });

                        var delta = w - element[0].offsetWidth;
                        if (delta > 0) {
                            var moveIn = overflow.last();
                            if (!widthStack.length) bag_item.removeClass('empty');
                            widthStack.push(moveIn.outerWidth(true));
                            bag.prepend(moveIn.detach());
                            return true;
                        }

                        if (widthStack.length && Math.abs(delta) >= widthStack[0]) {
                            widthStack.shift();
                            var moveOut = bag.children(":not(.expander)").first();
                            element.append(moveOut.detach());
                            if (!widthStack.length) bag_item.addClass('empty');
                            return true;
                        }

                        return false;
                    }

                    function __do_resize() {
                        while (onresize()) {
                        }

                        if (!bag.children().length) {
                            bag_item.addClass("empty");
                        } else {
                            bag_item.removeClass("empty");
                        }
                    }

                    __do_resize();
                    element.resize(__do_resize);
                    $window.addEventListener("resize", __do_resize);
                });
            };
        }])
        .directive('toggleState', [function () {
            var clearing_states = {};
            return {
                restrict: 'AC',
                scope: {
                    toggleState: '@',
                    toggleStateTarget: '@',
                    toggleStateCallback: '='
                },
                link: function (scope, element, attr) {
                    var state = scope.toggleState;
                    var target = angular.element(scope.toggleStateTarget);
                    if (!target.length) {
                        target = angular.element(element).parent();
                    }

                    if (!attr.hasOwnProperty('toggleStateOnlyMe')) {
                        clearing_states[target] = [];
                        clearing_states[target].push(state);
                    }

                    element.bind('click', function (e) {
                        if (clearing_states[target]) {
                            for (var i = 0; i < clearing_states[target].length; i++) {
                                if (state != clearing_states[target][i]) {
                                    target.removeClass(clearing_states[target][i]);
                                }
                            }
                        }

                        target.toggleClass(state);
                        element.toggleClass("active");
                        e.stopPropagation();

                        if (angular.isFunction(scope.toggleStateCallback)) {
                            var hasActiveClass = element.hasClass('active');
                            scope.toggleStateCallback(state, hasActiveClass);
                        }
                    });
                }
            };
        }
        ]);
    //.directive('masonryLight', ["$window", '$timeout', '$compile', function ($window) {
    //    return {
    //        restrict: 'A',
    //        transclude: true,
    //        scope: {
    //            collection: "=",
    //            user: "=",
    //            states: "=",
    //            masonryWidth: "@"
    //        },
    //        link: function ($scope, element, attributes, nullController, transclude) {
    //            $scope.masonryWidth = parseInt($scope.masonryWidth);
    //
    //            function buildGrid(apply) {
    //                var w = angular.element(element).outerWidth(true);
    //                var chunk = Math.floor(w / $scope.masonryWidth);
    //                $scope.columns = chunk;
    //                var work = function () {
    //                    if (chunk > 1) {
    //
    //                        var chunks = {};
    //                        for (var j = 0; j < $scope.collection.length; j++) {
    //                            var c = j % $scope.columns;
    //                            if (chunks[c + 1] === undefined) {
    //                                chunks[c + 1] = [];
    //                            }
    //
    //                            chunks[c + 1].push($scope.collection[j]);
    //                        }
    //
    //                        $scope.chunks = chunks;
    //                    } else {
    //                        $scope.chunks = {1: $scope.collection};
    //                    }
    //
    //                    transclude($scope, function (clone) {
    //                        element.html(clone);
    //                    });
    //                };
    //
    //                if (apply) {
    //                    $scope.$apply(work);
    //                } else {
    //                    work();
    //                }
    //            }
    //
    //            function onresize() {
    //                if (dataReady)
    //                    buildGrid(true);
    //            }
    //
    //            var dataReady = false;
    //            //var unwatch =
    //            $scope.$watch('collection', function (data) {
    //                if (data !== undefined) {
    //                    dataReady = true;
    //                    buildGrid();
    //                }
    //            });
    //
    //            angular.element(element).resize(onresize);
    //            $window.addEventListener("resize", onresize);
    //        }
    //    }
    //}]);

})();