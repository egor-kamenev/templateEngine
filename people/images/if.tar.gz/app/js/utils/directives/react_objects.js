(function () {
    /** @jsx React.DOM */
    "use strict";

    function updateUnreadMessage(scope, reqID, data) {
        var r = _.find(scope.unreadMessages, function (m) {
            return m.id == reqID;
        });

        if (r) {
            angular.extend(r, data);
        }
    }

    angular.module('app.react_stream_objects', ['app.react'])
        .factory("userLink", ['rLinks', function (rLinks) {
            return rLinks.users;
        }])
        .factory("userplaceLink", ['rLinks', function (rLinks) {
            return rLinks.places;
        }])
        .factory("eventLink", ['rLinks', function (rLinks) {
            return rLinks.events;
        }])
        .factory("photoLink", ['rLinks', function (rLinks) {
            return rLinks.photos;
        }])
        .factory("postLink", ['rLinks', function (rLinks) {
            return rLinks.posts;
        }])
        .factory("userlocationPreview", ['rLinks', function (rLinks) {
            return rLinks.places;
        }])
        .factory("photoPreview", ['rLinks', 'imageUrl', function (rLinks, imageUrl) {
            return React.createClass({
                displayName: 'photoPreview',
                render: function () {
                    var photo = this.props.instance,
                        key = 'post-' + photo.id + ':' + this.props.mode;

                    // TODO: add photo link here?
                    return (
                        <img
                            key={key}
                            src={imageUrl(photo.image_url, 'micro')} />
                    );
                }
            });
        }])
        .factory("event_user_statePreview", ['$filter', 'EventUserState', 'rLinks', function ($filter, EventUserState, rLinks) {
            var TEXT_MAP = {};
            TEXT_MAP[EventUserState.INTENDED] = 'STREAM_BODY_USER_STATE_CREATED_INTENDED';
            TEXT_MAP[EventUserState.CHECKED_IN] = 'STREAM_BODY_USER_STATE_CREATED_CHECKIN';
            TEXT_MAP[EventUserState.CHECKED_OUT] = 'STREAM_BODY_USER_STATE_CREATED_CHECKOUT';
            TEXT_MAP[EventUserState.WAS_NOT_THERE] = 'STREAM_BODY_USER_STATE_CREATED_WASNOTTHERE';
            TEXT_MAP[EventUserState.UNREAD_BUN_REQUEST] = 'STREAM_BODY_USER_STATE_CREATED_UNREAD_BUN_REQUEST';
            TEXT_MAP[EventUserState.READ_BUN_REQUEST] = 'STREAM_BODY_USER_STATE_CREATED_READ_BUN_REQUEST';

            return React.createClass({
                displayName: 'EventUserStatePreview',
                render: function () {
                    var o = this.props.object;
                    var c = TEXT_MAP[o.object.state] || "NOT_DEFINED";
                    return (
                        <div key={'user-state-preview-' + o.id + ':' + this.props.mode}>
                            {$filter('translate')(c)}
                            <rLinks.events instance={o.context}/>
                        </div>
                    );
                }
            });
        }])
        .factory("postPreview", [
            '$filter', 'rTagsWidget', 'photoSettings', 'imageUrl',
            function ($filter, rTagsWidget, photoSettings, imageUrl) {
                return React.createClass({
                    displayName: 'PostPreview',
                    render: function () {
                        var frame = {
                            border: '#000 1px solid',
                            borderRadius: '5px',
                            margin: '5px',
                            padding: '5px'
                        };

                        var post = this.props.instance,
                            tags = React.createFactory(rTagsWidget)({
                                tags: post.tags,
                                contentType: 'events',
                                key: 'events-tags-' + post.id
                            }),
                            key = 'post-' + post.id + ':' + this.props.mode;

                        // get post date
                        var postDateTime = $filter('toCommonDateTime')(post.ts_published);
                        var preview = null;
                        var title = null;

                        // Album
                        if (post.photos.length) {
                            preview = post.photos.slice(0, photoSettings.PHOTO_ALBUM_STREAM_PREVIEW_LENGTH).map(function (photo) {
                                return (
                                    <img
                                        key={"photo-" + photo.id}
                                        src={imageUrl(photo.image_url, 'micro')} />
                                );
                            });

                            title = (<div className="post-title">{post.title}</div>);
                        }

                        return (
                            <div key={key} className="object_body" style={frame}>
                                {title}
                                {preview}
                                <div className="post-date">{postDateTime}</div>
                                <div className="post-body">{post.body}</div>
                                <div className="post-tags">{tags}</div>
                            </div>
                        );
                    }
                });
            }])
        .factory("event_bun_requestPreview", [
            '$rootScope', '$filter', 'rLinks', 'xStates',
            function ($rootScope, $filter, rLinks, xStates) {
                return React.createClass({
                    displayName: 'event_bun_requestPreview',
                    render: function () {

                        var e = this.props.instance, // invitation
                            o = this.props.object,  // stream entry
                            action;

                        if (e.type == 'offer') {
                            var evtLink = "/events/" + e.bun_event_alias,
                                statusHead = $filter('translate')('EVENT_BUN_REQUEST_STATUS'),
                                commentHead = $filter('translate')('EVENT_BUN_REQUEST_COMMENT'),
                                amountHead = $filter('translate')('EVENT_BUN_REQUEST_AMOUNT'),
                                status = $filter('translate')(
                                    'EVENT_BUN_REQUEST_STATUS_' + (_.invert(xStates))[e.current_state].toUpperCase()
                                );

                            // Invite to me
                            if ($rootScope.user.username == e.username) {
                                action = $filter('translate')('INVITED_YOU_ARE');
                                var action2 = $filter('translate')('INVITED_BY_USER');
                                return (
                                    <div>
                                        {action}
                                        <a href={evtLink}>{e.bun_event_name}</a>
                                        {action2}
                                        {rLinks.users({instance: o.subject})}
                                        <div>{statusHead} {status}</div>
                                        <div>{commentHead} {e.comment}</div>
                                        <div>{amountHead} {e.amount}</div>
                                    </div>
                                );
                            }

                            // Invite from me
                            action = $filter('translate')('INVITED_BY_YOU_TO');
                            return (
                                <div>
                                    {rLinks.users({instance: o.object.user})}
                                    {action}
                                    <a href={evtLink}>{e.bun_event_name}</a>
                                    <div>{statusHead} {status}</div>
                                    <div>{commentHead} {e.comment}</div>
                                    <div>{amountHead} {e.amount}</div>
                                </div>);

                        }
                        else if (e.type == 'request') {
                            action = $filter('translate')('REQUESTS_INVITATION_TO');
                            return (
                                <div>
                                    {action}
                                    {rLinks.events({instance: e.event})}
                                </div>
                            );
                        }

                        return <div>UNKNOWN BUN REQUEST TYPE</div>;
                    }
                });
            }])
        .factory("userplacePreview", [
            '$filter', 'rTagsWidget',
            function ($filter, rTagsWidget) {
                return React.createClass({
                    displayName: 'userplacePreview',
                    render: function () {

                        var plc = this.props.instance,
                            descr = (plc.description && plc.description.length > 100) ? plc.description.substring(0, 100) + "..." : plc.description;

                        // Just to outline preview in the stream
                        var frame = {
                            border: '#000 1px solid',
                            borderRadius: '5px',
                            margin: '5px',
                            padding: '5px'
                        };

                        return (
                            <div className="object_body" style={frame}>
                                <div className="object_body_title">
                                    <a href="{placeLink}">{plc.name}</a>
                                </div>
                                <div className="content-object__info__description">
                                    {descr}
                                </div>
                                <rTagsWidget tags={plc.tags} contentType='places' key={'places-tags-' + plc.id}/>
                            </div>
                        );
                    }
                });
            }])
        .factory("eventPreview", ['$filter', 'rTagsWidget', function ($filter, rTagsWidget) {
            return React.createClass({
                displayName: 'EventPreview',
                render: function () {
                    var evt = this.props.instance,
                        fTime = evt.ts_finish ? $filter('toCommonDateTime')(evt.ts_finish) : null,
                        timeFinish = evt.ts_finish ? <span className="event__ts-finish">{fTime}</span> : null,
                        placeLink = evt.place ? (<div className="event__place"><a href={"/places/" + evt.place.alias}>{evt.place.name}</a></div>) : null,
                        descr = (evt.description && evt.description.length > 100) ? evt.description.substring(0, 100) + "..." : evt.description;

                    // Just to outline preview in the stream
                    var frame = {
                        border: '#000 1px solid',
                        borderRadius: '5px',
                        margin: '5px',
                        padding: '5px'
                    };

                    return (
                        <div className="object_body" style={frame}>
                            <div className="object_body_title">
                                <a href={"/events/" + evt.alias}>{evt.name}</a>
                            </div>
                            <div className="content-object__info__event-dates">
                                <span className="label"></span>
                                <span className="event__ts-start">{$filter('toCommonDateTime')(evt.ts_start)}</span>
                                {timeFinish}
                            </div>
                                {placeLink}
                            <div className="content-object__info__description">
                                {descr}
                            </div>
                            <rTagsWidget tags={evt.tags} contentType='events' key={'events-tags-' + evt.id}/>
                        </div>
                    );
                }
            });
        }])
        .factory("message_dialogPreview", [function () {
            return React.createClass({
                displayName: 'dialogPreview',
                render: function () {
                    return (
                        <div className="dialog-body">
                            {this.props.instance.body}
                        </div>
                    );
                }
            });
        }])
        .factory("textPreview", ['$filter', 'streamCodes', function ($filter, streamCodes) {
            return React.createClass({
                displayName: 'textPreview',
                render: function () {
                    var o = this.props.instance,
                        isHeader = this.props.header === true,
                        isBody = this.props.body === true,
                        text = (o.object.entity_type + "_" + streamCodes[o.action.code]).toUpperCase(),
                        key = "text";

                    if (isHeader) {
                        key += '-header';
                        text = "NTF_HEADER_" + text;
                        if (o.withContext) {
                            text += "_WITH_CONTEXT";
                        }
                        else if (o.withSubject) {
                            text += "_WITH_SUBJECT";
                        }
                    }
                    else if (isBody) {
                        key += '-body';

                        text = "NTF_BODY_" + text;
                        if (o.withContext) {
                            text += "_WITH_CONTEXT";
                        }
                        else if (o.withSubject) {
                            text += "_WITH_SUBJECT";
                        }

                    }

                    text = $filter('translate')(text);
                    key += '-' + o.id + ':' + this.props.mode;

                    return (
                        <div key={key} className="notification-text">
                            {text}
                        </div>
                    );
                }
            });
        }])
        .factory("userPreview", [
            '$filter', 'userAvatar', 'rLinks',
            function ($filter, userAvatar, rLinks) {
                var ua = React.createFactory(userAvatar);
                var ulink = React.createFactory(rLinks.users);

                return React.createClass({
                    displayName: 'userPreview',
                    render: function () {
                        return (
                            <div key={'user-preview-' + this.props.object.id + '-' + this.props.instance.id + ':' + this.props.mode} >
                                <div className="avatar">{ua({user: this.props.instance})}</div>
                                <div className="username">{ulink({instance: this.props.instance})}</div>
                            </div>
                        );
                    }
                });
            }])
        .factory("event_invite_requestPreview", [
            '$filter', 'eventsService', 'rLinks', 'xStates',
            function ($filter, eventsService, rLinks, xStates) {
                return React.createClass({
                    displayName: 'event_invite_requestPreview',
                    render: function () {

                        var e = this.props.instance, // invitation
                        //o = this.props.object,  // stream entry
                            c, action,
                            statusHead = $filter('translate')('EVENT_BUN_REQUEST_STATUS'),
                            status = $filter('translate')(
                                'EVENT_BUN_REQUEST_STATUS_' + (_.invert(xStates))[e.current_state].toUpperCase()
                            );

                        if (e.bun_type == eventsService.RESOURCE_TYPES.INVITATION) {
                            c = 'INVITE_' + e.type.toUpperCase() + "_TO";
                        }
                        else if (e.bun_type == eventsService.RESOURCE_TYPES.OTHER) {
                            c = 'OFFER_' + e.type.toUpperCase() + "_TO";
                        }

                        if (c) {
                            action = $filter('translate')(c);
                            return (
                                <div>
                                    {action}
                                    {rLinks.events({instance: e.event})}
                                    <div>
                                        {statusHead}
                                        {status}
                                    </div>
                                </div>
                            );
                        }

                        return <div>UNKNOWN INVITATION TYPE</div>;
                    }
                });
            }])
        .factory("friendship_requestPreview", [
            '$rootScope', '$compile', '$filter', 'xStates', 'rLinks', 'rListUtilsMixin', 'tagService', 'notificationBlockType',
            function ($rootScope, $compile, $filter, xStates, rLinks, rListUtilsMixin, tagService, notificationBlockType) {
                return React.createClass({
                    displayName: 'friendship_requestPreview',
                    componentDidMount: function () {
                        var scope = $rootScope.$new(true);
                        scope.rel = {
                            tags: this.props.instance.tags
                        };
                        scope.tagsEditor = tagService.getTagSelector('friendship_tags', true);
                        var template = '<div data-tag-input data-tags="rel.tags" data-selector="tagsEditor"></div>'; 
                        var el = $compile(template)(scope).show();
                        $("#" + this.selectID).append(el);
                    },
                    render: function () {

                        var e = this.props.instance, // friendship request
                            o = this.props.object,  // stream entry
                            mode = this.props.mode,
                            c, action,
                            tags = rListUtilsMixin.tags(
                                'friendship',
                                e.tags,
                                'friendship-tags-' + e.id
                            ),
                            statusHead = $filter('translate')('EVENT_BUN_REQUEST_STATUS'),
                            status = $filter('translate')(
                                'EVENT_BUN_REQUEST_STATUS_' + (_.invert(xStates))[e.state].toUpperCase()
                            ),
                            key = "friendship-request-" + o.id,
                            protractorID = 'friendship-request-';

                        this.selectID = "friendship-request-tags-" +
                        (mode === notificationBlockType.COMPACT ? 'compact' : 'full' ) +
                        '-' + e.id;

                        if (o.from_me) {
                            protractorID += 'from-me-' + o.context.username;
                            c = 'FRIENDSHIPREQUEST_FROM_YOU';
                            action = $filter('translate')(c);
                            return (
                                <div data-protractor-id={protractorID} key={key}>
                                    {action} {rLinks.users({instance: o.context})} {e.message} {tags}
                                    <div>{statusHead} {status}</div>
                                </div>
                            );

                        }
                        else {

                            protractorID += 'to-me-' + o.subject.username;
                            var canBeAccepted = (
                            o.object.state == xStates.sent ||
                            o.object.state == xStates.read ||
                            o.object.state == xStates.revised
                            );

                            if (canBeAccepted) {
                                tags = <div id={this.selectID}></div>;
                            }
                            c = 'FRIENDSHIPREQUEST_TO_YOU';
                            action = $filter('translate')(c);
                            return (
                                <div data-protractor-id={protractorID} key={key}>
                                    {action} {e.message} {tags}
                                    <div>{statusHead} {status}</div>
                                </div>
                            );
                        }

                    }
                });
            }])
        .factory("userbanPreview", [
            '$rootScope', '$filter', 'rLinks',
            function ($rootScope, $filter, rLinks) {
                return React.createClass({
                    displayName: 'userbanPreview',
                    render: function () {

                        var e = this.props.instance, // ban object
                            o = this.props.object,  // stream entry
                        // True if I banned somebody, false if somebody else banned me
                            byMe = o.subject.id === $rootScope.user.id,
                            suffix = e.active ? '' : '_EXPIRED',
                            text = $filter('translate')(byMe ? 'NTF_BODY_USERBAN_CREATED_BY_ME' + suffix : 'NTF_BODY_USERBAN_CREATED_TO_ME' + suffix),
                            banStatus = e.active ? 'Active' : 'Cancelled',
                            protractorID = byMe ? 'banTo' + o.subject.username + banStatus : 'banFrom' + o.subject.username + banStatus,
                            banCreatedDate = $filter('toCommonDateTime')(e.ts_created),
                            banExpireDate = e.expiration_date ? $filter('toCommonDateTime')(e.expiration_date) : $filter('translate')('BAN_NEVER_EXPIRES'),
                            createdText = $filter('translate')('BAN_CREATED'),
                            expireText = $filter('translate')('BAN_EXPIRES');

                        return (
                            <div data-protractor-id={protractorID}>
                                {text} {rLinks[e.ban_source.entity_type + "s"]({instance: e.ban_source})}
                                {o.object.comment}
                                <div data-protractor-id="">
                                    {createdText}: {banCreatedDate}
                                </div>
                                <div data-protractor-id="">
                                    {expireText}: {banExpireDate}
                                </div>
                            </div>
                        );

                    }
                });
            }])
        .factory("user_statusPreview", [
            '$rootScope', 'rTagsWidget',
            function ($rootScope, rTagsWidget) {
                return React.createClass({
                    displayName: 'user_statusPreview',
                    render: function () {
                        var e = this.props.instance, // status object
                            o = this.props.object;  // stream entry
                        return (
                            <div className="object_body">
                                {e.text}
                                <rTagsWidget
                                    tags={e.tags}
                                    contentType='users'
                                    key={'users-tags-' + o.subject.id}/>
                            </div>
                        );
                    }
                });
            }])
        .factory("goToThread", [
            '$filter', '$state',
            function ($filter, $state) {
                return React.createClass({
                    displayName: 'goToThread',
                    onClick: function () {
                        $state.go('userMessages.dialogue', {
                                partner_username: this.props.instance.from_me ?
                                    this.props.instance.context.username :
                                    this.props.instance.subject.username
                            }
                        );

                    },
                    render: function () {
                        if ($state.is('userMessages.dialogue')) {
                            return null;
                        }

                        var text = $filter('translate')('DIALOG_EXPAND_THREAD');
                        return (
                            <div className="message-meta-bottom">
                                <a
                                    className="thread"
                                    data-protractor-id={'expandThread:' + this.props.instance.context.username}
                                    onClick={this.onClick}>
                                    {text}
                                </a>
                            </div>
                        );

                    }
                });
            }])
        .factory("acceptInvitation", ['$filter', '$state', '$q', '$rootScope', 'xStates', 'messageService', 'eventsService', 'userSettingsService', function ($filter, $state, $q, $rootScope, xStates, messageService, eventsService, userSettingsService) {
            return React.createClass({
                displayName: 'acceptInvitation',
                onClick: function () {
                    var obj = this.props.instance,
                        invite = obj.object,
                        self = this;

                    // What to accept
                    // TODO: Always acceptOffer here
                    var method = (invite.type == 'request') ? messageService.acceptRequest : messageService.acceptOffer;

                    function accept(autoCheckin) {
                        method(invite.id, autoCheckin).then(
                            function (response) {
                                if (response.error) {
                                    if ($rootScope.isLogicError(response.error)) {
                                        $rootScope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка",
                                            text: response.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    invite.current_state = xStates.accepted;
                                    updateUnreadMessage($rootScope, obj.id, {
                                        object: {
                                            current_state: xStates.accepted
                                        }
                                    });
                                    self.forceUpdate();
                                    $rootScope.markAsRead([obj.id]);
                                    $rootScope.$emit('reloadMessages');
                                    $rootScope.$emit('mailPreviewChanged');


                                }

                            },
                            function () {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Попробуйте повторить попытку позже"
                                });
                            }
                        );
                    }

                    //todo: remove $rootScope.$apply ?
                    $rootScope.$apply(function () {
                        // Auto check-in for started event
                        if (invite.type == 'offer') {
                            // First of all we need to check that event is already started
                            eventsService.getEvent(invite.bun_event_alias).then(
                                function (response) {
                                    var clarifiedEvent = eventsService.processEventForFrontend(response.result),
                                        alreadyStarted = clarifiedEvent.ts_start <= new Date();

                                    if (alreadyStarted) {

                                        userSettingsService.getEventsParticipationSettings().then(
                                            function (settings) {
                                                var autoCheckIn = angular.isObject(settings.result) &&
                                                        angular.isObject(settings.result.enable_auto_check_in) &&
                                                        settings.result.enable_auto_check_in.value === true,
                                                    promise = autoCheckIn ?
                                                        $q.defer() :
                                                        $rootScope.confirm("Мероприятие уже началось, хотите сразу зачекиниться?");

                                                if (autoCheckIn) {
                                                    promise.resolve();
                                                    promise = promise.promise;
                                                }
                                                promise.then(
                                                    function () {
                                                        accept(true);
                                                    },
                                                    function () {
                                                        accept(false);
                                                    }
                                                );
                                            },
                                            function () {
                                                accept(false);
                                            }
                                        );
                                    }
                                    else {
                                        accept(false);
                                    }
                                },
                                // Error
                                function () {
                                    accept(false);
                                }
                            );
                        }
                        else {
                            accept();
                        }

                    });

                },
                render: function () {

                    var invite = this.props.instance,
                        toMe = $rootScope.user.username == invite.object.username,
                        canBeAccepted = toMe && (invite.object.current_state == xStates.sent || invite.object.current_state == xStates.read);

                    if (!canBeAccepted) {
                        return null;
                    }

                    var text = $filter('translate')('ACTION_ACCEPT_INVITATION');

                    return (
                        <div className="message-meta-bottom">
                            <a className="thread" onClick={this.onClick}>
                                {text}
                            </a>
                        </div>
                    );

                }
            });
        }])
        .factory("rejectInvitation", [
            '$rootScope', '$filter', '$state', 'xStates', 'messageService',
            function ($rootScope, $filter, $state, xStates, messageService) {
                return React.createClass({
                    displayName: 'rejectInvitation',
                    onClick: function () {
                        var obj = this.props.instance,
                            invite = obj.object,
                            self = this,
                        // What to reject
                            method = (invite.type == 'request') ? messageService.rejectRequest : messageService.rejectOffer;

                        $rootScope.$apply(function () {
                            method(invite.id).then(
                                function () {
                                    invite.current_state = xStates.rejected;
                                    updateUnreadMessage($rootScope, obj.id, {
                                        object: {
                                            current_state: xStates.rejected
                                        }
                                    });
                                    self.forceUpdate();
                                    $rootScope.markAsRead([obj.id]);
                                    $rootScope.$emit('reloadMessages');
                                    $rootScope.$emit('mailPreviewChanged');
                                },
                                function () {
                                    $rootScope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка",
                                        text: "Попробуйте повторить попытку позже"
                                    });
                                }
                            );
                        });

                    },
                    render: function () {

                        var invite = this.props.instance,
                            toMe = $rootScope.user.username == invite.object.username,
                            canBeRejected = toMe && (
                                invite.object.current_state == xStates.sent ||
                                invite.object.current_state == xStates.accepted ||
                                invite.object.current_state == xStates.read);

                        if (!canBeRejected) {
                            return null;
                        }

                        var text = $filter('translate')('ACTION_REJECT_INVITATION');

                        return (
                            <div className="message-meta-bottom">
                                <a className="thread" onClick={this.onClick}>
                                    {text}
                                </a>
                            </div>
                        );

                    }
                });
            }])
        .factory("ignoreInvitation", ['$rootScope', '$filter', '$state', 'xStates', 'userbanService',
            function ($rootScope, $filter, $state, xStates, userbanService) {
                return React.createClass({
                    displayName: 'ignoreInvitation',
                    onClick: function () {
                        var obj = this.props.instance,
                            invite = obj.object;

                        $rootScope.$apply(function () {
                            userbanService.ignoreUser(obj.subject.username).then(
                                function () {
                                    invite.current_state = xStates.ignored;
                                    updateUnreadMessage($rootScope, obj.id, {
                                        object: {
                                            current_state: xStates.ignored
                                        }
                                    });
                                    self.forceUpdate();
                                    $rootScope.markAsRead([obj.id]);
                                    $rootScope.$emit('reloadMessages');
                                    $rootScope.$emit('mailPreviewChanged');
                                },
                                function () {
                                    $rootScope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка",
                                        text: "Попробуйте повторить попытку позже"
                                    });
                                }
                            );
                        });

                    },
                    render: function () {

                        var invite = this.props.instance,
                            toMe = $rootScope.user.username == invite.object.username,
                            canBeIgnored = toMe && (
                                invite.object.current_state == xStates.sent ||
                                invite.object.current_state == xStates.read
                                );

                        if (!canBeIgnored) {
                            return null;
                        }

                        var text = $filter('translate')('ACTION_IGNORE_INVITATION');

                        return (
                            <div className="message-meta-bottom">
                                <a className="thread" onClick={this.onClick}>
                                    {text}
                                </a>
                            </div>
                        );

                    }
                });
            }])
        .factory("cancelFriendshipRequest", ['$filter', '$rootScope', 'friendsService', 'xStates', function ($filter, $rootScope, friendsService, xStates) {
            return React.createClass({
                displayName: 'cancelFriendshipRequest',
                onClick: function () {

                    var req = this.props.instance.object,
                        reqID = this.props.instance.id,
                        self = this;

                    $rootScope.$apply(function () {
                        friendsService.cancelFriendshipRequest(reqID).then(
                            function (response) {
                                if (response.error) {
                                    if ($rootScope.isLogicError(response.error)) {
                                        $rootScope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка",
                                            text: response.error.data.msg
                                        });
                                    }
                                }

                                else {

                                    req.state = xStates.cancelled;
                                    self.forceUpdate();
                                    $rootScope.$emit('reloadMessages');
                                    //$rootScope.$emit('mailPreviewChanged');
                                }

                            },
                            function () {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Попробуйте повторить попытку позже"
                                });
                            }
                        );
                    });

                },
                render: function () {
                    var r = this.props.instance,
                        canBeCancelled = r.from_me && (r.object.state == xStates.sent || r.object.state == xStates.read);

                    if (!r.from_me || !canBeCancelled) {
                        return null;
                    }

                    var text = $filter('translate')('ACTION_CANCEL_FRIENDSHIP_REQUEST');
                    return (
                        <div className="message-meta-bottom" data-protractor-id="cancelFriendshipRequest">
                            <a className="thread" onClick={this.onClick}>
                                {text}
                            </a>
                        </div>
                    );
                }
            });
        }])
        .factory("acceptFriendship", ['$filter', '$rootScope', 'friendsService', 'userService', 'xStates', 'notificationBlockType', function ($filter, $rootScope, friendsService, userService, xStates, notificationBlockType) {
            return React.createClass({
                displayName: 'acceptFriendship',
                onClick: function () {
                    var req = this.props.instance.object,
                        reqID = this.props.instance.object.id,
                        mode = this.props.mode,
                        selectID = "friendship-request-tags-" +
                            (mode === notificationBlockType.COMPACT ? 'compact' : 'full' ) +
                            '-' + reqID,
                        self = this;
                    var tags = angular.element(
                        $("#" + selectID).children().first()
                    ).scope().rel.tags;

                    $rootScope.$apply(function () {
                        friendsService.acceptFriendshipRequest(reqID, tags).then(
                            function (response) {
                                if (response.error) {
                                    if ($rootScope.isLogicError(response.error)) {
                                        $rootScope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка",
                                            text: response.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    //userService.addFriend(response.result);
                                    $rootScope.$emit("flash", {
                                        type: "success",
                                        title: "Готово",
                                        text: "Запрос на дружбу принят"
                                    });
                                    req.state = xStates.accepted;


                                    updateUnreadMessage($rootScope, reqID, {
                                        object: {
                                            state: xStates.accepted
                                        }
                                    });

                                    self.forceUpdate();
                                    $rootScope.markAsRead([reqID]);
                                    $rootScope.$emit('reloadMessages');
                                    $rootScope.$emit('mailPreviewChanged');

                                }

                            },
                            function () {
                            }
                        );
                    });

                },
                render: function () {
                    var r = this.props.instance,
                        canBeAccepted = (r.object.state == xStates.sent || r.object.state == xStates.read);

                    if (this.props.instance.from_me || !canBeAccepted) {
                        return null;
                    }

                    var text = $filter('translate')('ACTION_ACCEPT_FRIENDSHIP');
                    return (
                        <div className="message-meta-bottom">
                            <a data-protractor-id="acceptFriendshipRequest" className="thread" onClick={this.onClick}>
                                {text}
                            </a>
                        </div>
                    );

                }
            });
        }])
        .factory("rejectFriendship", ['$filter', '$rootScope', 'friendsService', 'userService', 'xStates', function ($filter, $rootScope, friendsService, userService, xStates) {
            return React.createClass({
                displayName: 'rejectFriendship',
                onClick: function () {

                    var req = this.props.instance.object,
                        reqID = this.props.instance.id,
                        self = this;

                    $rootScope.$apply(function () {
                        friendsService.rejectFriendshipRequest(reqID).then(
                            function (response) {
                                if (response.error) {
                                    if ($rootScope.isLogicError(response.error)) {
                                        $rootScope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка",
                                            text: response.error.data.msg
                                        });
                                    }
                                }
                                else {
                                    $rootScope.$emit("flash", {
                                        type: "success",
                                        title: "Готово",
                                        text: "Запрос на дружбу отклонен"
                                    });
                                    req.state = xStates.rejected;
                                    updateUnreadMessage($rootScope, reqID, {
                                        object: {
                                            state: xStates.rejected
                                        }
                                    });
                                    self.forceUpdate();
                                    $rootScope.markAsRead([reqID]);

                                    $rootScope.$emit('reloadMessages');
                                    $rootScope.$emit('mailPreviewChanged');
                                }

                            },
                            function () {
                            }
                        );
                    });

                },
                render: function () {
                    var r = this.props.instance,
                        canBeRejected = (r.object.state == xStates.sent || r.object.state == xStates.read);

                    if (r.from_me || !canBeRejected) {
                        return null;
                    }

                    if (this.props.instance.from_me) {
                        return null;
                    }
                    var text = $filter('translate')('ACTION_REJECT_FRIENDSHIP');

                    return (
                        <div className="message-meta-bottom" data-protractor-id="rejectFriendshipRequest">
                            <a className="thread" onClick={this.onClick}>
                                {text}
                            </a>
                        </div>
                    );

                }
            });
        }])
        .factory("userAvatar", ['$rootScope', 'rListUtilsMixin', function ($rootScope, rListUtilsMixin) {
            return React.createClass({
                displayName: 'UserAvatar',
                render: function () {
                    var user = this.props.user,
                        online = (user.online || $rootScope.user.username == user.username) ? 'online' : '';
                    return rListUtilsMixin.userAvatar(user, "small", React.DOM.div, true, online);
                }
            });
        }]);
})();
