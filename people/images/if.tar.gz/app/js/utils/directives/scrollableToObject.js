(function(){
angular.module('app.utils.scroll', []).directive('scrollableToObject', [
    function () {
        return {
            restrict: 'ACE',
            transclude: false,
            scope: {
                scrollTopMargin: '@',
                scrollToValue: '=',
                elementValueGetter: '=',
                elementsContainerSelector: '@'
            },
            link: function (scope, element) {
                var container = null;

                function getElementContainer() {
                    if (!scope.elementsContainerSelector) {
                        container = element.children();
                    }
                    else {
                        container = $(scope.elementsContainerSelector)[0];
                    }
                }

                function scrollTo(elem) {
                    var topMargin = Number(scope.scrollTopMargin);
                    var scrollTop = $(elem).offset().top - (angular.isNumber(topMargin) && !isNaN(topMargin) ? topMargin : 0);
                    angular.element('html, body')
                        .animate({
                            scrollTop: scrollTop + 'px'
                        }, 'slow');
                    return elem;
                }

                function findElement(value, selectorFunction) {
                    getElementContainer();

                    var childs = container.children();
                    if (childs && childs.length > 0) {
                        var destinationElement = _.find(childs, function (elem) {
                            return value === selectorFunction(angular.element(elem).scope());
                        });

                        if (destinationElement) {
                            scrollTo(destinationElement);
                        }
                    }
                }

                angular.element(element).ready(function () {
                    findElement(scope.scrollToValue, scope.elementValueGetter);
                });

                scope.$watch('scrollToValue', function (value) {
                    findElement(value, scope.elementValueGetter);
                });
            }
        };
    }
]);
})();