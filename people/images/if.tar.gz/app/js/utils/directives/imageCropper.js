(function () {
    'use strict';

    angular.module('app.utils.imagecropper', []).constant('imageCropperSettings', {
        AVATAR_THUMBNAIL: {
            'large': {'width': 120, 'height': 120},
            'big': {'width': 100, 'height': 100},
            'medium': {'width': 70, 'height': 70},
            'small': {'width': 48, 'height': 48},
            'micro': {'width': 36, 'height': 36}
        },
        BACKGROUND_THUMBNAIL: {
            'large': {'width': 1600, 'height': 200},
            'big': {'width': 1280, 'height': 160},
            'medium': {'width': 1024, 'height': 128},
            'small': {'width': 800, 'height': 100},
            'micro': {'width': 320, 'height': 40}
        },
        IMAGE_CROPPER_THEMES: {
            STANDARD: 'standard',
            LIGHT: 'light',
            DARK: 'dark'
        },
        IMAGE_CROPPER_MODES: {
            NONE: 'none',
            AVATAR: 'avatar',
            BACKGROUND: 'background'
        },
        Events: {
            FilesQueueUpdated: 'imageCropper:filesQueueUpdated'
        }
    }).directive('imageCropper', [
        'imageCropperSettings', 'scriptsSettings', 'asyncScriptLoader', '$q', '$window',
        function (imageCropperSettings, scriptsSettings, asyncScriptLoader, $q, $window) {
            return {
                restrict: 'AE',
                replace: true,
                scope: {
                    cropperSource: '=',
                    showPreview: '=preview',
                    mode: '=',
                    theme: '=',
                    effects: '='
                },
                templateUrl: '/static/partials/utils/imageCropper.html',
                controller: function ($scope, imageCropperSettings) {
                    $scope.mode = $scope.mode || imageCropperSettings.IMAGE_CROPPER_MODES.NONE;
                    $scope.theme = $scope.theme || imageCropperSettings.IMAGE_CROPPER_THEMES.STANDARD;
                    $scope.showPreview = $scope.showPreview || true;

                    $scope.updateFilesQueue = function (images) {
                        if (angular.isArray($scope.queue)) {
                            $scope.queue = _.filter($scope.queue, function (item) {
                                return item === $scope.src;
                            });
                        }
                        else {
                            $scope.queue = [];
                        }

                        angular.forEach(images, function (item) {
                            var blob = window.dataURLtoBlob && window.dataURLtoBlob(item.base64);
                            if (blob) {
                                blob.name = item.prefix + ':' + item.name;
                                $scope.queue.push(blob);
                            }
                        });

                        $scope.$emit(imageCropperSettings.Events.FilesQueueUpdated, {
                            queue: $scope.queue
                        });
                    };
                },
                link: function (scope) {
                    var originalFilename = scope.cropperSource && scope.cropperSource.name ?
                        scope.cropperSource.name.replace(/^(original|large|big|medium|small|micro):/, '') :
                        generateUniqueFilename();

                    var previewId = '#image-cropper-preview';
                    var canvasId = '#image-cropper-canvas';
                    var canvasResizedId = '#image-cropper-canvas-resized';
                    var imageId = '#image-cropper-target';

                    var image = $(imageId);
                    var preview = $(previewId);
                    var previewContainer = $('#preview-container');

                    function initializeImageSource() {
                        var getBlobURL = (window.URL || window.webkitURL).createObjectURL;
                        var isBlobSource = scope.cropperSource && angular.isObject(scope.cropperSource);

                        if (isBlobSource) {
                            scope.imageSource = getBlobURL(scope.cropperSource);
                        }
                        else {
                            scope.imageSource = scope.cropperSource;
                        }
                    }

                    function generateUniqueFilename() {
                        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                            return v.toString(16);
                        });
                    }

                    function getAspectRatio(mode) {
                        switch (mode) {
                            case imageCropperSettings.IMAGE_CROPPER_MODES.AVATAR:
                                return 1;
                            case imageCropperSettings.IMAGE_CROPPER_MODES.BACKGROUND:
                                var size = imageCropperSettings.BACKGROUND_THUMBNAIL.big;
                                return size.width / size.height;
                            case imageCropperSettings.IMAGE_CROPPER_MODES.NONE:
                                return null;
                            default:
                                return null;
                        }
                    }

                    var pixasticInitilized = false;

                    function initializePixastic() {
                        var deferred = $q.defer();

                        if (pixasticInitilized === true) {
                            deferred.resolve(Pixastic);
                        }
                        else {
                            asyncScriptLoader.load(scriptsSettings.scripts.PIXASTIC, null, true, function () {
                                return !!$window.Pixastic;
                            }).then(function () {
                                pixasticInitilized = true;
                                deferred.resolve(Pixastic);
                            });
                        }

                        return deferred.promise;
                    }

                    initializeImageSource();

                    var aspectRation = getAspectRatio(scope.mode);

                    var jcrop_api;
                    var boundx;
                    var boundy;

                    var previewWidth = 0;
                    var previewHeight = 0;

                    var selectionCoords = {};

                    var imageOriginalWidth;
                    var imageOriginalHeight;
                    var imageActualWidth;
                    var imageActualHeight;

                    var imageSettings = {};

                    function updateCoords(c) {
                        if (!scope.showPreview) {
                            return;
                        }

                        var ratioX = imageOriginalWidth / imageActualWidth;
                        var ratioY = imageOriginalHeight / imageActualHeight;

                        selectionCoords.x = c.x * ratioX;
                        selectionCoords.y = c.y * ratioY;
                        selectionCoords.h = c.h * ratioY;
                        selectionCoords.w = c.w * ratioX;
                    }

                    function setLayoutSizes() {
                        //set preview size
                        var avatarPreviewSize = {
                            width: 300,
                            height: 300
                        };

                        var previewParent = previewContainer.parent();
                        var maxAvailableWidth = $('#image-uploader-form').width() - 20;
                        if (scope.mode === imageCropperSettings.IMAGE_CROPPER_MODES.BACKGROUND) {
                            previewParent.width(maxAvailableWidth + 'px');
                        }
                        else {
                            var avatarWidth = Math.min(avatarPreviewSize.width, maxAvailableWidth / 2);
                            var avatarHeight = Math.min(avatarPreviewSize.height, maxAvailableWidth / 2);
                            previewParent.width(avatarWidth + 'px');
                            previewParent.height(avatarHeight + 'px');
                        }

                        //set image size
                        var imageContainer = $('.image-cropper-left-wrap .image-cropper-left-column');
                        var originalImageAspectRation = imageOriginalWidth / imageOriginalHeight;
                        var maxImageSize = {
                            width: maxAvailableWidth,
                            height: 400
                        };

                        var newImageHeight;
                        var newImageWidth;

                        newImageWidth = Math.min(imageContainer.height() * originalImageAspectRation, maxImageSize.width);
                        newImageWidth = Math.max(newImageWidth, maxImageSize.width);
                        //newImageWidth = Math.max(newImageWidth, previewParent.width());
                        newImageHeight = newImageWidth / originalImageAspectRation;

                        if (newImageHeight > maxImageSize.height) {
                            newImageHeight = maxImageSize.height;
                            newImageWidth = newImageHeight * originalImageAspectRation;
                        }
                        imageContainer.width(newImageWidth + 'px');
                        imageContainer.height(newImageHeight + 'px');

                        imageActualHeight = $(image).height();
                        imageActualWidth = $(image).width();
                    }

                    function setPreviewSize() {
                        if (!scope.showPreview) {
                            return;
                        }

                        previewWidth = previewContainer.width();

                        if (aspectRation) {
                            previewHeight = previewWidth / aspectRation;
                            previewContainer.height(previewHeight + 'px');
                        }
                        else {
                            previewHeight = previewContainer.height();
                        }

                        var progressBar = $('#image-uploader-progressjs');
                        if (progressBar) {
                            progressBar.height(previewHeight);
                            progressBar.width(previewWidth);
                        }
                    }


                    function updatePreview(c) {
                        if (scope.showPreview && parseInt(c.w) > 0) {
                            var ratioX = previewWidth / c.w;
                            var ratioY = previewHeight / c.h;

                            $(preview).css({
                                width: Math.round(ratioX * boundx) + 'px',
                                height: Math.round(ratioY * boundy) + 'px',
                                marginLeft: '-' + Math.round(ratioX * c.x) + 'px',
                                marginTop: '-' + Math.round(ratioY * c.y) + 'px'
                            });
                        }
                    }

                    function setJcropStyleOptions(theme) {
                        if (!jcrop_api) {
                            return;
                        }

                        switch (theme) {
                            case imageCropperSettings.IMAGE_CROPPER_THEMES.LIGHT:
                                jcrop_api.setOptions({
                                    bgColor: 'white',
                                    bgOpacity: 0.5
                                });
                                jcrop_api.ui.holder.addClass('jcrop-light');
                                break;
                            case imageCropperSettings.IMAGE_CROPPER_THEMES.DARK:
                                jcrop_api.setOptions({
                                    bgColor: 'black',
                                    bgOpacity: 0.4
                                });
                                jcrop_api.ui.holder.addClass('jcrop-dark');
                                break;
                            case imageCropperSettings.IMAGE_CROPPER_THEMES.STANDARD:
                                //default:
                                jcrop_api.setOptions({
                                    bgColor: $.Jcrop.defaults.bgColor,
                                    bgOpacity: $.Jcrop.defaults.bgOpacity
                                });
                                jcrop_api.ui.holder.addClass('jcrop-normal');
                        }
                    }

                    function saveCroppedImages() {
                        var sizesSource = null;
                        switch (scope.mode) {
                            case imageCropperSettings.IMAGE_CROPPER_MODES.AVATAR:
                                sizesSource = imageCropperSettings.AVATAR_THUMBNAIL;
                                break;
                            case imageCropperSettings.IMAGE_CROPPER_MODES.BACKGROUND:
                                sizesSource = imageCropperSettings.BACKGROUND_THUMBNAIL;
                                break;
                            default:
                                sizesSource = {
                                    'standtard': {'height': selectionCoords.h, 'width': selectionCoords.w}
                                };
                                break;
                        }


                        var resizedImages = [];
                        var count = Object.keys(sizesSource).length;
                        var index = 0;

                        angular.forEach(sizesSource, function (item, key) {

                            var image = new Image();
                            image.onload = function () {
                                var canvasResized = $(canvasResizedId)[0];
                                var ctx = canvasResized.getContext('2d');

                                canvasResized.width = item.width;
                                canvasResized.height = item.height;
                                ctx.drawImage(image, selectionCoords.x, selectionCoords.y, selectionCoords.w, selectionCoords.h, 0, 0, item.width, item.height);

                                applyPixasticEffects(canvasResizedId, function (canvas) {
                                    resizedImages.push({
                                        name: originalFilename,
                                        prefix: key,
                                        base64: canvas.toDataURL()
                                    });

                                    index += 1;
                                    if (index === count) {
                                        scope.updateFilesQueue(resizedImages.reverse());
                                    }
                                });
                            };
                            image.src = scope.imageSource;
                        });
                    }


                    function updatePixasticPreview() {

                        if (!scope.showPreview) {
                            return;
                        }

                        clearCanvas(canvasId);
                        var canvas = $(canvasId)[0];
                        var ctx = canvas.getContext("2d");

                        var image = new Image();
                        image.onload = function () {
                            ctx.drawImage(image, selectionCoords.x, selectionCoords.y, selectionCoords.w, selectionCoords.h, 0, 0, previewWidth, previewHeight);

                            applyPixasticEffects(canvasId, function () {
                                $(previewId).hide();
                                $(canvasId).show();
                                saveCroppedImages();
                            });
                        };
                        image.src = scope.imageSource;

                        canvas.width = previewWidth;
                        canvas.height = previewHeight;
                    }

                    function onSelectionMoved(c) {
                        $(previewId).show();
                        $(canvasId).hide();

                        updateCoords(c);
                        updatePreview(c);
                    }

                    function onSelectionCompleted(c) {
                        updateCoords(c);
                        updatePixasticPreview();
                    }

                    function getInitialSelectionCoords(width, height, imageWidth, imageHeight) {
                        var centerX = imageWidth / 2;
                        var centerY = imageHeight / 2;

                        return [
                            centerX - width / 2,
                            centerY - height / 2,
                            centerX + width / 2,
                            centerY + height / 2
                        ];
                    }

                    function getCropMinSize(imageHeight, imageWidth, aspectRatio) {
                        var height = 0;
                        var width = 0;

                        var minSize = 10;

                        switch (scope.mode) {
                            case imageCropperSettings.IMAGE_CROPPER_MODES.AVATAR:
                                height = imageCropperSettings.AVATAR_THUMBNAIL.large.height;
                                width = imageCropperSettings.AVATAR_THUMBNAIL.large.width;
                                break;
                            case imageCropperSettings.IMAGE_CROPPER_MODES.BACKGROUND:
                                height = imageCropperSettings.BACKGROUND_THUMBNAIL.micro.height;
                                width = imageCropperSettings.BACKGROUND_THUMBNAIL.micro.width;
                                break;
                            default:
                                height = 25;
                                width = 25;
                                break;
                        }

                        if (imageOriginalHeight && imageActualWidth) {
                            var dx = imageWidth / imageOriginalWidth;
                            var dy = imageHeight / imageOriginalHeight;
                            height *= dx;
                            width *= dy;
                        }

                        if (height < minSize) {
                            height = minSize;
                            if (angular.isNumber(aspectRatio)) {
                                width = height * aspectRatio;
                            }
                        }

                        if (width < minSize) {
                            width = minSize;
                            if (angular.isNumber(aspectRatio)) {
                                height = width / aspectRatio;
                            }
                        }

                        if (height > imageHeight) {
                            height = imageHeight;
                            if (angular.isNumber(aspectRatio)) {
                                width = height * aspectRatio;
                            }
                        }

                        if (width > imageWidth) {
                            width = imageWidth;
                            if (angular.isNumber(aspectRatio)) {
                                height = width / aspectRatio;
                            }
                        }

                        return {
                            height: height,
                            width: width
                        };
                    }


                    $(image).load(function () {
                        imageOriginalHeight = this.naturalHeight;
                        imageOriginalWidth = this.naturalWidth;
                        imageActualHeight = this.height;
                        imageActualWidth = this.width;

                        setLayoutSizes();
                        setPreviewSize();

                        var minSize = getCropMinSize(imageActualHeight, imageActualWidth, aspectRation);
                        var initialSelection = getInitialSelectionCoords(minSize.width, minSize.height, imageActualWidth, imageActualHeight);

                        if (jcrop_api) {
                            jcrop_api.destroy();
                        }

                        $(image).Jcrop({
                                onChange: onSelectionMoved,
                                onSelect: onSelectionCompleted,
                                aspectRatio: aspectRation,
                                setSelect: initialSelection,
                                bgFade: true
                            },
                            function () {
                                var bounds = this.getBounds();
                                boundx = bounds[0];
                                boundy = bounds[1];
                                jcrop_api = this;

                                jcrop_api.setOptions({
                                    minSize: [minSize.height, minSize.width]
                                });

                                setJcropStyleOptions(scope.theme);
                            });
                    });

                    function clearCanvas(id) {
                        var canvas = $(id)[0];
                        if (canvas) {
                            canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
                        }
                    }

                    function clear() {
                        imageSettings = {};

                        $(image).width('');
                        $(image).height('');

                        clearCanvas(canvasId);
                        clearCanvas(canvasResizedId);

                        if (jcrop_api) {
                            jcrop_api.destroy();
                        }

                        $('.image-cropper-container .jcrop-holder').remove();
                    }

                    scope.$watch('cropperSource', function () {
                        clear();
                        initializeImageSource();
                    });

                    scope.$on('$destroy', function () {
                        clear();
                    });

                    scope.$watch('theme', setJcropStyleOptions);

                    scope.$watch('mode', function (value) {
                        if (value) {
                            aspectRation = getAspectRatio(value);
                            //setLayoutSizes();
                            //setPreviewSize();
                            if (jcrop_api) {
                                jcrop_api.setOptions({
                                    aspectRatio: aspectRation
                                });
                            }
                        }
                    });

                    $('#image-cropper-accordion').accordion({
                        collapsible: true,
                        heightStyle: 'content'
                    });


                    function applyPixasticEffects(id, callback) {
                        if (!imageSettings) {
                            return;
                        }

                        var elementId = id || canvasId;
                        var options = {};

                        var count = Object.keys(imageSettings).length;
                        var index = 0;

                        if ((!imageSettings || count === 0 || !scope.effects) && angular.isFunction(callback)) {
                            callback($(elementId)[0]);
                        }
                        else {
                            angular.forEach(imageSettings, function (value, name) {
                                if (!value || !name) {
                                    return;
                                }

                                angular.extend(options, value);

                                var canvas = options.resultCanvas || $(elementId)[0];
                                index += 1;
                                if (index === count && angular.isFunction(callback)) {
                                    if (pixasticInitilized) {
                                        Pixastic.process(canvas, name, options, callback);
                                    }
                                    else {
                                        initializePixastic().then(function () {
                                            Pixastic.process(canvas, name, options, callback);
                                        });
                                    }
                                }
                                else {
                                    if (pixasticInitilized) {
                                        Pixastic.process(canvas, name, options);
                                    }
                                    else {
                                        initializePixastic().then(function () {
                                            Pixastic.process(canvas, name, options);
                                        });
                                    }
                                }
                            });
                        }
                    }

                    var skipLookingForFiltersChanged = false;

                    scope.resetFilters = function () {
                        $(previewId).show();
                        $(canvasId).hide();

                        imageSettings = {};

                        skipLookingForFiltersChanged = true;
                        $('.image-cropper-filter .filter-setting .filter-value').html('0');
                        $('.image-cropper-filter .filter-setting input[type="range"]').val(0);
                        skipLookingForFiltersChanged = false;

                        updatePixasticPreview();
                    };

                    if (scope.effects === true) {
                        $('.image-cropper-filter .filter-setting input[type="range"]').on('change input', function (event) {
                            if (!event || !event.target || skipLookingForFiltersChanged) {
                                return;
                            }

                            var target = event.target;
                            var value = target.value;
                            if (target.nextSibling) {
                                target.nextSibling.innerHTML = value;
                            }

                            var filter = target.getAttribute('data-filter');
                            if (filter) {
                                switch (filter) {
                                    case 'hue':
                                    case 'saturation':
                                    case 'lightness':
                                        imageSettings.hsl = {
                                            'hue': $('input[data-filter="hue"]')[0].value,
                                            'saturation': $('input[data-filter="saturation"]')[0].value,
                                            'lightness': $('input[data-filter="lightness"]')[0].value
                                        };
                                        break;
                                    case 'brightness':
                                    case 'contrast':
                                        imageSettings.brightness = {
                                            'brightness': $('input[data-filter="brightness"]')[0].value,
                                            'contrast': $('input[data-filter="contrast"]')[0].value
                                        };
                                        break;
                                    case 'sharpen':
                                        imageSettings.sharpen = {
                                            'amount': value
                                        };
                                        break;
                                }
                            }

                            $(previewId).show();
                            $(canvasId).hide();
                            updatePixasticPreview();
                        });
                    }
                }
            };
        }
    ]);
})();