(function () {
    'use strict';

    angular.module('utils.uploadImage', ['app', 'app.utils.imageuploader']).
        directive('uploadImage', [
            'imageCropperSettings',
            function (imageCropperSettings) {

                var scope = {
                    entity: '=',
                    callback: '&'
                };

                function link(scope, element, attributes, controller) {
                }

                function Controller($scope) {
                    $scope.options = {
                        url: RESTANGULAR_BASE_URL + 'api/upload_image/',
                        xhrFields: {
                            withCredentials: true
                        },
                        mode: imageCropperSettings.IMAGE_CROPPER_MODES.BACKGROUND,
                        singleFileUploads: true,
                        limitMultiFileUploads: 1,
                        maxNumberOfFiles: 1,
                        acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i,
                        prependFiles: false,
                        maxFileSize: 3145728,        // 3 Mb
                        fail: function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Image not loaded",
                                text: "Error upload image to server"
                            });
                        },
                        done: function (data) {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Success",
                                text: "Image uploaded"
                            });
                            $scope.closeUploadDialog();
                            angular.extend($scope.entity, data);
                            if ($scope.callback) {
                                $scope.callback();
                            }
                        },
                        cancel: function () {
                            $scope.closeUploadDialog();
                        }
                    };

                    $scope.openUploadDialog = function () {
                        $scope.entity.isUploadDialog = true;
                    };

                    $scope.closeUploadDialog = function () {
                        $scope.entity.isUploadDialog = false;
                    };

                }

                Controller.$inject = ['$scope'];

                return ({
                    scope: scope,
                    controller: Controller,
                    link: link,
                    restrict: "AE",
                    replace: true,
                    templateUrl: '/static/partials/utils/upload_image.html'
                });

            }]);

})();