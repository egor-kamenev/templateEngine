//(function(){
//'use strict';
//
//angular.module('app.utils.imagepreview', [])
//    .filter('bytes', function () {
//        return function (bytes, precision) {
//            if (isNaN(parseFloat(bytes)) || !isFinite(bytes)) {
//                return '-';
//            }
//            if (!angular.isDefined(precision)) {
//                precision = 1;
//            }
//            var units = ['bytes', 'kB', 'MB', 'GB', 'TB', 'PB'],
//                number = Math.floor(Math.log(bytes) / Math.log(1024));
//            return (bytes / Math.pow(1024, Math.floor(number))).toFixed(precision) + ' ' + units[number];
//        };
//    })
//    .directive('imagePreview',
//    [
//        '$filter',
//        function ($filter) {
//            return {
//                restrict: 'AE',
//                replace: true,
//                scope: {
//                    source: '='
//                },
//                templateUrl: '/static/partials/utils/imagePreview.html',
//                controller: function ($scope) {
//                    $scope.source = $scope.$parent.file;
//
//                    function initializeImageSource() {
//                        var getBlobURL = (window.URL || window.webkitURL).createObjectURL;
//                        $scope.isBlobSource = $scope.source && angular.isObject($scope.source);
//
//                        if ($scope.isBlobSource) {
//                            $scope.imageSource = getBlobURL($scope.source);
//                        }
//                        else {
//                            $scope.imageSource = $scope.source;
//                        }
//                    }
//
//                    function updateFileInfo() {
//                        $scope.fileInfo = {
//                            name: $scope.filename
//                        };
//
//                        if ($scope.isBlobSource) {
//                            $scope.fileInfo.type = $scope.source.type;
//                            $scope.fileInfo.size = $filter('bytes')($scope.source.size, 1);
//                        }
//                    }
//
//                    if ($scope.source) {
//                        $scope.filename = $scope.source.name ?
//                            $scope.source.name.replace(/^(original|large|big|medium|small|micro):/, '') :
//                            $scope.source.replace(/^.*[\\\/]/, '');
//                    }
//                    else {
//                        $scope.filename = '';
//                    }
//
//                    initializeImageSource();
//                    updateFileInfo();
//
//                    $scope.$watch('source', function () {
//                        initializeImageSource();
//                    });
//
//                    $scope.deleteFile = function () {
//                        if ($scope.isBlobSource && $scope.$parent && $scope.$parent.$parent && $scope.$parent.$parent.queue) {
//                            var prefixPattern = /^(original|large|big|medium|small|micro):/;
//                            var originalFilename = $scope.source.name.replace(prefixPattern, '');
//
//                            $scope.$parent.$parent.queue = _.filter($scope.$parent.$parent.queue, function (item) {
//                                var filename = item.name.replace(prefixPattern, '');
//                                return filename !== originalFilename;
//                            });
//                        }
//                    };
//                },
//                link: function (scope, element) {
//                    $(element).find('.post-content .icons').hover(
//                        function () {
//                            $(this).find('.pxu-data').show('slow');
//                        },
//                        function () {
//                            $(this).find('.pxu-data').hide('fast');
//                        });
//                }
//            };
//        }
//    ]);
//})();