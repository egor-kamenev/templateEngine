(function () {
    'use strict';
    angular.module('app.utils.imageuploader', []).directive('imageUploader', [
        'imageCropperSettings', '$cookies', '$timeout', 'xmlHttpService',
        function (imageCropperSettings, $cookies, $timeout, xmlHttpService) {
            return {
                restrict: 'AE',
                replace: true,
                templateUrl: '/static/partials/utils/imageUploader.html',
                scope: {
                    entity: '=',
                    title: '=',
                    source: '=',
                    options: '='
                },
                controller: function ($scope) {
                    var defaultOptions = {
                        upload: true,
                        open: true,
                        progress: true,
                        cropper: true,
                        preview: true,
                        effects: false,
                        mode: imageCropperSettings.IMAGE_CROPPER_MODES.AVATAR,
                        theme: imageCropperSettings.IMAGE_CROPPER_THEMES.DARK
                    };

                    if (!$scope.options) {
                        $scope.options = defaultOptions;
                    }
                    else {
                        $scope.options = angular.extend({}, defaultOptions, $scope.options);
                    }

                    $scope.originalFile = null;
                    $scope.queue = [];
                    $scope.uploadedPercentage = 0;
                    $scope.uploadInProgress = false;

                    function prepareFormData(entity, queue, originalFile) {
                        var formData = new FormData();

                        formData.append("content_type_id", entity.content_type_id);
                        formData.append("content_id", entity.id);

                        if (originalFile) {
                            var originalNameWithPrefix = 'original:' + originalFile.name;
                            formData.append('files', originalFile, originalNameWithPrefix);
                        }

                        angular.forEach(queue, function (file) {
                            formData.append('files', file, file.name);
                        });

                        return formData;
                    }

                    function updateProgress(percentage) {
                        $scope.$apply($scope.uploadedPercentage = percentage);
                    }

                    function transferComplete(data) {
                        $scope.$apply($scope.uploadedPercentage = 100);
                        if ($scope.options && $scope.options.done && angular.isFunction($scope.options.done)) {
                            $timeout(function () {
                                $scope.$apply($scope.options.done(data));
                                $scope.$apply($scope.uploadInProgress = false);
                            }, 500);
                        }
                    }

                    function transferFailed() {
                        $scope.$apply($scope.uploadedPercentage = 0);
                        $scope.$apply($scope.uploadInProgress = false);

                        console.log("An error occurred while uploading the files.");
                        if ($scope.options && $scope.options.fail && angular.isFunction($scope.options.fail)) {
                            $scope.$apply($scope.options.fail());
                        }
                    }

                    function transferCanceled() {
                        $scope.$apply($scope.uploadedPercentage = 0);
                        $scope.$apply($scope.uploadInProgress = false);

                        console.log("The upload has been canceled by the user.");
                        if ($scope.options && $scope.options.fail && angular.isFunction($scope.options.fail)) {
                            $scope.$apply($scope.options.fail());
                        }
                    }

                    $scope.upload = function () {
                        var data = prepareFormData($scope.entity, $scope.queue, $scope.originalFile);

                        xmlHttpService.post($scope.options.url, data, {
                            credentials: true,
                            csrf: true,
                            onSuccess: transferComplete,
                            onError: transferFailed,
                            onAbort: transferCanceled,
                            onUpdateProgress: updateProgress
                        });

                        $scope.uploadedPercentage = 0;
                        $scope.uploadInProgress = true;
                    };

                    $scope.cancel = function () {
                        console.log('imageUploader.cancel');

                        if ($scope.options && $scope.options.cancel && angular.isFunction($scope.options.cancel)) {
                            $scope.options.cancel();
                        }
                    };

                    $scope.$onRootScope(imageCropperSettings.Events.FilesQueueUpdated, function (event, args) {
                        if (args) {
                            $scope.queue = args.queue;
                        }

                        if (!angular.isArray($scope.queue)) {
                            $scope.queue = [];
                        }
                    });
                },
                link: function (scope) {
                    var fileInputId = '#image-uploader-input-files';

                    $(fileInputId).on('change', function () {
                        var file = $(this).prop('files')[0];
                        if (file) {
                            scope.$apply(scope.originalFile = file);
                            scope.$apply(scope.queue = [file]);
                        }
                    });

                    var progressBarId = '#image-uploader-progressjs';
                    var progressBarContainerId = '.progressjs-container';
                    var progressStarted = false;

                    scope.$watch('uploadInProgress', function (value) {
                        if (value === true) {
                            progressStarted = true;

                            $(progressBarContainerId).show();

                            progressJs(progressBarId).setOptions({
                                overlayMode: true,
                                theme: 'blueOverlayRadiusWithPercentBar'
                            }).start();
                        }
                        else {
                            if (!progressStarted) {
                                return;
                            }

                            progressStarted = false;
                            $timeout(function () {
                                progressJs(progressBarId).end();
                                $(progressBarContainerId).hide();
                            }, 500);
                        }
                    });

                    scope.$watch('uploadedPercentage', function (value) {
                        if (progressStarted) {
                            progressJs(progressBarId).set(value);
                        }
                    });
                }
            };
        }
    ]);
})();