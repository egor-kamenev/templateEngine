(function () {
    /** @jsx React.DOM */
    'use strict';

    angular.module('app.react', [])
        .factory("rLinks", ["$filter", "fullName", function ($filter, fullName) {
            var _render = function (href, text, title, withoutText) {
                return (
                    <a
                        href={href}
                        title={title || text}>
                        { !!withoutText ? null : text}
                    </a>
                );
            };

            var UserLink = React.createClass({
                displayName: 'UserLink',
                render: function () {
                    //return _render.bind(this)("/users/" + this.props.instance.username, this.props.useUsername ? this.props.instance.username : fullName(this.props.instance));
                    return _render(
                        "/users/" + this.props.instance.username,
                        this.props.useUsername ? this.props.instance.username : fullName(this.props.instance),
                        this.props.withoutText
                    );
                }
            });

            var EventLink = React.createClass({
                displayName: 'EventLink',
                render: function () {
                    return _render(
                        "/events/" + this.props.instance.alias, this.props.instance.name,
                        this.props.withoutText
                    );
                }
            });

            var PlaceLink = React.createClass({
                displayName: 'PlaceLink',
                render: function () {
                    return _render(
                        "/places/" + this.props.instance.alias,
                        this.props.instance.name,
                        this.props.withoutText
                    );
                }
            });

            var PhotoLink = React.createClass({
                displayName: 'PhotoLink',
                render: function () {
                    var photo = this.props.instance,
                        post = photo.post,
                        wallObj = post.entity,
                        url = '',
                        title = photo.title || $filter('translate')('PHOTO');

                    if (wallObj.entity_type == 'userplace') {
                        url += '/places/' + wallObj.alias;
                    }
                    else if (wallObj.entity_type == 'event') {
                        url += '/events/' + wallObj.alias;
                    }
                    else if (wallObj.entity_type == 'user') {
                        url += '/users/' + wallObj.username;
                    }

                    url += '/posts/' + post.id + '/photo/' + photo.id;
                    return _render(url, title);
                }
            });

            var PostLink = React.createClass({
                displayName: 'PostLink',
                render: function () {
                    var post = this.props.instance,
                        wallObj = post.entity.entity,
                        url = '',
                        title = post.body || $filter('translate')('POST');


                    if (!angular.isDefined(wallObj)) {
                        return null;
                    }

                    if (wallObj.entity_type == 'userplace') {
                        url += '/places/' + wallObj.alias;
                    }
                    else if (wallObj.entity_type == 'event') {
                        url += '/events/' + wallObj.alias;
                    }
                    else if (wallObj.entity_type == 'user') {
                        url += '/users/' + wallObj.username;
                    }

                    url += '/posts/' + post.entity.id;
                    return _render(url, title);
                }
            });

            return {
                users: UserLink,
                places: PlaceLink,
                userplaces: PlaceLink,
                events: EventLink,
                photos: PhotoLink,
                posts: PostLink
            };
        }])
        .factory("rLoadingStateMixin", [function () {
            return {
                getInitialState: function () {
                    return {
                        loading: false
                    };
                },
                isLoading: function () {
                    return this.state.loading;
                },
                setLoadingState: function () {
                    this.setState({
                        loading: true
                    });
                },
                resetLoadingState: function () {
                    this.setState({
                        loading: false
                    });
                },
                doAction: function (res) {
                    if (!this.isLoading()) {
                        this.setLoadingState();
                        if (res) {
                            res.finally(this.resetLoadingState);
                        } else {
                            this.resetLoadingState();
                        }
                    } else {
                        $rootScope.$emit("flash", {
                            type: "info",
                            title: "Сохранение закладки",
                            text: "Пожалуйста, подождите завершения предыдущей операции"
                        });
                    }
                }
            };
        }])
        .factory('rTagsWidget', [
            '$rootScope', '$state', 'filtersService',
            function ($rootScope, $state, filtersService) {
                return React.createClass({
                    propTypes: {
                        tags: React.PropTypes.array.isRequired,
                        contentType: React.PropTypes.string.isRequired
                    },
                    shouldComponentUpdate: function (nextProps, nextState) {
                        return !angular.equals(nextProps.tags, this.props.tags) || nextProps.contentType !== this.props.contentType;
                    },
                    onClick: function (e) {
                        // In case tag is not attached to any cotent-type
                        // clicks are ignored
                        if (!angular.isString(this.props.contentType) || this.props.contentType === '') {
                            return;
                        }
                        //var inContentState = $state.includes('content');
                        var tagText = angular.element(e.target).text(),
                            clickedTag = _.find(this.props.tags, function (t) {
                                return t.name === tagText;
                            });

                        if (!clickedTag) {
                            return;
                        }
                        filtersService.searchByTag(this.props.contentType, clickedTag);

                        $rootScope.$apply();
                    },
                    render: function () {
                        var items = null;
                        if (angular.isArray(this.props.tags)) {
                            items = _.map(this.props.tags, _.bind(function (tag) {
                                return (
                                    <li
                                        key={'tag-' + tag.id}
                                        className='tag'
                                        onClick={this.onClick}>
                                        {tag.name}
                                    </li>
                                );
                            }, this));
                        }
                        return (
                            <ul className={'content-object__info__tags tags'}>
                                {this.props.children}
                                {items}
                            </ul>
                        );
                    }
                });
            }
        ])
        .factory("rListUtilsMixin", [
            "$rootScope", "rLinks", "imageUrl", "toggleBookmark", "toggleLike", "toggleSubscription", "addComplain",
            'xStates', 'eventUserStates', 'rTagsWidget', "checkInOutService",
            function ($rootScope, rLinks, imageUrl, toggleBookmark, toggleLike, toggleSubscription, addComplain, xStates, eventUserStates, rTagsWidget, checkInOutService) {
                return {
                    userAvatar: function (user, size, tag, withoutText, online) {
                        var style = {
                            backgroundImage: "url(" + (imageUrl(user.avatar, size.split(' ')[0]) || '/static/i/no-avatar.gif') + ")"
                        };
                        return (
                            <div
                                key={'avatar-user-' + user.id + size}
                                className={"avatar " + online}
                                style={style}>
                                <rLinks.users instance={user} withoutText={withoutText}/>
                            </div>
                        );
                    },
                    userAvatarList: function (data) {
                        if (!data || !data.length) {
                            return null;
                        }

                        var users = _.map(data, function (user, index) {
                            var css = index == 5 ? 'avatar small participant spare' : 'avatar small participant',
                                online = (user.online || $rootScope.user.username == user.username) ? 'online' : '',
                                style = {
                                    backgroundImage: "url(" + (imageUrl(user.avatar, "small") || '/static/i/no-avatar.gif') + ")"
                                };

                            return (
                                <li
                                    key={'avatar-user-' + user.id + "-small"}
                                    className={css + " " + online}
                                    style={style}>
                                    <rLinks.users instance={user} withoutText={true}/>
                                </li>
                            );
                        });

                        return (
                            <ul>{users}</ul>
                        );
                    },
                    name: function (item, ct) {
                        var rlink = rLinks[ct];
                        return (
                            <h1
                                key={'name-' + ct + item.id}>
                                <rlink instance={item}/>
                            </h1>
                        );
                    },
                    header: function (item) {
                        var bg = imageUrl(item.background, 'micro') || '/static/i/default.jpg';
                        var style = {backgroundImage: "url(" + bg + ")"};
                        return (
                            <div
                                key={'header-' + item.id}
                                className="content-object__header"
                                style={style}>
                            </div>
                        );
                    },
                    description: function (item) {
                        return (item.description) ? <div key={'description-' + item.id} className="content-object__info__description">{item.description}</div> : null;
                    },
                    tags: function (ct, tags, key, children) {
                        return React.createFactory(rTagsWidget)({tags: tags, contentType: ct, key: key}, children);
                    },
                    title: function (item, parts) {
                        return (
                            <div
                                key={'content-info-top-' + item.id}
                                className="content-object__info__top">
                                <div className="content-object__info__title">
                                    {parts}
                                </div>
                            </div>
                        );
                    },
                    infoOwner: function (item) {
                        return (
                            <div key={'meta-owner-' + item.id} className="meta owner">
                                <rLinks.users instance={item.owner}/>
                                <span className="ts_published">
                                    {moment(item.ts_published).format('DD MMM, YY')}
                                </span>
                            </div>
                        );
                    },
                    infoAge: function (item) {
                        var text = "возраст:" + item.age_restriction;
                        if (item.age_restriction) {
                            text = "для всех возрастных групп";
                        }

                        return (
                            <li
                                key={'meta-age-' + item.id}
                                className={"tag tag--meta tag--meta--age " + ((item.age_restriction > 18) && "adult" || "")}>
                                {text}
                            </li>
                        );
                    },
                    infoModerationState: function (item) {
                        if (item.is_being_moderated || item.is_banned) {
                            var className = ["tag tag--meta", "tag--meta--moderation"];
                            var text = "на модерации";
                            if (item.is_being_moderated) {
                                className.push("tag--meta--pending-moderation");
                                text = "";
                            }
                            if (item.is_banned) {
                                className.push("tag--meta--moderation--banned");
                                text = "заблокировано";
                            }

                            return (
                                <li
                                    className={className.join(" ")}
                                    data-protractor-id="isBeingModerated">
                                    {text}
                                </li>
                            );
                        }
                    },
                    infoByInvitation: function (item) {
                        if (item.by_invitation) {
                            return <li key={'meta-by_invitation-' + item.id} className="tag tag--meta tag--meta--by_invitation" title="мероприятие по приглашениям">по приглашениям</li>;
                        }

                        return <li key={'meta-without_invitation-' + item.id} className="tag tag--meta tag--meta--open" title="Доступно без особого приглашения">без приглашений</li>;
                    },
                    info: function (item, alfa, beta) {
                        var parts = [];
                        if (alfa) parts.push(<div key={'content-info-alfa-' + item.id} className="content-object__info__alfa">{alfa}</div>);
                        if (beta) parts.push(<div key={'content-info-beta-' + item.id} className="content-object__info__beta">{beta}</div>);
                        return <div key={'content-info-' + item.id} className="content-object__info">{parts}</div>;
                    },
                    _actionHandler: function (service, item) {
                        if ($rootScope.user.authenticated) {
                            if (angular.isUndefined(item.owner)) {
                                this.doAction(service.bind(item)());
                            } else if (!angular.isUndefined(item.owner) && item.owner.username !== $rootScope.user.username) {
                                this.doAction(service.bind(item)());
                            }

                        } else {
                            $rootScope.$emit('needLogin');
                        }
                    },
                    likeAction: function (item) {
                        var css = item.liked && 'like like--liked' || 'like';
                        var buttonTitle = item.liked && 'Удалить лайк' || 'Лайкнуть';
                        return (
                            <button
                                type="button"
                                className={"megamenu__item " + css}
                                name="like"
                                title={buttonTitle}
                                onClick={this._actionHandler.bind(this, toggleLike, item)}>
                                {item.liked_count}
                            </button>
                        );
                    },
                    bookmarkAction: function (item) {
                        var css = item.bookmarked && 'bookmark bookmark--bookmarked' || 'bookmark';
                        var buttonTitle = item.liked && 'Убрать из закладок' || 'Добавить в закладки';
                        return (
                            <button
                                type="button"
                                className={"megamenu__item " + css}
                                name="bookmark"
                                title={buttonTitle}
                                onClick={this._actionHandler.bind(this, toggleBookmark, item)}>
                            </button>
                        );
                    },
                    subscribeAction: function (item) {
                        var css = item.is_subscribed && 'subscribe subscribe--subscribed' || 'subscribe';
                        var buttonTitle = item.liked && 'Отменить подписку' || 'Подписаться';
                        return (
                            <button
                                type="button"
                                className={"megamenu__item " + css}
                                name="subscribe"
                                title={buttonTitle}
                                onClick={this._actionHandler.bind(this, toggleSubscription, item)}>
                            </button>
                        );
                    },
                    complainAction: function (item) {
                        var buttonTitle,
                            css,
                            isDisabled = true;

                        switch (item.can_complain) {
                            case false:
                                buttonTitle = 'Уже есть активная жалоба';
                                css = 'complain  complain--complained';
                                break;
                            case true:
                                buttonTitle = 'пожаловаться';
                                isDisabled = false;
                                css = 'complain cant-complain';
                                break;
                            default:
                                buttonTitle = 'Вы не имеете права жаловаться или объект прошел ручную модерацию';
                                css = 'complain';
                                isDisabled = false;
                                break;
                        }

                        return (
                            <button
                                type="button"
                                className={"megamenu__item " + css}
                                name="complain"
                                title={buttonTitle}
                                onClick={this._actionHandler.bind(this, addComplain, item)}
                                disabled={isDisabled ? "disabled" : false}>
                            </button>
                        );
                    },
                    actions: function (item, actions) {
                        var actionList = _.map(actions, function (action, index) {
                            return (
                                <li
                                    key={"action-" + action.props.name}
                                    className="megamenu__item__wrap">
                                {action}
                                </li>
                            );
                        });
                        return (
                            <ul
                                key={'actions-megamenu-' + item.id}
                                className="megamenu megamenu--dropline content-object__action-menu">
                                {actionList}
                            </ul>
                        );
                    },
                    renderIt: function (item, css, parts) {
                        var className = ["masonry-brick", "content-object", "content-object--list-entry"];
                        var attrs = {
                            className: className.concat(css).join(" ")
                        };

                        if (this.props.attrs) {
                            _.forOwn(this.props.attrs, function (val, key) {
                                if (_.isFunction(val)) {
                                    val = _.bind(val, this, item);
                                }

                                attrs[key] = val;
                            });
                        }

                        return (
                            <div {...attrs}>
                                {parts}
                            </div>
                        );
                    }
                };
            }])
        .factory("rEventListItem", ["$rootScope", "typeByTags", "eventUserStates", "xStates", "rLoadingStateMixin", "rListUtilsMixin", "rLinks", "checkInOutService", "dateTimeFormat",
            function ($rootScope, typeByTags, eventUserStates, xStates, rLoadingStateMixin, rListUtilsMixin, rLinks, checkInOutService, dateTimeFormat) {
                return React.createClass({
                    mixins: [rLoadingStateMixin, rListUtilsMixin],
                    renderEventDates: function (item) {
                        var dates_value = [
                            <span key={'event-dates-label-start-' + item.id}  className="label">{moment(item.ts_start).format(dateTimeFormat.COMMON_WITH_TIME)}</span>
                        ];

                        if (item.ts_finish) {
                            dates_value.push(<span key={'event-dates-label-finish' + item.id} className="label">{moment(item.ts_finish).format(dateTimeFormat.COMMON_WITH_TIME)}</span>);
                        }

                        return <div key={'events-dates-' + item.id} className="content-object__info__event-dates">{dates_value}</div>;
                    },
                    renderEventPlace: function (item) {
                        if (!item.place) {
                            return (
                                <div key={'event-place-' + item.id} className="content-object__info__event-place">
                                    <span key={'event-place-label-' + item.id}  className="label">Место проведения еще не определено</span>
                                </div>
                            );
                        }

                        var event_place_pieces = [
                            <span key={'event-place-label-' + item.id} className="label">
                                <rLinks.places
                                    key={'event-place-link-' + item.id}
                                    instance={item.place}/>
                            </span>
                        ];

                        if (item.place.formatted_address) {
                            event_place_pieces.push(<div key={'event-place-address-' + item.id} className="address">{item.place.formatted_address}</div>);
                        }

                        return <div key={'event-place-' + item.id} className="content-object__info__event-place">{event_place_pieces}</div>;
                    },
                    doCheckInOut: function (item, action) {
                        this.doAction(checkInOutService.handler(item, action));
                    },
                    cancelVisit: function (item) {
                        this.doAction(checkInOutService.cancelVisit(item));
                    },
                    getBetaParts: function (item) {
                        var beta = [];
                        if ($rootScope.user.authenticated && !item.readOnly) {
                            var buttons = checkInOutService.getButtons(
                                $rootScope.user, item, item.invite_request,
                                item.bun_request, item.user_state
                            );
                            if (buttons) {
                                var self = this;
                                angular.forEach(buttons, function (buttonInfo, i) {
                                    beta.push(
                                        <div key={'content-info-participate-checkin-' + item.id + '-' + i} className="content-object__info__participate">
                                            <button type="button" className={"button checkin " + buttonInfo.btnCss} onClick={self.doCheckInOut.bind(self, item, buttonInfo.btnAction)}>
                                        {buttonInfo.btnText}
                                            </button>
                                        </div>
                                    );
                                });
                            }
                        }

                        if (item.participants !== null) {
                            var participants = (
                                <div key={'content-info-participants-' + item.id} className="content-object__info__participants">
                                    <h4>Участвуют (сейчас: { item.participants_now }, всего { item.participants_num }):</h4>
                                    {this.userAvatarList(item.participants)}
                                </div>
                            );

                            beta.push(participants);
                        }
                        return beta;
                    },
                    render: function () {
                        var item = this.props.item;
                        //var online = (item.owner.online || $rootScope.user.username == item.owner.username) ? 'online' : '';
                        //var published_info_parts = [
                        //    //this.userAvatar(item.owner, "small", React.DOM.div, true, online),
                        //    this.infoOwner(item)
                        //    //this.infoAge(item),
                        //    //this.infoModerationState(item),
                        //    //this.infoByInvitation(item)
                        //];

                        var titleParts = [
                            this.infoOwner(item),
                            this.name(item, "events")
                        ];

                        var alfa = [
                            this.renderEventDates(item),
                            this.renderEventPlace(item),
                            this.description(item),
                            this.tags("events", item.tags, 'events-tags-' + item.id, [
                                this.infoAge(item),
                                this.infoModerationState(item),
                                this.infoByInvitation(item)
                            ])
                        ];

                        var actions = [
                            this.likeAction(item),
                            this.bookmarkAction(item),
                            this.subscribeAction(item),
                            this.complainAction(item)
                        ];

                        var listEntryParts = [
                            this.header(item),
                            this.title(item, titleParts),
                            this.info(item, _.filter(alfa, notNull), _.filter(this.getBetaParts(item), notNull)),
                            this.actions(item, actions)
                        ];
                        //
                        ////data-ng-mouseenter="highlightObject(item, true)"
                        ////data-ng-mouseleave_dep="highlightObject(item, false)">
                        var css = ["event", typeByTags(item)];
                        if (this.state.loading) {
                            css.push("loading");
                        }

                        ////return <div>7!</div>;

                        return this.renderIt(item, css, listEntryParts);
                        //return this.renderIt(item, css, null);
                        //<div className={css.join(" ")}>{listEntryParts}</div>;
                    }
                });
            }])
        .factory("rPlaceListItem", ["$rootScope", "typeByTags", "eventUserStates", "rLoadingStateMixin", "rListUtilsMixin", 'toggleFavorite', 'checkInOutService', 'placesService',
            function ($rootScope, typeByTags, eventUserStates, rLoadingStateMixin, rListUtilsMixin, toggleFavorite, checkInOutService, placesService) {
                return React.createClass({
                    mixins: [rLoadingStateMixin, rListUtilsMixin],
                    placeAddress: function (item) {
                        if (!item.formatted_address) {
                            return null;
                        }

                        return (
                            <div key={'place-address-' + item.id} className="content-object__info__map map-field">
                                <p className="map-hint" data-protractor-id="formattedAddress">{item.formatted_address}</p>
                            </div>
                        );
                    },
                    addPlaceToFavoritesAction: function (item) {
                        var css = item.is_favorite && 'favorite favorite--used' || 'favorite';
                        var buttonTitle = item.is_favorite && 'Удалить из избранного' || 'В избранное';
                        var h = function () {
                            this.addPlaceToFavoritesHandler(item);
                        }.bind(this);

                        return (
                            <button
                                type="button"
                                className={"megamenu__item " + css}
                                title={buttonTitle}
                                name="add-to-favorite"
                                onClick={this._actionHandler.bind(this, toggleFavorite, item)}>
                            </button>
                        );

                    },
                    render: function () {
                        var item = this.props.item;

                        //var online = (item.owner.online || $rootScope.user.username == item.owner.username) ? 'online' : '';
                        var titleParts = [
                            // todo: use api for sidebar and enable owner
                            //this.infoOwner(item),
                            this.name(item, "places")
                        ];

                        var alfa = [
                            this.placeAddress(item),
                            this.description(item),
                            this.tags("places", item.tags, 'places-tags' + item.id, [
                                this.infoAge(item),
                                this.infoModerationState(item)
                            ])
                        ];

                        var actions = [
                            this.likeAction(item),
                            this.bookmarkAction(item),
                            this.subscribeAction(item),
                            this.addPlaceToFavoritesAction(item),
                            this.complainAction(item)
                        ];

                        var listEntryParts = [
                            this.header(item),
                            this.title(item, titleParts),
                            this.info(item, _.filter(alfa, notNull)), //, _.filter(this.getBetaParts(item), notNull)),
                            this.actions(item, actions)
                        ];

                        var css = ["place", typeByTags(item)];
                        if (this.state.loading) {
                            css.push("loading");
                        }

                        return this.renderIt(item, css, listEntryParts);
                    }
                });
            }])
        .factory("rUserMixin", ["rLinks", function (rLinks) {
            return {
                infoOwner: function (item) {
                    return (
                        <div key={'meta-owner-' + item.id} className="meta owner" data-protractor-id={'userBlock:' + item.username}>
                            <rLinks.users instance={item} useUsername={true}/>
                            <span className="ts_published">{moment(item.ts_joined).format('DD MMM, YY')}</span>
                        </div>
                    );
                },
                location: function (item) {
                    if (item.last_location && item.last_location.place) {
                        var user_place_pieces = [
                            <div key={'event-place-label-' + item.last_location.place.id} className="label">
                                <rLinks.places
                                    instance={item.last_location.place}
                                    key={'event-place-link-' + item.last_location.place.id}/>
                            </div>
                        ];

                        //var user_place_pieces = [
                        //    <span key={'event-place-label-' + item.last_location.place.id} className="label">Сейчас здесь:</span>,
                        //    rLinks.places({instance: item.last_location.place, key: 'event-place-link-' + item.last_location.place.id})
                        //];
                        //
                        if (item.last_location.place.formatted_address) {
                            user_place_pieces.push(
                                <div key={'event-place-address-' + item.last_location.place.id} className="address">
                                    {item.last_location.place.formatted_address}
                                </div>
                            );
                        }
                        return (
                            <div key={'content-user-place-' + item.last_location.place.id} className="content-object__info__user-place">
                                {user_place_pieces}
                            </div>
                        );
                    }
                },
                description: function (item) {
                    var parts = [];
                    if (item.last_online_ts) parts.push(<p key={'description-last-visit-' + item.id} className="last-visit">Последний визит: {moment(item.last_online_ts).fromNow()}</p>);
                    if (item.status) parts.push(<p key={'description-status-' + item.id}>{item.status}</p>);

                    return <div key={'content-description-' + item.id} className="content-object__info__description">{parts}</div>;
                }
            };
        }])
        .factory("rUserListItem", ["$rootScope", "rLoadingStateMixin", "rListUtilsMixin", "rLinks", "rUserMixin",
            function ($rootScope, rLoadingStateMixin, rListUtilsMixin, rLinks, rUserMixin) {
                return React.createClass({
                    mixins: [rLoadingStateMixin, _.omit(rListUtilsMixin, "description", "infoOwner"), rUserMixin],
                    render: function () {
                        var item = this.props.item;
                        var online = (item.online || $rootScope.user.username == item.username) ? 'online' : '';
                        //var published_info_parts = [
                        //    this.userAvatar(item, "small", React.DOM.div, true, online),
                        //    this.infoOwner(item)
                        //];

                        var titleParts = [
                            this.infoOwner(item),
                            this.userAvatar(item, "small", React.DOM.div, true, online),
                            this.name(item, "users")
                            //this.publishedInfo(item, _.filter(published_info_parts, notNull))
                        ];

                        var alfa = [
                            this.location(item),
                            this.description(item)
                        ];

                        var actions = [
                            this.likeAction(item),
                            this.bookmarkAction(item),
                            this.subscribeAction(item)
                        ];

                        var listEntryParts = [
                            this.header(item),
                            this.title(item, titleParts),
                            this.info(item, _.filter(alfa, notNull)),
                            this.actions(item, actions)
                        ];

                        //data-ng-mouseenter="highlightObject(item, true)"
                        //data-ng-mouseleave_dep="highlightObject(item, false)">
                        var css = ["user"];
                        if (this.state.loading) {
                            css.push("loading");
                        }

                        return this.renderIt(item, css, listEntryParts);

                        //return <div className={css.join(" ")}>{listEntryParts}</div>;
                    }
                });
            }])
        .factory("rFriendListItem", ["$rootScope", "$compile", "rLoadingStateMixin", "rListUtilsMixin", "rLinks", "rUserMixin", "breakFriendship", "$stateParams", "tagService", "editFriendshipTags",
            function ($rootScope, $compile, rLoadingStateMixin, rListUtilsMixin, rLinks, rUserMixin, breakFriendship, $stateParams, tagService, editFriendshipTags) {
                var scope = $rootScope.$new(true);
                return React.createClass({
                    mixins: [rLoadingStateMixin, _.omit(rListUtilsMixin, "description", "infoOwner"), rUserMixin],

                    isEditTagsMode: function () {
                        return this.state.editTags === true;
                    },
                    componentDidUpdate: function () {

                        var selectID = this.getSelectID(this.props.item);

                        if (this.isEditTagsMode()) {
                            scope.rel = {
                                tags: this.props.item.tags
                            };
                            scope.tagsEditor = tagService.getTagSelector('friendship_tags', true);
                            var template = '<div data-tag-input data-tags="rel.tags" data-selector="tagsEditor"></div>'; 
                            var el = $compile(template)(scope).show();
                            $("#" + selectID).append(el);
                        }
                        // Destroy select2 input to clean the DOM
                        else {
                            $("#" + selectID).remove();
                        }
                    },
                    getSelectID: function (item) {
                        return 'friendship-tags-' + item.username;
                    },
                    toggleEditTagsState: function () {
                        this.setState({
                            editTags: !this.state.editTags
                        });
                    },
                    saveTags: function (item) {
                        var tags = scope.rel.tags;  // Hack to copy tags
                        item.tags = tags;
                        this.toggleEditTagsState();

                        $rootScope.$apply(function () {
                            editFriendshipTags(item, tags);
                        });

                    },
                    friendshipTags: function (item) {
                        if (this.isEditTagsMode()) {
                            var selectID = this.getSelectID(item);
                            return (
                                <div key={selectID}>
                                    <div id={selectID} />
                                    <button
                                        type="button"
                                        data-protractor-id={'saveFriendshipTags:' + item.username}
                                        onClick={this.saveTags.bind(this, item)}
                                        className={'button'}>
                                        Сохранить
                                    </button>
                                </div>
                            );
                        }

                        return (item.tags) ? rListUtilsMixin.tags(
                            'friendship',
                            item.tags,
                            'friendship-tags-' + item.id
                        ) : null;
                    },
                    changeTags: function (item) {
                        var buttonTitle = 'Изменить теги',
                            protractorID = "changeFriendshipTags:" + item.username;

                        return <button type="button"
                            className={"megamenu__item change_friendship_tags"}
                            name="changeFriendshipTags" title={buttonTitle}
                            data-protractor-id={protractorID}

                            onClick={this.toggleEditTagsState}>
                        </button>;
                    },
                    breakFriendship: function (item) {
                        var buttonTitle = 'Убрать из друзей',
                            protractorID = "breakFriendship:" + item.username;

                        return <button type="button" className={"megamenu__item break_friendship"} name="breakFriendship" title={buttonTitle}
                            data-protractor-id={protractorID}
                            onClick={this._actionHandler.bind(this, function () {
                                $rootScope.$apply(function () {
                                    breakFriendship(item);
                                });
                            }, item)}></button>;
                    },

                    render: function () {
                        var item = this.props.item;
                        var online = (item.online || $rootScope.user.username == item.username) ? 'online' : '';
                        var isOwnProfile = $stateParams.username == $rootScope.user.username;

                        //var published_info_parts = [
                        //    this.userAvatar(item, "small", React.DOM.div, true, online),
                        //    this.infoOwner(item)
                        //];

                        var titleParts = [
                            this.infoOwner(item),
                            this.userAvatar(item, "small", React.DOM.div, true, online),
                            this.name(item, "users")
                        ];

                        var alfa = [
                            this.location(item),
                            this.description(item),
                            this.friendshipTags(item)
                        ];

                        var actions = [];

                        if (isOwnProfile) {
                            actions.push(this.breakFriendship(item));
                            actions.push(this.changeTags(item));
                        }

                        var listEntryParts = [
                            this.header(item),
                            this.title(item, titleParts),
                            this.info(item, _.filter(alfa, notNull)),
                            this.actions(item, actions)
                        ];

                        //data-ng-mouseenter="highlightObject(item, true)"
                        //data-ng-mouseleave_dep="highlightObject(item, false)">
                        var css = ["user"];
                        if (this.state.loading) {
                            css.push("loading");
                        }

                        return this.renderIt(item, css, listEntryParts);

                        //return <div className={css.join(" ")}>{listEntryParts}</div>;
                    }
                });
            }])
        .factory("rDataList", ['contentSettings', 'filtersService',
            function (contentSettings, filtersService) {
                //var pagination = React.createFactory(rPagination);


                return React.createClass({
                    displayName: 'DataList',
                    propTypes: {
                        currentPage: React.PropTypes.number.isRequired,
                        pageSize: React.PropTypes.number.isRequired,
                        data: React.PropTypes.array.isRequired,
                        filterMode: React.PropTypes.string.isRequired,
                        contentType: React.PropTypes.string.isRequired,
                        mapMode: React.PropTypes.bool.isRequired,
                        selectedItem: React.PropTypes.object
                    },
                    shouldComponentUpdate: function (nextProps, nextState) {
                        var self = this;

                        return nextProps.contentType !== this.props.contentType ||
                            nextProps.currentPage !== this.props.currentPage ||
                            nextState.currentPage !== this.state.currentPage ||
                            nextProps.maxPage !== this.props.maxPage ||
                            nextProps.filterMode !== this.props.filterMode ||
                            nextProps.selectedItem !== this.props.selectedItem ||
                            nextProps.data !== this.props.data ||
                            nextProps.selectedItem !== this.props.selectedItem ||
                            nextState.maxPage !== this.state.maxPage ||
                            _.some(nextState.currentItems, function (x) {
                                return _.some(self.state.currentItems, function (y) {
                                    return x.id === y.id && x.entity_type === y.entity_type;
                                });
                            });
                    },
                    getDefaultState: function (props) {
                        var count = angular.isArray(props.data) ? props.data.length : 0;
                        var maxPage = Math.ceil(count / props.pageSize);

                        var currentPage = props.currentPage;
                        var currentItems = null;

                        if (!props.mapMode) {
                            currentItems = props.data;
                        }
                        else {
                            if (angular.isArray(props.data)) {
                                var start = (currentPage - 1) * props.pageSize;
                                var end = start + props.pageSize;
                                currentItems = props.data.slice(start, end);
                            }
                        }

                        return {
                            maxPage: maxPage,
                            currentItems: currentItems,
                            currentPage: currentPage
                        };
                    },
                    getInitialState: function () {
                        return this.getDefaultState(this.props);
                    },
                    componentWillReceiveProps: function (newProps) {
                        var state = this.getDefaultState(newProps);
                        this.setState(state);
                    },
                    componentWillUpdate: function (nextProps, nextState) {
                        if (nextProps.selectedItem &&
                            nextProps.selectedItem !== this.props.selectedItem &&
                            nextProps.selectedItem !== nextState.selectedItem) {

                            this.setState({selectedItem: nextProps.selectedItem});
                        }
                    },
                    scrollToElement: function (elem) {
                        var scrollTop = 0;
                        if (elem) {
                            var topMargin = this.state.scrollTopMargin || 0;
                            scrollTop = elem.offsetTop - topMargin;
                        }

                        var container = this.refs.scrollable;
                        if (container && container.isMounted()) {
                            angular.element(container.getDOMNode())
                                .animate({
                                    scrollTop: scrollTop + 'px'
                                }, 'slow');
                            return elem;
                        }
                    },
                    componentDidUpdate: function (prevProps, prevState) {
                        if (this.state.selectedItem) {
                            var selectedItem = this.props.selectedItem;

                            var itemIndex = _.findIndex(this.props.data, function (item) {
                                return item.id === selectedItem.id && item.entity_type === selectedItem.entity_type;
                            });
                            var itemPage = Math.floor(itemIndex / this.props.pageSize) + 1;

                            if (itemPage == this.state.currentPage) {
                                this.setState({selectedItem: null});
                                var item = this.refs[selectedItem.id];
                                if (item && item.isMounted()) {
                                    this.scrollToElement(item.getDOMNode());
                                }
                            }
                            else {
                                if (selectedItem !== this.state.selectedItem) {
                                    this.setState({
                                        selectedItem: selectedItem
                                    });
                                }

                                this.scrollToElement();
                                filtersService.mapPageChange(itemPage);
                            }
                        }
                    },
                    render: function () {

                        //var pager = pagination({
                        //    currentPage: this.state.currentPage,
                        //    maxPage: this.state.maxPage
                        //});
                        //
                        //var self = this;

                        var items = _.map(this.state.currentItems, _.bind(function (item) {
                            return this.props.listEntryComponent({
                                key: 'list-entry-' + item.id,
                                ref: item.id,
                                item: item,
                                attrs: this.props.listEntryAttrs
                            });
                        }, this));

                        //if (this.props.filterMode === contentSettings.MODE.MAP && this.state.maxPage > 1) {
                        //    return (
                        //        <div className="data-set-wrapper" ref="scrollable">
                        //            <div className="data-set">
                        //                {items}
                        //            </div>
                        //        </div>
                        //    );
                        //} else {
                        return (
                            <div className="data-set-wrapper" ref="scrollable">
                                <div className="data-set">
                                    {items}
                                </div>
                            </div>
                        );
                        //}
                    }
                });
            }])
        .directive('renderList', [
            "$window", "$rootScope", "rEventListItem", "rPlaceListItem", "rUserListItem", "rDataList", "mapEvents",
            'frontendSettings', 'contentSettings',
            function ($window, $rootScope, rEventListItem, rPlaceListItem, rUserListItem, rDataList, mapEvents,
                      frontendSettings, contentSettings) {
                var renderers = {
                    events: rEventListItem,
                    places: rPlaceListItem,
                    users: rUserListItem
                    //events: React.createFactory(rEventListItem),
                    //places: React.createFactory(rPlaceListItem),
                    //users: React.createFactory(rUserListItem)
                };

                return {
                    restrict: 'A',
                    link: function ($scope, element, attrs) {

                        $scope.data = [];
                        $scope.pageLimit = frontendSettings.pageLimitMap;
                        $scope.mapMode = $rootScope.currentFilterMode === contentSettings.MODE.MAP;

                        var data = angular.isArray($scope[attrs.source]) ? $scope[attrs.source] : null;

                        //var DataList = React.createFactory(rDataList);
                        var DataList = rDataList;

                        function renderList() {

                            if ($rootScope.currentFilterMode !== contentSettings.MODE.STREAM && renderers[$rootScope.currentFilterContentType]) {
                                var attrs = null;

                                if ($rootScope.currentFilterMode == 'map') {
                                    attrs = {
                                        onMouseEnter: function (item) {
                                            $scope.$apply(function () {
                                                $rootScope.$broadcast(mapEvents.HIGHLIGHT_OBJECT, {
                                                    element: item,
                                                    value: true
                                                });
                                            });

                                        },
                                        onMouseLeave: function (item) {
                                            $scope.$apply(function () {
                                                $rootScope.$broadcast(mapEvents.HIGHLIGHT_OBJECT, {
                                                    element: item,
                                                    value: false
                                                });
                                            });
                                        }
                                    };
                                }

                                var currentPage = $scope.mapMode ? $rootScope.mapCurrentPage : $scope.currentPage;
                                var maxPage = $scope.mapMode ? $rootScope.mapMaxPage : $scope.maxPage;

                                React.render(React.createElement(DataList, {
                                    data: $scope.data,
                                    pageSize: $scope.pageLimit,
                                    selectedItem: $scope.selectedItem,
                                    currentPage: currentPage,
                                    maxPage: maxPage,
                                    mapMode: $scope.mapMode,
                                    filterMode: $rootScope.currentFilterMode,
                                    contentType: $rootScope.currentFilterContentType,
                                    listEntryAttrs: attrs,
                                    listEntryComponent: renderers[$rootScope.currentFilterContentType]
                                }), element[0]);

                            }
                        }

                        function changePage(e, page, force) {
                            var newPageIndex;

                            switch (page) {
                                case 'first':
                                    newPageIndex = 1;
                                    break;
                                case 'previous':
                                    newPageIndex = $rootScope.mapCurrentPage == 1 ? 1 : $rootScope.mapCurrentPage - 1;
                                    break;
                                case 'next':
                                    newPageIndex = $rootScope.mapCurrentPage == $rootScope.mapMaxPage ? $rootScope.mapMaxPage : $rootScope.mapCurrentPage + 1;
                                    break;
                                case 'last':
                                    newPageIndex = $rootScope.mapMaxPage;
                                    break;
                                default:
                                    newPageIndex = angular.isNumber(page) ? page : $scope.mapCurrentPage;
                            }

                            if (newPageIndex < 1) {
                                newPageIndex = 1;
                            }
                            else if (newPageIndex > $rootScope.mapMaxPage) {
                                newPageIndex = $rootScope.mapMaxPage;
                            }
                            $rootScope.mapCurrentPage = newPageIndex;

                            renderList();
                        }

                        if (data && data.length > 0) {
                            $scope.data = data;
                            renderList();
                        }

                        $rootScope.$onRootScope("contentListUpdated", function (e, args) {
                            $scope.data = args.data;
                            $scope.mapMode = angular.isDefined(args.mapMode) ? args.mapMode : $scope.mapMode;

                            if (args.mapMode) {
                                changePage(e, 'first', true);
                            }
                            else {
                                $scope.currentPage = args.page;
                                $scope.maxPage = args.maxPage;
                                renderList();
                            }
                        });

                        $rootScope.$onRootScope("mapPageChange", changePage);


                        $scope.$on('$destroy', function () {
                            React.unmountComponentAtNode(element[0]);
                        });

                        $scope.$onRootScope(mapEvents.SCROLL_TO_OBJECT, function (event, args) {
                            if (args && args.obj) {
                                $scope.selectedItem = args.obj;
                                renderList();
                            }
                        });

                        $rootScope.$watch('currentFilterMode', function (value) {
                            $scope.mapMode = value === contentSettings.MODE.MAP;
                        });
                    }
                };
            }]);

    function notNull(bit) {
        return !!bit;
    }

})();
