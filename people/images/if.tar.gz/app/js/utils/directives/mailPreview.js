/** @jsx React.DOM */

(function () {
    'use strict';

    angular.module('app.mailPreview', [])
        .factory('rMessagesPreview', ['NotificationBlock', function (NotificationBlock) {
            var component = React.createFactory(NotificationBlock);
            return React.createClass({
                displayName: 'MessagesPreview',
                render: function () {
                    var mode = this.props.renderMode;
                    var items = _.map(this.props.messages, function (item) {
                        return component({
                            key: "messages-preview-" + item.id,
                            item: item,
                            mode: mode
                        });
                    });

                    return (
                        <div
                            className="mail-preview-content"
                            key={"render-mail-preview-" + this.props.renderMode}>
                            {items}
                        </div>
                    );
                }
            });
        }])
        .directive('mailPreview', ['$rootScope', 'rMessagesPreview', 'notificationBlockType',
            function ($rootScope, rMessagesPreview, notificationBlockType) {
                return {
                    restrict: 'A',
                    scope: false,
                    link: function (scope, el) {
                        function __render(data) {
                            React.render(
                                React.createElement(rMessagesPreview, {
                                    messages: data,
                                    renderMode: notificationBlockType.COMPACT
                                }),
                                el[0]
                            );
                        }

                        if ($rootScope.unreadMessages && $rootScope.unreadMessages.length) {
                            __render($rootScope.unreadMessages);
                        }

                        $rootScope.$onRootScope("mailPreviewChanged", function (e) {
                            console.debug("mailPreviewChanged: ", e);
                            __render($rootScope.unreadMessages);
                        });
                    }
                };
            }]);
})();
