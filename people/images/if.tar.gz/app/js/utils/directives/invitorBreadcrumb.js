(function(){
angular.module('app.utils.breadcrumb', ['ui.router.state', 'app.utils.breadcrumb.service'])
    .provider('breadcrumb', function () {
        this.$get = ['$state', '$rootScope', 'breadcrumbService', function ($state, $rootScope, breadcrumbService) {

            var lastViewScope = $rootScope;

            var addStateToSequenceIfNeed = function (sequence, state) {
                if (!state.data) {
                    state.data = {};
                }

                var existedState = _.find(sequence, function (item) {
                    return item && (item.name == state.name);
                });


                if (!existedState && !state.abstract && !breadcrumbService.realHasOwnDataProperty(state, lastViewScope, 'breadcrumbSkip')) {
                    sequence.unshift(state);
                }
            };

            $rootScope.$on('$viewContentLoaded', function (event) {
                if (breadcrumbService.isScopeOlderThan(event.targetScope.$id, lastViewScope.$id)) {
                    lastViewScope = event.targetScope;
                }
            });

            return {
                getStatesSequence: function () {
                    var sequence = [];
                    var state = $state.$current.self;

                    do {
                        addStateToSequenceIfNeed(sequence, state);
                        state = breadcrumbService.getBreadcrumbParentState(state, lastViewScope);
                    }
                    while (state && state.name);

                    return sequence;
                },

                getLastViewScope: function () {
                    return lastViewScope;
                }
            };
        }];
    });
    //.directive('invitorBreadcrumb', [
    //    '$rootScope', 'breadcrumb', '$parse', '$injector', 'breadcrumbService', '$location',
    //    function ($rootScope, breadcrumb, $parse, $injector, breadcrumbService, $location) {
    //
    //        function buildBreadcrumbs(useTranslate) {
    //            var breadcrumbs = [];
    //            var path = breadcrumb.getStatesSequence();
    //            var viewScope = breadcrumb.getLastViewScope();
    //
    //            //console.log("BREADCRUMBS scope: ", viewScope);
    //            console.log("BREADCRUMBS path: ", path);
    //            angular.forEach(path, function (state) {
    //                console.log("BREADCRUMBS state: ", state);
    //                breadcrumbs.push({
    //                    data: breadcrumbService.buildBreadcrumbData(state, viewScope, useTranslate)
    //                });
    //            });
    //
    //            if (breadcrumbs.length) {
    //                breadcrumbs[breadcrumbs.length - 1].data.active = true;
    //            }
    //
    //            if(viewScope.rootPost && viewScope.rootPost.title) { // for post userprofile
    //                breadcrumbs.push({
    //                    data: {
    //                        link: $location.url(),
    //                        caption: viewScope.rootPost.title
    //                    }
    //                })
    //            }
    //
    //            ////scope.breadcrumbs = breadcrumbs;
    //            console.log("BREADCRUMBS: ", breadcrumbs);
    //            return breadcrumbs;
    //        }
    //
    //        return {
    //            restrict: 'AE',
    //            replace: true,
    //            scope: {
    //                useTranslate: '='
    //            },
    //            templateUrl: '/static/partials/utils/invitorBreadcrumb.html',
    //            link: function($scope, el) {
    //
    //                function __updateBreadcrumbs(){
    //                    $scope.$apply(function(){
    //                        $scope.breadcrumbs = buildBreadcrumbs($scope.useTranslate);
    //                    });
    //                }
    //
    //                $rootScope.$onRootScope('breadcrumbDataUpdated', __updateBreadcrumbs);
    //                $rootScope.$onRootScope('changedLanguage', __updateBreadcrumbs);
    //                $rootScope.$on('$viewContentLoaded', __updateBreadcrumbs);
    //                $rootScope.$on('$locationChangeSuccess', __updateBreadcrumbs);
    //
    //                $scope.breadcrumbs = buildBreadcrumbs(true);
    //            }
    //        };
    //    }]);
})();