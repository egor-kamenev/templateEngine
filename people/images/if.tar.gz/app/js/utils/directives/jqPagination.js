(function(){
angular.module('app.jqPagination', []).directive('jqPagination', [
    '$location', '$state', 'filtersService', '$rootScope',
    function ($location, $state, filtersService, $rootScope) {

        return {
            restrict: 'AC',
            scope: {
                currentpage: '=',
                maxpage: '='
            },
            transclude: true,
            template: '<div class="pagination">' +
            '<a href="[[firstLink]]"></a>' +
            '<a href="[[previousLink]]"></a>' +
            '<input type="text" data-ng-readOnly="true" value="[[ \'\'+currentpage + \'/\' + maxpage]]"/>' +
            '<a href="[[nextLink]]"></a>' +
            '<a href="[[lastLink]]"></a>' +
            '</div>',
            link: function (scope) {

                var currentState;

                var type = $rootScope.currentFilterContentType;
                var mode = $rootScope.currentFilterMode;

                $rootScope.$on('filterCurrentPageChanged', function (event, value) {
                    console.log('UPDATE PAGINATOR CURRENT PAGE:', value);
                    if (value) {
                        scope.currentpage = value;
                        setCurrentPage();
                    }
                });

                function setCurrentPage() {
                    if ($state.current.name == 'content') {
                        currentState = 'content';

                        scope.firstLink = null;
                        scope.previousLink = null;
                        scope.nextLink = null;
                        scope.lastLink = null;

                        var first = {show: mode, content: type, page: 1};
                        var prev = {
                            show: mode,
                            content: type,
                            page: (scope.currentpage == 1) ? 1 : parseInt($location.search().page, 10) - 1
                        };
                        var next = {
                            show: mode,
                            content: type,
                            page: (scope.currentpage == scope.maxpage) ? scope.maxpage : parseInt($location.search().page, 10) + 1
                        };
                        var last = {show: mode, content: type, page: scope.maxpage};

                        if ($location.search().dt1) {
                            first.dt1 = $location.search().dt1;
                            prev.dt1 = $location.search().dt1;
                            next.dt1 = $location.search().dt1;
                            last.dt1 = $location.search().dt1;
                        }

                        if ($location.search().dt2) {
                            first.dt2 = $location.search().dt2;
                            prev.dt2 = $location.search().dt2;
                            next.dt2 = $location.search().dt2;
                            last.dt2 = $location.search().dt2;
                        }

                        if ($location.search().tags) {
                            first.tags = $location.search().tags;
                            prev.tags = $location.search().tags;
                            next.tags = $location.search().tags;
                            last.tags = $location.search().tags;
                        }

                        scope.firstLink = $state.href(currentState, first);
                        scope.previousLink = $state.href(currentState, prev);
                        scope.nextLink = $state.href(currentState, next);
                        scope.lastLink = $state.href(currentState, last);

                    } else {
                        currentState = $state.current.name;

                        scope.firstLink = $state.href(currentState, {page: 1});
                        scope.previousLink = $state.href(currentState, {page: (scope.currentpage == 1) ? 1 : scope.currentpage - 1});
                        scope.nextLink = $state.href(currentState, {page: (scope.currentpage == scope.maxpage) ? scope.maxpage : scope.currentpage + 1});
                        scope.lastLink = $state.href(currentState, {page: scope.maxpage});
                    }
                }


                setCurrentPage();

            }

        };
    }]);

})();