(function(){
'use strict';
angular.module('app.directives.confirmdialog', [])
.directive('confirmDialog', [ '$rootScope', function ($rootScope) {
    return {
        restrict: 'AE',
        controller: function($scope){
            $scope.yes = function(){
                $rootScope.confirmDialogActive = false;
                $rootScope.deferredConfirm.resolve();
            };

            $scope.no = function(){
                $rootScope.confirmDialogActive = false;
                $rootScope.deferredConfirm.reject();
            };
        },
        replace: true,
        templateUrl: '/static/partials/utils/confirm_dialog.html'
        
    };
}]);

})();