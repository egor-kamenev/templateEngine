(function () {
    /** @jsx React.DOM */
    'use strict';

    var renderMatrix = {
        message_dialog_created: {
            compact: {
                header: ['subject:preview'],
                body: ['object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['object:preview'],
                actions: ['goToThread']
            }
            // stream mode not supported
        },
        event_finished: {
            compact: {
                header: ['text'],
                body: ['object:preview']
            },
            full: {
                header: ['text'],
                body: ['object:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['object:preview']
                }

            }
        },
        event_started: {
            compact: {
                header: ['text'],
                body: ['object:preview']
            },
            full: {
                header: ['text'],
                body: ['object:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['object:preview']
                }

            }
        },

        event_created: {
            compact: {
                header: ['object:preview'],
                body: ['text', 'subject:link']
            },
            full: {
                header: ['object:preview'],
                body: ['text', 'subject:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'text', 'object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['text']
                }
            }
        },

        event_deleted: {
            compact: {
                header: ['object:preview'],
                body: ['text', 'subject:link']
            },
            full: {
                header: ['object:preview'],
                body: ['text', 'subject:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'text', 'object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['text']
                }
            }
        },

        event_changed: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'object:link']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'object:link']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview']
                }
            }
        },

        event_user_state_created: {
            compact: {
                header: ['subject:preview'],
                body: ['object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['object:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:preview', 'object:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview']
                }
            }
        },
        // this is deprecated
        content_visibility_changed: {
            compact: {
                header: ['text'],
                body: ['subject:link', 'text', 'context:preview']
            },
            full: {
                header: ['text'],
                body: ['subject:link', 'text', 'context:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'text', 'context:preview']
                },
                context: {
                    header: [],
                    body: []
                },
                subject: {
                    header: [],
                    body: []
                }
            }
        },
        post_created: {
            compact: {
                header: ['subject:preview'],
                body: ['object:preview', 'context:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['object:preview', 'context:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'object:preview', 'text', 'context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text', 'object:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview', 'text', 'context:preview']
                }
            }
        },

        post_changed: {
            compact: {
                header: ['subject:preview'],
                body: ['object:preview', 'context:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['object:preview', 'context:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'object:preview', 'text', 'context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text', 'object:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview', 'text', 'context:preview']
                }
            }
        },

        post_deleted: {
            compact: {
                header: ['subject:preview'],
                body: ['object:preview', 'context:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['object:preview', 'context:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'object:preview', 'text', 'context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text', 'object:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview', 'text', 'context:preview']
                }
            }
        },


        friendship_created: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'text', 'context:link']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['text', 'context:link']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['context:link']
                }
            }
        },

        friendship_deleted: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'text', 'context:link']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['text', 'subject:link']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['context:link']
                }
            }
        },

        event_bun_request_created: {
            compact: {
                header: ['context:preview'],
                body: ['object:preview'],
                actions: ['acceptInvitation', 'rejectInvitation', 'ignoreInvitation']
            },
            full: {
                header: ['context:preview'],
                body: ['object:preview'],
                actions: ['acceptInvitation', 'rejectInvitation', 'ignoreInvitation']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['object:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview']
                }
            }
        },
        event_invite_request_created: {
            compact: {
                header: ['context:preview'],
                body: ['object:preview']
                //actions: ['acceptInvitation', 'rejectInvitation']
            },
            full: {
                header: ['context:preview'],
                body: ['object:preview']
                //actions: ['acceptInvitation', 'rejectInvitation']
            }
        },
        event_invite_request_accepted: {
            compact: {
                header: ['context:preview'],
                body: ['object:preview']
                //actions: ['acceptInvitation', 'rejectInvitation']
            },
            full: {
                header: ['context:preview'],
                body: ['object:preview']
                //actions: ['acceptInvitation', 'rejectInvitation']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['context:preview']
                }
            }
        },
        friendship_request_created: {
            compact: {
                header: ['subject:preview'],
                body: ['object:preview'],
                actions: ['acceptFriendship', 'rejectFriendship']
            },
            full: {
                header: ['subject:preview'],
                body: ['object:preview'],
                actions: ['cancelFriendshipRequest', 'acceptFriendship', 'rejectFriendship']
            }
        },
        event_bun_request_accepted: {
            compact: {
                header: ['subject:preview'],
                body: ['object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['object:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['object:preview']
                }
            }

        },

        event_bun_request_declined: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'object:preview']
                }
            }
        },

        birthday_birthday_today: {
            compact: {
                header: ['subject:preview'],
                body: ['text']
            },
            full: {
                header: ['subject:preview'],
                body: ['text']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:preview']
                }
            }
        },
        user_birthday_today: {
            compact: {
                header: ['object:preview'],
                body: ['text']
            },
            full: {
                header: ['object:preview'],
                body: ['text']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['object:preview']
                }
            }
        },
        birthday_birthday_tomorrow: {
            compact: {
                header: ['subject:preview'],
                body: ['text']
            },
            full: {
                header: ['subject:preview'],
                body: ['text']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:preview']
                }
            }

        },

        user_birthday_tomorrow: {
            compact: {
                header: ['object:preview'],
                body: ['text']
            },
            full: {
                header: ['object:preview'],
                body: ['text']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['object:preview']
                }
            }

        },

        userban_created: {
            compact: {
                header: ['context:preview'],
                body: ['object:preview']
            },
            full: {
                header: ['context:preview'],
                body: ['object:preview']
            },
            stream: {
                single: {
                    header: ['context:preview'],
                    body: ['object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['object:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview']
                }
            }

        },
        userban_deleted: {
            compact: {
                header: ['context:preview'],
                body: ['object:preview']
            },
            full: {
                header: ['context:preview'],
                body: ['object:preview']
            },
            stream: {
                single: {
                    header: ['context:preview'],
                    body: ['object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['object:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['object:preview']
                }
            }

        },
        subscription_created: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'context:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:preview']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['context:preview']
                }
            }
        },
        userplace_created: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'text', 'object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['text']
                }
            }
        },
        userplace_deleted: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['subject:link', 'text', 'object:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['text']
                }
            }
        },
        userplace_changed: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'object:preview']
                }
            }
        },
        userlocation_created: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['text', 'context:preview']
                }
            }

        },
        manualtask_declined: {
            compact: {
                header: ['text'],
                body: ['context:preview']
            },
            full: {
                header: ['text'],
                body: ['context:preview']
            }
        },
        complaintask_created: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'context:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['subject:link', 'text']
                },
                subject: {
                    header: ['text', 'subject:preview'],
                    body: ['text', 'context:preview']
                }
            }
        },
        complaintask_declined: {
            compact: {
                header: ['text'],
                body: ['context:link']
            },
            full: {
                header: ['text'],
                body: ['context:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['text']
                },
                subject: {
                    header: ['text'],
                    body: ['text', 'context:preview']
                }
            }
        },
        complaintask_accepted: {
            compact: {
                header: ['text'],
                body: ['context:link']
            },
            full: {
                header: ['text'],
                body: ['context:preview']
            },
            stream: {
                single: {
                    header: ['text'],
                    body: ['context:preview']
                },
                context: {
                    header: ['text', 'context:preview'],
                    body: ['text']
                },
                subject: {
                    header: ['text'],
                    body: ['text', 'context:preview']
                }
            }
        },
        favorite_place_created: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'context:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['context:preview']
                },
                context: {
                    header: ['subject:preview'],
                    body: ['text']
                },
                subject: {
                    header: ['subject:preview'],
                    body: ['text', 'context:preview']
                }
            }
        },
        favorite_place_deleted: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'context:link']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'context:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['context:preview']
                },
                context: {
                    header: ['subject:preview'],
                    body: ['text']
                },
                subject: {
                    header: ['subject:preview'],
                    body: ['text', 'context:preview']
                }
            }
        },
        user_status_created: {
            compact: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            full: {
                header: ['subject:preview'],
                body: ['text', 'object:preview']
            },
            stream: {
                single: {
                    header: ['subject:preview'],
                    body: ['text', 'object:preview']
                },
                context: {
                    header: ['subject:preview'],
                    body: ['text', 'object:preview']
                },
                subject: {
                    header: ['subject:preview'],
                    body: ['text', 'object:preview']
                }
            }
        }
    };

    angular.module('app.react_stream', ['app.react_stream_objects'])
        .factory("NotificationBlock", ['$rootScope', '$injector', 'notificationBlockType', 'streamCodes', 'textPreview', '$state', function ($rootScope, $injector, notificationBlockType, streamCodes, textPreview, $state) {
            //todo: this should be direct React component, not factory of rendering function!
            function markAsRead(msg) {
                //$rootScope.$apply(function () {
                $rootScope.markAsRead([msg]);
                //});
            }

            function switchToMessagesFolder(item, evt) {
                var ignoreTargets = ['A', 'BUTTON'];
                if (ignoreTargets.indexOf(angular.element(evt.target).prop("tagName")) === -1) {
                    if (angular.isDefined(item.folder)) {
                        if (item.folder == 'dialog') {
                            $state.go('userMessages.dialogue', {partner_username: item.subject.username});
                        }
                        else {
                            $state.go('userMessages.' + item.folder);
                        }
                    }
                }
            }

            return React.createClass({
                render: function () {
                    var e = this.props.item,
                        schema, head, body, rName,
                        objectActions,
                        checkTarget = angular.isArray(e) ? e[0] : e,
                        objectIsValid = !!checkTarget.object && !!checkTarget.object.entity_type &&
                            !!checkTarget.action && angular.isDefined(checkTarget.action.code) &&
                            !!streamCodes[checkTarget.action.code];

                    if (!objectIsValid) {
                        console.warn("Notification render got invalid object: ", this.props);
                        return null;
                    }

                    var getRendererName = function (item) {
                        return item.object.entity_type + "_" + streamCodes[item.action.code];
                    };

                    var textPreviewComponent = React.createFactory(textPreview);

                    function _getRenderer(obj, r) {
                        if (angular.isObject(obj)) {
                            var rendererName = obj.entity_type + r.charAt(0).toUpperCase() + r.slice(1);
                            try {
                                //return React.createFactory($injector.get(rendererName));
                                return $injector.get(rendererName);
                            }
                            catch (err) {
                                console.warn("Header: No renderer for: ", rendererName, err);
                                return null;
                            }
                        }
                    }

                    //(<div>7!</div>);//
                    function getHeader(schema, entry, mode) {
                        return _.map(schema.header, function (hEl, iH) {
                            if (hEl == 'text') {
                                var e = angular.isArray(entry) ? entry[0] : entry;
                                return textPreviewComponent({
                                    key: 'ntf-head-text-' + e.id + '-' + iH + ':' + mode,
                                    instance: angular.isArray(entry) ? entry[0] : entry,
                                    header: true,
                                    mode: mode
                                });

                            }
                            else {
                                var renderData = hEl.split(':');
                                if (renderData.length != 2) {
                                    return null;
                                }

                                var o = renderData[0],
                                    r = renderData[1],
                                    obj = angular.isArray(entry) ? entry[0][o] : entry[o],
                                    renderer = _getRenderer(obj, r);

                                if (renderer) {
                                    return React.createElement(renderer, {
                                        key: 'ntf-head-' + obj.id + '-' + iH + ':' + mode,
                                        instance: obj,
                                        object: angular.isArray(entry) ? entry[0] : entry,
                                        mode: mode
                                    });
                                }

                                console.warn("Header: invalid object ", entry, hEl, schema);
                            }
                        });
                    }

                    function getBody(schema, entry, mode) {
                        return _.map(angular.isArray(entry) ? entry : [entry], function (entry_i) {
                            return _.map(schema.body, function (bEl, iB) {
                                if (bEl == 'text') {
                                    var e = angular.isArray(entry) ? entry[0] : entry;
                                    return textPreviewComponent({
                                        key: 'ntf-body-text-' + e.id + '-' + iB + ':' + mode,
                                        instance: entry_i,
                                        body: true,
                                        mode: mode
                                    });
                                }
                                else {
                                    var renderData = bEl.split(':');
                                    if (renderData.length != 2) {
                                        return null;
                                    }
                                    var o = renderData[0],
                                        r = renderData[1],
                                        obj = entry_i[o],
                                        renderer = _getRenderer(obj, r);

                                    if (renderer) {
                                        return React.createElement(renderer, {
                                            key: 'ntf-body-' + entry_i.id + '-' + iB + ':' + mode,
                                            instance: obj,
                                            object: entry_i,
                                            mode: mode
                                        });
                                    }

                                    console.warn("Body: invalid object ", entry, bEl);
                                }
                            });
                        });
                    }

                    var _id = this.props.item.id;

                    function getActions(schema, mode) {
                        var actions = _.map(schema, function (action, i) {
                            return React.createFactory($injector.get(action))({
                                key: 'ntf-action-' + _id + '-' + i + ':' + mode,
                                instance: e,
                                //object: this.props,
                                mode: mode
                            });
                        });

                        return (
                            <div className="entry-actions">{actions}</div>
                        );
                    }

                    if (this.props.mode == notificationBlockType.COMPACT) {
                        e = angular.isDefined(e.stream) ? e.stream : e;

                        var iconClass = angular.isDefined(e.object) ? "type type--" + e.object.entity_type : "type type--generic";

                        rName = getRendererName(e);

                        try {
                            schema = renderMatrix[rName].compact;
                        }
                        catch (err) {
                            console.warn("No schema for: ", rName, ' in compact mode', this.props);
                            return null;
                        }

                        if (!angular.isDefined(schema)) {
                            console.warn("No schema for: ", rName, ' in compact mode', this.props);
                            return null;
                        }

                        head = getHeader(schema, e, this.props.mode);
                        body = getBody(schema, e, this.props.mode);

                        if (!!schema.actions) {
                            objectActions = getActions(schema.actions, this.props.mode);
                        }

                        return (
                            <div onClick={switchToMessagesFolder.bind(this, e)} key={e.id + ':' + this.props.mode} className="mail-message-wrap">
                                <div className="message-bar">
                                    <div className="meta">
                                        <div className={iconClass}></div>
                                    </div>
                                    <div className="message-about">{head}</div>
                                    <div className="mail-message-actions">
                                        <button onClick={markAsRead.bind(this, e.id)} type="button" title="Отметить как прочитанное" className="mark-read"></button>
                                    </div>
                                </div>
                                <div className="mail-message-content">{body}</div>
                                    {objectActions}
                            </div>
                        );
                    }
                    else if (this.props.mode == notificationBlockType.FULL) {

                        rName = getRendererName(e);

                        try {
                            schema = renderMatrix[rName].full;
                        }
                        catch (err) {
                            console.warn("No schema for: ", rName, ' in full mode', this.props);
                            return <noscript/>;
                        }

                        if (!angular.isDefined(schema)) {
                            console.warn("No schema for: ", rName, ' in full mode', this.props);
                            return <noscript/>;
                        }

                        head = getHeader(schema, e, this.props.mode);
                        body = getBody(schema, e, this.props.mode);

                        if (angular.isDefined(schema.actions)) {
                            objectActions = getActions(schema.actions, this.props.mode);
                        }

                        return (
                            <div key={e.id + ':' + this.props.mode} className="list-entry" data-protractor-id={'protractor-' + rName}>
                                <div className="content-object__info">
                                    <div className="sender-info">{head}</div>
                                    <div className="message">{body}</div>
                                        {objectActions}
                                </div>
                            </div>
                        );
                    }
                    else if (this.props.mode == notificationBlockType.STREAM) {

                        var isContextGroup = e[0].withContext,
                            isSubjectGroup = e[0].withSubject;

                        rName = getRendererName(e[0]);
                        if (isContextGroup) {

                            console.log("rendering: ", getRendererName(e[0]), ' in stream mode, groupped by context');

                            try {
                                schema = renderMatrix[rName].stream.context;
                            }
                            catch (err) {
                                console.warn("No schema for: ", rName, ' in stream context mode');
                                return <noscript/>;
                            }
                        }
                        else if (isSubjectGroup) {
                            console.log("rendering: ", getRendererName(e[0]), ' in stream mode, groupped by subject');

                            try {
                                schema = renderMatrix[rName].stream.subject;
                            }
                            catch (err) {
                                console.warn("No schema for: ", rName, ' in stream subject mode');
                                return <noscript/>;
                            }
                        }
                        else {
                            console.log("rendering: ", getRendererName(e[0]), ' in stream mode, single');

                            try {
                                schema = renderMatrix[rName].stream.single;
                            }
                            catch (err) {
                                console.warn("No schema for: ", rName, ' in stream single mode', this.props.entry);
                                return <noscript/>;
                            }
                        }

                        head = getHeader(schema, e, this.props.mode);
                        body = getBody(schema, e, this.props.mode);
                        console.log("Rendering done", rName, head, e);

                        return (
                            <div key={e[0].id + ':' + this.props.mode} className="timeline__entry">
                                <div className="timeline__entry__picture"></div>
                                <div className="timeline__entry__content">
                                    <h2 key={'head_' + e[0].id + ':' + this.props.mode}>{head}</h2>
                                    <div className="timeline__entry__content__body">{body}</div>
                                </div>
                            </div>
                        );
                    }

                    console.warn("GOT NO RENDERING CONFIG FOR", this.props);
                    return null;
                }
            });
        }])
        .factory("rDataStream", ['$filter', 'streamCodes', 'EventUserState', 'rLinks', 'photoSettings', 'imageUrl', 'rListUtilsMixin', 'rTagsWidget', '$rootScope', 'NotificationBlock', 'notificationBlockType', function ($filter, streamCodes, EventUserState, rLinks, photoSettings, imageUrl, rListUtilsMixin, rTagsWidget, $rootScope, NotificationBlock, notificationBlockType) {
            function isStreamEntryValid(entry) {

                // Debug
                var valid = angular.isDefined(entry) &&
                    angular.isObject(entry.action) &&
                    angular.isObject(entry.object) &&
                    angular.isDefined(entry.action.code);
                if (!valid) {
                    console.log("Invalid stream object: ", entry);
                }

                return angular.isDefined(entry) &&
                    angular.isObject(entry.action) &&
                    angular.isObject(entry.object) &&
                    angular.isDefined(entry.action.code);

            }

            return React.createClass({
                displayName: 'DataStream',
                render: function () {

                    var i = 0,
                    //k = 0,
                        validStreamEntries = _.filter(this.props.data, isStreamEntryValid),
                        prevContextKey = "",
                        prevSubjectKey = "",
                        contextGroupForming = false,
                        subjectGroupForming = false,
                        allGroups = [];

                    console.log("Total validStreamEntries: ", validStreamEntries.length);

                    for (var gi = 0; gi < validStreamEntries.length; gi++) {
                        var
                            e = validStreamEntries[gi],
                            contextKey = e.object.entity_type + ":" + streamCodes[e.action.code] + (angular.isObject(e.context) ? ":" + e.context.entity_type + ":" + e.context.id : ":" + (i++)),
                            subjectKey = (e.subject ? e.subject.entity_type + ":" + e.subject.id : "null") + ":" + e.object.entity_type + ":" + streamCodes[e.action.code],
                            canBeGrouppedByContext = prevContextKey == contextKey,
                            canBeGrouppedBySubject = prevSubjectKey == subjectKey;

                        //console.log("ContextKey: ", gi, contextKey);
                        //console.log("subjKey: ", gi, subjectKey);

                        if (canBeGrouppedByContext && !subjectGroupForming) {
                            //console.log("Can canBeGrouppedByContext!");
                            validStreamEntries[gi].withContext = allGroups[allGroups.length - 1][0].withContext = true;
                            allGroups[allGroups.length - 1].push(validStreamEntries[gi]);
                        }
                        else if (canBeGrouppedBySubject && !contextGroupForming) {
                            //console.log("Can canBeGrouppedBySubject!");
                            validStreamEntries[gi].withSubject = allGroups[allGroups.length - 1][0].withSubject = true;
                            allGroups[allGroups.length - 1].push(validStreamEntries[gi]);
                            subjectGroupForming = true;

                        }
                        else {
                            allGroups.push([validStreamEntries[gi]]);
                            subjectGroupForming = contextGroupForming = false;

                        }
                        prevContextKey = contextKey;
                        prevSubjectKey = subjectKey;

                    }

                    console.log(":: Stream groups: ", allGroups);
                    var streamEntries = _.map(allGroups, function (g) {
                        return NotificationBlock({
                            entry: angular.isArray(g) ? g : [g],
                            mode: notificationBlockType.STREAM
                        });
                    });

                    if (allGroups.length) {
                        return (
                            <div className="timeline">
                                {streamEntries}
                            </div>
                        );
                    }

                    return null;

                }
            });
        }])
        .directive('renderStream', [
            "$window", "$rootScope", "rDataStream", "userService",
            function ($window, $rootScope, rDataStream, userService) {

                //var DataStream = React.createFactory(rDataStream);
                var DataStream = rDataStream;

                return {
                    restrict: 'A',
                    scope: {
                        stream: '='
                    },
                    link: function (scope, element) {

                        function renderStream(stream) {
                            React.render(
                                //DataStream({
                                //    data: stream
                                //}),
                                React.createElement(DataStream, {
                                    data: stream
                                }),
                                element[0]
                            );
                        }

                        scope.$watch('stream', function (newStream) {
                            if (newStream) {
                                console.log("New stream data: ", newStream);
                                // User must be resolved before stream render
                                userService.getUser().then(function () {
                                    renderStream(newStream);
                                });

                            }

                        });
                    }
                };
            }]);

})();
