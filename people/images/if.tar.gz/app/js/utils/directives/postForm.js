(function(){
angular.module('app.utils.postform', ['app']).directive('postForm', [
    function () {
        return {
            restrict: 'AE',
            replace: true,
            templateUrl: '/static/partials/wall/post_form.html',
            scope: false,
            link: function () {
                angular.element(document).ready(function () {
                    $('#post-form-file-upload-section div > div, #post-form-file-upload-section div > span').click(function (e) {
                        if (!e.target || $(e.target).parents('div.masonry-brick').length === 0) {
                            $('#post-form-file-input').click();
                        }
                    });
                });
            }
        };
    }]);

})();