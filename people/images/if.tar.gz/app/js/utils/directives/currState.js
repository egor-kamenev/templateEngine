(function () {
    'use strict';
    angular.module('app.currentState', []).directive('body', [
        '$rootScope',
        function ($rootScope) {
            var html = angular.element('html');

            function setAuthState() {
                if ($rootScope.user.authenticated) {
                    html.addClass("auth-logged-in");
                } else {
                    html.removeClass("auth-logged-in");
                }
                console.info("AUTH: ", $rootScope.user.authenticated);
            }

            return {
                restrict: 'E',
                compile: function (el) {
                    if ($rootScope.user.authenticated) {
                        el.addClass("auth-logged-in");
                    } else {
                        el.removeClass("auth-logged-in");
                    }

                    $rootScope.$on('$stateChangeSuccess',
                        function (event, toState, toParams, fromState) {
                            setAuthState();
                            el.addClass("state-" + toState.name.split(".").join("-"));
                            el.removeClass("state-" + fromState.name.split(".").join("-"));
                        });
                }
            };
        }]).directive('loading', [
        function () {
            return {
                restrict: 'A',
                scope: false,
                link: function (scope, el, attrs) {
                    var element = angular.element(el);
                    element.addClass("loading");
                    var unwatch = scope.$watch(attrs.loading, function (val) {
                        if (val === true) {
                            element.removeClass("loading");
                            unwatch();
                        }
                    });
                }
            };
        }]).directive('csrftoken', [
        "$cookies",
        function ($cookies) {
            return {
                restrict: "AC",
                template: '<input type="hidden" name="csrfmiddlewaretoken" value="[[ CSRF_TOKEN ]]">',
                replace: true,
                scope: true,
                link: function (scope) {
                    scope.CSRF_TOKEN = $cookies.csrftoken;
                }
            };
        }]).filter('toDate', [function () {
        return function (stringVal, formatStr) {
            return moment(stringVal).format(formatStr);
        };
    }]).filter('toCommonDate', ['dateTimeFormat', function (dateTimeFormat) {
        return function (stringVal) {
            return moment(stringVal).format(dateTimeFormat.COMMON);
        };
    }]).filter('toCommonDateTime', ['dateTimeFormat', function (dateTimeFormat) {
        return function (stringVal) {
            return moment(stringVal).format(dateTimeFormat.COMMON_WITH_TIME);
        };
    }]).filter('toWeekDayDateTime', ['dateTimeFormat', function (dateTimeFormat) {
        return function (stringVal) {
            return moment(stringVal).format(dateTimeFormat.WEEKDAY_WITH_TIME);
        };
    }]).filter('fromNow', [function () {
        return function (stringVal) {
            return stringVal ? moment(stringVal).fromNow() : ''; //.format(formatStr);
        };
    }]).filter('timeDelta', [function () {
        return function (stringVal, formatStr) {
            return moment().diff(stringVal).format(formatStr);
        };
    }]).factory('fullName', [function () {
        return function (user) {
            if (!user)
                return null;

            var name = user.username;
            if (user.last_name && user.first_name)
                name = user.first_name + " " + user.last_name;

            return name;
        };
    }])
        .filter('fullName', ["fullName", function (fullName) {
            return fullName;
        }])
        .filter('shortName', [function () {
            return function (user) {
                if (!user)
                    return null;

                var name = user.username;
                if (user.first_name)
                    name = user.first_name;

                if (user.last_name)
                    name += " " + user.last_name[0];
                return name;
            };
        }])
        .factory("typeByTags", [function () {
            return function (item) {
                if (!item || !item.tags)
                    return null;
                var x = _.filter(_.sortBy(item.tags, "id"), "is_system");
                return x.length ? x[0].alias : "default";
            };
        }]).filter('typeByTags', ["typeByTags", function (typeByTags) {
            return typeByTags;
        }]).filter('age', [function () {
            var now = moment();
            return function (stringVal) {
                if (stringVal) {
                    var value = moment(stringVal);
                    if (value.isValid()) {
                        return Math.round(now.diff(value, 'years', true));
                    }
                }
                return null;
            };
        }]).factory('imageUrl', ['MEDIA_URL', function (MEDIA_URL) {
            return function (image_path, size) {
                if (!image_path) {
                    return null;
                }
                if (size) {
                    return MEDIA_URL + size + '/' + image_path;
                }
                return MEDIA_URL + image_path;
            };
        }]).filter('imageUrl', ["imageUrl", function (imageUrl) {
            return imageUrl;
        }]).factory('contentType', [function () {
            return function (item) {
                return {
                    ct_pk: item.content_type_id,
                    pk: item.id
                };
            };
        }]);
})();