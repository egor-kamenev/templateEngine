(function() {
    'use strict';

    var STATUS_PROCESSING = 'STATUS_PROCESSING',
        STATUS_REJECT = 'STATUS_REJECT',
        STATUS_PROCESSING_AFTER_REJECT = 'STATUS_PROCESSING_AFTER_REJECT',
        BACKEND_WORK = 'backend_work',
        BACKEND_DOWN = 'backend_down',
        BACKEND_WAIT = 'backend_wait',
        PING_TIMEOUT = 5000,
        QUEUE_RESOLVE_TIMEOUT = 500,
        LONG_REQUEST_TIMEOUT = 500,
        MAX_ATTEMPTS_RESTORE = 5,
        RPC_STATE_UI_URL = '/static/partials/maintenance/rpc_state.html',
        jsonRPC,
        $compile;


    angular.module('rpc.interceptor', [])
        .factory('jsonRpcInterceptor', ['$q', '$rootScope', '$interval', function($q, $rootScope, $interval) {
            var requestQueue = {},
                requestCounter = 0;

            $rootScope.is_connection_established = true;
            $rootScope.ping_time_left = 0;

            var CheckingConnection = {
                is_connection_checking: false,
                interval_promise: undefined,
                timer_promise: undefined,
                failed_check_counter: 0,

                startChecking: function startChecking() {
                    if (!this.is_connection_checking) {
                        this.is_connection_checking = true;
                        this.check();
                    }
                },

                stopChecking: function() {
                    this.failed_check_counter = 0;
                    this.is_connection_checking = false;
                    $interval.cancel(this.interval_promise);
                    $interval.cancel(this.timer_promise);
                },

                check: function() {
                    jsonRPC.ping({
                        skip_interceptor: true,
                        jsonRPC: true
                    });

                    this.failed_check_counter += 1;
                    var self = this;
                    var timeout = this.failed_check_counter * PING_TIMEOUT + PING_TIMEOUT;

                    $rootScope.$broadcast('pingTimeout', timeout);

                    $interval.cancel(this.interval_promise);
                    this.interval_promise = $interval(function() {
                        self.check();
                    }, timeout, 1);
                },

                forceCheck: function() {
                    if (this.is_connection_checking) {
                        $interval.cancel(this.interval_promise);
                        $interval.cancel(this.timer_promise);
                        this.check();
                    }
                }
            };

            var ConnectionState = {
                is_established: true,
                connectionLost: function() {
                    if (this.is_established) {
                        this.is_established = false;
                        CheckingConnection.startChecking();
                        $rootScope.$broadcast('backendDown');
                    }
                },
                connectionRestore: function() {
                    if (!this.is_established) {
                        this.is_established = true;
                        CheckingConnection.stopChecking();
                        $rootScope.$broadcast('backendWork');
                        processQueue();
                    }
                }
            }

            var LongRequestChecker = {
                interval_promise: undefined,
                checkQueue: function() {
                    var first_ts = _.min(_.values(requestQueue), 'ts').ts;
                    var now = new Date().getTime();

                    if (first_ts === undefined || first_ts === Infinity) {
                        $rootScope.$broadcast('backendWork');
                        return;
                    } else if (now - first_ts > LONG_REQUEST_TIMEOUT) {
                        $rootScope.$broadcast('backendWait');
                    }
                    $interval.cancel(this.interval_promise);
                    var self = this;
                    $interval(function() {
                        self.checkQueue();
                    }, Math.min(now - first_ts, 500), 1);
                }
            }

            function addRequest(config) {
                if ('skip_interceptor' in config && config.skip_interceptor)
                    return config;
                if ('request_id' in config)
                    return config;

                config.request_id = requestCounter;

                requestQueue[requestCounter] = {
                    config: config,
                    status: STATUS_PROCESSING,
                    ts: new Date().getTime()
                };
                requestCounter += 1;
                LongRequestChecker.checkQueue();
                return config;
            }

            function processResponse(response) {

                if (!ConnectionState.is_established)
                    ConnectionState.connectionRestore();

                if ('skip_interceptor' in response.config && response.config.skip_interceptor)
                    return response;

                var record = requestQueue[response.config.request_id];
                delete requestQueue[response.config.request_id];

                if (record.status === STATUS_PROCESSING_AFTER_REJECT)
                    record.defer.resolve(response);

                return response;
            }


            function rejectedRequest(rejection) {
                if (rejection.config.skip_interceptor)
                    return rejection;
                var deferred = $q.defer();
                requestQueue[rejection.config.request_id]['status'] = STATUS_REJECT;
                requestQueue[rejection.config.request_id]['defer'] = deferred;

                ConnectionState.connectionLost();
                return deferred.promise;
            }

            function rejectedResponse(response) {
                if (response.config.skip_interceptor)
                    return response;

                var deferred = $q.defer();

                ConnectionState.connectionLost();

                requestQueue[response.config.request_id]['status'] = STATUS_REJECT;
                requestQueue[response.config.request_id]['defer'] = deferred;
                requestQueue[response.config.request_id]['config']['attempts_restore'] = requestQueue[response.config.request_id]['config']['attempts_restore'] || 0;

                return deferred.promise;
            };

            function rejectAfterMaxAttemptsRestore(record) {
                delete requestQueue[record.config.request_id];
                record.defer.reject(record.config);
            };

            function processQueue() {
                var values = _.values(requestQueue);
                var rejected = values.filter(function(record) {
                    return record.status == STATUS_REJECT;
                });
                var interval_promise = $interval(function() {
                    if (rejected.length) {
                        var record = rejected.shift();
                        record.config.attempts_restore += 1;
                        if (record.config.attempts_restore > MAX_ATTEMPTS_RESTORE) {
                            rejectAfterMaxAttemptsRestore(record);
                        } else {
                            record.status = STATUS_PROCESSING_AFTER_REJECT;
                            jsonRPC.recovered_request(record.config);
                        }
                    } else {
                        $interval.cancel(interval_promise);
                    }
                }, QUEUE_RESOLVE_TIMEOUT);
            };

            return {
                request: addRequest,
                requestError: rejectedRequest,
                response: processResponse,
                responseError: rejectedResponse,
                forcePing: function() {
                    CheckingConnection.forceCheck()
                }
            }
        }])
        .directive('rpcState', [function() {
            return {
                restrict: 'AE',
                replace: true,
                scope: false,
                controller: ['$scope', '$interval', 'jsonRpcInterceptor', function($scope, $interval, interceptor) {
                    $scope.is_fog_on_screen = false;
                    $scope.ping_time_left = 0;
                    $scope.backendState = BACKEND_WORK;
                    $scope.forcePing = interceptor.forcePing;

                    var unBackendDown = $scope.$onRootScope("backendDown", function() {
                        if (!$scope.is_fog_on_screen) {
                            $scope.is_fog_on_screen = true;
                            $('body').children(':not(#rpc-ui-state)').wrapAll('<div class="loading-fog"/>');
                        }
                        $scope.backendState = BACKEND_DOWN;
                    });
                    var unBackendWork = $scope.$onRootScope("backendWork", function() {
                        if ($scope.is_fog_on_screen) {
                            $scope.is_fog_on_screen = false;
                            $('.loading-fog').children(':first-child').unwrap('.loading-fog');
                        }
                        $scope.backendState = BACKEND_WORK;
                    });

                    var unBackendWaiting = $scope.$onRootScope('backendWait', function() {
                        if (!$scope.is_fog_on_screen) {
                            $scope.is_fog_on_screen = true;
                            $('body').children(':not(#rpc-ui-state)').wrapAll('<div class="loading-fog"/>');
                        }
                        if ($scope.backendState != BACKEND_DOWN)
                            $scope.backendState = BACKEND_WAIT;
                    });

                    var unPingTimeout = $scope.$onRootScope('pingTimeout', function(event, timeout) {
                        $scope.ping_time_left = timeout / 1000;

                        $interval.cancel($scope.timer_promise);
                        $scope.timer_promise = $interval(function() {
                            $scope.ping_time_left -= 1;
                        }, 1000, Math.ceil(timeout / 1000));

                        if ($scope.ping_time_left < 0) {
                            $scope.ping_time_left = 0;
                            $interval.cancel($scope.timer_promise);
                        }
                    });

                    $scope.$on('$destroy', function() {
                        unBackendDown();
                        unBackendWaiting();
                        unPingTimeout();
                        unBackendWork();
                    });
                }],
                templateUrl: RPC_STATE_UI_URL
            }
        }])
    angular.module('rpc.delay_load', ['rpc.request'])
        .run(['jsonRPC', '$compile', function(local_jsonRPC, local_compile) {
            jsonRPC = local_jsonRPC;
            $compile = local_compile;
        }])

})();
