(function() {
    'use strict';
    angular.module('rpc', ['rpc.request', 'rpc.interceptor', 'rpc.delay_load'])
        .config(['$httpProvider', function ($httpProvider) {
            console.log('interceptor config');
            $httpProvider.interceptors.push('jsonRpcInterceptor');
        }])
})();
