(function () {
    'use strict';

    var toFixed = function (value, precision) {
        var power = Math.pow(10, precision || 0);
        return String(Math.round(value * power) / power);
    };

    angular.module('rpc.request', []).provider('jsonRPC', function () {
        // RPC Version Number
        this.version = '2.0';

        // End point URL, sets default in requests if not
        // specified with the request call
        this.endPoint = null;

        // Default namespace for methods
        this.namespace = null;


        /*
         * Provides the RPC client with an optional default endpoint and namespace
         *
         * @param {object} The params object which can contain
         *   endPoint {string} The default endpoint for RPC requests
         *   namespace {string} The default namespace for RPC requests
         *   cache {boolean} If set to false, it will force requested
         *       pages not to be cached by the browser. Setting cache
         *       to false also appends a query string parameter,
         *       "_=[TIMESTAMP]", to the URL. (Default: true)
         */
        this.setup = function (params) {
            this._validateConfigParams(params);
            this.endPoint = params.endPoint;
            this.namespace = params.namespace;
            this.cache = params.cache !== undefined ? params.cache : true;
            return this;
        };

        ///*
        // * Convenience wrapper method to allow you to temporarily set a config parameter
        // * (endPoint or namespace) and ensure it gets set back to what it was before
        // *
        // * @param {object} The params object which can contains
        // *   endPoint {string} The default endpoint for RPC requests
        // *   namespace {string} The default namespace for RPC requests
        // * @param {function} callback The function to call with the new params in place
        // */
        //this.withOptions = function (params, callback) {
        //    this._validateConfigParams(params);
        //    // No point in running if there isn't a callback received to run
        //    if (callback === undefined) throw("No callback specified");
        //
        //    var origParams = {endPoint: this.endPoint, namespace: this.namespace};
        //    this.setup(params);
        //    callback.call(this);
        //    this.setup(origParams);
        //};

        /*
         * Perform a single RPC request
         *
         * @param {string} method The name of the rpc method to be called
         * @param {object} options A collection of object which can contains
         *  params {array} the params array to send along with the request
         *  success {function} a function that will be executed if the request succeeds
         *  error {function} a function that will be executed if the request fails
         *  url {string} the url to send the request to
         *  id {string} the provenance id for this request (defaults to 1)
         *  cache {boolean} If set to false, it will force requested
         *       pages not to be cached by the browser. Setting cache
         *       to false also appends a query string parameter,
         *       "_=[TIMESTAMP]", to the URL. (Default: cache value
         *       set with the setup method)
         * @return {undefined}
         */
        this.request = function ($http, $q, $rootScope, $injector, method, params, options) {
            if (options === undefined) {
                options = {id: 1};
            }
            if (options.id === undefined) {
                options.id = 1;
            }
            if (options.cache === undefined) {
                options.cache = this.cache;
            }

            // Validate method arguments
            this._validateRequestMethod(method);
            this._validateRequestParams(params);
//        this._validateRequestCallbacks(options.success, options.error);
            // Perform the actual request
            return this._doRequest(
                $http, $q, $rootScope, $injector,
                this._requestDataObj(method, params, options.id),
                options
            );
        };

        // Validate a params hash
        this._validateConfigParams = function (params) {
            if (params === undefined) {
                throw("No params specified");
            }
            else {
                if (params.endPoint && typeof(params.endPoint) !== 'string') {
                    throw("endPoint must be a string");
                }
                if (params.namespace && typeof(params.namespace) !== 'string') {
                    throw("namespace must be a string");
                }
            }
        };

        // Request method must be a string
        this._validateRequestMethod = function (method) {
            if (typeof(method) !== 'string') throw("supplied for jsonRPC request");
            return true;
        };

        // Validate request params.  Must be a) empty, b) an object (e.g. {}), or c) an array
        this._validateRequestParams = function (params) {
            if (!(params === null ||
                params === undefined ||
                typeof(params) === 'object' ||
                angular.isArray(params))) {
                throw("Invalid params supplied for jsonRPC request. It must be empty, an object or an array.");
            }
            return true;
        };

        //this._validateRequestCallbacks = function (success, error) {
        //    // Make sure callbacks are either empty or a function
        //    if (success !== undefined &&
        //        typeof(success) !== 'function') throw("Invalid success callback supplied for jsonRPC request");
        //    if (error !== undefined &&
        //        typeof(error) !== 'function') throw("Invalid error callback supplied for jsonRPC request");
        //    return true;
        //};

        // Internal method used for generic ajax requests
        this._doRequest = function ($http, $q, $rootScope, $injector, data, options) {
            function __getTS() {
                return (performance || Date).now();
            }
            
            var a = __getTS();
            var deferred = $q.defer();
            var self = this;

            var onsuccess = function (response) {
                // If we've encountered an error in the response, trigger the error callback if it exists
                if (response.error) {
                    onerror(response);
                }
                // Otherwise, successful request, run the success request if it exists
                else {
                    if (response.data.error) {
                        if ($rootScope.isRegularUserRoleRequired(response.data.error)) {
                            $rootScope.$emit('checkEmailConfirmation');
                        }
                    }
                    deferred.resolve(response.data);
                    var b = __getTS() - a;
                    console.debug('JSONRPC', data, options, "took:", toFixed(b, 4), "ms");
                }

                // Request no longer failed
                var reqInFailQueue = _.find($rootScope.failedRequests, function(r){
                    return r[0].method == data.method;
                }),
                    requestQueuedAsFailed = reqInFailQueue !== undefined;
                
                if(requestQueuedAsFailed){
                    // Resolve it's promise
                    reqInFailQueue[2].resolve(response.data);
                    $rootScope.failedRequests = _.without($rootScope.failedRequests, reqInFailQueue);
                }

                $rootScope.backendFailed = $rootScope.failedRequests.length !== 0;

                // Last failed request removed fom the queue
                if(requestQueuedAsFailed && !$rootScope.backendFailed){
                    $rootScope.resetFailedRequest();
                    var socketio = null;
                    try{
                        socketio = $injector.get('socketio');
                    }
                    catch(e){
                        return;
                    }
                    if(socketio){
                        socketio.reconnect();
                    }
                    $rootScope.user.offline = false;
                }
            };

            var onerror = function (response) {
                var backendFailed = response.status === 0,
                    showNotify = !backendFailed;

                // Failure pnotify is shown when 500 type errors occur
                // Otherwise block screen with countdown is displayed
                if(showNotify){
                    $rootScope.$emit("flash", {
                        type: "error",
                        title: "Error",
                        text: (response.error && response.error.data.msg || response.statusText) || "Request failed, try again later."
                    });
                }

                if (backendFailed) {

                    $rootScope.user.offline = true;

                    var requestAlreadyQueued = _.find($rootScope.failedRequests, function(r){
                        return r[0].method == data.method;
                    });

                    // Request not in queue
                    if( requestAlreadyQueued === undefined ){
                        $rootScope.failedRequests.push([data, options, deferred]);
                    }
                    else{
                        requestAlreadyQueued[0].params = data.params;
                        requestAlreadyQueued[1] = options;
                    }
                    if(!$rootScope.backendFailed){
                        $rootScope.backendFailed = true;
                        $rootScope.failedRequest = true;
                        $rootScope.backendFailedNum = 1;
                    }
                    
                }

                if (!backendFailed) {
                    // Promise gets resolved if backend not failed 
                    deferred.reject(response);
                }

                var b = __getTS() - a;
                console.debug('JSONRPC', data, options, "took:", toFixed(b, 4), "ms");
            };

            if (options.method && options.method == "GET") {
                data.params = JSON.stringify(data.params);

                $http.get(self._requestUrl((options.endPoint || options.url), options.cache), {
                    params: data,
                    cache: false, //options.cache,
                    headers: {'Content-Type': 'application/json'}
                }).then(onsuccess, onerror);

            } else {
                $http({
                    method: "POST",
                    cache: false, //options.cache,
                    url: self._requestUrl((options.endPoint || options.url), options.cache),
                    headers: {'Content-Type': 'application/json'},
                    data: JSON.stringify(data)
                }).then(onsuccess, onerror);
            }

            return deferred.promise;

        };

        // Determines the appropriate request URL to call for a request
        this._requestUrl = function (url, cache) {
            url = url || this.endPoint;
            if (!cache) {
                if (url.indexOf("?") < 0) {
                    url += '?tm=' + new Date().getTime();
                }
                else {
                    url += "&tm=" + new Date().getTime();
                }
            }
            return url;
        };

        // Creates an RPC suitable request object
        this._requestDataObj = function (method, params, id) {
            var dataObj = {
                jsonrpc: this.version,
                method: this.namespace ? this.namespace + '.' + method : method,
                id: id
            };

            if (params !== undefined) {
                dataObj.params = params;
            }
            return dataObj;
        };

        this.$get = ['$http', '$q', '$rootScope', '$injector', function ($http, $q, $rootScope, $injector) {
            var self = this;

            return {
                request: function (method, params, options) {
                    return self.request($http, $q, $rootScope, $injector, method, params, options);
                },
                ping: function (options) {
                    var opts = angular.extend({cache: false}, options);
                    return $http.head( JSON_RPC_ENDPOINT.replace('jsonrpc/', 'api/utils/ping/'), opts);
                },
                recovered_request: function(config){
                    return $http(config);
                }
            };
        }];
    });

})();
