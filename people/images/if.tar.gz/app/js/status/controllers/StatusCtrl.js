(function(){
'use strict';

angular.module('app.controllers.statusctrl', [])
    .controller('StatusCtrl', ['$scope', '$q', '$rootScope', '$stateParams', 'jsonRPC', 'userService', 'tagService', 'tagTypes', 'statusService', 'jqPaginationSettings',
    function ($scope, $q, $rootScope, $stateParams, jsonRPC, userService, tagService, tagTypes, statusService, jqPaginationSettings) {

        $scope.username = $stateParams.username;
        $scope.isOwnProfile = $scope.username == $rootScope.user.username;

        $scope.statusHistory = [];
        $scope.statusFavorites = [];

        $scope.historyLoaded = false;

        $scope.loaded = false;
        $scope.limit = jqPaginationSettings.limit;
        $scope.total = 0;
        $scope.maxPage = 0;
        
        $scope.currentPage =  $stateParams.page ? parseInt($stateParams.page, 10) : 1;

        $scope.$watch('user.current_status', function (value) {
            if (value) {
                $scope.currentStatus = value;
                $scope.reloadHistory();
            }
        });

        $scope.toggleFav = function (status_id) {
            
            /*if (!$rootScope.hasPerm('statuses.change_status')){
                $scope.$emit('checkEmailConfirmation', {
                    permission: 'statuses.change_status',
                    warningMessage: 'У вас недостаточно прав для добавления/удаления статуса в избранное'
                });
                return;
            }*/

            statusService.toggleFavorite(status_id).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Toggle favorite status error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        for (var i in $scope.statusHistory) {
                            if ($scope.statusHistory[i].id == status_id) {
                                $scope.statusHistory[i].favorite = data.result;
//                                break;
                            }
                        }
                        $scope.reloadFavorites();
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Toggle favorite status error",
                        text: "Toggle favorite status error"
                    });
                }
            );
            
        };

        $scope.setStatus = function (status_id) {
            
            /*if (!$rootScope.hasPerm('statuses.change_status')){
                $scope.$emit('checkEmailConfirmation', {
                    permission: 'statuses.change_status',
                    warningMessage: 'У вас недостаточно прав для установления статуса'
                });
                return;
            }*/

            statusService.setStatus(status_id).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Set status error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        for (var i in $scope.statusHistory) {
                            if ($scope.statusHistory[i].id == status_id) {
                                $scope.currentStatus = angular.copy($scope.statusHistory[i]);
                                updateUserStatus();
                                break;
                            }
                        }
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Set status error",
                        text: "Set status error"
                    });
                }
            );
        };

        $scope.deleteStatus = function (status_id) {
           
            /*if (!$rootScope.hasPerm('statuses.delete_status')){
                $scope.$emit('checkEmailConfirmation', {
                    permission: 'statuses.change_status',
                    warningMessage: 'У вас недостаточно прав для удаления статуса'
                });
                return;
            }*/
            
            statusService.deleteStatus(status_id).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Set status error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        $scope.reloadHistory();
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Set status error",
                        text: "Set status error"
                    });
                }
            );
            
        };

        $scope.reloadFavorites = function () {
            $scope.statusFavorites = [];
            for (var i in $scope.statusHistory) {
                if ($scope.statusHistory[i].favorite) {
                    $scope.statusFavorites.push($scope.statusHistory[i]);
                }
            }
        };

        $scope.reloadHistory = function () {

            statusService.getHistory($scope.username, $scope.currentPage).then(
                function (data) {

                    $scope.statusHistory = [];

                    if(!data.result.items.length) {
                        $scope.loaded = true;
                        return;
                    }

                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Get status history error",
                                text: data.error.data.msg
                            });
                        }
                        $scope.historyLoaded = true;
                        $scope.loadMoreBusy = false;
                    }
                    else {

                        var n = $scope.statusHistory.length;

                        angular.forEach(data.result.items, function (status) {
                            var first = true;
                            angular.forEach($scope.statusHistory, function (history) {
                                if (history.text == status.text) {
                                    first = false;
                                }
                            });
                            if (first) {
                                status.current = true;
                            }
                            // number is for 'track by' 
                            // we cant user track by status.id 
                            // as far it's possible to have several statuses with the same id here
                            status.number = n++;
                            $scope.statusHistory.push(status);
                        });

                        $scope.total = data.result.total;
                        $scope.loaded = true;
                        
                        if(!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10)/$scope.limit);

                        $scope.reloadFavorites();
                        $scope.historyLoaded = true;
                        $scope.loadMoreBusy = false;
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Get status history error",
                        text: "Get status history error"
                    });
                    $scope.historyLoaded = true;
                    $scope.loadMoreBusy = false;
                }
            );

        };

        function updateUserStatus() {
            $rootScope.user.current_status = $scope.currentStatus;
        }
        function reloadCurrentStatus() {
            if ($scope.isOwnProfile) {
                $scope.currentStatus = $rootScope.user.current_status;
            }
            else {
                statusService.getCurrent($scope.username).then(
                    function(data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Set status error",
                                    text: data.error.data.msg
                                });
                                deferred.reject();
                            }
                        }
                        else {
                            $scope.currentStatus = data.result;
                        }
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Get status error",
                            text: "Get status error"
                        });
                        deferred.reject();
                    }
                );
            }
        }
        reloadCurrentStatus();

  }]);

})();