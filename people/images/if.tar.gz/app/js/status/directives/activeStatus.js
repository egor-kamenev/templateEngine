(function () {
    'use strict';
    angular.module('status.activeStatus.directive', ['app']).directive('activeStatus', [
        '$q', '$rootScope', '$state', 'jsonRPC', 'tagService', 'channelService', 'socketio', 'statusService',
        function ($q, $rootScope, $state, jsonRPC, tagService, channelService, socketio, statusService) {

            var scope = {
                entity: '=',
                hideStatusButton: '='
            };

            function link() {
            }

            function Controller($scope) {

                $scope.$watch('entity', function () {
                    console.log("active status watch", $scope.entity);
                    if ($scope.entity && $scope.entity.username) {
                        $scope.isOnwer = $rootScope.user.username == $scope.entity.username;
                        reloadCurrentStatus();
                        listenSocket();
                    }
                });

                $scope.$watch('entity.isSelectStatus', function (value) {
                    if (value) {
                        $scope.entity.isSelectStatus = false;
                        if ($rootScope.hasPerm('statuses.add_status')) {
                            $scope.openStatusForm();
                        }

                        $scope.$emit('checkEmailConfirmation', {
                            permission: 'statuses.add_status',
                            warningMessage: 'У вас недостаточно прав для установки статуса'
                        });
                    }
                });

                $scope.$watch('entity.current_status', function (value) {
                    if (value) {
                        $scope.currentStatus = value;
                    }
                });

                $scope.$on('$destroy', function () {
                    console.log('destroy!');
                    if ($scope.channelName) {
                        channelService.unsubscribe($scope.channelName).sync();
                        socketio.getSocket().removeListener($scope.channelName, updateData);
                    }
                });

                var updateData = function (data) {
                    console.log('data', data);
                    $scope.currentStatus = data.content;
                    updateUserStatus();
                };

                var subscribeFlagLock = false;
                var listenSocket = function () {
                    if (!subscribeFlagLock && $scope.entity.id) {
                        $scope.channelName = channelService.getChannelName('status', $scope.entity.id);
                        channelService.subscribe($scope.channelName).sync();
                        socketio.getSocket().on($scope.channelName, updateData);
                        subscribeFlagLock = true;
                    }
                };

                $scope.statusEditor = statusService.getStatusSelector();
                $scope.tagsEditor = tagService.getTagSelector();
                $scope.newStatus = {
                    status: {
                        tags: []
                    }
                };
                $scope.currentStatus = {};
                $scope.statuses = [];

                $scope.setStatus = function () {

                    //if ($scope.newStatus.status.text.length < 1) return;
                    var formData = _.extend({status: {text: "", tags: []}}, angular.copy($scope.newStatus));
                    var deferred = $q.defer();

                    statusService.changeStatus(formData.status).then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isFormError(data.error)) {
                                    deferred.reject(data.error.data);
                                    return data.error.data;
                                }
                                else if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Set status error",
                                        text: data.error.data.msg
                                    });
                                    deferred.reject();
                                }
                            }
                            else {
                                $scope.currentStatus = data.result;
                                updateUserStatus();
                                $scope.closeStatusForm();
                                $scope.newStatus = {};
                                deferred.resolve();
                            }
                        },
                        function () {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Set status error",
                                text: "Set status error"
                            });
                            deferred.reject();
                        }
                    );
                    return deferred.promise;
                };

                $scope.openStatusForm = function () {
                    statusService.getStatuses().then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Get favotires error",
                                        text: data.error.data.msg
                                    });
                                    $scope.statuses = [];
                                }
                            }
                            else {
                                $scope.statuses = data.result;
                                $scope.isSelectStatus = true;
                            }
                        },
                        function () {
                            $scope.statuses = [];
                        }
                    );
                };

                $scope.closeStatusForm = function () {
                    $scope.newStatus = {};
                    $scope.isSelectStatus = false;
                };

                function reloadCurrentStatus() {
                    if ($scope.isOnwer) {
                        statusService.currentStatus = $rootScope.user.current_status;
                        $scope.currentStatus = $rootScope.user.current_status;
                    }
                    else {
                        statusService.getCurrent($scope.entity.username).then(
                            function (data) {
                                if (data.error) {
                                    if ($scope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Set status error",
                                            text: data.error.data.msg
                                        });
                                        deferred.reject();
                                    }
                                }
                                else {
                                    $scope.currentStatus = data.result;
                                }
                            },
                            function () {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Get status error",
                                    text: "Get status error"
                                });
                                deferred.reject();
                            }
                        );
                    }
                }

                $scope.hasPerm = function (perm) {
                    return $rootScope.hasPerm(perm);
                };

                function updateUserStatus() {
                    if ($scope.entity) {
                        $scope.entity.current_status = $scope.currentStatus;
                    }
                }
            }

            Controller.$inject = ['$scope', '$element'];

            return ({
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                scope: scope,
                templateUrl: '/static/partials/status/active_status.html'
            });

        }]);

})();
