(function(){
angular.module('status.services', []).
    service('statusService', ['$q', '$rootScope', 'tagService', 'jsonRPC', 'jqPaginationSettings', 'permissionRequired',
     function($q, $rootScope, tagService, jsonRPC, jqPaginationSettings, permissionRequired) {

    var self = this;

    this.getStatusSelector = function(){
        return {
            choices: [],
            query: function (searchTerm) {
                var selector = this;
                if (searchTerm.length < 3) return;
                self.getStatuses(searchTerm).then(
                    function(response){
                        var res = [];
                        if (response.result.length === 0) {
                            res.push({text: searchTerm}); 
                        } else {
                            var inResponse = false;
                            angular.forEach(response.result, function (item) {
                                res.push(item);
                                if (item.name === searchTerm) {
                                    inResponse = true;
                                }
                            });
                            if (!inResponse) {
                                res.splice(0, 0, {text: searchTerm});
                            }
                        }
                        selector.choices = res;
                    },
                    function(response){
                        selector.choices = [];
                    }
                );
            }
        };
    };

    this.getCurrent = function (username) {

        return jsonRPC.request('statuses.get_current', {username: username});
    };

    this.getHistory = function (username, page) {

        var data = {
            username: username,
            page: page,
            page_size: jqPaginationSettings.limit,
            with_total: true
        };

        return jsonRPC.request('statuses.get_history', data);
    };

    this.getStatuses = function (search_term) {

        return jsonRPC.request('statuses.get_statuses', {search_term: search_term});
    };

    this.setStatus = permissionRequired('statuses.change_status', function (status_id) {

        //if ($rootScope.accessRequired('statuses.change_status')) return;

        return jsonRPC.request('statuses.set_active', {status_id: status_id});
    });

    this.toggleFavorite = permissionRequired('statuses.change_status', function (status_id) {
        return jsonRPC.request('statuses.toggle_favorite', {status_id: status_id});
    });

    this.addStatus = permissionRequired('statuses.add_status', function (status) {
        var data = {
            text: status.text,
            tags: status.tags
        };
        data.tags = tagService.convertTagsToRPCData(data.tags);

        return jsonRPC.request('statuses.add_status', data);
    });

    this.changeStatus = function (status) {
        var data = {
            text: status.text,
            tags: status.tags
        };
        data.tags = tagService.convertTagsToRPCData(data.tags);
        return jsonRPC.request('statuses.change_status', data);
    };

    this.deleteStatus = permissionRequired('statuses.change_status', function (status_id) {
        return jsonRPC.request('statuses.delete_status', {status_id: status_id});
    });

}]);

})();
