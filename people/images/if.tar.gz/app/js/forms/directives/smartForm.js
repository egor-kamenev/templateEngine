(function () {
    'use strict';
    angular.module('forms.directives', []).directive('autoFillSync', ['$timeout', function ($timeout) {
        return {
            require: 'ngModel',
            link: function (scope, elem, attrs, ngModel) {
                var origVal = elem.val();
                $timeout(function () {
                    var newVal = elem.val();
                    if (ngModel.$pristine && origVal !== newVal) {
                        ngModel.$setViewValue(newVal);
                    }
                }, 500);
            }
        };
    }]).directive("validateInputOnSubmit", ['$parse', function () {
        return {
            require: "ngModel",
            link: function (scope, elem, attrs, ctrl) {
                var parentForm = elem.inheritedData("$formController");
                ctrl.$parsers.push(function (value) {
                    if (!parentForm.wasSubmited) {
                        ctrl.$setPristine();
                    }
                    return value;
                });
            }
        };
    }]).directive("validateOnSubmit", ['$parse', function ($parse) {
        /*
         If used with smart-form resets the form to pristine state untill user submits the form.
         */
        return {
            controller: function ($scope) {
                $scope.$watch('formController.$valid', function (val) {
                    if (!val && !$scope.formController.wasSubmited) {
                        $scope.formController.$setPristine();
                    }
                });
            },
            link: function (scope, elem, attrs) {
                scope.formController = $parse(attrs.name)(scope);
            }
        };
    }]).directive("ngMustBeEqual", [function () {
        return {
            require: "ngModel",
            link: function (scope, elem, attrs, ctrl) {
                var otherInput = elem.inheritedData("$formController")[attrs.ngMustBeEqual];

                ctrl.$parsers.push(function (value) {
                    if (value === otherInput.$viewValue) {
                        ctrl.$setValidity("notequal", true);
                        return value;
                    }

                    ctrl.$setValidity("notequal", false);
                    return null;
                });

                otherInput.$parsers.push(function (value) {
                    ctrl.$setValidity("notequal", value === ctrl.$viewValue);
                    return value;
                });
            }
        };
    }]).directive('smartForm', ['$parse', '$rootScope', '$timeout', function ($parse, $rootScope, $timeout) {

        var formErrors = [];

        function setFormValidity(f, val) {
            f.$valid = val;
            f.$invalid = !val;
        }

        function cleanFormErrors(formController) {

            angular.forEach(formErrors, function (error) {
                var ctrl = formController[error.formField];
                if (ctrl) {
                    ctrl.$dirty = false;
                    ctrl.$setValidity(error.errorCode, true);
                }
                delete formController.$error[error.formField];
                //delete formController.$error[error.errorCode];
            });

            // Shitty workaround to fix
            // date-time-picker's name
            delete formController['[[name]]'];

            var formHasHTMLErrors = _.some(formController.$error, function (v) {
                return angular.isArray(v);
            });
            setFormValidity(formController, !formHasHTMLErrors);
            formErrors = [];
        }

        function addControlError(formController, controlName, errorCode, isCustom) {

            var ctrl = formController[controlName];
            // Error related to form field
            if (ctrl) {
                ctrl.$dirty = true;
                ctrl.$setValidity(errorCode, false);
            }

            if (isCustom) {
                formErrors.push(
                    {
                        formField: controlName,
                        errorCode: errorCode
                    }
                );
                //formController.$error[errorCode] = [controlName];
                if (!formController.$error[controlName]) {
                    formController.$error[controlName] = {};
                }
                formController.$error[controlName][errorCode] = true;

            }

        }

        function handleErrors(formController, errors) {
            angular.forEach(errors, function (controlErrors, controlName) {

                if (controlName == "__all__") {

                    angular.forEach(controlErrors, function (error) {
                        formController.$error[error] = true;
                        formErrors.push(
                            {
                                formField: controlName,
                                errorCode: error
                            }
                        );
                    });
                    setFormValidity(formController, false);
                }
                else {
                    if (angular.isArray(controlErrors)) {

                        if (controlErrors.length > 0) {
                            setFormValidity(formController, false);
                        }
                        angular.forEach(controlErrors, function (error) {
                            addControlError(formController, controlName, error, true);
                        });

                    }
                    else {
                        setFormValidity(formController, false);
                        addControlError(formController, controlName, controlErrors, true);
                    }
                }
            });
        }

        return {
            link: function (scope, element, attributes) {

                var formController = $parse(attributes.name)(scope);
                var formName = scope[attributes.name].$name;
                scope.handleErrors = handleErrors;


                if (attributes.permission) {
                    $rootScope.$watch(function () {
                        return $rootScope.hasPerm(attributes.permission);
                    }, function (hasPerm) {
                        if (hasPerm === false) {
                            // Better way to disable form?
                            angular.element('[name=' + formController.$name + ']').find("input:not(:disabled), select:not(:disabled), textarea:not(:disabled)").prop("disabled", true);
                            formController.$setValidity("notauthorized", false, formController);
                        }
                        else if (hasPerm === true) {
                            angular.element('[name=' + formController.$name + ']').find("input:disabled, select:disabled, textarea:disabled").removeAttr("disabled");
                            formController.$setValidity("notauthorized", true, formController);
                        }
                    });
                }

                function submit() {

                    var submitFunc = $parse(attributes.smartForm);
                    $rootScope.loading = true;
                    cleanFormErrors(formController);
                    formController.wasSubmited = true;

                    if (formController.$valid) {
                        var ret = submitFunc(scope);
                        if (ret) {
                            // Promise returned
                            if (ret.then) {
                                ret.then(
                                    function () {
                                        formController.$setPristine();
                                        formController.wasSubmited = false;
                                        $rootScope.loading = false;
                                    },
                                    function (errors) {
                                        if (errors) {
                                            console.log("Backend form errors: ", errors);
                                            handleErrors(formController, errors);
                                        }
                                        $rootScope.loading = false;
                                    }
                                );
                            }
                            // Plain object with errors returned
                            else {
                                console.log("Custom frontend form errors: ", ret);
                                handleErrors(formController, ret);
                                $rootScope.loading = false;
                            }
                        }
                        else {
                            $rootScope.loading = false;
                        }
                    }

                    else {
                        // get all inputs with errors
                        angular.forEach(formController.$error, function (controlsArray, error) {
                            angular.forEach(controlsArray, function (control) {
                                addControlError(formController, control.$name, error, false);
                            });
                        });
                        $rootScope.loading = false;

                    }
                }

                element.bind("submit", function () {
                    scope.$apply(submit);
                });
            },
            restrict: "A"
        };
    }]);
})();
