(function () {
    'use strict';
    angular.module('visibility.directives', ['app']).directive('selectVisibility', [
        '$q', '$rootScope', '$compile', '$http', '$templateCache', 'Visibility', 'VisibilityTypes', 'tagService', 'tagTypes',
        'userService', 'visibilityService', 'verifiedEmailRequired',
        function ($q, $rootScope, $compile, $http, $templateCache, Visibility, VisibilityTypes, tagService, tagTypes, userService, visibilityService, verifiedEmailRequired) {

            var scope = {
                entity: '=',
                autosave: '=',
                callback: '&',
                allowedTypes: '=',
                xrequired: '='
            };

            function link(scope, element, attributes) {
                scope.FRIENDSHIP = VisibilityTypes.FRIENDS_1C;
                scope.USERLIST = VisibilityTypes.LIST;
                scope.ALL = VisibilityTypes.ALL;

                // in case 'required' attribute changes dynamically
                // TODO: wtf it's not working with ng-required???
                scope.$watch('xrequired', function (value) {
                    if (angular.isDefined(value)) {
                        scope.required = (value === true);
                    }
                });

                attributes.$observe('required', function (value) {
                    scope.required = angular.isDefined(value);
                });

                scope.visibilities = [];

                angular.forEach(Visibility, function (k, v) {
                    var id = parseInt(v);
                    scope.visibilities.push({'id': id, 'text': k});
                });

                scope.$watch('visibility.value', function (val) {
                    if (typeof(val) != 'undefined') {
                        scope.user_select_disabled = val != VisibilityTypes.LIST;
                        scope.friendship_tags_select_disabled = val != VisibilityTypes.FRIENDS_1C;
//                        scope.user_select_disabled = scope.entity.visibility.value != VisibilityTypes.LIST;
//                        scope.friendship_tags_select_disabled = scope.entity.visibility.value != VisibilityTypes.FRIENDS_1C;
                    }
                    else {
                        scope.user_select_disabled = true;
                        scope.friendship_tags_select_disabled = true;
                    }
                });

                scope.$watch('allowedTypes', function (val) {
                    scope.visibilities = [];

                    angular.forEach(Visibility, function (k, v) {

                        var id = parseInt(v);
                        // Allow all visibility types
                        if (!angular.isArray(val)) {
                            scope.visibilities.push({'id': id, 'text': k});
                        }
                        // Allow this type if it's in alloweTypes array only
                        else if (val.indexOf(id) !== -1) {
                            scope.visibilities.push({'id': id, 'text': k});
                        }
                    });
                });

                // T998 only user with verified email can change visibilities
                element.bind('click', verifiedEmailRequired(scope.showForm));

                $http.get('/static/partials/visibility/select_visibility.html', {cache: $templateCache}).success(function (template) {
                    scope.modal_form = angular.element($compile(template)(scope));
                    var elem = element;
                    while (elem.context.parentElement && elem.context.parentElement.tagName != 'BODY') {
                        elem = angular.element(elem.context.parentElement);
                    }
                    elem.after(scope.modal_form);
                });
            }

            function Controller($scope, $element) {

                $scope.userSelector = userService.getUserSelector();
                //$scope.visibilityFtagSelector = tagService.getTags(tagTypes.friendship, true);
                $scope.tagsEditor = tagService.getTagSelector('friendship_tags');
                $scope.default_visibility = {
                    value: 0,
                    show_for_all: false,
                    indexable: false
                };
                $scope.saved = false;

                var last_show_for_all = false,
                    last_indexable = false;

                var css = "";
                $scope.privacyCss = function (privacy) {
                    $element.removeClass(css);
                    if (privacy.value == VisibilityTypes.ALL) {
                        css = "privacy-all";
                    } else if (privacy.value == VisibilityTypes.OWNER) {
                        css = "privacy-owner";
                        if (privacy.show_for_all) {
                            css = " show-all";
                        }
                    } else {
                        css = "privacy-custom";
                        if (privacy.show_for_all) {
                            css = " show-all";
                        }
                    }
                    $element.addClass(css);
                };

                $scope.setCurrentVisibility = function () {
                    $scope.$emit('changeVisibility', $scope.entity.visibility);
                };


                $scope.$watch("entity.visibility", function (value) {
                    if (value) {
                        $scope.privacyCss(value);
                    }
                });


                $scope.$watch("entity", function (value) {
                    if (!value) return;
                    if (value.visibility) {
                        if (value.visibility.show_for_all) {
                            last_show_for_all = value.visibility.show_for_all;
                        }
                        if (value.visibility.indexable) {
                            last_indexable = value.visibility.indexable;
                        }
                    }
                    else {
                        value.visibility = angular.copy($scope.default_visibility);
                    }

                    $scope.setCurrentVisibility();
                });

                $scope.changeVisibility = function () {
                    console.log("Visibility changed to:", $scope.entity.visibility);

                    // If visibility set is not LIST - reset user list
                    if ($scope.entity.visibility.value != VisibilityTypes.LIST) {
                        $scope.entity.visibility.users = [];
                    }

                    if ($scope.entity.visibility.value != VisibilityTypes.FRIENDS_1C) {
                        $scope.entity.visibility.friendship_tags = [];
                    }

                    if ($scope.entity.visibility.value == VisibilityTypes.ALL) {
                        last_show_for_all = $scope.entity.visibility.show_for_all;
                        $scope.entity.visibility.show_for_all = true;
                    }
                    else {
                        $scope.entity.visibility.show_for_all = last_show_for_all;
                    }

                    $scope.privacyCss($scope.entity.visibility);
                    $scope.changeShowing();
                    $scope.setCurrentVisibility();
                };

                $scope.changeShowing = function () {
                    $scope.entity.visibility.indexable = $scope.entity.visibility.show_for_all;
                };

                $scope.changeIndexable = function () {
                    last_indexable = $scope.entity.visibility.indexable;
                };

                $scope.showForm = function () {
                    $scope.visibility_data = angular.copy($scope.entity.visibility);
                    $scope.saved = false;
                    $scope.modal_form.addClass('active');
                };

                $scope.closeForm = function () {
                    if (!$scope.saved) {
                        $scope.entity.visibility = $scope.visibility_data;
                        $scope.$parent.currentVisibility = Visibility[$scope.visibility_data.value];
                    }
                    $scope.modal_form.removeClass('active');
                };

                $scope.saveVisibility = function () {
                    if ($scope.autosave) {
                        var deferred = $q.defer();
                        visibilityService.setVisibility(
                            $scope.entity.content_type_id,
                            $scope.entity.id,
                            $scope.entity.visibility
                        ).then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isLogicError(data.error) || $rootScope.isPermissionDenied(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Set visibility error",
                                            text: data.error.data.msg
                                        });
                                        deferred.reject();
                                    }
                                }
                                else {
                                    $scope.$emit("flash", {
                                        type: "success",
                                        title: "Success",
                                        text: "Visibility saved"
                                    });
                                    $scope.entity.visibility = angular.copy($scope.entity.visibility);
                                    $scope.saved = true;
                                    $scope.closeForm();
                                }
                            },
                            function () {
                                // general RPC error
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Server error",
                                    text: "Sorry, error occurred while submitting. Please try again later."
                                });
                                deferred.reject();
                            }
                        );

                        return deferred.promise;
                    }
                    else {
                        $scope.saved = true;
                    }

                    if ($scope.callback) {
                        $scope.callback();
                    }
                    $scope.closeForm();
                };

            }

            Controller.$inject = ['$scope', "$element"];

            return ({
                scope: scope,
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true
            });

        }]);

})();
