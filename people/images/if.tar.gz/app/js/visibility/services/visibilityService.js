(function(){
'use strict';
angular.module('visibility.services', []).
    value({
        Visibility: {
            0: "только мне",
            1: "выбранным пользователям",
            2: "друзьям",
            3: "друзьям моих друзей",
            4: "всем"
            //0: "Only me",
            //1: "Specified users",
            //2: "Friends",
            //3: "Friends of my friends",
            //4: "Everyone"
        },
        VisibilityTypes: {
            OWNER: 0,
            LIST: 1,
            FRIENDS_1C: 2,
            FRIENDS_2C: 3,
            ALL: 4
        }
    }).
    service('visibilityService', ['$rootScope', 'Visibility', 'jsonRPC', 'tagService', function ($rootScope, Visibility, jsonRPC, tagService) {

        this.setSectionVisibility = function (section_name, visibility) {

            var data = {
                visibility: visibility.visibility,
                section: section_name
            };

            return jsonRPC.request('profile_sections.set_visibility', data);
        };

        this.switchSectionVisibility = function (section, visibility) {
            this.setSectionVisibility(section, visibility).then(
                function (response) {
                    if (response.error) {
                        if ($rootScope.isLogicError(response.error)) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: response.error.data.msg
                            });
                        }
                        else if($rootScope.isPermissionDenied(response.error)){
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: "Недостаточно прав для установки этого уровня видимости"
                            });
                        }
                        else{
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: "Неизвестная ошибка"
                            });
                        }
                    }
                    else {
                        $rootScope.$emit("flash", {
                            type: "success",
                            title: "Готово",
                            text: "Видимость раздела изменена"
                        });
                    }

                },
                function () {
                    $rootScope.$emit("flash", {
                        type: "error",
                        title: "Unable to set section visibility"
                    });
                }
            );

        };
        // Converts from select2 json data value
        // to server-side readable value
        this.convertToRPCData = function (visibility) {
            var v = {};
            if (visibility) {
                v.value = visibility.value;
                v.users = angular.copy(visibility.users);
                v.tags = angular.copy(tagService.convertTagsToRPCData(visibility.friendship_tags));
                v.show_for_all = angular.copy(visibility.show_for_all);
                v.indexable = angular.copy(visibility.indexable);
            }
            return v;
        };

        //this.getVisibilitySelector = function () {
        //
        //    return {
        //        placeholder: "Set visibility",
        //        query: function (query) {
        //            var data = {results: []};
        //            angular.forEach(Visibility, function (title, id) {
        //                data.results.push({id: parseInt(id), text: title});
        //            });
        //            query.callback(data);
        //        },
        //        dropdownCssClass: "bigdrop"
        //    };
        //};

        this.checkEventsViewable = function (eventIDs) {
            var eventIDList = (Object.prototype.toString.call(eventIDs) === '[object Array]') ? eventIDs : [eventIDs];
            return jsonRPC.request('visibility.check_events_viewable', {event_id_list: eventIDList});
        };

        this.checkPlacesViewable = function (placeIDs) {
            var placeIDList = (Object.prototype.toString.call(placeIDs) === '[object Array]') ? placeIDs : [placeIDs];
            return jsonRPC.request('visibility.check_places_viewable', {place_id_list: placeIDList});
        };

        this.setVisibility = function (content_type_id, content_id, visibility) {

            var data = {
                content_type_id: content_type_id,
                content_id: content_id,
                visibility: visibility
            };

            return jsonRPC.request('visibility.set_visibility', data);
        };

    }]);

})();