(function(){
angular.module('favorites.services', []).
service('favoritesService',['$rootScope', 'jsonRPC','jqPaginationSettings', function($rootScope, jsonRPC, jqPaginationSettings){
    
    function onError(msg) {
        $rootScope.$emit("flash", {
            type: "error",
            title: "Error",
            text: msg || "Request failed, try again later."
        });
    }

    return {
        getFavorites: function(page){
            var data = {
                page: page,
                page_size: jqPaginationSettings.limit,
                with_total: true
            };

            console.log("get favorites");
            return jsonRPC.request('favorites.get_favorites', data);
        },
        addFavorite: function (item) {
            var data = {            
                place_id: item.id
            };
            
            return jsonRPC.request('favorites.add_favorite', data).then(function(data){
                if (data.error) {
                    if ($rootScope.isLogicError(data.error)) {
                        onError(data.error.data.msg);
                    }
                } else {
                    item.is_favorite = true;
                }
            });
        },
        removeFavorite: function (item) {
            var data = {
                place_id: item.id
            };
            return jsonRPC.request('favorites.remove_favorite', data).then(function(data){
                if (data.error) {
                    if ($rootScope.isLogicError(data.error)) {
                        onError(data.error.data.msg);
                    }
                } else {
                    $rootScope.$emit('event:favorite.removed', item);
                    item.is_favorite = false;
                }
            });
        },
        toggleFavorite: function (item) {
            return (item.is_favorite) ? this.removeFavorite(item) : this.addFavorite(item);
        }
    };
    
}]).factory("toggleFavorite", ["favoritesService", function (favoritesService) {
        return function () {
            return favoritesService.toggleFavorite(this);
        };
    }]);

})();