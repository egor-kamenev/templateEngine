(function () {
    'use strict';

    angular.module('app.controllers.favoritesctrl', ['app']).controller('FavoritesCtrl', [
        '$scope', '$rootScope', '$q', 'favoritesService', 'jqPaginationSettings', '$stateParams',
        function ($scope, $rootScope, $q, favoritesService, jqPaginationSettings, $stateParams) {
            $scope.userFavorites = [];
            $scope.loaded = false;
            $scope.limit = jqPaginationSettings.limit;
            $scope.total = 0;
            $scope.maxPage = 0;

            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            function sortFavotites(favList) {
                return _.sortBy(favList, function (e) {
                    return e.name;
                });
            }

            function pushFavorite(fav) {
                if (!_.contains(_.pluck($scope.userFavorites, 'place_id'), fav.place_id)) {
                    $scope.userFavorites.push(fav);
                    $scope.userFavorites = sortFavotites($scope.userFavorites);
                    $scope.$apply();
                }
            }

            function delFavorite(fav) {
                if (_.contains(_.pluck($scope.userFavorites, 'place_id'), fav.place_id)) {
                    $scope.userFavorites = _.reject($scope.userFavorites, function (e) {
                        return e.place_id === fav.place_id;
                    });
                    $scope.$apply();
                }
            }

            function reloadFavorites() {
                $rootScope.loading = true;
                favoritesService.getFavorites($scope.currentPage).then(
                    function (data) {

                        $scope.userFavorites = [];

                        if (!data.result.items.length) {
                            $scope.loaded = true;
                            $rootScope.loading = false;
                            return;
                        }

                        var favorites = sortFavotites(data.result.items);
                        $scope.total = data.result.total;
                        $scope.loaded = true;

                        if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);

                        $rootScope.user.userFavorites = favorites;
                        $scope.userFavorites = favorites;

                        console.log("$rootScope.user.userFavorites", $rootScope.user.userFavorites);

                        //listenSocket();
                        $rootScope.loading = false;
                    },
                    function (error) {
                        console.log('Error fetch data', error);
                        $rootScope.loading = false;
                    }
                );
            }

            // T964
            // var listenSocket = function () {
            //     $scope.channelName = channelService.getChannelName('favorites');
            //     channelService.subscribe($scope.channelName).sync();
            //     socketio.getSocket().on($scope.channelName, updateData);
            // };

            // $scope.$on('$destroy', function () {
            //     console.log('destroy!');
            //     if ($scope.channelName) {
            //         channelService.unsubscribe($scope.channelName).sync();
            //     }
            // });

            // var updateData = function (data) {
            //     console.log('update data', data);
            //     if (data.code === StreamCode.CREATED) {
            //         pushFavorite(data.content);
            //     } else if (data.code === StreamCode.DELETED) {
            //         delFavorite(data.content);
            //     }
            // };

            //$scope.removeFavorite = function(place_id) {

            //    favoritesService.removeFavorite(place_id).then(
            //        function(data){
            //
            //            if (data.error){
            //                if ($scope.isLogicError(data.error)) {
            //                    $scope.$emit("flash", {
            //                        type: "error",
            //                        title: "Unable to remove contact",
            //                        text: data.error.data.msg
            //                    });
            //                }
            //            } else {
            //                $scope.$emit("flash", {
            //                    type: "success",
            //                    title: "Done",
            //                    text: "Removed from favorites"
            //                });
            //                console.log(place_id);
            //                console.log($rootScope.user.userFavorites);
            //                //$rootScope.user.userFavorites = data.result.places;
            //            }
            //            $scope.userFavorites = $rootScope.user.userFavorites;
            //
            //        },
            //        function() {
            //            $scope.$emit("flash", {
            //                type: "error",
            //                title: "Server error",
            //                text: "Sorry, error occurred while submitting. Please try again later."
            //            });

            //        }
            //    );
            //};

            $scope.$onRootScope('event:favorite.removed', function (e, favPlace) {
                //console.log('!!!!', favPlace);
                //var removedFav = _.find($scope.userFavorites, function(f){
                //    return angular.equals(f.place, favPlace);
                //});
                //console.log('@@@', removedFav);
                //console.log($scope.userFavorites);

                //if(angular.isDefined(removedFav)){
                //    $scope.userFavorites.splice(_.indexOf($scope.userFavorites, removedFav), 1);
                //}
                $scope.userFavorites = _.filter($scope.userFavorites, function (el) {
                    return el.place_id !== favPlace.id;
                });
                $rootScope.user.userFavorites = angular.copy($scope.userFavorites);

            });

            reloadFavorites();
        }]);

})();
