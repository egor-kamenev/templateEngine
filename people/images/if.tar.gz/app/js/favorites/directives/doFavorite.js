(function(){
angular.module('favorites.doFavorite', ['app']).
    directive('doFavorite', ['$rootScope', 'favoritesService', '$parse', function ($rootScope, favoritesService, $parse) {
        var loading = false;
        return {
            restrict: "AC",
            scope: false,
            link: function (scope, element, attrs) {
                var entity = $parse(attrs.doFavorite)(scope);
                if (!entity) {
                    console.error("cant get item");
                    return;
                }

                function setLoadingState() {
                    element.addClass("loading");
                    loading = true;
                }

                function resetLoadingState() {
                    element.removeClass("loading");
                    loading = false;
                }

                element.bind('click', function () {
                    if ($rootScope.user.authenticated) {
                        if (!loading) {
                            setLoadingState();
                            favoritesService.toggleFavorite(entity).then(resetLoadingState, resetLoadingState);
                        } else {
                            $rootScope.$emit("flash", {
                                type: "info",
                                title: "Избранные",
                                text: "Пожалуйста, подождите завершения предыдущей операции"
                            });
                        }
                    }
                });
            }
        };
    }]);

})();