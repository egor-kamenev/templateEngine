(function(){
angular.module('places.placeCheckInOut', []).
    directive('placeCheckInOut', ['$rootScope', 'checkInOutService', '$parse', 'userService',
    function ($rootScope, checkInOutService, $parse, userService) {
        var loading = false;
        return {
            restrict: "AC",
            scope: false,
             template: '' +
               '<button data-protractor-id="placeCheckInOut" class="button checkin button--secondary" type="button">' +
               '[[btnText]]<span class="hint" data-ng-if="!entity.visitors.length">Пока участников нет, будь первым!</span>' +
               '</button>',
            controller: function($scope){

                $scope.updateElement = function(user) {
                    var currentUser = $rootScope.user || user;
                    if (currentUser.last_location && currentUser.last_location.place && currentUser.last_location.place.id === $scope.entity.id){
                        $scope.btnText = 'Чекаут';
                    }
                    else {
                        $scope.btnText = 'Чекин';
                    }
                };

                userService.getUser().then(function(user){
                    $scope.updateElement(user);
                });
            },
            link: function(scope, element, attrs) {
                scope.entity = $parse(attrs.placeCheckInOut)(scope);

                if (!scope.entity) {
                    console.error("cant get item");
                    return; 
                }

                function setLoadingState() {
                    element.addClass("loading");
                    loading = true;
                }

                function resetLoadingState() {
                    element.removeClass("loading");
                    loading = false;
                    scope.updateElement();
                }
                
                element.bind('click', function () {

                    userService.getUser().then(function(user){
                        if(!user.authenticated){
                            $rootScope.$emit('needLogin');
                            return;
                        }

                        if (!loading) {
                            setLoadingState();
                            if ($rootScope.user.authenticated) {
                                checkInOutService.placeHandler(scope.entity).then(resetLoadingState,resetLoadingState);
                            }
                        } else {
                            $rootScope.$emit("flash", {
                                type: "info",
                                title: "Нравится",
                                text: "Пожалуйста, подождите завершения предыдущей операции"
                            });
                        }
                    });



                });

            }

        };

    }]);

})();
