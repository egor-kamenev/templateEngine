(function(){
angular.module('places.hostEvent.directive', []).
    directive('hostEvent', ['verifiedEmailRequired', 'placesService', function (verifiedEmailRequired, placesService) {
        return {
            scope:{
                place: '='
            },
            restrict: "AE",
            link: function (scope, element, attrs) {
                element.bind(
                    'click', 
                    verifiedEmailRequired(function () {
                        placesService.copyToClipboard(scope.place, true);
                    })
                );
            }
        };
    }]);

})();
