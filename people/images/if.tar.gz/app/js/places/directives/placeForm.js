(function () {
    'use strict';
    angular.module('places.placeForm', []).directive('placeForm', [
        '$rootScope', '$state', '$q', '$compile', 'tagService', 'visibilityService', 'mapService', 'mapSettings',
        'placesService', 'leafletData', 'userService', 'settingsService', '$timeout', 'userLocationService', 'Visibility',
        'permissionRequired',
        function ($rootScope, $state, $q, $compile, tagService, visibilityService, mapService, mapSettings,
                  placesService, leafletData, userService, settingsService, $timeout, userLocationService, Visibility,
                  permissionRequired) {
            return {
                restrict: "AE",
                replace: true,
                templateUrl: '/static/partials/places/place_form.html',
                scope: {
                    place: '=',
                    visible: '=',
                    userLocation: '=',
                    formData: '=',
                    editMode: '=',
                    standalone: '='
                },
                link: function postLink(scope, elem, attrs, controller) {

                    scope.placeform = {
                        country: '',
                        state: '',
                        city: '',
                        formatted_address: '',
                        tags: [],
                        visibility: {
                            value: 4,
                            show_for_all: true,
                            indexable: true
                        }
                    };

                    //function invalidateMapSize() {
                    //    leafletData.getMap(controller.mapID).then(function (map) {
                    //        map.invalidateSize();
                    //    });
                    //}
                    //
                    /*
                     var maxWaitIterations = 1000;
                     function recursiveWaitForElementVisible(selector, callback, element, iteration) {
                     iteration = iteration || 1;

                     var node = element && element.length > 0 ? element : $(selector);
                     if (node.is(':visible')) {
                     preventLeafletDestroyEventHandler();
                     return callback();
                     }

                     if (iteration > maxWaitIterations) {
                     return;
                     }

                     $timeout(function () {
                     recursiveWaitForElementVisible(selector, callback, node, ++iteration);
                     }, 10);
                     }
                     */

                    //hack to prevent firing of $destroy event of leaflet-directive twice
                    function preventLeafletDestroyEventHandler() {
                        angular.element(document).ready(function () {
                            var mapField = angular.element(elem).find('.map-field');
                            if (mapField) {
                                var mapFieldScope = mapField.scope();
                                if (mapFieldScope) {
                                    mapFieldScope.$on('$destroy', function () {
                                        mapFieldScope.$$destroyed = true;
                                    });
                                }
                            }
                        });
                    }

                    function watchForMapInit() {
                        if (!userService.isAuthenticated()) {
                            var watchForAuth = scope.$watch(userService.isAuthenticated, function (value) {
                                if (value) {
                                    watchForAuth();
                                    watchForMapInit();
                                }
                            });
                        }

                        //if (!userService.hasPerm('events.add_userplace')) {
                        //
                        //}
                        /*
                         var mapSelector = '#' + controller.mapID;
                         if (scope.mapInitDone === true) {
                         recursiveWaitForElementVisible(mapSelector, invalidateMapSize);
                         }
                         else {
                         var mapInitDoneWatcher = scope.$watch('mapInitDone', function (value) {
                         if (value === true) {
                         recursiveWaitForElementVisible(mapSelector, invalidateMapSize);
                         mapInitDoneWatcher();
                         }
                         });
                         }*/
                    }

                    var mapInitDoneWatch = scope.$watch('mapInitDone', function (value) {
                        if (value === true) {
                            leafletData.getMap(controller.mapID).then(function (map) {
                                L.control.locate(angular.extend(mapSettings.DefaultLocateControlSettings, {
                                    OnLocationError: userLocationService.showWarningIfGeolocationNotAvailable
                                })).addTo(map);

                                if (scope.place) {

                                    var lat = scope.place.lat || scope.place.latitude,
                                        lng = scope.place.lng || scope.place.longitude;

                                    scope.createPlaceMarker(lat, lng);
                                    scope.showPlaceMarkerPopup();
                                    scope.center = {
                                        lat: lat,
                                        lng: lng,
                                        zoom: mapSettings.DefaultPlaceZoom
                                    };

                                }
                                else {
                                    mapService.getDefaultLocation().then(function (coordinates) {

                                        if (coordinates) {
                                            scope.center = {
                                                lat: coordinates.center.latitude,
                                                lng: coordinates.center.longitude,
                                                zoom: mapSettings.DefaultPlaceZoom
                                            };
                                        }
                                        else {
                                            scope.center = null;
                                        }
                                    });
                                }
                            });
                            mapInitDoneWatch();
                        }

                        scope.$watch('center', function (value) {
                            if (value) {
                                leafletData.getMap(controller.mapID).then(function (map) {
                                    var lat = value.lat || value.latitude,
                                        lng = value.lng || value.longitude;
                                    var zoom = value.zoom || 8;
                                    map.setView([lat, lng], zoom, {reset: true});
                                });
                            }
                        });
                    });

                    controller.initializeMap(scope.editMode);

                    if (scope.editMode) {
                        var stopWatch = scope.$watch('formData', function (coordinates) {
                            if (coordinates) {
                                scope.center = {
                                    lat: coordinates.lat || coordinates.latitude,
                                    lng: coordinates.lng || coordinates.longitude,
                                    zoom: mapSettings.DefaultPlaceZoom
                                };
                            }

                            stopWatch();
                        });
                    }


                    if (scope.visible !== false) {
                        watchForMapInit();
                    }

                    scope.$watch('visible', function (becomesVisible) {
                        if (becomesVisible) {
                            // If marker was moved - set it back to place
                            var p = scope.place || mapService.getSelectedPlace();
                            if (angular.isDefined(p) && angular.isObject(p) && p.geometry && p.geometry.center) {
                                scope.createPlaceMarker(p.geometry.center.latitude, p.geometry.center.longitude);
                            }
                            if (scope.isEditMode) {
                                scope.placeform = scope.formData;
                            }
                            watchForMapInit();
                        }
                    });

                    var addrTypeahead = angular.element('#id_map_geocode').typeahead(
                        {
                            hint: true,
                            highlight: true,
                            minLength: 1
                        },
                        {
                            displayKey: 'text',
                            source: function (query, cb) {
                                var data = [];

                                if (query) {

                                    placesService.getAddressSuggest(query).then(function (result) {
                                        scope.processAddressSuggestResult(result, data);
                                        cb(data);
                                    });

                                }
                                // empty query
                                else {
                                    cb(data);
                                }
                            }
                        }
                    );

                    leafletData.getMap(controller.mapID).then(function () {
                        preventLeafletDestroyEventHandler();
                    });

                    addrTypeahead.on('typeahead:selected', function (e, item) {
                        scope.$apply(scope.addressSearch = item);
                    });
                },
                controller: function ($scope) {
                    $scope.mapInitDone = false;
                    $scope.placeDetectionInProgress = false;
                    $scope.placeDetectionError = false;
                    $scope.tagsEditor = tagService.getTagSelector('place_tags');

                    //Map's settings define
                    $scope.mapMarkers = {};
                    $scope.controls = {};
                    $scope.leafletDefaults = mapSettings.LeafletDefaults;

                    $scope.layers = {baselayers: {}};
                    angular.extend($scope.layers.baselayers, mapSettings.DefaultMapBaselayer);

                    $scope.currentVisibility = '';

                    this.mapID = 'place-form-map';

                    /*var markerPopupHtml =
                     '<div class="mapVenueTooltip blue 5 above">' +
                     '<span class="tooltipCarat"></span>' +
                     '<div class="venueBlock">' +
                     '<div class="venueDetails details-wide">' +
                     '<div class="venueName"><a href="">[[place.formatted_address]]</a></div>' +
                     '<div class="venueAddressData">' +
                     '<div class="venueData">' +
                     '</div>' +
                     '</div>' +
                     '</div>' +
                     '</div>' +
                     '<span class="reasonMsg">' +
                     '</span>' +
                     '</div>';*/

                    $scope.$on('changeVisibility', function (event, visibility) {
                        $scope.currentVisibility = Visibility[visibility.value];
                    });

                    var mapPlaceID = -1,
                        self = this;
                    var initialPlace = angular.copy($scope.place);

                    this.initializeMap = function (isEditMode) {
                        var map = mapService.getDefaultMap(mapSettings.DefaultMapLayers, null, false);
                        angular.extend($scope, map);

                        // Form data is provided when we edit an existing place.
                        if (isEditMode) {
                            $scope.placeform = $scope.formData;
                            $scope.place_lat = $scope.place.geometry ? $scope.place.geometry.center.latitude : $scope.place.latitude;
                            $scope.place_lng = $scope.place.geometry ? $scope.place.geometry.center.longitude : $scope.place.longitude;
                            $scope.placeform.formatted_address = $scope.place.address;
                        }

                        if ($scope.userLocation) {
                            $scope.userMarker = {
                                lat: $scope.userLocation.latitude,
                                lng: $scope.userLocation.longitude,
                                focus: false,
                                draggable: false,
                                icon: mapSettings.MarkerUserLocation
                            };
                            $scope.mapMarkers.userMarker = $scope.userMarker;
                        }

                        $scope.mapInitDone = true;
                    };

                    $scope.canGoBack = function () {
                        return $state.previous && $state.previous.name;
                    };

                    // reset form (fix T994)
                    $scope.resetPlaceForm = function() {
                        $scope.placeform.name = '';
                        $scope.placeform.description = '';
                        $scope.placeform.driveway = '';
                        $scope.placeform.tags = [];
                        $scope.placeform.age_restriction = '';
                    };

                    $scope.closeForm = function () {
                        //mapService.resetSelectedPlace();
                        //$scope.removePlaceMarker();
                        if ($scope.isEditMode || !$scope.standalone) {
                            $scope.$emit('closePlaceForm', null);
                            $scope.visible = false; // uncommented for T994
                            $scope.resetPlaceForm();
                            $scope.resetPlaceMarker();
                        }
                        else {
                            $state.go($state.previous.name, $state.previous.params);
                        }
                    };

                    $scope.checkLatLng = function () {

                        var newLat = parseFloat($scope.place_lat),
                            newLng = parseFloat($scope.place_lng),
                            latCtrl = $scope.placeForm.latitude,
                            lngCtrl = $scope.placeForm.longitude,
                            ret = true;

                        if (isNaN(newLat) || newLat < -90 || newLat > 90) {
                            latCtrl.$setValidity("invalid", false);
                            ret = false;
                        }
                        else {
                            latCtrl.$setValidity("invalid", true);
                        }

                        if (isNaN(newLng) || newLng < -180 || newLng > 180) {
                            lngCtrl.$setValidity("invalid", false);
                            ret = false;
                        }
                        else {
                            lngCtrl.$setValidity("invalid", true);
                        }
                        return ret;

                    };

                    $scope.resetPlaceMarker = function () {
                        if (initialPlace && !angular.equals($scope.place, initialPlace)) {
                            $scope.place = angular.copy(initialPlace);

                            var lat = $scope.place.latitude || $scope.place.lat;
                            var lng = $scope.place.longitude || $scope.place.lng;

                            $scope.createPlaceMarker(lat, lng);
                        }
                        else {
                            initialPlace = null;
                            $scope.removePlaceMarker();
                        }
                    };

                    $scope.removePlaceMarker = function () {

                        $scope.place_lat = null;
                        $scope.place_lng = null;
                        $scope.place = null;

                        $scope.placeform.formatted_address = null;
                        $scope.placeform.country = null;
                        $scope.placeform.state = null;
                        $scope.placeform.city = null;

                        delete $scope.mapMarkers.placeMarker;

                        $scope.placeForm.latitude.$setPristine();
                        $scope.placeForm.longitude.$setPristine();
                    };

                    $scope.updateAddress = function (lat, lng, skipUpdate) {
                        if (lat && lng && !skipUpdate) {
                            $scope.place_lat = lat;
                            $scope.place_lng = lng;
                        }

                        $scope.placeDetectionInProgress = true;
                        $scope.placeDetectionError = false;

                        placesService.getGeoPlace(lat, lng).then(function (place) {

                            $scope.placeDetectionInProgress = false;
                            $scope.placeDetectionError = !place;

                            $scope.place = place;
                            if (place) {
                                $scope.placeform.formatted_address = place.formatted_address;
                                $scope.placeform.country = place.address.country;
                                $scope.placeform.state = place.address.state;
                                $scope.placeform.city = place.address.city;
                            }
                            else {
                                $scope.removePlaceMarker();
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Ошибка определения адреса места, повторите попытку позже"
                                });
                            }
                        });
                    };

                    $scope.createPlaceMarker = function (lat, lng) {

                        $scope.removePlaceMarker();

                        $scope.mapMarkers.placeMarker = {
                            lat: lat,
                            lng: lng,
                            focus: false,
                            draggable: true,
                            icon: angular.extend({}, mapSettings.MarkerPlace, {className: "pin pin--new"})
                        };

                        $scope.updateAddress(lat, lng);
                    };

                    $scope.changeLatLng = function () {
                        // Timeout here helps to reduce the number
                        // of geocoder requests as user types
                        // longitude or latitude
                        clearTimeout($scope.movePlaceMarkerTimeout);
                        $scope.movePlaceMarkerTimeout = setTimeout(function () {
                            $scope.$apply(
                                $scope.movePlaceMarker(true)
                            );
                        }, 500);
                    };

                    $scope.movePlaceMarker = function (skipUpdate) {

                        var newLat = parseFloat($scope.place_lat);
                        var newLng = parseFloat($scope.place_lng);

                        if (!$scope.checkLatLng()) {
                            return;
                        }

                        var m = $scope.mapMarkers.placeMarker;
                        if (angular.isDefined(m)) {
                            m.lat = newLat;
                            m.lng = newLng;
                        }

                        $scope.updateAddress(newLat, newLng, skipUpdate);

                    };


                    //$scope.updateLocation = function (force, moveCenter) {
                    //    mapService.getUpdatedUserLocation(force).then(
                    //        function (location) {
                    //            if (userService.isGeoLocationDetected()) {
                    //                if (location) {
                    //                    var centeredOnLocation = $scope.center && ($scope.center.lat == location.lat) && ($scope.center.lng == location.lng);
                    //
                    //                    if (moveCenter && !centeredOnLocation) {
                    //                        leafletData.getMap(mapID).then(function (map) {
                    //                            map.panTo(L.latLng(location.lat, location.lng));
                    //                        });
                    //                    }
                    //                    $scope.userMarker.lat = location.lat;
                    //                    $scope.userMarker.lng = location.lng;
                    //                }
                    //            }
                    //        })
                    //};

                    $scope.showPlaceMarkerPopup = function () {

                        var unreg_watch = $scope.$watch('mapMarkers', function (new_markers) {

                            if (angular.isDefined(new_markers.placeMarker)) {
                                leafletData.getMarkers(self.mapID).then(function (markers) {

                                    var m = markers.placeMarker;
                                    if (angular.isDefined(m)) {
                                        var popupHTML = $compile(mapSettings.MapPopupPlaceAddress)($scope);
                                        m.bindPopup(popupHTML[0]).openPopup();
                                    }
                                });

                            }
                            unreg_watch();
                        });

                    };

                    $scope.$on('leafletDirectiveMap.dblclick', function (event, e) {
                        var pos = e.leafletEvent.latlng;
                        $scope.createPlaceMarker(pos.lat, pos.lng);
                        $scope.showPlaceMarkerPopup();
                    });

                    $scope.$on('leafletDirectiveMarker.dragend', function (ze, e) {
                        var pos = e.leafletEvent.target.getLatLng();
                        $scope.updateAddress(pos.lat, pos.lng);
                        $scope.showPlaceMarkerPopup();
                        $scope.checkLatLng();

                    });

                    $scope.isRequiredField = function (f) {
                        return $rootScope.isRequiredField(f);
                    };

                    $scope.hasCustomError = function (f, errorCode) {
                        return $rootScope.hasCustomError(f, errorCode);
                    };

                    $scope.hasError = function (f) {
                        return $rootScope.hasError(f);
                    };

                    $scope.submitPlace = permissionRequired(
                        $scope.editMode === true ? 'events.change_userplace' : 'events.add_userplace',
                    function () {
                        if (!$scope.place) {
                            return {
                                map: 'selectPlace'
                            };
                        }

                        // Check tags
                        if (!(angular.isArray($scope.placeform.tags) && $scope.placeform.tags.length > 0)) {
                            return {
                                tags: 'setTags'
                            };
                        }

                        // Send to server
                        var deferred = $q.defer();

                        var data = angular.copy($scope.placeform);
                        data.point = {
                            lat: parseFloat($scope.place_lat),
                            lng: parseFloat($scope.place_lng)
                        };

                        data.visibility = visibilityService.convertToRPCData(data.visibility);
                        data.tags = tagService.convertTagsToRPCData(data.tags);


                        var method = $scope.editMode === true ?
                            placesService.editPlace($scope.placeform.id, data) :
                            placesService.addPlace(data);

                        method.then(
                            function (data) {
                                if (data.error) {
                                    if ($rootScope.isFormError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка сохранения места",
                                            text: data.error.data.message
                                        });
                                        deferred.reject(data.error.data);
                                    }
                                    else if ($rootScope.isLogicError(data.error)) {
                                        $scope.$emit("flash", {
                                            type: "error",
                                            title: "Ошибка сохранения места",
                                            text: data.error.data.message
                                        });
                                        deferred.reject();
                                    }
                                    else{
                                        deferred.reject();
                                    }
                                }
                                else {
                                    // Server returns new created place in response
                                    var new_place = data.result;

                                    // Everything is ok
                                    $scope.placeform.name = $scope.placeform.description = $scope.placeform.driveway = '';
                                    $scope.placeform.visibility = '';
                                    $scope.placeform.tags = '';

                                    $scope.$emit("flash", {
                                        type: "success",
                                        title: "Готово",
                                        text: "Место сохранено"
                                    });

                                    $scope.removePlaceMarker();
                                    mapService.resetSelectedPlace();
                                    if ($scope.editMode) {
                                        placesService.getPlaceByID($scope.placeform.id).then(function (data) {
                                            deferred.resolve();
                                            var alias = data.result.alias;
                                            $state.go('place.wall', {place_alias: alias}, {reload: true});
                                        });
                                    }
                                    else {
                                        if ($scope.standalone) {
                                            $state.go('place.wall', {place_alias: new_place.alias});
                                        }
                                        else {
                                            $scope.closeForm();
                                            $scope.place = new_place;
                                        }
                                        deferred.resolve();
                                    }


                                }
                            },
                            function () {
                                // general RPC error
                                deferred.reject();
                            }
                        );
                        return deferred.promise;
                    });

                    $scope.processAddressSuggestResult = function (results, data) {
                        if (results && angular.isArray(results)) {
                            angular.forEach(results, function (place) {
                                var lat = place.geometry.center.latitude;
                                var lng = place.geometry.center.longitude;
                                var bounds = place.geometry.bounds || placesService.createPlaceBounds(lat, lng);

                                data.push({
                                    'text': place.formatted_address,
                                    'latitude': lat,
                                    'longitude': lng,
                                    'bounds': bounds
                                });
                            });
                        }
                    };

                    $scope.placeSelector = {
                        //tags: true,
                        allowClear: true,
                        multiple: false,
                        maximumSelectionSize: 1,
                        closeOnSelect: true,
                        query: function (query) {
                            var data = {
                                results: []
                            };
                            if (query.term !== "") {
                                placesService.getAddressSuggest(query.term).then(function (result) {
                                    $scope.processAddressSuggestResult(result, data.results);
                                    query.callback(data);
                                });
                            }
                            // empty query
                            else {
                                query.callback(data);
                            }
                        }
                    };

                    $scope.$watch('place', function (v) {
                        if (v && angular.isObject(v)) {
                            $scope.addressSearch = {
                                id: mapPlaceID,
                                text: v.formatted_address
                            };

                            angular.element('#id_map_geocode').typeahead('val', v.formatted_address);
                        }
                        else {
                            angular.element('#id_map_geocode').typeahead('val', '');
                        }
                    });

                    $scope.$watch('addressSearch', function (v) {
                        if (v && angular.isObject(v)) {
                            if (v.id != mapPlaceID) {
                                $scope.createPlaceMarker(v.latitude, v.longitude);
                                $scope.showPlaceMarkerPopup();
                            }
                        }
                    });

                    $scope.$on('$destroy', function (event) {
                        event.preventDefault();
                    });

                    settingsService.get(function (settings) {
                        if (!$scope.placeform) {
                            $scope.placeform = {};
                        }

                        if ($scope.standalone) {
                            $scope.placeform.age_restriction = settings.DEFAULT_AGE_RESTRICTION;
                        }

                        $scope.ageRestrictions = settings.ALL_AGE_RESTRICTIONS;
                    });
                }
            };
        }
    ]);

})();
