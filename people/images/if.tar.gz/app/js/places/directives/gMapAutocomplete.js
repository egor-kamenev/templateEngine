(function(){
angular.module('places.directives', []).directive('gMapAutocomplete', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, el, attrs) {
            attrs.$observe('gMapAutocomplete', function () {
                var map = $parse(attrs.gMapAutocomplete)(scope);
                var autocomplete = new google.maps.places.Autocomplete(el[0], {types: ['geocode']});
                var callback = $parse(attrs.gMapAutocompleteCallback);
                autocomplete.bindTo('bounds', map);
                google.maps.event.addListener(autocomplete, 'place_changed', function () {
                    var place = autocomplete.getPlace();
                    callback(scope, {place: place});
                });
            });
        }
    };
}]);

})();