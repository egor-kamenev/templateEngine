(function () {
    'use strict';
    angular.module('places.saveuserplace', []).directive('saveUserPlace', [
        '$q', '$state', '$rootScope', 'jsonRPC', 'placesService', 'userService', 'visibilityService', 'userLocationService',
        function ($q, $state, $rootScope, jsonRPC, placesService, userService, visibilityService, userLocationService) {

            var scope = {
                entity: '='
            };

            function link(scope, element, attributes, controller) {
            }

            function Controller($scope) {
                // mock visibility entity object
                $scope.visibilityEntity = {};
                $scope.currentPlace = $scope.entity.last_location;

                $scope.$watch('entity.isUserLocationFormOpen', function (value) {
                    if (value) {
                        $scope.entity.isUserLocationFormOpen = false;
                        if ($rootScope.hasPerm('users.add_userlocationhistory')) {
                            $scope.openUserPlaceDialog();
                            return;
                        }

                        $scope.$emit('checkEmailConfirmation', {
                            permission: 'users.add_userlocationhistory',
                            warningMessage: 'У вас недостаточно прав для создания сохранения местоположения'
                        });
                    }
                });

                userLocationService.getUserLocation().then(
                    function (data) {
                        if (data) {
                            $scope.userLocation = data;
                            $scope.mapMarkers = {
                                'userMarker': {
                                    lat: $scope.userLocation.latitude,
                                    lng: $scope.userLocation.longitude,
                                    message: "Это Вы",
                                    focus: false,
                                    draggable: false,
                                    icon: {
                                        type: 'awesomeMarker',
                                        icon: 'fa-users',
                                        markerColor: 'green'
                                    }
                                }
                            };
                        }
                    }
                );

                $scope.userPlaceSelector = placesService.getPlaceSelectorWithFavorites($scope.entity.username);

                function saveLocationHistory(place_id) {
                    // current location logging
                    userLocationService.addUserLocation(place_id, visibilityService.convertToRPCData($scope.visibilityEntity.visibility)).then(
                        function (data) {
                            if (data.error) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Location log error",
                                    text: data.error
                                });
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Your location saved successfully"
                                });

                                $scope.$emit('reloadUserData', function () {
                                });

                                $scope.userPlaceFormClose();
                            }
                        },
                        function (data) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Location log error",
                                text: data
                            });
                        }
                    );
                }

                var addUserPlace = function (latitude, longitude) {
                    return placesService.getGeoPlace(latitude, longitude)
                        .then(function (place) {
                            if (place) {
                                $scope.newUserPlace = {
                                    country: place.country,
                                    state: place.state,
                                    city: place.city,
                                    formatted_address: place.formatted_address
                                };
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: "Ошибка определения текущего местоположения"
                                });
                                return $q.reject(null);
                            }
                        }
                    );
                };

                $scope.openUserPlaceDialog = function () {
                    var latitude;
                    var longitude;

                    if ($scope.mapMarkers && $scope.mapMarkers.userMarker &&
                        $scope.mapMarkers.userMarker.lat && $scope.mapMarkers.userMarker.lng) {
                        latitude = $scope.mapMarkers.userMarker.lat;
                        longitude = $scope.mapMarkers.userMarker.lng;
                    }

                    if ((!latitude || !longitude) && userLocationService.geolocationAvailable) {
                        userLocationService.getUserLocation().then(function (location) {
                            addUserPlace(location.latitude, location.longitude).then(function () {
                                $scope.isUserLocationFormOpen = true;
                                reloadCurrentPlace();
                            });
                        });
                    }
                    else if (latitude && longitude) {
                        addUserPlace(latitude, longitude).then(function () {
                            $scope.isUserLocationFormOpen = true;
                            reloadCurrentPlace();
                        });
                    }
                    else {
                        //TODO: get default place location
                        $scope.isUserLocationFormOpen = true;
                        reloadCurrentPlace();
                    }
                };

                $scope.saveUserPlace = function () {
                    saveLocationHistory($scope.currentUserPlace.id);
                };

                $scope.userPlaceFormClose = function () {
                    $scope.currentUserPlace = null;
                    $scope.visibilityEntity = {};
                    $scope.isUserLocationFormOpen = false;
                };

                var reloadCurrentPlace = function () {
                    jsonRPC.request('users.get_last_location').
                        then(function (data) {
                            $scope.currentPlace = data.result;
                        },
                        function (error) {
                            console.log('users.get_last_location error ', error);
                        }
                    );
                };

                $scope.closeForm = function () {
                    $scope.isSelectPlace = false;
                };

                $scope.openPlaceForm = function () {
                    $scope.favPlace = $scope.currentPlace.id;
                    $scope.isSelectPlace = true;
                };

                $scope.hasPerm = function (perm) {
                    return $rootScope.hasPerm(perm);
                };

            }

            Controller.$inject = ['$scope'];


            return ({
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                scope: scope,
                templateUrl: '/static/partials/places/save_user_place.html'
            });
        }]);
})();
