(function(){
angular.module('places.services.cache', ['places.services.nominatim', 'places.services.nokia'])
    .service('cacheLocationService',
    [
        '$translate', '$cacheFactory', '$q',
        function ($translate, $cacheFactory, $q) {

            var cacheId = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });

            var maxLifetime = moment.duration(3, 'minutes').asMilliseconds();
            var coordsPrecision = 4;

            var cache = $cacheFactory(cacheId);

            function cacheObject(key, value) {
                console.log('added to cache', key, value, cache.info());
                cache.put(key, value === undefined ? null : value);
            }

            function getCached(key) {
                return cache.get(key);
            }

            function isActual(cachedTimestamp) {
                return !cachedTimestamp || (moment().valueOf() - cachedTimestamp) <= maxLifetime;
            }

            function roundParameterIfNeed(value) {
                var number = Number(value);
                if (!value || !angular.isNumber(number) || isNaN(number)) {
                    return value;
                }

                return number.toFixed(coordsPrecision);
            }

            this.get = function (source, context /* arguments */) {
                var key = null;
                var params = null;
                if (arguments.length > 1) {
                    params = Array.prototype.slice.call(arguments, 2);

                    if (params && params.length > 0) {
                        angular.forEach(params, function (item, key) {
                            params[key] = roundParameterIfNeed(item);
                        });
                    }

                    key = params.join(';') + $translate.use();
                }
                else {
                    key = source.toString();
                }

                var cachedObject = getCached(key);
                if (cachedObject && isActual(cachedObject.timestamp)) {
                    var deferred = $q.defer();
                    deferred.resolve(cachedObject.value);
                    return deferred.promise;
                }

                var obj = {
                    timestamp: moment().valueOf(),
                    value: null
                };

                if (angular.isFunction(source)) {
                    return source.apply(context, params).then(function (val) {
                        obj.value = val;
                        cacheObject(key, obj);

                        return val;
                    });
                }
                else {
                    obj.value = source;
                    cacheObject(key, obj);
                }

                return obj.value;
            };
        }
    ]);
})();