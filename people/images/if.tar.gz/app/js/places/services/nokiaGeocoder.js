(function () {
    'use strict';
    angular.module('places.services.nokia', []).constant('nokiaSettings', {
        USE_API: false,
        REVERSE_GEOCODER_URL: 'https://reverse.geocoder.cit.api.here.com/6.2/reversegeocode.json?prox={latitude},{longitude},1000&gen={gen}&mode=retrieveAddresses&app_id={app_id}&app_code={app_code}&language={language}&accept=application%2Fjson',
        FIND_PLACES_URL: 'https://places.cit.api.here.com/places/v1/discover/search/?app_id={app_id}&app_code={app_code}&Accept-Language={language}&size={limit}&q={query}&at=0,0&accept=application%2Fjson',
        SEARCH_PLACE_CENTER_URL: 'https://places.cit.api.here.com/places/v1/discover/search/?&app_id={app_id}&app_code={app_code}&Accept-Language={language}&q={query}&at={latitude},{longitude}&accept=application%2Fjson'
    }).factory('nokiaAPIGeocoder', [
        '$q', '$rootScope', '$translate', 'placesSettings', '$window', '$timeout', 'scriptsSettings', 'asyncScriptLoader',
        function ($q, $rootScope, $translate, placesSettings, $window, $timeout, scriptsSettings, asyncScriptLoader) {
            //var scriptLoadingIsInProgress = false;

            //function asyncLoadNokiaScripts(success) {
            //    $timeout(function () {
            //            var oScript = document.createElement("script");
            //            oScript.type = "text/javascript";
            //            oScript.src = document.location.protocol + "//js.api.here.com/se/2.5.3/jsl.js?blank=true";
            //
            //            if (!scriptLoadingIsInProgress) {
            //                scriptLoadingIsInProgress = true;
            //                document.getElementsByTagName("head")[0].appendChild(oScript);
            //            }
            //
            //            oScript.onload = function () {
            //                nokia.Features.load(
            //                    nokia.Features.getFeaturesFromMatrix(["placesdata"]),
            //                    function () {
            //                        console.log('here api loaded');
            //                        if (angular.isFunction(success)) {
            //                            success();
            //                        }
            //                    },
            //                    function (e) {
            //                        console.log('here api loaded failed', e);
            //                    },
            //                    null,
            //                    false
            //                );
            //            };
            //        },
            //        100
            //    );
            //}

            var initialized = false;

            function waitForNokiaInit(callback) {
                if ($window.nokia && $window.nokia.places) {
                    callback();
                }
                else {
                    $timeout(function () {
                        waitForNokiaInit(callback);
                    }, 10);
                }
            }

            function setAcceptLanguage() {
                var languageCode = null;
                var language = $translate.use();
                switch (language) {
                    case 'ru':
                        languageCode = 'ru-RU';
                        break;
                    case 'en':
                        //default:
                        languageCode = 'en-US';
                        break;

                }
                nokia.Settings.set("defaultLanguage", languageCode);
            }

            function loadNokiaApiFeatures() {
                nokia.Features.load(
                    nokia.Features.getFeaturesFromMatrix(["placesdata"]),
                    function () {
                        console.log('here api loaded');
                    },
                    function (e) {
                        console.log('here api loaded failed', e);
                    },
                    null,
                    false
                );
            }

            function initializeGeocoder() {
                var deferred = $q.defer();

                if (initialized) {
                    deferred.resolve(nokia);
                }
                else {
                    asyncScriptLoader.load(scriptsSettings.scripts.NOKIA_API, loadNokiaApiFeatures, true, function () {
                        return !!($window.nokia && $window.nokia.places);
                    }).then(function () {
                        if (initialized !== true) {
                            nokia.Settings.set("app_id", NOKIA_API_APP_ID);
                            nokia.Settings.set("app_code", NOKIA_API_APP_CODE);

                            // Use staging environment (remove the line for production environment)
                            nokia.Settings.set("serviceMode", "cit");

                            setAcceptLanguage();
                            initialized = true;
                            if (document.location.protocol == "https:") {
                                console.info("HACK HERE");
                                nokia.Settings.set("secureConnection", "force");

                                var hack_ssl_wrap = function (origin) {
                                    return function () {
                                        var res = origin.apply(this, arguments);
                                        res = res.replace("http:", "https:");
                                        console.info("NOKIA URL: ", res, origin);
                                        return res;
                                    };
                                };

                                var to_hack = [
                                    'getGeoCodeUrl',
                                    'getReverseGeoUrl',
                                    'getPlaceUrl',
                                    'getPlacesServerUrl',
                                    'getSearchUrl'
                                ];

                                for (var i = 0; i < to_hack.length; i++) {
                                    var func = to_hack[i];
                                    nokia.places.settings[func] = hack_ssl_wrap(nokia.places.settings[func]);
                                    console.info("HACKED: ", func);
                                }
                            }
                        }
                        deferred.resolve(nokia);
                    });
                }

                return deferred.promise;
            }

            $rootScope.$onRootScope("changedLanguage", function () {
                if (initialized) {
                    setAcceptLanguage();
                }
            });

            return {
                initializeGeocoder: initializeGeocoder,
                findPlaces: function (term, callback, limit) {
                    nokia.places.search.manager.findPlaces({
                        searchTerm: term,
                        limit: limit || placesSettings.MAX_SEARCH_RESULTS,
                        onComplete: function (data, status) {
                            if (angular.isFunction(callback)) {
                                callback(data, status);
                            }
                        }
                    });
                },
                reverseGeo: function (latitude, longitude, callback) {
                    nokia.places.search.manager.reverseGeoCode({
                        latitude: latitude,
                        longitude: longitude,
                        onComplete: function (data, status) {
                            if (angular.isFunction(callback)) {
                                callback(data, status);
                            }
                        }
                    });
                },
                searchPlacesCenter: function (address, center, callback) {
                    nokia.places.search.manager.findPlaces({
                        searchTerm: address,
                        searchCenter: center,
                        //limit: 1,
                        onComplete: function (data, status) {
                            if (angular.isFunction(callback)) {
                                callback(data, status);
                            }
                        }
                    });
                }
            };
        }
    ])
        .factory('nokiaRESTGeocoder',
        [
            '$q', '$http', '$translate', '$rootScope', 'nokiaSettings', 'placesSettings', 'xmlHttpService',
            function ($q, $http, $translate, $rootScope, nokiaSettings, placesSettings, xmlHttpService) {
                var self = this;
                this._initialized = false;
                this._language = null;

                function setAcceptLanguage() {
                    var languageCode = null;
                    var language = $translate.use();
                    switch (language) {
                        case 'ru':
                            languageCode = 'ru-RU';
                            break;
                        case 'en':
                            //default:
                            languageCode = 'en-US';
                            break;

                    }
                    self._language = languageCode;
                }

                function transformReverseGeoResponse(response) {
                    var data = null;

                    if (response.Response && response.Response.View && response.Response.View.length > 0) {
                        var result = response.Response.View[0].Result[0];
                        if (result && result.Location) {
                            var address = result.Location.Address;
                            data = {
                                location: {
                                    address: {
                                        city: address.City,
                                        countryCode: address.Country,
                                        country: address.Country,
                                        district: address.District,
                                        postalCode: address.PostalCode,
                                        state: address.State,
                                        street: address.Street,
                                        house: address.HouseNumber,
                                        text: address.Label
                                    },
                                    position: {
                                        latitude: result.Location.DisplayPosition.Latitude,
                                        longitude: result.Location.DisplayPosition.Longitude
                                    }
                                },
                                name: address.Label
                            };

                            if (address.AdditionalData && address.AdditionalData.length > 0) {
                                angular.forEach(address.AdditionalData, function (item) {
                                    if (item.key === 'CountryName') {
                                        data.location.address.country = item.value;
                                    }
                                    else if (item.key === 'StateName') {
                                        data.location.address.state = item.value;
                                    }
                                });
                            }
                        }
                    }

                    return data;
                }

                function transformResponseData(response) {
                    var data = angular.copy(response);

                    if (data.results && data.results.items && data.results.items.length > 0) {
                        angular.forEach(data.results.items, function (item) {
                            if (item.bbox && item.bbox.length > 0) {
                                item.boundingBox = {
                                    topLeft: {
                                        longitude: Number(item.bbox[0]),
                                        latitude: Number(item.bbox[3])
                                    },
                                    bottomRight: {
                                        longitude: Number(item.bbox[2]),
                                        latitude: Number(item.bbox[1])
                                    }
                                };
                            }

                            if (item.position && item.position.length > 0) {
                                item.position = {
                                    latitude: item.position[0],
                                    longitude: item.position[1]
                                };
                            }
                        });
                    }

                    return data;
                }

                $rootScope.$onRootScope("changedLanguage", function () {
                    if (self._initialized) {
                        setAcceptLanguage();
                    }
                });

                return {
                    initializeGeocoder: function () {
                        var deferred = $q.defer();

                        if (!self._initialized) {
                            setAcceptLanguage();
                            self._initialized = true;
                        }
                        deferred.resolve(this);

                        return deferred.promise;
                    },
                    findPlaces: function (term, callback, limit) {
                        var url = nokiaSettings.FIND_PLACES_URL;
                        url = url
                            .replace('{app_id}', NOKIA_API_APP_ID)
                            .replace('{app_code}', NOKIA_API_APP_CODE)
                            .replace('{language}', self._language)
                            .replace('{query}', term)
                            .replace('{limit}', limit || placesSettings.MAX_SEARCH_RESULTS);

                        xmlHttpService.get(url, {
                            credentials: false,
                            csrf: false,
                            onSuccess: function (response) {
                                if (angular.isFunction(callback)) {
                                    var data = transformResponseData(response);
                                    callback(data, 'OK');
                                }
                            },
                            onError: function () {
                                if (angular.isFunction(callback)) {
                                    callback(null, 'ERROR');
                                }
                            }
                        });
                    },
                    reverseGeo: function (latitude, longitude, callback) {
                        var url = nokiaSettings.REVERSE_GEOCODER_URL;
                        url = url
                            .replace('{app_id}', NOKIA_API_APP_ID)
                            .replace('{app_code}', NOKIA_API_APP_CODE)
                            .replace('{language}', self._language)
                            .replace('{gen}', 1)
                            .replace('{latitude}', latitude)
                            .replace('{longitude}', longitude);

                        xmlHttpService.get(url, {
                            credentials: false,
                            csrf: false,
                            onSuccess: function (response) {
                                if (angular.isFunction(callback)) {
                                    var data = transformReverseGeoResponse(response);
                                    callback(data, 'OK');
                                }
                            },
                            onError: function () {
                                if (angular.isFunction(callback)) {
                                    callback(null, 'ERROR');
                                }
                            }
                        });
                    },
                    searchPlacesCenter: function (address, center, callback) {
                        var url = nokiaSettings.SEARCH_PLACE_CENTER_URL;
                        url = url
                            .replace('{app_id}', NOKIA_API_APP_ID)
                            .replace('{app_code}', NOKIA_API_APP_CODE)
                            .replace('{language}', self._language)
                            .replace('{query}', address)
                            .replace('{latitude}', center.latitude)
                            .replace('{longitude}', center.longitude);

                        xmlHttpService.get(url, {
                            credentials: false,
                            csrf: false,
                            onSuccess: function (response) {
                                if (angular.isFunction(callback)) {
                                    var data = transformResponseData(response);
                                    callback(data, 'OK');
                                }
                            },
                            onError: function () {
                                if (angular.isFunction(callback)) {
                                    callback(null, 'ERROR');
                                }
                            }
                        });
                    }
                };
            }
        ])
        .factory('nokiaGeocoder',
        [
            '$q', 'placesSettings', 'nokiaAPIGeocoder', 'nokiaRESTGeocoder', 'nokiaSettings',
            function ($q, placesSettings, nokiaAPIGeocoder, nokiaRESTGeocoder, nokiaSettings) {
                var geocoder = nokiaSettings.USE_API === true ? nokiaAPIGeocoder : nokiaRESTGeocoder;

                var addressComponents = [];
                addressComponents[placesSettings.GEOACCURACY_LEVELS.COUNTRY] = 'country';
                addressComponents[placesSettings.GEOACCURACY_LEVELS.STATE] = 'state';
                addressComponents[placesSettings.GEOACCURACY_LEVELS.COUNTY] = 'county';
                addressComponents[placesSettings.GEOACCURACY_LEVELS.CITY] = 'city';
                addressComponents[placesSettings.GEOACCURACY_LEVELS.AREA] = 'district';
                addressComponents[placesSettings.GEOACCURACY_LEVELS.STREET] = 'street';
                addressComponents[placesSettings.GEOACCURACY_LEVELS.BUILDING] = 'house';

                function buildFormattedAddress(addressObject, accuracy, includePostCode) {
                    if (angular.isNumber(accuracy)) {
                        var address = [];
                        if (includePostCode === true && addressObject.postalCode) {
                            address.push(addressObject.postalCode);
                        }

                        for (var i = placesSettings.GEOACCURACY_LEVELS.COUNTRY; i >= accuracy; i--) {
                            var component = addressComponents[i];
                            if (addressObject[component]) {
                                address.push(addressObject[component]);
                            }
                        }

                        return address.reverse().join(', ');
                    }
                    else {
                        return addressObject.text;
                    }
                }


                function buildGeoResult(searchResults, formattedAddress, address) {
                    var place = searchResults[0];
                    var boundingBox = place.boundingBox;

                    if (!boundingBox) {
                        var placeWithBoundingBox = _.find(searchResults, function (item) {
                            return !!item.boundingBox;
                        });
                        if (placeWithBoundingBox) {
                            boundingBox = placeWithBoundingBox.boundingBox;
                        }
                    }

                    var bounds = null;
                    if (boundingBox) {
                        bounds = {
                            northEast: {
                                lat: Number(boundingBox.topLeft.latitude),
                                lng: Number(boundingBox.topLeft.longitude)
                            },
                            southWest: {
                                lat: Number(boundingBox.bottomRight.latitude),
                                lng: Number(boundingBox.bottomRight.longitude)
                            }
                        };
                    }

                    var center = {
                        latitude: Number(place.position.latitude),
                        longitude: Number(place.position.longitude)
                    };

                    return {
                        category: {
                            id: place.category.categoryId,
                            name: place.category.name
                        },
                        formatted_address: formattedAddress,
                        address: address,
                        latitude: center.latitude,
                        longitude: center.longitude,
                        geometry: {
                            center: center,
                            bounds: bounds
                        }
                    };
                }

                return {
                    name: 'nokia',
                    getGeoPlace: function (lat, lng, accuracy) {
                        return geocoder.initializeGeocoder().then(function (nokia) {

                            var deferred = $q.defer();
                            console.log('nokia.getGeoPlace: ' + lat + ', ' + lng);
                            geocoder.reverseGeo(lat, lng, function (data, status) {
                                if (status === 'OK') {
                                    var addressToSearch = null;
                                    if (angular.isNumber(accuracy) && data.location && data.location.address) {
                                        addressToSearch = buildFormattedAddress(data.location.address, accuracy, true);
                                    }
                                    else {
                                        addressToSearch = data.name;
                                    }
                                    geocoder.searchPlacesCenter(addressToSearch, data.location.position, function (searchResult, geoStatus) {
                                        if (status === 'OK') {
                                            if (searchResult.results && searchResult.results.items.length > 0) {
                                                var geoResult = buildGeoResult(searchResult.results.items, addressToSearch, data.location.address);
                                                deferred.resolve(geoResult);
                                            }
                                            else {
                                                var result = {
                                                    address: data.location.address,
                                                    formatted_address: addressToSearch
                                                };
                                                console.log('nokia.getGeoPlace success', result);
                                                deferred.resolve(result);
                                            }
                                        }
                                        else {
                                            console.log('nokia.getGeoPlace failed');
                                            deferred.reject('Geo request failed. Status: ' + geoStatus);
                                        }
                                    });
                                }
                                else {
                                    console.log('nokia.getGeoPlace failed');
                                    deferred.reject('Geo request failed. Status: ' + status);
                                }
                            });

                            return deferred.promise;
                        });
                    },
                    getAddressSuggest: function (address, limit) {
                        return geocoder.initializeGeocoder().then(function () {

                            console.log('nokia.getAddressSuggest: ' + address);
                            var deferred = $q.defer();

                            geocoder.findPlaces(address, function (data, status) {
                                if (status === 'OK') {
                                    if (data && data.results && data.results.items) {
                                        var result = _.map(data.results.items, function (place) {
                                            var bounds = null;
                                            if (place.boundingBox) {
                                                bounds = {
                                                    northEast: {
                                                        lat: Number(place.boundingBox.topLeft.latitude),
                                                        lng: Number(place.boundingBox.topLeft.longitude)
                                                    },
                                                    southWest: {
                                                        lat: Number(place.boundingBox.bottomRight.latitude),
                                                        lng: Number(place.boundingBox.bottomRight.longitude)
                                                    }
                                                };
                                            }
                                            var center = {
                                                latitude: Number(place.position.latitude),
                                                longitude: Number(place.position.longitude)
                                            };
                                            return {
                                                formatted_address: place.title,
                                                category: {
                                                    id: place.category.categoryId,
                                                    name: place.category.name
                                                },
                                                latitude: center.latitude,
                                                longitude: center.longitude,
                                                geometry: {
                                                    center: center,
                                                    bounds: bounds
                                                }
                                            };
                                        });
                                        console.log('nokia.getAddressSuggest success', result);
                                        deferred.resolve(result);
                                    }
                                    else {
                                        console.log('nokia.getAddressSuggest failed');
                                        deferred.resolve(null);
                                    }
                                }
                                else {
                                    console.log('nokia.getAddressSuggest failed');
                                    deferred.reject('Geo request failed. Status: ' + status);
                                }
                            }, limit);

                            return deferred.promise;
                        });
                    }
                };
            }
        ]);
})();
