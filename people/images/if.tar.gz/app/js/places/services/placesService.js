(function(){
angular.module('places.services', ['places.services.nominatim', 'places.services.nokia', 'places.services.cache'])
    .constant('placesSettings', {
        //GeocoderProvider: 'nominatim',
        GeocoderProvider: 'nokia',
        GeocoderAddressTypes: {
            street: 'street_address',
            area: 'sublocality',
            city: 'locality',
            region: 'administrative_area_level_2',
            state: 'administrative_area_level_1',
            country: 'country'
        },
        GeocoderStatusOK: 200,
        GeocoderReverseUrlTemplate: '//nominatim.openstreetmap.org/reverse?format=json&json_callback=JSON_CALLBACK&lat={lat}&lon={lng}&zoom=18&addressdetails=1&countrycodes=ru',
        GeocoderForwardUrlTemplate: '//nominatim.openstreetmap.org/search/{query}?format=json&addressdetails=1&json_callback=JSON_CALLBACK&limit={limit}',
        GEOACCURACY_LEVELS: {
            BUILDING: 0,
            STREET: 1,
            AREA: 2,
            CITY: 3,
            COUNTY: 4,
            STATE: 5,
            COUNTRY: 6
        },
        MAX_SEARCH_RESULTS: 10
    })
    .service('placesService',
    [
        'jsonRPC', '$q', 'placesSettings', 'nokiaGeocoder', 'nominatimGeocoder', 'cacheLocationService', 'jqPaginationSettings', '$state', 'permissionRequired', 'filtersTagTypes',
        function (jsonRPC, $q, placesSettings, nokiaGeocoder, nominatimGeocoder, cacheLocationService, jqPaginationSettings, $state, permissionRequired, filtersTagTypes) {

            var geocoderProviders = {
                'nokia': nokiaGeocoder,
                'nominatim': nominatimGeocoder
            };

            var currentGeocoder = geocoderProviders[placesSettings.GeocoderProvider || 'nokia'];

            var self = this;

            this._lastUsedFilter = null;
            this._cachedPlaces = [];
            this._cachedStreamPlaces = [];
            this._clibboardPlace = null;


            this.needsReloading = function (f) {
                return !angular.equals(self._lastUsedFilter, f);
            };

            this.saveCache = function (places) {
                self._cachedPlaces = angular.copy(places);
            };

            this.getCache = function () {
                return self._cachedPlaces;
            };

            this.saveStreamCache = function (places) {
                self._cachedStreamPlaces = angular.copy(places);
            };

            this.getStreamCache = function () {
                return self._cachedStreamPlaces;
            };

            this.getObjectsByParams = function (params) {
                // @deprecated places.filter_places
                return jsonRPC.request('places.map_filter_places', params);
            };

            this.getObjects = function (filters, forceReload, page, pageSize, withTotal) {

                var data = {
                    filters: filters,
                    page: page,
                    page_size: pageSize,
                    with_total: withTotal
                };

                if (self.needsReloading(filters) || forceReload) {
                    self._lastUsedFilter = angular.copy(filters);
                    return self.getObjectsByParams(data);
                }

                var deferred = $q.defer();
                deferred.resolve({result: self.getCache()});
                return deferred.promise;

            };

            this.getStream = function (filters, forceReload, page, pageSize, withTotal) {

                var data = {
                    filters: filters,
                    page: page,
                    page_size: pageSize,
                    with_total: withTotal
                };

                if (self.needsReloading(filters) || forceReload) {
                    self._lastUsedFilter = angular.copy(filters);
                    return jsonRPC.request('places.stream_places', data);
                }

                var deferred = $q.defer();
                deferred.resolve({result: self.getStreamCache()});
                return deferred.promise;
            };

            this.suggestPlace = function(text, lat, lng, page, pageSize, withTotal){

                var data = {
                    text: text,
                    longitude: lng,
                    latitude: lat,
                    page: page,
                    page_size: pageSize,
                    with_total: withTotal
                };

                return jsonRPC.request('places.suggest', data);
            };

            this.editPlace = permissionRequired('events.change_userplace', function (place_id, place_data) {
                var data = {
                    place_id: place_id
                };
                angular.extend(data, place_data);
                return jsonRPC.request('events.edit_place', data);
            });

            this.addPlace = permissionRequired('events.add_userplace', function (place_data) {
                return jsonRPC.request('places.add_place', place_data);
            });

            this.getPlace = function (place_alias) {
                var data = {
                    place_alias: place_alias
                };

                return jsonRPC.request('places.get_place', data);
            };

            this.getPlaceByID = function (place_id) {
                var data = {
                    place_id: place_id
                };

                return jsonRPC.request('places.get_place', data);
            };

            this.getUserAccessiblePlacesWithFavorites = function (query) {

                // T1028
                var data = {
                    index_name: 'places',
                    count: 10,
                    with_scroll: false,
                    filters: {
                        placesTags: [
                            {
                                name: query,
                                tag_type: filtersTagTypes.WORD
                            },
                            {
                                name: 'owner_or_favorited',
                                tag_type: filtersTagTypes.PRE_DEFINED
                            }
                        ]
                    }
                };
                return jsonRPC.request('esearch.filter', data).then(function (data) {
                    return {result: data.result.items};
                });
            };

            this.getUserAccessiblePlaces = function (searchText, onlyFavorites, visibility) {
                // T1028
                var data = {
                    index_name: 'places',
                    count: 10,
                    with_scroll: false,
                    filters: {
                        placesTags: [
                            {
                                name: searchText,
                                tag_type: filtersTagTypes.WORD
                            }
                        ]
                    }
                };
                if (visibility) {
                    data.filters.visibility = visibility;
                }

                if (onlyFavorites) {
                    data.filters.eventsTags.push({
                        name: 'favorited',
                        tag_type: 3,
                    });
                }
                return jsonRPC.request('esearch.filter', data).then(function (data) {
                    return {result: data.result.items};
                });
            };

            this.getPlaceSelectorWithFavorites = function () {
                return {
                    choices: [],
                    query: function(searchTerm) {
                        var selector = this;
                        if(searchTerm === "") {
                            self.getUserAccessiblePlacesWithFavorites(searchTerm).then(
                                function (response) {
                                    selector.choices = response.result;
                                },
                                function () {
                                    selector.choices = [];
                                }
                            );
                        } else {
                            if(searchTerm.length < 3) return;
                            self.getUserAccessiblePlaces(searchTerm, false).then(
                                function (response) {
                                    selector.choices = response.result;
                                },
                                function () {
                                    selector.choices = [];
                                }
                            );
                        }
                    }
                };
            };

            this.deletePlace = permissionRequired('events.delete_userplace', function (place_id) {
                var data = {place_id: place_id};
                return jsonRPC.request('events.delete_place', data);
            });

            this.createPlaceBounds = function (lat, lng) {
                return {
                    northEast: {
                        lat: lat + 0.001,
                        lng: lng + 0.001
                    },
                    southWest: {
                        lat: lat - 0.001,
                        lng: lng - 0.001
                    }
                };

            };

            this.getGeoPlace = function (lat, lng, accuracy) {
                //return currentGeocoder.getGeoPlace(lat, lng, accuracy);
                return cacheLocationService.get(currentGeocoder.getGeoPlace, currentGeocoder, lat, lng, accuracy);
            };

            this.getAddressSuggest = function (address) {
                //return currentGeocoder.getAddressSuggest(address);
                return cacheLocationService.get(currentGeocoder.getAddressSuggest, currentGeocoder, address);
            };

            this.getPlaceEvents = function (place_id, page) {
                var data = {
                    place_id: place_id,
                    page: page,
                    page_size: jqPaginationSettings.limit,
                    with_total: true
                };
                return jsonRPC.request('places.get_place_events', data);
            };

            this.copyToClipboard = function (place, toNewEvent) {
                self._clibboardPlace = angular.copy(place);
                if(toNewEvent) $state.go('new_event');
            };

            this.getClipboard = function () {
                return self._clibboardPlace;
            };

            this.resetClipboard = function () {
                self._clibboardPlace = null;
            };

        }]);

})();
