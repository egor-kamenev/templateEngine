(function () {
    'use strict';
    angular.module('places.services.nominatim', []).factory('nominatimGeocoder', [
        '$q', '$http', 'placesSettings',
        function ($q, $http, placesSettings) {
            var geocoder = {
                name: 'nominatim'
            };

            var addressComponents = [];
            addressComponents[placesSettings.GEOACCURACY_LEVELS.COUNTRY] = 'country';
            addressComponents[placesSettings.GEOACCURACY_LEVELS.STATE] = 'state';
            addressComponents[placesSettings.GEOACCURACY_LEVELS.COUNTY] = 'county';
            addressComponents[placesSettings.GEOACCURACY_LEVELS.CITY] = 'city';
            addressComponents[placesSettings.GEOACCURACY_LEVELS.AREA] = 'area';
            addressComponents[placesSettings.GEOACCURACY_LEVELS.STREET] = 'street';
            addressComponents[placesSettings.GEOACCURACY_LEVELS.BUILDING] = 'building';

            function buildFormattedAddress(geoPlace, accuracy, includePostCode) {
                if (angular.isNumber(accuracy)) {
                    var address = [];
                    if (includePostCode === true && geoPlace.postcode) {
                        address.push(geoPlace.postcode);
                    }

                    for (var i = placesSettings.GEOACCURACY_LEVELS.COUNTRY; i >= accuracy; i--) {
                        var component = addressComponents[i];
                        if (geoPlace[component]) {
                            address.push(geoPlace[component]);
                        }
                    }

                    return address.reverse().join(', ');
                }
                else {
                    return geoPlace.formatted_address;
                }
            }

            function getGeometry(address, includeFormatAddress, multipleResults) {
                var deferred = $q.defer();

                if (address) {
                    var geocoderUrl = placesSettings.GeocoderForwardUrlTemplate;
                    geocoderUrl = geocoderUrl.replace('{query}', address);
                    geocoderUrl = geocoderUrl.replace('{limit}', multipleResults === true ? placesSettings.MAX_SEARCH_RESULTS : 1);

                    $http({method: 'JSONP', url: geocoderUrl}).
                        success(function (data, status) {
                            if (status == placesSettings.GeocoderStatusOK && angular.isArray(data) && data.length > 0) {
                                var results = [];
                                for (var i = 0; i < data.length; i++) {
                                    var geoData = data[i];
                                    var geometry = {
                                        type: geoData.type,
                                        center: {
                                            latitude: Number(geoData.lat),
                                            longitude: Number(geoData.lon)
                                        }
                                    };

                                    if (geoData.boundingbox) {
                                        geometry.bounds = {
                                            northEast: {
                                                lat: Number(geoData.boundingbox[0]),
                                                lng: Number(geoData.boundingbox[2])
                                            },
                                            southWest: {
                                                lat: Number(geoData.boundingbox[1]),
                                                lng: Number(geoData.boundingbox[3])
                                            }
                                        };
                                    }

                                    var result = {
                                        latitude: geometry.center.latitude,
                                        longitude: geometry.center.longitude,
                                        geometry: geometry
                                    };

                                    if (includeFormatAddress === true) {
                                        result.formatted_address = buildFormattedAddress(geoData.address, placesSettings.GEOACCURACY_LEVELS.BUILDING, true);
                                    }

                                    results.push(result);
                                }

                                deferred.resolve(multipleResults === true ? results : results[0]);
                            }
                            else {
                                deferred.reject('Geo request failed. Status: ' + status);
                            }
                        }).
                        error(function () {
                            deferred.reject("Geo request failed.");
                        });
                }
                else {
                    deferred.resolve(null);
                }

                return deferred.promise;
            }

            geocoder.getGeoPlace = function (lat, lng, accuracy) {
                var deferred = $q.defer();

                accuracy = accuracy || placesSettings.GEOACCURACY_LEVELS.BUILDING;

                if (lat && lng) {
                    var geocoderUrl = placesSettings.GeocoderReverseUrlTemplate;
                    geocoderUrl = geocoderUrl.replace('{lat}', lat);
                    geocoderUrl = geocoderUrl.replace('{lng}', lng);

                    $http({method: 'JSONP', url: geocoderUrl}).
                        success(function (data, status) {
                            if (status == placesSettings.GeocoderStatusOK) {
                                if (!data || !data.address) {
                                    deferred.resolve({});
                                    return;
                                }

                                var geoPlace = {
                                    postcode: data.address.postcode,
                                    country: data.address.country,
                                    state: data.address.state,
                                    county: data.address.county,
                                    city: data.address.city,
                                    area: data.address.state_district,
                                    street: data.address.road,
                                    building: data.address.house_number
                                    //address: data['display_name']
                                };

                                //Fix for Moscow (in particular) - when state is a city
                                if (!geoPlace.city && geoPlace.state) {
                                    geoPlace.city = geoPlace.state;
                                    geoPlace.state = null;
                                }
                                else if (geoPlace.state === geoPlace.city) {
                                    geoPlace.state = null;
                                }

                                geoPlace.formatted_address = buildFormattedAddress(geoPlace, accuracy, true);

                                //fix for forward geocoding
                                var addressForSearch = (geoPlace.formatted_address || geoPlace.address);
                                if (addressForSearch && geoPlace.postcode) {
                                    addressForSearch = addressForSearch.replace(', ' + geoPlace.postcode, '');
                                }

                                getGeometry(addressForSearch, false).then(
                                    function (result) {
                                        var geometry = result.geometry;

                                        deferred.resolve({
                                            category: {
                                                id: geometry.type,
                                                name: geometry.type
                                            },
                                            latitude: geometry.center.latitude,
                                            longitude: geometry.center.longitude,
                                            geometry: geometry,
                                            address: data.address,
                                            formatted_address: geoPlace.formatted_address
                                        });
                                    },
                                    function () {
                                        deferred.reject();
                                    });
                            }
                            else {
                                deferred.reject('Geo request failed. Status: ' + status);
                            }
                        }
                    )
                        .error(function () {
                            deferred.reject("Geo request failed.");
                        });
                }
                else {
                    deferred.reject('Coordinates of the place does not defined.');
                }
                return deferred.promise;
            };

            geocoder.getAddressSuggest = function (address) {
                console.log("getAddressSuggest", address);

                var deferred = $q.defer();

                getGeometry(address, true, true).then(
                    function (result) {
                        deferred.resolve(result);
                    },
                    function (status) {
                        console.log("geocoder call failed", status);
                        deferred.reject();
                    });

                return deferred.promise;
            };

            return geocoder;
        }
    ]);
})();