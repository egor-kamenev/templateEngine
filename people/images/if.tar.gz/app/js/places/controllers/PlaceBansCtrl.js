(function () {
    'use strict';
    angular.module('app.controllers.placebansctrl', []).controller('PlaceBansCtrl', [
        '$scope', '$stateParams', '$rootScope', 'userbanService', 'jqPaginationSettings', '$state',
        function ($scope, $stateParams, $rootScope, userbanService, jqPaginationSettings, $state) {

            $scope.limit = jqPaginationSettings.limit_tile;
            $scope.maxPage = 0;
            $scope.loaded = false;
            $scope.total = 0;
            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            // This state is accessible by the owner only
            var doneWatch = $scope.$parent.$watch('place_loaded', function (loadComplete) {
                if (loadComplete) {
                    if (!$scope.$parent.isOwner) {
                        $state.go('403');
                    }
                    doneWatch();
                }
            });

            $scope.removeBan = function (banID) {
                userbanService.removeBan(banID).then(
                    function () {
                        $scope.loadBannedUsers();
                    },
                    function () {
                    }
                );
            };

            $scope.loadBannedUsers = function () {

                userbanService.getObjectBannedUsers('places', $stateParams.place_alias, $scope.currentPage).then(
                    function (data) {

                        $scope.dataSource = [];

                        if (!data.result.items.length) {
                            $scope.loaded = true;
                            return;
                        }

                        $scope.dataSource = data.result.items;
                        $scope.total = data.result.total;
                        $scope.loaded = true;

                        if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Please try again later."
                        });
                    }
                );

            };

            $scope.loadBannedUsers();


        }]);

})();