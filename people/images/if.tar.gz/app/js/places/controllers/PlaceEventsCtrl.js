(function () {
    'use strict';
    angular.module('app.controllers.placeeventsctrl', []).controller('PlaceEventsCtrl', [
        '$scope', '$stateParams', '$rootScope', 'placesService', 'jqPaginationSettings',
        function ($scope, $stateParams, $rootScope, placesService, jqPaginationSettings) {
            $scope.limit = jqPaginationSettings.limit;
            $scope.total = 0;
            $scope.maxPage = 0;
            $scope.loaded = false;
            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            $scope.events = [];

            $scope.getPlaceEvents = function () {
                placesService.getPlaceEvents($stateParams.place_alias, $stateParams.page).then(
                    function (data) {

                        if (!data.result.items.length) {
                            $scope.loaded = true;
                            return;
                        }

                        $scope.events = data.result.items;
                        $scope.total = data.result.total;
                        $scope.loaded = true;

                        if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Please try again later."
                        });
                    });

            };

            $scope.getPlaceEvents();

        }]);

})();