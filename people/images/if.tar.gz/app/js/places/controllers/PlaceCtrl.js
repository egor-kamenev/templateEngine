(function () {
    'use strict';

    angular.module('app.controllers.placectrl', []).controller('PlaceWallCtrl', [
        '$scope', '$rootScope', '$state',
        function ($scope, $rootScope, $state) {
            $scope.isCurrentStateHasXWall = function () {
                return $state.current.name === 'place.wall';
            };

            $scope.canAddXPosts = function () {
                return $rootScope.user.authenticated && !$scope.place.user_banned && !$scope.place.readOnly;
            };
        }]).controller('PlaceAlbumsCtrl', [
        '$scope', '$rootScope',
        function ($scope, $rootScope) {
            $scope.canAddXPosts = function () {
                return $rootScope.user.authenticated && !$scope.place.user_banned && !$scope.place.readOnly;
            };
        }]).controller('PlaceCtrl', [
        '$scope', '$http', '$q', '$state', '$stateParams', '$rootScope', '$filter',
        'userService', 'channelService', 'visibilityService', 'placesService', 'socketio', 'StreamCode',
        'mapService', 'mapSettings', 'Service404', 'contentSettings', 'leafletData', '$compile', '$timeout',
        'userLocationService', 'typeByTags',
        function ($scope, $http, $q, $state, $stateParams, $rootScope, $filter, userService, channelService,
                  visibilityService, placesService, socketio, StreamCode, mapService, mapSettings,
                  Service404, contentSettings, leafletData, $compile, $timeout, userLocationService, typeByTags) {

            $scope.place = {};
            $scope.place_alias = $stateParams.place_alias;
            $scope.place_loaded = false;
            $scope.isOwner = false;
            $scope.placeform = {};
            $scope.events = [];
            $scope.loadMoreBusy = false;
            $scope.offset = 0;
            $scope.discussionSettingsDialogActive = false;

            $rootScope.$watch('user', function () {
                $scope.isOwner = $scope.place && $scope.place.owner && $rootScope.user.id == $scope.place.owner.id;
            });

            $scope.$on('$destroy', function () {
                console.log('destroy!');
                if ($scope.channelName) {
                    channelService.unsubscribe($scope.channelName).sync();
                    socketio.getSocket().removeListener($scope.channelName, updateData);
                }
            });

            var updateData = function (data) {
                console.log('place channel', data);

                if (data.code === StreamCode.CHANGED) {
                    if (data.stream.object && data.stream.object.entity_type === 'userplace') {
                        if (data.stream.visibility_changed) {
                            console.log('visibility changed');
                            visibilityService.checkPlacesViewable($scope.place.id).then(function (data) {
                                if (!data.error) {
                                    console.log(data.result);
                                    var viewableHash = data.result;
                                    var redir = (viewableHash.hasOwnProperty($scope.place.id)) ? !viewableHash[$scope.place.id] : false;
                                    if (redir) {
                                        redirectToList("Доступ к месту закрыт.");
                                    }
                                }
                            });
                        }
                        $scope.$apply(function () {
                            //var needUpdateTags = false;
                            //if($scope.place.tags.length != data.content.tags.length) {
                            //    needUpdateTags = true;
                            //} else {
                            //    needUpdateTags = _.any($scope.place.tags, function(value, index){
                            //        return $scope.place.tags[index].id === data.content.tags[index].id;
                            //    });
                            //}
                            angular.extend($scope.place, data.content);
                            $scope.$broadcast('tagsChanged', $scope.place.tags);
                        });
                    } else if (data.stream.object && data.stream.object.entity_type === 'userlike') {
                        $scope.$apply(function () {
                            $scope.place.liked_count = data.content.liked_count;
                        });
                    } else if (data.stream.object && data.stream.object.entity_type === 'userlocation') {
                        $scope.$apply(function () {
                            $scope.place.visitors = data.content.visitors;
                            $scope.$emit('placeParticipantsChanged');
                        });
                    }
                } else if (data.code === StreamCode.DELETED) {
                    redirectToList("Данное место было удалено!");
                }
            };

            var redirectToList = function (msg) {
                alert(msg);
                $state.go('content', {content: 'places'});
            };

            var listenSocket = function () {
                $scope.channelName = channelService.getChannelName('place', $scope.place.id);
                console.log('subsc', 'place', $scope.place.id);
                channelService.subscribe($scope.channelName).sync();
                socketio.getSocket().on($scope.channelName, updateData);
            };

            var mapID = 'place-map';
            $scope.mapInitDone = false;
            $scope.mapMarkers = {};
            $scope.controls = {};
            $scope.leafletDefaults = mapSettings.LeafletDefaults;
            $scope.center = {};
            $scope.layers = {baselayers: {}};
            angular.extend($scope.layers.baselayers, mapSettings.DefaultMapBaselayer);

            var initializeMap = function () {

                var mapCenter = null;

                if ($scope.place) {
                    mapCenter = {
                        center: {
                            latitude: $scope.place.latitude,
                            longitude: $scope.place.longitude
                        },
                        zoom: mapSettings.DefaultPlaceZoom
                    };

                    $scope.mapMarkers.placeMarker = {
                        lat: mapCenter.center.latitude,
                        lng: mapCenter.center.longitude,
                        focus: true,
                        draggable: false,
                        icon: angular.extend({}, mapSettings.MarkerPlace, {className: "pin pin--event " + typeByTags($scope.place)})
                    };
                }

                var map = mapService.getDefaultMap(mapSettings.DefaultMapLayers, mapCenter, false);
                angular.extend($scope, map);

                $scope.mapInitDone = true;

                leafletData.getMap(mapID).then(function (map) {
                    L.control.locate(angular.extend(mapSettings.DefaultLocateControlSettings, {
                        OnLocationError: userLocationService.showWarningIfGeolocationNotAvailable
                    })).addTo(map);
                });
            };

            $scope.$watch('place', function (value) {
                if ($scope.place && (Object.keys($scope.place).length !== 0) && $scope.place.id) {
                    if (channelService.checkSubscribe('place', $scope.place.id) === -1) {
                        listenSocket();
                    }

                    $scope.place_loaded = true;
                    initializeMap();
                    $scope.xPostsLocator = {place: value.id};

//                    reloadEvents();
                }
                if ($scope.place && $scope.place.owner && $rootScope && $rootScope.user.id == $scope.place.owner.id) {
                    $scope.isOwner = true;
                }
            });

            $scope.startEditPlace = function () {
                $scope.is_being_edited = true;
                $scope.editPlace = angular.copy($scope.place);
                $scope.editPlaceFormData = angular.copy($scope.place);
            };

            $scope.replacePlace = function () {
                $scope.placeform = angular.copy($scope.place);
                $scope.placeform.point = {
                    lat: $scope.place.latitude,
                    lng: $scope.place.longitude
                };
                $scope.placeform.ancestor = $scope.place.id;
            };

            $scope.$onRootScope('event_newPlaceCreated', function (event, new_place) {
                //$scope.removeNewPlaceMarker();
                //$scope.addMapMarker(new_place);
            });


            $scope.createEventHere = function () {
                console.log("Create event:", $scope.place);
            };

            $scope.deletePlace = function () {

                $scope.confirm("Вы уверены, что хотите удалить место?").then(function () {
                    placesService.deletePlace($scope.place.id).then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка удаления места",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            else {

                                $state.go('content', {content: 'places'});

                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Место удалено"
                                });

                            }

                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                        }
                    );

                });

            };

            $scope.reloadPlaceData = function () {

                placesService.getPlace($scope.place_alias).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                Service404.setMessage(data.error.message);
                                $state.go('404');
                            }

                            else if ($scope.isPermissionDenied(data.error)) {
                                Service404.setMessage($filter('translate')('EXCEPT_PLACE_NO_PERMISSION'));
                                $state.go('403');
                            }
                            else if ($scope.isContentBanned(data.error)) {
                                Service404.setMessage($filter('translate')('EXCEPT_PLACE_BANNED'));
                                $state.go('403');
                            }
                            else if ($scope.isContentOnModeration(data.error)) {
                                Service404.setMessage($filter('translate')('EXCEPT_PLACE_WAITING_MODERATION'));
                                $state.go('403');
                            }

                        }
                        else {
                            $scope.place = data.result;
                            $scope.place_loaded = true;

                            if ($scope.place && $scope.placeName !== $scope.place.name) {
                                $scope.placeName = $scope.place.name;
                                $rootScope.$emit('breadcrumbDataUpdated');
                            }
                            else {
                                $scope.placeName = $scope.place ? $scope.place.name : null;
                            }
                        }
                    },
                    function () {
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Sorry, error occurred while submitting. Please try again later."
                        });
                        $state.go('404');
                    }
                );

            };

//            function reloadEvents() {
//                $scope.loadMoreBusy = true;
//                placesService.getPlaceEvents($scope.place.id, $scope.offset).then(
//                    function (data) {
//                        if (data.error) {
//                            if ($scope.isLogicError(data.error)) {
//                                $scope.$emit("flash", {
//                                    type: "error",
//                                    title: "Get place data error",
//                                    text: data.error.data.msg
//                                });
//                            }
//                        }
//                        else {
//                            angular.forEach(data.result, function (event) {
//                                $scope.events.push(event);
//                            });
//                            $scope.offset = $scope.events.length;
//                            $scope.loadMoreBusy = false;
//                        }
//                    },
//                    function (data) {
//                        // general RPC error
//                        $scope.$emit("flash", {
//                            type: "error",
//                            title: "Server error",
//                            text: "Sorry, error occurred while submitting. Please try again later."
//                        });
//                        $scope.loadMoreBusy = false;
//                    }
//                );
//            }

            $scope.reloadPlaceData();
            $rootScope.currentFilterContentType = contentSettings.CONTENT_TYPES.PLACES;

            function togglePlaceInfoWindow(show) {
                $q.all({
                    markers: leafletData.getMarkers(mapID),
                    layers: leafletData.getLayers(mapID)
                })
                    .then(function (values) {
                        var visibleParent = values.markers.placeMarker;

                        if (visibleParent) {
                            if (show) {
                                $scope.obj = $scope.place;
                                var popup = $compile(mapSettings.MapPopupPlaces)($scope)[0];
                                visibleParent.bindPopup(popup);
                                $timeout(function () {
                                    visibleParent.openPopup();
                                }, 0, false);
                            } else {
                                visibleParent.closePopup();
                            }
                        }
                    });
            }

            $scope.$on('leafletDirectiveMarkersClick', function (event, marker) {
                if (marker === 'placeMarker') {
                    togglePlaceInfoWindow(true);
                }
            });

            $scope.$on('closePlaceForm', function () {
                $scope.is_being_edited = false;
                $scope.editPlace = null;
                $scope.editPlaceFormData = null;
            });

            $scope.$onRootScope("photosUploaded", function () {
                $scope.reloadPlaceData();
            });
        }]);
})();