(function () {
    'use strict';
    angular.module('app.controllers.placeparticipantsctrl', []).controller('PlaceParticipantsCtrl', [
        '$scope', '$stateParams', '$rootScope', 'eventsService', 'jqPaginationSettings',
        function ($scope, $stateParams, $rootScope, eventsService, jqPaginationSettings) {

            $scope.limit = jqPaginationSettings.limit_tile;
            $scope.total = 0;
            $scope.maxPage = 0;
            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;

            $scope.getParticipants = function (update) {
                if (!update) $scope.dataSource = [];

                eventsService.getPlaceParticipants($stateParams.place_alias, $scope.currentPage).then(
                    function (data) {

                        if (!data.result.items.length) {
                            $scope.loaded = true;
                            return;
                        }

                        $scope.dataSource = data.result.items;
                        $scope.total = data.result.total;
                        $scope.loaded = true;

                        if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);

                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Please try again later."
                        });
                    }
                );
            };

            $scope.$onRootScope('placeParticipantsChanged', function () {
                $scope.getParticipants(true);
            });

            $scope.getParticipants(false);

        }]);

})();