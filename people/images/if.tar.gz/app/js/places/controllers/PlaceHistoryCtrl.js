(function(){
'use strict';

angular.module('app.controllers.placehistoryctrl', ['app']).
    controller('PlaceHistoryCtrl', ['$scope', '$rootScope', '$stateParams', '$q', 'jsonRPC', 'placesService',
    function ($scope, $rootScope, $stateParams, $q, jsonRPC, placesService) {

        $scope.alias = $stateParams.place_alias;

        placesService.getPlace($scope.alias).then(function(data){
            $scope.place = data;
        });
        
        jsonRPC.request('places.get_ancestors', {place_id: $scope.place.id}).then(function(data) {
           $scope.history = data.result;
        });
        
    }]);

})();