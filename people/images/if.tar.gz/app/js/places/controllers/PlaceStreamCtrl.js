(function () {
    'use strict';

    angular.module('app.controllers.placestreamctrl', ['app']).controller('PlaceStreamCtrl', [
        '$scope', '$rootScope', '$stateParams', '$q', 'jsonRPC', 'streamCodes', 'xPostsService', 'jqPaginationSettings',
        'LoadItemsMode', 'contentItemsSourceService', 'contentEvents', 'notificationBlockType',
        function ($scope, $rootScope, $stateParams, $q, jsonRPC, streamCodes, xPostsService, jqPaginationSettings,
                  LoadItemsMode, contentItemsSourceService, contentEvents, notificationBlockType) {

            $scope.streamCodes = streamCodes;
            $scope.stream = [];
            $scope.alias = $stateParams.place_alias;

            /*
             $scope.limit = jqPaginationSettings.limit;
             $scope.total = 0;
             $scope.maxPage = 0;
             $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;
             */

            $scope.loadStream = function (options) {

                var deferred = $q.defer(),

                    params = {
                        itemsCount: $scope.listViewOptions.visibleItemsCount,
                        mode: LoadItemsMode.APPEND,
                        force: options.force,
                        //contentType: 'messages', //???
                        //filterMode: 'userContent', // ???
                        offset_from: options.offsetFrom,
                        count: options.count,
                        with_total: true,
                        ts: options.ts,
                        source: {
                            fetcher: function (data) {
                                return jsonRPC.request('places.stream_places', data);
                            }
                        },
                        fetcherParams: {
                            by_object: $scope.alias
                        }
                    };

                contentItemsSourceService.loadItems(params).then(
                    function (data) {
                        $scope.stream = data.items;
                        $scope.listViewOptions.totalItems = data.total;
                        console.log("Data items:", data.items);
                        console.log("Total stream lenth:", $scope.listViewOptions.totalItems);

                        if (options.force) {
                            $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.stream});
                        }
                        else {
                            $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.stream});
                        }

                        deferred.resolve(data);
                    },
                    function () {
                        deferred.reject();
                    }).finally(function () {
                        $rootScope.loading = false;
                    });
                return deferred.promise;
            };

            $scope.listViewOptions = {
                checkOnLoad: true,
                totalItems: 0,
                maxColumns: 1,
                appendItemsCount: 5,
                visibleItemsCount: 10,
                itemComponent: NotificationBlock,
                itemComponentProps: {
                    mode: notificationBlockType.FULL
                },
                scrollContainerId: 'user-content-wrap',
                compareItemsPredicate: $scope.compareItems,
                itemSelector: '.list-entry',
                loadItems: $scope.loadStream
            };


            /*
             $scope.loadStream = function () {
             var data = {
             by_object: $scope.alias,
             page: $scope.currentPage,
             page_size: $scope.limit,
             with_total: true
             };
             jsonRPC.request('places.stream_places', data).then(function (data) {
             if (data.error) {
             if ($scope.isLogicError(data.error)) {
             $scope.$emit("flash", {
             type: "error",
             title: "Get events data error",
             text: data.error.data.msg
             });
             }
             $scope.loaded = true;
             }
             else {

             if (!data.result.items.length) {
             $scope.loaded = true;
             return;
             }

             $scope.stream = data.result.items;
             $scope.total = data.result.total;
             $scope.loaded = true;

             if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);
             }
             },
             function () {
             // general RPC error
             $scope.loaded = true;
             $scope.$emit("flash", {
             type: "error",
             title: "Server error",
             text: "Sorry, error occurred while submitting. Please try again later."
             });
             });

             };
             */

            $scope.getDiscussionState = function (post) {
                return xPostsService.getDiscussionStateByType(post, 'place');
            };

            //$scope.loadStream();

        }]);

})();
