(function () {
    'use strict';
    angular.module('app.controllers.newplacectrl', []).controller('newPlaceCtrl', [
        '$scope', 'userLocationService', 'mapService',
        function ($scope, userLocationService, mapService) {
            userLocationService.getUserLocation().then(function (location) {
                $scope.userLocation = location;
            });

            $scope.mapPlace = mapService.getSelectedPlace();
        }
    ]);

})();