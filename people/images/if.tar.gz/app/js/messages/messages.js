(function(){
'use strict';

angular.module('messages', [
    'messages.doSendMessage.directive'
]).config([
    "$stateProvider",
    function ($stateProvider) {
        var messagesSiblings = [
            'userMessages.main',
            'userMessages.dialog',
            'userMessages.notice',
            'userMessages.invite',
            'userMessages.friendship'
        ];

        $stateProvider
            .state('userMessages', {
                url: '/messages',
                abstract: true,
                parent: "userPrivate",
                //onEnter: // Copy of app.js 'enterPrivate'
                //    ['$state', '$stateParams', '$rootScope', function ($state, $stateParams, $rootScope) {
                //        var accessedByOwner = $rootScope.user.authenticated &&
                //            $rootScope.user.username == $stateParams.username;
                //
                //        if (!accessedByOwner) {
                //            $state.go('403');
                //        }
                //    }],
                template: '<div data-ui-view></div>',
                //parent: 'user',
                title: 'PAGE_TITLE_USER_MESSAGES',
                data: {
                    breadcrumbParentState: 'user',
                    breadcrumbSiblings: messagesSiblings
                },
                controller: 'MessagesCtrl'
            })

            .state('userMessages.main', {
                url: '',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadMessages');
                    }, 0);
                }],
                views: {
                    "@userMessages": {
                        templateUrl: '/static/partials/messages/partials/generic_messages.html'
                    }
                },
                title: 'PAGE_TITLE_USER_MESSAGES_MAIN',
                data: {
                    breadcrumbParentState: 'userMessages',
                    breadcrumbSiblings: messagesSiblings
                }
            })

            .state('userMessages.dialog', {
                url: '/private',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadMessages');
                    }, 0);
                }],
                views: {
                    "@userMessages": {
                        templateUrl: '/static/partials/messages/partials/generic_messages.html'
                    },
                    "section-tools@user": {
                        templateUrl: '/static/partials/messages/partials/private-messages-tools.html'
                    }
                },
                title: 'PAGE_TITLE_USER_MESSAGES_LIST_DIALOGUES',
                data: {
                    breadcrumbParentState: 'userMessages',
                    breadcrumbSiblings: messagesSiblings,
                    folder: 'dialog'
                }
            })

            
            .state('userMessages.dialogue', {
                url: '/dialogue/:partner_username',
                views: {
                    "@userMessages": {
                        templateUrl: '/static/partials/messages/partials/generic_messages.html'
                    }
                },
                resolve: {
                    partnerInfo: ['$stateParams', '$rootScope', 'userService', function($stateParams, $rootScope, userService){
                        return userService.getGeneralInfo($stateParams.partner_username).then(function(response){

                            var partnerInfo = response.result;

                            if (partnerInfo) {
                                // Shitty workouround to put partnerDisplayName to the root scope
                                // better way is to store it in the state data or params
                                var i = partnerInfo;
                                $rootScope.partnerDisplayName = i.first_name +
                                    (i.middle_name ? " " + i.middle_name : "") +
                                    (i.last_name ? " " + i.last_name : "");
                                
                                if (!$rootScope.partnerDisplayName)
                                    $rootScope.partnerDisplayName = partnerInfo.username;
                            }
                            return response.result;
                        });
                    }]
                },
                onEnter: ['$rootScope', '$timeout', '$stateParams', function ($rootScope, $timeout, $stateParams) {
                    $timeout(function(){
                        $rootScope.$emit('reloadMessages', $stateParams);
                    }, 0);
                }],
                data: {
                    breadcrumbParentState: 'userMessages.dialog',
                    breadcrumbCaption: function (state, $rootScope, viewScope, i, d) {
                        return angular.isDefined(viewScope.partnerDisplayName) ? viewScope.partnerDisplayName : null;
                    },
                    breadcrumbSiblings: messagesSiblings
                }
            })
            .state('userMessages.notice', {
                url: '/notice',
                templateUrl: '/static/partials/messages/partials/generic_messages.html',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadMessages');
                    }, 0);
                }],
                title: 'PAGE_TITLE_USER_MESSAGES_NOTICE',
                data: {
                    breadcrumbParentState: 'userMessages',
                    breadcrumbSiblings: messagesSiblings,
                    folder: 'notice'
                }
            })
            .state('userMessages.invite', {
                url: '/invite',
                templateUrl: '/static/partials/messages/partials/generic_messages.html',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadMessages');
                    }, 0);
                }],
                title: 'PAGE_TITLE_USER_MESSAGES_INVITE',
                data: {
                    breadcrumbParentState: 'userMessages',
                    breadcrumbSiblings: messagesSiblings,
                    folder: 'invite'
                }
            })
            .state('userMessages.friendship', {
                url: '/friendship',
                templateUrl: '/static/partials/messages/partials/generic_messages.html',
                onEnter: ['$rootScope', '$timeout', function ($rootScope, $timeout) {
                    $timeout(function(){
                        $rootScope.$emit('reloadMessages');
                    }, 0);
                }],
                title: 'PAGE_TITLE_USER_MESSAGES_FRIENDSHIP',
                data: {
                    breadcrumbParentState: 'userMessages',
                    breadcrumbSiblings: messagesSiblings,
                    folder: 'friendship'
                }
            });
    }]);

})();
