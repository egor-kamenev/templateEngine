(function () {
    'use strict';
    angular.module('messages.doSendMessage.directive', ['app']).directive('doSendMessage', [
        '$q', '$rootScope', '$compile', '$state', '$http', '$templateCache', 'messageService', 'userService',
        function ($q, $rootScope, $compile, $state, $http, $templateCache, messageService, userService) {
            var scope = {
                username: '=',
                callback: '&'
            };

            function link(scope, element) {
                scope.$watch('username', function (val) {
                    if (val) {
                        //console.log(val);
                        scope.username = val;
                    }
                });

                element.bind('click', function () {
                    scope.openMessageBox();
                });


                scope.modal_form = angular.element($compile($templateCache.get('/static/partials/messages/partials/do_sendmessage.html'))(scope));
                element.after(scope.modal_form);

            }

            function Controller($scope) {
                $scope.userSelector = userService.getUserSelector();

                $scope.openMessageBox = function () {
                    if ($rootScope.hasPerm('messages.add_message')) {
                        console.log("open message box");
                        $scope.modal_form.addClass('active');
                    }

                    $scope.$emit('checkEmailConfirmation', {
                        permission: 'messages.add_message',
                        warningMessage: 'У вас недостаточно прав для отправки сообщений'
                    });
                };

                $scope.sendMessage = function () {
                    console.log("send message");
                    var deferred = $q.defer();
                    var result = {};

                    if ($scope.username) {
                        result = messageService.sendMessageByName($scope.username, $scope.newMessage.body);
                    }
                    else {
                        result = messageService.sendMessage(angular.copy($scope.newMessage));
                    }
                    result.then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isFormError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Send message error",
                                        text: data.error.data
                                    });
                                }
                                else if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Send message error",
                                        text: data.error.data.msg
                                    });
                                }
                                deferred.reject();

                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Message sent",
                                    text: "Message was sent successfully"
                                });

                                $scope.newMessage = {
                                    body: '',
                                    users: []
                                };

                                $scope.close();

                                if ($scope.callback) {
                                    $scope.callback();
                                }

                                deferred.resolve();

                            }
                        },
                        function () {
                            deferred.reject();
                        }
                    );
                    return deferred.promise;
                };

                $scope.close = function () {
                    console.log("close");
                    $scope.newMessage = {
                        body: '',
                        users: []
                    };
                    $scope.modal_form.removeClass('active');
                };

                $scope.hasPerm = function (perm) {
                    return $rootScope.hasPerm(perm);
                };
            }

            Controller.$inject = ['$scope', '$element'];

            return ({
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                scope: scope
            });
        }]);

})();