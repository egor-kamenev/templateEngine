(function(){
angular.module('messages.services', [])
    .service('messageService', ['$rootScope', 'jsonRPC', 'jqPaginationSettings', 'permissionRequired',
        function ($rootScope, jsonRPC, jqPaginationSettings, permissionRequired) {

            this.asyncUnreadMessages = function () {
                return jsonRPC.request('messages.get_unread_messages');
            };

            this.sendMessage = permissionRequired('messages.add_message', function (data) {
                return jsonRPC.request('messages.send_message', data);
            });

            this.sendMessageByName = function (username, message) {
                var data = {
                    username: username,
                    message: message
                };
                return jsonRPC.request('messages.send_message_by_name', data);
            };

            this.markAsRead = function (ids, with_messages) {
                return jsonRPC.request('messages.mark_as_read', {ids: ids, with_messages: !!with_messages});
            };

            this.getMessages = function (data) {
                return jsonRPC.request('messages.get_messages', data);
            };

            this.getDialogue = function (data) {
                return jsonRPC.request('messages.get_dialogue', data);
            };

            this.accept = function (bunId) {
                return jsonRPC.request('events.accept_bun_request', {bun_request_id: bunId});
            };

            this.acceptOffer = function (offerID, autoCheckIn) {
                return jsonRPC.request('events.accept_bun_request', {bun_request_id: offerID, auto_check_in: autoCheckIn});
            };

            this.acceptRequest = function (requestID) {
                return jsonRPC.request('events.accept_invite_request', {request_id: requestID});
            };

            this.rejectOffer = function (offerID) {
                return jsonRPC.request('events.reject_bun_request', {bun_request_id: offerID});
            };

            // For compatblity
            this.reject = this.rejectOffer;

            this.rejectRequest = function (requestID) {
                return jsonRPC.request('events.reject_invite_request', {request_id: requestID});
            };


            this.ban = function (bunId) {
                return jsonRPC.request('events.ban_bun_request', {bun_request_id: bunId});
            };

            this.postpone = function (bunId) {
                return jsonRPC.request('events.postpone_bun_request', {bun_request_id: bunId});
            };

}]);

})();
