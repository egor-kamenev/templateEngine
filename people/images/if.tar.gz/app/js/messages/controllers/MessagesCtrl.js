(function () {
    'use strict';

    angular.module('app.controllers.messagesctrl', []).controller('MessagesCtrl', [
        '$scope', '$state', '$q', '$stateParams', '$rootScope', 'messageService', 'contentItemsSourceService',
        'contentEvents', 'LoadItemsMode', 'socketio', 'notificationBlockType', 'NotificationBlock',
        function ($scope, $state, $q, $stateParams, $rootScope, messageService, contentItemsSourceService, contentEvents,
                  LoadItemsMode, socketio, notificationBlockType, NotificationBlock) {

            // Indicates that we are lokign at the beginning of our messages
            // and have not scrolled down yet
            $scope.isScrollTop = true;

            $scope.compareItems = function (x, y) {
                return x.id === y.id && x.object.state === y.object.state && x.object.ts_state_changed === y.object.ts_state_changed;
            };

            $scope.loadMessages = function (options) {

                var deferred = $q.defer();
                var fetcherParams = {folder: $state.current.data.folder},
                    fetcher = messageService.getMessages;

                if ($state.is('userMessages.dialogue')) {
                    if (options.partner_username) {
                        $scope.partner_username = options.partner_username;
                    }
                    else {
                        options.partner_username = $scope.partner_username;
                    }
                    fetcherParams = {partner_username: options.partner_username};
                    fetcher = messageService.getDialogue;
                }

                var params = {
                    itemsCount: $scope.listViewOptions.visibleItemsCount,
                    mode: LoadItemsMode.APPEND,
                    force: options.force,
                    offset_from: options.offsetFrom,
                    count: options.count,
                    with_total: true,
                    ts: options.ts,
                    source: {
                        fetcher: fetcher
                    },
                    fetcherParams: fetcherParams
                };

                contentItemsSourceService.loadItems(params).then(
                    function (data) {
                        //$scope.messages = contentItemsSourceService.getCurrentItemsSource(params.contentType, params.filterMode);
                        $scope.messages = data.items;
                        $scope.listViewOptions.totalItems = data.total;

                        var markAsRead = _.pluck(_.filter($scope.messages, function (msg) {
                            return msg.ts_read_recipient === null;
                        }), 'id');

                        if (markAsRead.length) {
                            $rootScope.markAsRead(markAsRead);
                        }

                        if (options.force) {
                            $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.messages});
                        }
                        else {
                            $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.messages});
                        }

                        deferred.resolve(data);
                    },
                    function () {
                        deferred.reject();
                    }).finally(function () {
                        $rootScope.loading = false;
                    });
                return deferred.promise;

            };

            $scope.listViewOptions = {
                checkOnLoad: false,
                totalItems: 0,
                maxColumns: 1,
                appendItemsCount: 5,
                visibleItemsCount: 15,
                itemSelector: '.list-entry',
                itemComponent: NotificationBlock,
                itemComponentProps: {
                    mode: notificationBlockType.FULL
                },
                compareItemsPredicate: $scope.compareItems,
                loadItems: $scope.loadMessages,
                scrollContainerId: 'user-content-wrap'
            };

            $scope.$onRootScope('reloadMessages', function (e, stateParams) {
                $scope.loadMessages({
                    force: true,
                    offsetFrom: 0,
                    count: $scope.listViewOptions.visibleItemsCount,
                    partner_username: stateParams ? stateParams.partner_username : null
                });
            });

            function updateMessages(data) {

                // Update messages if new messsage
                // corresponds to the current open folder
                var doUpdate = false;

                switch ($state.current.name) {
                    // Always update in main
                    case 'userMessages.main':
                        doUpdate = true;
                        break;

                    case 'userMessages.dialog':
                        doUpdate = data.inbox.dialog.new_count > 0;
                        break;

                    case 'userMessages.friendship':
                        doUpdate = data.inbox.friendship.new_count > 0;
                        break;

                    case 'userMessages.notice':
                        doUpdate = data.inbox.notice.new_count > 0;
                        break;

                    case 'userMessages.invite':
                        doUpdate = data.inbox.invite.new_count > 0;
                        break;

                    // Dialogue updates if new message comes from current partner
                    case 'userMessages.dialogue':
                        var isMessageFromCurrentPartner = _.find(data.inbox.dialog.messages, function (msg) {
                            return msg.subject.username == $state.params.partner_username;
                        });
                        doUpdate = data.inbox.dialog.new_count > 0 && isMessageFromCurrentPartner;
                        break;
                }

                if (doUpdate && $scope.isScrollTop) {
                    $rootScope.$emit('reloadMessages');
                }

            }


            socketio.getSocket().on('messages:private', updateMessages);

        }]);

})();
