(function(){
'use strict';

angular.module('friends.controllers.invitationsfriendsctrl', [])
.controller('InvitationsFriendsCtrl', ['$scope', 'jsonRPC', function ($scope, jsonRPC) {

    $scope.addInvitations = function () {

        var data = {
            emails: $scope.newInvitations
        };

        jsonRPC.request('people.add_invitations', data).then(
            function (data) {
                if (data.error) {
                    if ($scope.isLogicError(data.error)) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Error",
                            text: data.error.data.msg
                        });
                    }
                }
                else {
                    $scope.$emit("flash", {
                        type: "success",
                        title: "Accepted",
                        text: "Invitations were sent"
                    });
                    $scope.newInvitations = '';
                    $scope.invitationFormClose();
                }
            },

            function (data) {
                $scope.$emit("flash", {
                    type: "error",
                    title: "Server error",
                    text: "Unable to send invitations"
                });
            }
        );

    };
    /*
    $scope.reloadInvitations = function () {

        jsonRPC.request('people.get_invitations').then(
            function (data) {
                if (data.error) {
                    if ($scope.isLogicError(data.error)) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Error",
                            text: data.error.data.msg
                        });
                    }
                }
                else {
                    $scope.invitations = data.result;
                }
            },
            function (data) {
                $scope.$emit("flash", {
                    type: "error",
                    title: "Server error",
                    text: "Unable to get invitations"
                });
            }
        );
    };
     */
    $scope.invitationFormOpen = function () {
        $scope.newInvitations = '';
        $scope.invitationFormVisible = true;
    };

    $scope.invitationFormClose = function () {
        $scope.invitationFormVisible = false;
    };
}]);

})();