(function(){
angular.module('friends.services', []).service('friendsService', [
    'jsonRPC', 'permissionRequired', 'tagService', '$rootScope',
    function (jsonRPC, permissionRequired, tagService, $rootScope) {
        this.sendRelationRequest = permissionRequired('friendship.add_friendshiprequest', function (data) {
            return jsonRPC.request('friendship.send_relation_request', data);
        });

        this.getFriendsEditor = function (include_self, self_name) {
            return {
                allowClear: true,
                multiple: true,
                formatSelection: function (friend) {
                    return friend.name;
                },
                formatResult: function (friend) {
                    return friend.name;
                },
                closeOnSelect: false,
                ajax: {
                    url: "/api/friendship/friends/",
                    dataType: "json",
                    data: function (term, page) {
                        return {
                            p: page,
                            include_self: (include_self) ? 1 : 0
                        };
                    },
                    results: function (data) {
                        if (include_self && self_name && (data.length > 0)) {
                            data[0].name = self_name;
                        }
                        return {
                            results: data
                        };
                    }
                }
            };
        };

        this.getFriendRequest = function (username) {
            return jsonRPC.request('friendship.get_friend_request', {username: username});
        };

        this.checkFriend = function (username) {
            return jsonRPC.request('friendship.check_friend', {username: username});
        };

        this.cancelFriendshipRequest = function (requestID) {
            return jsonRPC.request('friendship.cancel_request', {request_id: requestID});
        };

        this.acceptFriendshipRequest = function (requestID, tags) {
            var data = {
                request_id: requestID,
                tags: tagService.convertTagsToRPCData(tags)
            };

            return jsonRPC.request('friendship.accept_request', data);
        };

        this.rejectFriendshipRequest = function (requestID) {
            return jsonRPC.request('friendship.reject_request', {request_id: requestID});
        };

        this.breakFriendship = permissionRequired('friendship.delete_userrelation', function (friendID) {
            var data = {
                friend_id: friendID
            };
            return jsonRPC.request('friendship.break_friendship', data);
        });


    }])
    .factory("editFriendshipTags", ["$rootScope", "tagService", "friendsService", "jsonRPC", function ($rootScope, tagService, friendsService, jsonRPC) {
        return function(friend, tags){
            var data = {
                related_user_id: friend.id,
                tags: tagService.convertTagsToRPCData(tags)
            };

            jsonRPC.request('friendship.edit_relation_tags', data).then(
                function(data){
                    if (data.error) {
                        if ($rootScope.isLogicError(data.error)) {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        $rootScope.$emit("flash", {
                            type: "success",
                            title: "Готово",
                            text: "Теги дружбы изменены"
                        });
                        // Refresh the list
                        $rootScope.$emit('reloadFriends');
                    }

                },
                function(data){
                    $rootScope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Попробуйте повторить запрос позже"
                    });
                    
                }
            );


        };
    }])
    .factory("breakFriendship", ["$rootScope", "friendsService", function ($rootScope, friendsService) {
        return function (friend) {

            $rootScope.confirm("Вы уверены, что хотите разорвать дружбу?").then(function () {
                friendsService.breakFriendship(friend.id).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isLogicError(data.error)) {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $rootScope.$emit("flash", {
                                type: "success",
                                title: "Готово",
                                text: "Дружба разорвана"
                            });
                            $rootScope.$emit("friendshipBroken", friend.id);
                        }
                    },
                    function () {
                        $rootScope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Попробуйте повторить запрос позже"
                        });
                    }
                );
            });
        };
    }]);



})();
