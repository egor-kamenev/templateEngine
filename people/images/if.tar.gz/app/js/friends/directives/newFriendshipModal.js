(function () {
    'use strict';
    angular.module('app.directives.newfriendshipmodal', ['app']).directive('newFriendshipModal', [
        'tagService', '$q', '$rootScope', '$compile', '$state', '$http', '$templateCache', 'friendsService', 'userService',
        function (tagService, $q, $rootScope, $compile, $state, $http, $templateCache, friendsService, userService) {
            var scope = {
                entity: '='
            };

            function link(scope, element) {

                element.on('click', function () {
                    scope.openNewFriendship();
                });

                scope.$watch('are_friends', function (val) {
                    if (val === false) {
                        element.removeClass('disabled');
                    } else {
                        element.addClass('disabled');
                    }
                });

                $http.get('/static/partials/friends/new_friendship_modal.html', {cache: $templateCache}).success(function (template) {
                    scope.modal_form = angular.element($compile(template)(scope));
                    element.after(scope.modal_form);
                });
            }

            function Controller($scope) {

                var checkFriendshipRequest = $rootScope.user.authenticated &&
                    $rootScope.user.username != $scope.entity.username;

                $scope.newFriend = {
                    message: ""
                };

                $scope.tagsEditor = tagService.getTagSelector('friendship_tags', false);
                $scope.friendRequestExists = false;

                $scope.closeFriendshipDialog = function () {
                    $scope.modal_form.removeClass('active');
                };

                if (checkFriendshipRequest) {
                    friendsService.getFriendRequest($scope.entity.username).then(
                        function (data) {
                            //$scope.newFriend.tags = data.result.tags;
                            //$scope.newFriend.message = data.result.body;
                            $scope.friendRequestExists = !angular.equals({}, data.result);
                        }
                    );
                }

                if (checkFriendshipRequest) {
                    friendsService.checkFriend($scope.entity.username).then(
                        function (data) {
                            $scope.are_friends = data.result;
                        },
                        function () {
                            $scope.are_friends = false;
                        }
                    );
                }
                else {
                    $scope.friendRequestExists = false;
                }

                $scope.addFriend = function () {

                    var deferred = $q.defer();
                    var data = angular.copy($scope.newFriend);
                    data.to_user = $scope.entity.username;
                    data.tags = tagService.convertTagsToRPCData(data.tags);

                    friendsService.sendRelationRequest(data).then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isFormError(data.error)) {
                                    deferred.reject(data.error.data);
                                }
                                else if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка",
                                        text: data.error.data.msg
                                    });
                                    deferred.reject();
                                }
                            }
                            else {
                                $scope.closeFriendshipDialog();
//                            $scope.newFriend.message = '';
//                            $scope.newFriend.tags = '';
                                $scope.friendRequestExists = true;

                                // TODO
                                //$scope.userGeneralInfo.is_friendship_send = true;
                                //$scope.userGeneralInfo.i_follow = true;

                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Готово",
                                    text: "Запрос на дружбу отправлен"
                                });
                                deferred.resolve();
                            }
                        },
                        function () {
                            deferred.reject();
                        }
                    );
                    return deferred.promise;
                };

                $scope.openNewFriendship = function () {
                    if ($scope.are_friends) {

                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Вы уже друзья"
                        });

                        return;
                    }
                    else if ($scope.friendRequestExists) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Вы уже отправили запрос на дружбу этому пользователю"
                        });
                        return;
                    }

                    if ($rootScope.hasPerm('friendship.add_friendshiprequest')) {
                        $scope.modal_form.addClass('active');
                    }

                    $scope.$emit('checkEmailConfirmation', {
                        permission: 'friendship.add_friendshiprequest',
                        warningMessage: 'У вас недостаточно прав для добавления в друзья'
                    });
                };

                $scope.hasPerm = function (perm) {
                    return userService.hasPerm(perm);
                };
            }

            Controller.$inject = ['$scope'];

            return ({
                scope: scope,
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true
            });
        }]);

})();
