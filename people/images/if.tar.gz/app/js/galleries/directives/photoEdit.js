(function () {
    'use strict';
    angular.module('galleries.photoedit.directive', ['app']).directive('photoEdit', [
        '$rootScope', '$q', 'tagService', 'xPostsService',
        function ($rootScope, $q, tagService, xPostsService) {
            var scope = {
                entity: '=',
                callback: '&'
            };

            function link(scope, element, attributes, controller) {
            }

            function Controller($scope) {

                $scope.tagsEditor = tagService.getTagSelector();
                $scope.formClose = function () {
                    $scope.entity = {};
                };

                $scope.savePhoto = function () {

                    var deferred = $q.defer(),
                        photo = $scope.entity,
                        srcTags = angular.copy(photo.tags);

                    photo.tags = tagService.convertTagsToRPCData(photo.tags);
                    xPostsService.editPhoto(photo).then(
                        function (data) {
                            if (data.error) {
                                if ($rootScope.isFormError(data.error)) {
                                    deferred.reject(data.error.data);
                                }
                                else if ($rootScope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Ошибка изменения фотографии",
                                        text: data.error.data.msg
                                    });
                                    deferred.reject();
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Готово",
                                    text: "Информация о фотографии изменена успешно"
                                });

                                if ($scope.callback) {
                                    $scope.callback({photo: angular.extend(photo, {tags: srcTags})});
                                }
                                $scope.formClose();
                                deferred.resolve();
                            }
                        },
                        function () {
                            // general error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: "Ошибка сохранения фотографии, повторите запрос позже."
                            });

                            deferred.reject();
                        }
                    );
                    return deferred.promise;
                };

            }

            Controller.$inject = ['$scope', '$element'];

            //
            return ({
                scope: scope,
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                templateUrl: "/static/partials/galleries/photo_edit.html"
            });
        }]);
})();
