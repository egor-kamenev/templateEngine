(function () {
    'use strict';
    angular.module('galleries.attach.directive', ['app']).directive('galleryAttach', [
        'permissionRequired', '$compile', '$http', '$templateCache', 'galleriesService', 'userService',
        function (permissionRequired, $compile, $http, $templateCache, galleriesService, userService) {

            var scope = {
                user: '=',
                entity: '=',
                addAttachIf: '=',
                callback: '&'
            };

            function Controller($scope) {

                $scope.galleries = [];

                $scope.showGalleries = false;

                $scope.newGallery = {
                    showForm: false
                };

                $scope.$watch('entity', function () {
                    console.log("attach gallery watch", $scope.entity);
                    if ($scope.entity && $scope.entity.id && $scope.entity.content_type_id) {
                        $scope.reloadAttachedGalleries();
                        $scope.loadGalleries();
                    }
                });

                $scope.loadGalleries = permissionRequired('galleries.attach_photogallery', function () {

                    if ($scope.showGalleries) {
                        $scope.showGalleries = false;
                        return;
                    }

                    $scope.userGalleries = [];
                    $scope.userGalleriesLoaded = false;

                    if (userService.isAuthenticated()) {
                        galleriesService.getNotAttachedGalleries(userService.getUsername(), $scope.entity).then(
                            function (galleries) {
                                $scope.userGalleriesLoaded = true;
                                // Exclude attached galleries
                                angular.forEach(galleries, function (gallery) {
                                    var attached = false;

                                    angular.forEach($scope.exclude, function (gallery_ex) {
                                        if (gallery_ex.id == gallery.id) {
                                            attached = true;
                                        }

                                    });

                                    if (!attached) {
                                        $scope.userGalleries.push(gallery);
                                    }

                                });
                                $scope.showGalleries = true;
                            },
                            function () {
                                $scope.userGalleriesLoaded = true;
                            }
                        );
                    }
                });

                $scope.attachGallery = function (gallery_id) {
                    galleriesService.attachGallery(gallery_id, $scope.entity).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Attach error",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Gallery attached"
                                });
                                if ($scope.callback) {
                                    $scope.callback();
                                }
//                        $scope.reloadAttachedGalleries();
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                        }
                    );
                };

                $scope.detachGallery = function (gallery_id) {
                    galleriesService.detachGallery(gallery_id, $scope.entity).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Attach error",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Gallery detached"
                                });
                                $scope.reloadAttachedGalleries();
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                        }
                    );
                };

                $scope.reloadAttachedGalleries = function () {
                    galleriesService.getAttachedGalleries($scope.entity).then(
                        function (data) {
                            $scope.galleries = data;
                        }
                    );
                    $scope.showGalleries = false;
                };
            }

            Controller.$inject = ['$scope', '$element'];

            return ({
                scope: scope,
                controller: Controller,
                restrict: "AE",
                replace: true,
                templateUrl: "/static/partials/galleries/gallery_attach.html"
            });
        }]);
})();
