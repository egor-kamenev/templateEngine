(function () {
    'use strict';
    angular.module('galleries.preview.directive', ['app']).directive('albumPreview', ['xPostsService', function (xPostsService) {

        function Controller($scope, $state, settingsService) {
            $scope.PHOTO_ALBUM_PREVIEW_LENGTH = 0;

            settingsService.get(function (settings) {
                $scope.PHOTO_ALBUM_PREVIEW_LENGTH = settings.PHOTO_ALBUM_PREVIEW_LENGTH;
            });

            $scope.goToLastPhotoState = function (stateParams) {
                if ($state.includes('user')) {
                    $state.go('user.photo', stateParams);
                }
                else if ($state.includes('event')) {
                    $state.go('event.photo', stateParams);
                }
                else if ($state.includes('place')) {
                    $state.go('place.photo', stateParams);
                }
            };

            // T970
            $scope.removePhoto = function (photo) {
                // remove photo on server
                xPostsService.deletePhoto(photo).then(
                    function () {
                        // remove from list
                        $scope.photos = _.without(
                            $scope.photos,
                            _.findWhere($scope.photos, {id: photo.id})
                        );
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Ошибка удаления фотографии"
                        });
                    }
                );
            };
        }

        Controller.$inject = ['$scope', '$state', 'settingsService'];

        return ({
            scope: {
                album: '=', // may be null
                photos: '=',
                allowRemove: '='
            },
            link: function ($scope, el) {

                el.delegate('a', 'click', function (e) {
                    var el = angular.element(e.currentTarget),
                        links = el.parent().children('a'),
                        options = {
                            index: el.index()
                            // Switch to the last viewed photo
                            /* T798
                             onclose: function () {
                             if(angular.isDefined($scope.album)){
                             var finishedIndex = this.index;
                             $scope.$apply(function(){
                             var photo = $scope.photos[finishedIndex];
                             $scope.goToLastPhotoState({
                             username: $scope.album.owner.username,
                             post_id: $scope.album.id,
                             photo_id: photo.id
                             });
                             });
                             }
                             }*/
                        };
                    e.preventDefault();


                    var gallery = blueimp.Gallery(links, options);

                    angular.element(".slide-content").on('click', function () {

                        var clickedIndex = gallery.index;

                        $scope.$apply(function () {

                            var photo = $scope.photos[clickedIndex],
                                album = angular.isObject($scope.album) ? $scope.album : photo.post;
                            gallery.close();

                            $scope.goToLastPhotoState({
                                username: album.owner.username,
                                post_id: album.id,
                                photo_id: photo.id
                            });
                        });


                    });
                });
            },
            controller: Controller,
            restrict: "AE",
            replace: true,
            templateUrl: "/static/partials/galleries/gallery_only_preview.html"
        });
    }]);

})();
