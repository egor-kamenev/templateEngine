(function(){
    'use strict';
angular.module('galleries.edit.directive', ['app']).directive('albumEdit', [
    '$rootScope', '$q', 'tagService', 'tagTypes', 'xPostsService',
    function ($rootScope, $q, tagService, tagTypes, xPostsService) {

        var scope = {
            entity: '=',
            callback: '&'
        };

        function link() {
        }

        function Controller($scope) {

            $scope.tagsEditor = tagService.getTagSelector();

            $scope.formClose = function () {
                $scope.entity = {};
            };

            $scope.saveGallery = function () {

                var deferred = $q.defer(),
                    album = $scope.entity;

                album.tags = tagService.convertTagsToRPCData(album.tags);
                xPostsService.editPost(album).then(
                    function (data) {
                        if (data.error) {
                            if ($rootScope.isFormError(data.error)) {
                                deferred.reject(data.error.data);
                            }
                            else if ($rootScope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                                deferred.reject();
                            }
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Готово",
                                text: "Альбом успешно изменен"
                            });

                            if ($scope.callback) {
                                $scope.callback();
                            }
                            $scope.formClose();
                        }
                    },
                    function () {
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Sorry, error occurred while submitting. Please try again later."
                        });

                        deferred.reject();
                    }
                );
                return deferred.promise;
            };
        }

        Controller.$inject = ['$scope', '$element'];

        //
        return ({
            scope: scope,
            controller: Controller,
            link: link,
            restrict: "AE",
            replace: true,
            templateUrl: "/static/partials/galleries/gallery_edit.html"
        });
    }]);

})();
