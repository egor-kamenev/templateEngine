(function () {
    'use strict';
    angular.module('galleries.detach.directive', ['app']).directive('galleryDetach', [
        '$rootScope', '$compile', '$http', '$templateCache', 'galleriesService',
        function ($rootScope, $compile, $http, $templateCache, galleriesService) {

            var scope = {
                entity: '=',
                gallery: '=',
                callback: '&'
            };

            function link(scope, element) {
                element.bind('click', function () {
                    scope.detachGallery();
                });
            }

            function Controller($scope) {

                $scope.detachGallery = function () {
                    galleriesService.detachGallery($scope.gallery.id, $scope.entity).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Detach error",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Gallery detached"
                                });
                                if ($scope.callback) {
                                    $scope.callback();
                                }
                            }
                        },
                        function () {
                            // general RPC error
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Server error",
                                text: "Sorry, error occurred while submitting. Please try again later."
                            });
                        }
                    );
                };
            }

            Controller.$inject = ['$scope', '$element'];
            return ({
                scope: scope,
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true
            });
        }]);
})();