(function(){
angular.module('galleries.slideshow.directive', [
    'app'
]).
directive('gallerySlideshow', [function () {
    return({
	restrict: "AE",
        replace: true,
        template: '<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls"><div class="slides"></div><h3 class="title"></h3><a class="prev">‹</a><a class="next">›</a><a class="close">×</a><a class="play-pause"></a><ol class="indicator"></ol></div>'
    });

    
}]);
})();