(function () {
    'use strict';
    angular.module('galleries.multiupload.directive', ['app']).directive('multiUpload', [function () {

        var scope = {
            galleryId: '@',
            newGallery: '=',
            callback: '&'
        };

        //function link( scope, element, attributes, controller ){
        //};
        //

        function Controller($scope, $rootScope, blueimpPhotoProcessQueue) {
            var url = '/api/galleries/upload_file/';
            $scope.loadingFiles = false;
            $scope.queue = [];

            // TODO make global filter
            $scope.onlyOriginalImages = function (item) {
                return !item.name.match(/^(large|big|medium|small|micro):/);

            };

            $scope.options = {
                url: url,
                singleFileUploads: false,
                done: function (e, data) {

                    $scope.galleryId = data.result.gallery_id;
                    if ($scope.newGallery) {
                        $scope.newGallery.id = data.result.gallery_id;
                    }
                    $rootScope.$emit('event_multiuploadFinished');

                    // Remove uploaded files from the queue
                    for (var f in data.files) {


                        for (var i = 0; i < $scope.queue.length; i += 1) {
                            if ($scope.queue[i] === data.files[f]) {
                                $scope.queue.splice(i, 1);
                            }
                        }
                    }
                    if ($scope.callback) {
                        $scope.callback();
                    }
                },
                processQueue: blueimpPhotoProcessQueue
            };

        }

        Controller.$inject = ['$scope', '$rootScope', 'blueimpPhotoProcessQueue'];

        return ({
            controller: Controller,
            //link: link,
            restrict: "AE",
            replace: true,
            scope: scope,
            templateUrl: "/static/partials/galleries/multi_upload_form.html"
        });

    }]);

})();