(function(){
'use strict';

angular.module('app.controllers.galleriesctrl', [])
  .controller('GalleriesCtrl', ['$scope', 'visibilityService', '$stateParams', function ($scope, visibilityService, $stateParams, sectionPrivacy) {
      
        $scope._canPost = function () {
            return $scope.isOwnProfile;
        };

        //$scope.defaultAlbumVisibility = null;
        $scope.defaultAlbumVisibility = sectionPrivacy;

        //visibilityService.loadSectionVisibility('wall', $stateParams.username).then(
        //    function (data) {
        //        if (data.error) {
        //            if ($scope.isLogicError(data.error)) {
        //                $scope.$emit("flash", {
        //                    type: "error",
        //                    title: "Can't get wall visibility",
        //                    text: data.error.data.msg
        //                });
        //            }
        //        }
        //        else {
        //            $scope.defaultAlbumVisibility = data.result.visibility;
        //        }
        //    },
        //    function () {
        //        $scope.$emit("flash", {
        //            type: "error",
        //            title: "Error",
        //            text: 'Try again later'
        //        });
        //    }
        //);

    }]);
})();