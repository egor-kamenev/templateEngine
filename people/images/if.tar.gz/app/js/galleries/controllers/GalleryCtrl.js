// (function(){
// 'use strict';

// angular.module('app.controllers.galleryctrl', [])
//   .controller('GalleryCtrl', ['$scope', '$q', '$rootScope', 'jsonRPC', '$stateParams', '$location', '$state', '$filter', 'tagService', 'tagTypes', 'placesService', 'visibilityService', 'channelService', 'socketio', 'StreamCode', 'xPostsService', 'albumInfo', function ($scope, $q, $rootScope, jsonRPC, $stateParams, $location, $state, $filter, tagService, tagTypes, placesService, visibilityService, channelService, socketio, StreamCode, xPostsService, albumInfo) {

//         $scope.photo = {};
//         $scope.albumID = $stateParams.albumID;

//         $scope.albumInfo = albumInfo;
//         $scope.galleryPhotos = $scope.albumInfo.photos;

//         $scope.userAlbums = [];
//         $scope.userAlbumsLoaded = false;
//         $scope.tagsEditor = tagService.getTagSelector();
//         $scope.userPlaceSelector = placesService.getPlaceSelector();
//         $scope.isMergeModalActive = false;
//         $scope.selectedToMerge = null;
//         $scope.mergeTarget = null;

//         $scope.$on('$destroy', function() {
//           console.log('destroy!');
//           if ($scope.channelName) {
//             channelService.unsubscribe($scope.channelName).sync();
//             socketio.getSocket().removeListener($scope.channelName, updateData);
//           }
//         });

//         $scope.liked = false;

//         var updateData = function(data) {
//             if (data.code == StreamCode.CHANGED) {
//                 if (data.hasOwnProperty('user_id')) {
//                     if (!$scope.liked) {
//                         var obj = angular.extend(angular.copy($scope.albumInfo), data.content);
//                         if (data.user_id === $rootScope.user.id) {
//                             obj.liked = $scope.albumInfo.liked ? false : true;
//                         } else {
//                             obj.liked = $scope.albumInfo.liked;
//                         }
//                         $scope.liked = false;
//                         $scope.albumInfo = obj;
//                         $scope.$apply();
//                     }
//                 }
//             }
//         };

//         var listenSocket = function () {
//             $scope.channelName = channelService.getChannelName('gallery', $scope.albumInfo.id);
//             console.log('subsc', 'gallery', $scope.albumInfo.id);
//             channelService.subscribe($scope.channelName).sync();
//             socketio.getSocket().on($scope.channelName, updateData);
//         };
      
//       var removeOpenAlbum = function(){
//           xPostsService.deletePost($scope.albumInfo).then(
//               function (data) {
//                   if (data && data.error) {
//                       if ($rootScope.isLogicError(data.error)) {
//                           $scope.$emit("flash", {
//                               type: "error",
//                               title: "Ошибка",
//                               text: data.error.data.msg
//                           });
//                       }
//                   }
                  
//                   else {
//                       $scope.$emit("flash", {
//                           type: "success",
//                           title: "Готово",
//                           text: "Альбом '" + $scope.albumInfo.title + "' удален"
//                       });
//                   }
//                   $state.go('user.albums');
                  
//               },
//               function () {
//                   // general RPC error
//                   $scope.$emit("flash", {
//                       type: "error",
//                       title: "Ошибка",
//                       text: "Ошибка удаления альбома"
//                   });
//                   $state.go('user.albums');
                  
//               }
              
//           );
//       };

//         $scope.openViewer = function(){

//             var options = {
//                 index: 0,
//                 onclose: function () {
//                     var finishedIndex = this.index;
//                     $scope.$apply(function(){
//                         var photo = $scope.albumInfo.photos[finishedIndex];
//                         $state.go('user.photo', {albumID: $scope.albumID, photo_id: photo.id});
//                     });
//                 }
//             },
//                 links = [];

//             angular.forEach($scope.galleryPhotos, function(p){
//                 links.push({
//                     title: p.title,
//                     href: $filter('imageUrl')(p.image_url, 'large')
//                 });
//             });
//             blueimp.Gallery(links, options);
//         };

//         // Gallery view init
        
//         //document.getElementById('links').onclick = function (event) {
//         //    event = event || window.event;
//         //    var target = event.target || event.srcElement,
//         //        link = target.src ? target.parentNode : target,
//         //        options = {index: link, event: event},
//         //    blueimp.Gallery(links, options);
//         //};
         

//         $scope.$onRootScope('event_multiuploadFinished', function (){
//             //$scope.reloadPhotos();
//             $scope.reloadGallery();
//         });

//         $scope.reloadGallery = function(){
//           var locator = {
//               username: $stateParams.username
//           };

//           xPostsService.getPostByID(locator, $scope.albumID).then(
//               function(gallery){
//                   $scope.albumInfo = gallery;
//                   $scope.galleryPhotos = gallery.photos;

//                   listenSocket();
//                   //$scope.reloadPhotos();
//               },
//               function(){
//                   $scope.$emit("flash", {
//                       type: "error",
//                       title: "Ошибка",
//                       text: "Ошибка получения галлереи, попробуйте повторить запрос позже"
//                   });
//               }
//           );
//             /*
//             jsonRPC.request('galleries.get_gallery', {gallery_id:$scope.albumID}).then(
//                 function(data) {
//                     if(data.error){
//                         if($scope.isLogicError(data.error)){
//                             $scope.$emit("flash", {
//                                 type: "error",
//                                 title: "Error",
//                                 text: data.error.data.msg
//                             });
//                         }
//                         else if($scope.isPermissionDenied(data.error)){
//                             $state.go('403');
//                         }
//                     }
//                     else{
//                         $scope.albumInfo = data.result;
//                         listenSocket();
//                         $scope.reloadPhotos();
			
//                         //angular.forEach($scope.albumInfo.visibility['users'], function(v, i){
//                         //    v.text = v.username;
//                         //}); 

//                     }
//                 },
//                 function(data) {
//                     $scope.$emit("flash", {
//                         type: "error",
//                         title: "Server error",
//                         text: "Unable to fetch gallery info"
//                     });
//                 }
//             );
//               */
//         };

        

//         $scope.editPhoto = function( photoIndex ){
            
//             if($scope.accessRequired('galleries.change_photo')) return;
            
//             $scope.photo = angular.copy($scope.galleryPhotos[photoIndex]);
// //            if($scope.photo.place){
// //                $scope.photo.place.text = $scope.photo.place.name;
// //            }

//             $scope.photoIndex = photoIndex;
            
//         };

//         $scope.loadAlbums = function(){
//             $scope.userAlbums = [];
//             $scope.userAlbumsLoaded = false;

//             var locator = {
//                 username: $scope.userObject.username
//             };

//             xPostsService.getAlbums(locator).then(
//                 function(albums) {
//                     if(albums.error){
//                         if($scope.isLogicError(albums.error)){
//                             $scope.$emit("flash", {
//                                 type: "error",
//                                 title: "Ошибка",
//                                 text: albums.error.data.msg
//                             });
//                         }
//                     }
//                     else{
//                         $scope.userAlbums = _.filter(albums, function(album){
//                             return parseInt(album.id)!=parseInt($scope.albumID);
//                         });
//                         $scope.userAlbumsLoaded = true;

//                     }
//                 },
//                 function() {
//                     $scope.$emit("flash", {
//                         type: "error",
//                         title: "Ошибка",
//                         text: "Невозможно получить список альбомов, попробуйте повторить попытку позже"
//                     });
//                 }
//             );
//         };
        
//         $scope.deletePhoto = function(photoIndex){
            
//             if($scope.accessRequired('galleries.delete_photo')) return;

//             var removingLastPhoto = $scope.albumInfo.photos.length == 1,
//                 whatToConfirm = removingLastPhoto ? 
//                     "Удаление последнего фото из альбома приведет к его удалению, действительно удалить фото?":
//                     "Вы уверены, что хотите удалить фото?";

//             $scope.confirm(whatToConfirm).then(function(){

//                 xPostsService.getPhotoByID($scope.galleryPhotos[photoIndex].id).then(
//                     function(photo) {
//                         xPostsService.deletePhoto(photo).then(
//                             function (data) {
//                                 if (data && data.error) {
//                                     if ($rootScope.isLogicError(data.error)) {
//                                         $scope.$emit("flash", {
//                                             type: "error",
//                                             title: "Ошибка",
//                                             text: data.error.data.msg
//                                         });
//                                     }
//                                 }
                                
//                                 else {
//                                     $scope.$emit("flash", {
//                                         type: "success",
//                                         title: "Готово",
//                                         text: "Фото удалено"
//                                     });
//                                     if(removingLastPhoto){
//                                         removeOpenAlbum();
//                                     }
//                                     else{
//                                         $scope.reloadGallery();
//                                     }
//                                 }
//                             },
//                             function () {
//                                 // general RPC error
//                                 $scope.$emit("flash", {
//                                     type: "error",
//                                     title: "Ошибка",
//                                     text: "Ошибка удаления фото, повторите запрос позже"
//                                 });
//                             }
//                         );
//                     },
//                     function(){
//                         $scope.$emit("flash", {
//                             type: "error",
//                             title: "Ошибка",
//                             text: "Ошибка загрузки фотографии"
//                         });
//                     }
//                 );
//             });
//         };

//         $scope.updatePhoto = function () {
//             $scope.galleryPhotos[$scope.photoIndex] = $scope.photo;
//         };

//         $scope.editGallery = function(){
//             $scope.editAlbum = $scope.albumInfo;
//         };

//         $scope.updateGallery = function() {
//             $scope.albumInfo = $scope.editAlbum;
//         };

//         $scope.openMergeModal = function(){
//             $scope.isMergeModalActive = true;
//             $scope.loadAlbums();
//         };

//         $scope.closeMergeModal = function(){
            
//             $scope.isMergeModalActive = false;
//             $scope.selectedToMerge = null;
//             $scope.mergeTarget = null;
//         };

//         $scope.mergeAlbums = function(){


//             var deferred = $q.defer();
//             var album = $scope.albumInfo;
//             album.merge_to  = $scope.mergeTarget.id;
//             album.title  = $scope.mergeTarget.title;
//             album.tags  = tagService.convertTagsToRPCData($scope.mergeTarget.tags);
            
//             xPostsService.editPost(album).then(
//                 function(data) {
//                     if(data.error){
//                         if($rootScope.isFormError(data.error)){
//                             $scope.$emit("flash", {
//                                 type: "error",
//                                 title: "Ошибка",
//                                 text: "Попробуйте повторить запрос позже"
//                             });
//                             deferred.reject(data.error.data);
                            
//                         }
//                         else if($rootScope.isLogicError(data.error)){
//                             $scope.$emit("flash", {
//                                 type: "error",
//                                 title: "Ошибка",
//                                 text: data.error.data.msg
//                             });
//                         }
//                         deferred.reject();
//                     }
//                     else{
//                         $scope.$emit("flash", {
//                             type: "success",
//                             title: "Готово",
//                             text: "Альбомы объединены"
//                         });
//                         deferred.resolve();
//                         $scope.closeMergeModal();
//                         $state.go('user.albums');
                        
//                     }
//                 },
//                 function() {
//                     // general RPC error
//                     $scope.$emit("flash", {
//                         type: "error",
//                         title: "Ошибка",
//                         text: "Попробуйте повторить запрос позже"
//                     });
//                     deferred.reject();
//                 }
                
                
//             );
            
//             return deferred.promise;

//         };

//         $scope.viewPhoto = function(photo){
//             $state.go('user.photo', {username: $scope.albumInfo.owner.username, albumID: $scope.albumInfo.id, photo_id: photo.id} );
//         };


//         $scope.moveToAlbum = function(photo, targetAlbum){


//             if($scope.accessRequired('galleries.change_photo')) return;

//             var confirmationRequired = $scope.albumInfo.photos.length == 1;
//             function move(removeAlbum){
//                 xPostsService.getPhotoByID(photo.id).then(
//                     function(photo){
//                         photo.move_to = targetAlbum.id;
//                         xPostsService.editPhoto(photo).then(
//                             function(){
//                                 $scope.$emit("flash", {
//                                     type: "success",
//                                     title: "Готово",
//                                     text: "Фотография перемещена в альбом " + targetAlbum.title
//                                 });
//                                 if(removeAlbum){
//                                     removeOpenAlbum();
//                                 }
//                                 else{
//                                     $scope.reloadGallery();
//                                 }

//                             },
//                             function(){
//                                 $scope.$emit("flash", {
//                                     type: "error",
//                                     title: "Ошибка",
//                                     text: "Ошибка перемещения фотографии"
//                                 });
//                             }
//                         );
//                     },
//                     function(){
//                         $scope.$emit("flash", {
//                             type: "error",
//                             title: "Ошибка",
//                             text: "Ошибка загрузки фотографии"
//                         });
//                     }
//                 );
//             }

//             if(confirmationRequired){
//                 $scope.confirm("Перемещение последней фотографии из альбома приведет к его удалению, действительно переместить фото?").then(function(){
//                     move(true);
//                 });
//             }
//             else{
//                 move();
//             }

//         };

//       $scope.changePhotoVisibility = function(photoIndex){

//           xPostsService.getPhotoByID($scope.galleryPhotos[photoIndex].id).then(
//               function(photo) {
//                   photo.visibility = $scope.galleryPhotos[photoIndex].visibility;
//                   xPostsService.editPhoto(photo).then(

//                       function(){
//                           $scope.$emit("flash", {
//                               type: "success",
//                               title: "Готово",
//                               text: "Видимость фотографии изменена"
//                           });
                          
//                       },
//                       function(){
//                           $scope.$emit("flash", {
//                               type: "error",
//                               title: "Ошибка",
//                               text: "Невозможно изменить видимость фотографии, повторите попытку позже"
//                           });
                          
//                       }
//                   );
//               },
//               function(){
//                   $scope.$emit("flash", {
//                       type: "error",
//                       title: "Ошибка",
//                       text: "Ошибка загрузки фотографии"
//                   });
//               }
//           );
          
//       };

//       $scope.setTarget = function(){
//           $scope.mergeTarget = angular.copy($scope.selectedToMerge);
//           $scope.mergeTarget.tags = ($scope.mergeTarget.tags || []).concat(albumInfo.tags);
//       };
      
//       $scope.loadAlbums();

//     }]);

// })();
