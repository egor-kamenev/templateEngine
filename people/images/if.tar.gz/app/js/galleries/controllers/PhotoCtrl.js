(function(){
'use strict';

angular.module('app.controllers.photoctrl', [])
.controller('PhotoCtrl', ['$scope', '$rootScope', '$q', 'jsonRPC', '$stateParams', '$location', '$state', '$filter', 'placesService', 'channelService', 'tagService', 'tagTypes', 'socketio', 'StreamCode', 'xPostsService', 'rootPost', 'Service404', 'userService', 'permissionRequired',
function ($scope, $rootScope, $q, jsonRPC, $stateParams, $location, $state, $filter, placesService, channelService, tagService, tagTypes, socketio, StreamCode, xPostsService, rootPost, Service404, userService, permissionRequired) {

    $scope.rootObject = rootPost.object;
    $scope.rootPost = rootPost.post;

    $scope.photoID = $stateParams.photo_id;
    $scope.albumID = $stateParams.post_id;
    $scope.photo = {};
    $scope.isOwnPhoto = false;
    $scope.photoLoaded = false;
    //$scope.userPlaceSelector = placesService.getPlaceSelector();
    //$scope.tagsEditor = tagService.getTagSelector();
    $scope.galleryPhotos = [];
    $scope.editPhotoInstance = {};
    $scope.userAlbums = [];
    $scope.userAlbumsLoaded = false;

    $scope.goToAlbum = function(){

        if($state.includes('user')){
            $state.go('user.post', {post_id: $scope.rootPost.id});
        }
        else if($state.includes('event')){
            $state.go('event.post', {post_id: $scope.rootPost.id});
        }
        else if($state.includes('place')){
            $state.go('place.post', {post_id: $scope.rootPost.id});
        }
    };

    $scope.goToRootObjectAlbums = function(){

        if($state.includes('user')){
            $state.go('user.albums', {username: $scope.rootObject.username});
        }
        else if($state.includes('event')){
            $state.go('event.albums', {event_alias: $scope.rootObject.alias});
        }
        else if($state.includes('place')){
            $state.go('place.albums', {place_alias: $scope.rootObject.alias});
        }

    };

    var removeOpenAlbum = function(){
        xPostsService.deletePost($scope.rootPost).then(
            function (data) {
                if (data && data.error) {
                    if ($rootScope.isLogicError(data.error)) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: data.error.data.msg
                        });
                    }
                }
                
                else {
                    $scope.$emit("flash", {
                        type: "success",
                        title: "Готово",
                        text: "Альбом '" + $scope.rootPost.title + "' удален"
                    });
                }
                $scope.goToRootObjectAlbums();
            },
            function () {
                // general RPC error
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Ошибка удаления альбома"
                });
                $scope.goToRootObjectAlbums();
            }
            
        );
    };

    $scope.isCurrentStateHasXWall = function () {
        var state = $state.$current.self;
        //TODO: check state name where there is xWall
        return state && state.name === 'user.photo';
    };

    $scope.$on('$destroy', function() {
        console.log('destroy!');
        if ($scope.channelName) {
            channelService.unsubscribe($scope.channelName).sync();
            socketio.getSocket().removeListener($scope.channelName, updateData);
        }
    });

    $scope.liked = false;

    var updateData = function(data) {
        if (data.code == StreamCode.CHANGED) {
            if (data.hasOwnProperty('user_id')) {
                if (!$scope.liked) {
                    var obj = angular.extend(angular.copy($scope.photo), data.content);
                    if (data.user_id === $rootScope.user.id) {
                        obj.liked = $scope.photo.liked ? false : true;
                    } else {
                        obj.liked = $scope.photo.liked;
                    }
                    $scope.liked = false;
                    $scope.photo = obj;
                    $scope.$apply();
                }
            }
        }
    };

    var listenSocket = function () {
        $scope.channelName = channelService.getChannelName('photo', $scope.photo.id);
        console.log('subsc', 'photo', $scope.photo.id);
        channelService.subscribe($scope.channelName).sync();
        socketio.getSocket().on($scope.channelName, updateData);
    };

    $scope.openViewer = function(){
        var links = [],
            index = 0;

        angular.forEach($scope.galleryPhotos, function(p, i){
            links.push({
                id: p.id,
                title: p.title,
                href: $filter('imageUrl')(p.image_url, 'large')
            });
            if (p.id == $scope.photo.id){
                index = i;
            }
        });
        var options = {
            index: index,
            onclose: $scope.getAnotherPhoto
        };
        blueimp.Gallery(links, options);
    };

    $scope.getAnotherPhoto = function(){
        var photo_id = this.list[this.getIndex()].id;
        $state.go('user.photo', {username: $scope.photo.owner, albumID: $scope.photo.gallery, photo_id: photo_id});
    };

    $scope.reloadPhoto = function(){

        xPostsService.getPhotoByID($scope.photoID).then(
            function(response) {

                if(response.error){
                    if($rootScope.isContentBanned(response.error)){
                        Service404.setMessage($filter('translate')('EXCEPT_PHOTO_BANNED'));
                        $state.go('403');

                    }
                    else if($rootScope.isContentOnModeration(response.error)){
                        Service404.setMessage($filter('translate')('EXCEPT_PHOTO_WAITING_MODERATION'));
                        $state.go('403');

                    }
                    else if($rootScope.isPermissionDenied(response.error)){
                        Service404.setMessage($filter('translate')('EXCEPT_PHOTO_NO_PERMISSION'));
                        $state.go('403');

                    }
                    else{
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Ошибка загрузки фотографии"
                        });
                        $state.go('404');
                    }

                }
                else{
                    $scope.photo = response;
                    $scope.photoLoaded = true;
                    userService.getUser().then(function(user){
                        $scope.isOwnPhoto = user.username == $scope.photo.owner.username;
                    });
                    listenSocket();
                }
            },
            function(response) {
                /*
                if (response.status == 403) {
                    if($rootScope.isContentBanned(response.data)){
                        Service404.setMessage($filter('translate')('EXCEPT_PHOTO_BANNED'));
                    }
                    else if($rootScope.isContentOnModeration(response.data)){
                        Service404.setMessage($filter('translate')('EXCEPT_PHOTO_WAITING_MODERATION'));
                    }
                    else if($rootScope.isPermissionDenied(response.data)){
                        Service404.setMessage($filter('translate')('EXCEPT_PHOTO_NO_PERMISSION'));
                    }
                    $state.go('403');
                }
                else{
                 */
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Ошибка загрузки фотографии"
                });
                $state.go('404');

                //}
            }
        );
    };

    /*$scope.loadGalleryPhotos = function(){

        $scope.galleryPhotos = [];
        var data = {
            username: $stateParams.username,
            gallery_id: $scope.photo.gallery
        };

        jsonRPC.request('galleries.get_photos', data).then(
            function(data) {
                if(data.error){
                    if($scope.isLogicError(data.error)){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Error",
                            text: data.error.data.msg
                        });
                    }
                }
                else{
                    $scope.galleryPhotos = data.result;
                }
            },
            function(data) {
                $scope.$emit("flash", {
                    type: "error",
                    title: "Server error",
                    text: "Unable to fetch gallery photos"
                });
            }
        );
    };
     */

    $scope.editPhoto = permissionRequired('galleries.change_photo', function(){
        $scope.editPhotoInstance = $scope.photo;
    });

    $scope.updatePhoto = function() {
        $scope.photo = $scope.editPhotoInstance;
    };

    $scope.canAddXPosts = function(){
        return $rootScope.user.authenticated && !$scope.photo.readOnly && !$scope.photo.user_banned;
    };

    $scope.changePhotoVisibility = function(){
        xPostsService.editPhoto($scope.photo).then(
            function(){
                $scope.$emit("flash", {
                    type: "success",
                    title: "Готово",
                    text: "Видимость фотографии изменена"
                });

            },
            function(){
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Невозможно изменить видимость фотографии, повторите попытку позже"
                });

            }
        );

    };

    $scope.deletePhoto = permissionRequired('galleries.delete_photo', function(){

        var removingLastPhoto = $scope.rootPost.photos.length == 1,
            whatToConfirm = removingLastPhoto ? 
                "Удаление последнего фото из альбома приведет к его удалению, действительно удалить фото?":
                "Вы уверены, что хотите удалить фото?";
        
        $scope.confirm(whatToConfirm).then(function(){
            
            xPostsService.deletePhoto($scope.photo).then(
                function (data) {
                    if (data && data.error) {
                        if ($rootScope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: data.error.data.msg
                            });
                        }
                    }
                    
                    else {
                        $scope.$emit("flash", {
                            type: "success",
                            title: "Готово",
                            text: "Фото удалено"
                        });

                        if(removingLastPhoto){
                            removeOpenAlbum();
                        }
                        else{
                            $scope.goToAlbum();
                            //$state.go('user.post', {post_id: rootPost.id });
                        }
                    }
                },
                function () {
                    // general RPC error
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Ошибка удаления фото, повторите запрос позже"
                    });
                }
            );
        });
    });

    /*$scope.loadAlbums = function(){

        $scope.userAlbums = [];
        $scope.userAlbumsLoaded = false;

        var locator = {
            username: $scope.userObject.username
        };

        xPostsService.getAlbums(locator).then(
            function(albums) {
                if(albums.error){
                    if($scope.isLogicError(albums.error)){
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: albums.error.data.msg
                        });
                    }
                }
                else{
                    $scope.userAlbums = _.filter(albums, function(album){
                        return parseInt(album.id)!=parseInt($scope.albumID);
                    });
                    $scope.userAlbumsLoaded = true;

                }
            },
            function(data) {
                $scope.$emit("flash", {
                    type: "error",
                    title: "Ошибка",
                    text: "Невозможно получить список альбомов, попробуйте повторить попытку позже"
                });
            }
        );
    };
     */
    $scope.moveToAlbum = permissionRequired('galleries.change_photo', function(targetAlbum){

        var confirmationRequired = $scope.rootPost.photos.length == 1;

        function move(removeAlbum){
            $scope.photo.move_to = targetAlbum.id;
            xPostsService.editPhoto($scope.photo).then(
                function(){
                    $scope.$emit("flash", {
                        type: "success",
                        title: "Готово",
                        text: "Фотография перемещена в альбом " + targetAlbum.title
                    });
                    if(removeAlbum){
                        removeOpenAlbum();
                    }
                    else{
                        $state.go('user.post', { post_id: $scope.rootPost.id} );
                    }
                    
                },
                function(){
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Ошибка перемещения фотографии"
                    });
                }
            );
        }
        
        if(confirmationRequired){
            $scope.confirm("Перемещение последней фотографии из альбома приведет к его удалению, действительно переместить фото?").then(function(){
                move(true);
            });
        }
        else{
            move();
        }

    });

    $scope.reloadPhoto();
    //$scope.loadAlbums();

}]);

})();
