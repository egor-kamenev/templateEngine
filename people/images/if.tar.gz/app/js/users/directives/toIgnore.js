(function () {
    'use strict';
    angular.module('users.toIgnore', ['app']).directive('toIgnore', [
        '$rootScope', 'userbanService',
        function ($rootScope, userbanService) {

            var scope = {
                username: '=',
                callback: '&'
            };

            function link(scope, element) {
                element.bind('click', function () {
                    scope.ignore();
                });
            }

            function Controller($scope) {

                $scope.ignore = function () {
                    userbanService.ignoreUser($scope.username).then(
                        function (data) {
                            if (data.error) {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                            }
                            else {
                                $rootScope.$emit("flash", {
                                    type: "success",
                                    title: "Готово",
                                    text: "Пользователь добавлен в игнор"
                                });
                                if ($scope.callback) {
                                    $scope.callback();
                                }
                            }
                        }
                    );
                };
            }

            Controller.$inject = ['$scope'];

            return ({
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                scope: scope
            });
        }]);

})();