(function () {
    'use strict';
    angular.module('users.userAvatar', ['app']).directive('userAvatar', [
        'imageUrl', '$state', '$rootScope', 'userService',
        function (imageUrl, $state, $rootScope, userService) {
            return {
                restrict: "AE",
                scope: {
                    //size: '@',
                    entity: '='
                },
                replace: true,
                template: '<a data-ui-sref="user.wall({username: entity.username})"></a>',
                link: function (scope, element, attrs) {
                    function setData(user) {
                        //var size = attrs['data-size'] || attrs.size;
                        //console.info("avatar: ", scope.size);
                        var currentUser = $rootScope.user || user;
                        //var path = (size === 'big') ? 'large' : size;
                        var path = (attrs.picturesize == "\'big\'") ? 'large' : '';

                        var url = (scope.entity.avatar !== null && scope.entity.avatar !== '') ? imageUrl(scope.entity.avatar, path) : '/static/i/no-avatar.gif';
                        var online = (scope.entity.online || currentUser.username == scope.entity.username) ? 'online' : '';
                        //element.addClass('avatar avatar--' + size + ' ' + online);
                        element.addClass('avatar ' + online);
                        //element.style['background-image']= 'url(' + url + ')';
                        element.css({'background-image': 'url(' + url + ')'});
                    }
                    // restore scope.entity
                    scope.$onRootScope('avatarUploadDone', function (e, user) {
                        scope.entity.avatar = user.avatar;
                        setData();
                    });

                    if ($rootScope.user && angular.isUndefined($rootScope.user.username)) {
                        userService.getUser().then(function (user) {
                            setData(user);
                        });
                    } else {
                        setData();
                    }

                }
            };
        }]);
})();