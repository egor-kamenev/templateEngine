(function () {
    'use strict';
    angular.module('users.welcome', ['app']).directive('welcome', [
        '$rootScope', '$window', '$http', '$compile', '$templateCache', 'userService',
        function ($rootScope, $window, $http, $compile, $templateCache, userService) {

            //var scope = {
            //    user: '='
            //};

            function link(scope, element) {

                userService.getUser().then(function (user) {
                    scope.showWelcomeDialog = !user.authenticated && !$window.localStorage.hideWelcome;
                    if (scope.showWelcomeDialog) {
                        $http.get('/static/partials/users/welcome.html', {cache: $templateCache}).success(function (template) {
                            scope.modalForm = angular.element($compile(template)(scope));
                            element.after(scope.modalForm);
                        });
                    }
                    else {
                        scope.closeDialog();
                    }

                });
                /*scope.$watch('user.authenticated', function (data) {
                 //scope.showWelcomeDialog = !data && !$rootScope.hideWelcome && !$window.localStorage.hideWelcome;
                 if (scope.showWelcomeDialog) {
                 $http.get('/static/partials/users/welcome.html', {cache: $templateCache}).success(function (template) {
                 scope.modalForm = angular.element($compile(template)(scope));
                 element.after(scope.modalForm);
                 });
                 }
                 else {
                 scope.closeDialog();
                 }
                 });*/
            }

            function Controller($scope) {

                $scope.closeDialog = function () {
                    if ($scope.modalForm) {
                        $scope.modalForm.removeClass('active');
                        $scope.modalForm[0].innerHTML = '';
                    }
                };

                $scope.hideWelcome = function () {
                    $scope.closeDialog();
                    $window.localStorage.hideWelcome = true;
                };
            }

            Controller.$inject = ['$scope'];

            return ({
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true
                //scope: scope
            });
        }]);

})();