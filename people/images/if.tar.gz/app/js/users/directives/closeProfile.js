(function () {
    'use strict';
    angular.module('users.closeProfile', ['app']).directive('closeProfile', [
        '$rootScope', 'jsonRPC',
        function ($rootScope, jsonRPC) {

            var scope = {};

            function Controller($scope) {

                $scope.closeProfile = function () {
                    jsonRPC.request('users.close_profile').then(
                        function (data) {
                            if (data.error) {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Close profile error",
                                    text: data.error.data.msg
                                });
                            }
                            else {
                                $rootScope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Your profile is closed"
                                });
                                $rootScope.user = data.result;
                            }
                        }
                    );
                };

                $scope.openProfile = function () {
                    jsonRPC.request('users.open_profile').then(
                        function (data) {
                            if (data.error) {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Open profile error",
                                    text: data.error.data.msg
                                });
                            }
                            else {
                                $rootScope.$emit("flash", {
                                    type: "success",
                                    title: "Success",
                                    text: "Your profile is open"
                                });
                                $rootScope.user = data.result;
                            }
                        }
                    );
                };
            }

            Controller.$inject = ['$scope'];

            return ({
                controller: Controller,
                link: function (scope, element) {
                    element.bind('click', function () {
                        if ($rootScope.user.is_discoverable) {
                            scope.closeProfile();
                        }
                        else {
                            scope.openProfile();
                        }
                    });
                    $rootScope.$watch('user', function (value) {
                        if (value.is_discoverable) {
                            element.text('Закрыть профиль');
                        }
                        else {
                            element.text('Открыть профиль');
                        }
                    });

                },
                restrict: "AE",
                replace: true,
                scope: scope
            });
        }]);
})();