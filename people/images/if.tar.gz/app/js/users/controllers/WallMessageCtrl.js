(function(){
'use strict';

angular.module('app.controllers.wallmessagectrl', ['app']).
  controller('WallMessageCtrl', ['$scope', '$rootScope', '$q', '$state', '$stateParams', 'userService',
    'tagService', 'tagTypes', 'visibilityService', 'jsonRPC', 'channelService', 'socketio', 'StreamCode',
    function ($scope, $rootScope, $q, $state, $stateParams, userService, tagService, tagTypes, visibilityService, jsonRPC, channelService, socketio, StreamCode) {

        var reportError = function(error) {
            console.log("error: ", error);
            $scope.$emit("flash", {
                type: "error",
                title: "Error",
                text: "Message load error " + error
            });
        };

        $scope.$on('$destroy', function() {
            console.log('destroy!');
            if ($scope.channelName) {
                channelService.unsubscribe($scope.channelName).sync();
                socketio.getSocket().removeListener($scope.channelName, updateData);
            }
        });

        $scope.liked = false;


        var updateData = function(data) {
            console.log('####', data);
            if (data.code == StreamCode.CHANGED) {
                if (data.hasOwnProperty('user_id')) {
                    if (!$scope.liked) {
                        var obj = angular.extend(angular.copy($scope.message), data.content);
                        if (data.user_id === $rootScope.user.id) {
                            obj.liked = $scope.message.liked ? false : true;
                        } else {
                            obj.liked = $scope.message.liked;
                        }
                        $scope.liked = false;
                        $scope.message = obj;
                        $scope.$apply();
                    }
                }
            }
        };

        var listenSocket = function () {
            $scope.channelName = channelService.getChannelName('wallmessage', $scope.message.id);
            console.log('subsc', 'wallmessage', $scope.message.id);
            channelService.subscribe($scope.channelName).sync();
            socketio.getSocket().on($scope.channelName, updateData);
        };

        var updateMessage = function () {
            jsonRPC.request('wall.get_message', {username: $stateParams.username, id: $stateParams.messageid}).then(
                function(data) {
                    if (data.error){
                        reportError(data.error);
                    } else {
                        $scope.message = data.result;
                        //var ids = [$scope.message.id];
                        listenSocket();
                        //channelService.deleteChannel('WallMessages').
                        //addChannel('WallMessages', ids).sync();
                    }
                },
                function(data) {
                    reportError(data);
                }
            );
        };

        updateMessage();

        $scope.startEditWallMessage = function(message){
            message.isEdit = true;
        };

        $scope.deleteWallMessage = function(message){
            $rootScope.confirm("Вы уверены, что хотите удалить это сообщение?").then(function(){
                var data = {
                    message_id: message.id
                };

                jsonRPC.request('wall.delete_message', data).then(
                    function(data){
                        if(data.error){
                            if($rootScope.isLogicError(data.error)){
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка удаления поста",
                                    text: data.error.data.msg
                                });
                            }
                        }

                        else{

                            $scope.$emit("flash", {
                                type: "success",
                                title: "Готово",
                                text: "Пост удален"

                            });

                            $state.go('user');

                        }

                    },
                    function(){
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Произошла ошибка, повторите запрос позже"
                        });
                    }
                );

            });

        };

  }]);

})();