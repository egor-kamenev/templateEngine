(function () {
    'use strict';

    angular.module('app.controllers.signupctrl', []).controller('SignupCtrl', [
        '$scope', '$rootScope', '$q', '$state', '$stateParams', '$window', '$location', 'jsonRPC', 'userService',
        function ($scope, $rootScope, $q, $state, $stateParams, $window, $location, jsonRPC, userService) {

            var initial_data = {
                username: '',
                email: '',
                phone: '',
                phone_code: '',
                first_name: '',
                last_name: '',
                middle_name: '',
                date_of_birth: '',
                password: '',
                password2: '',
                eula: false
            };


            $scope.step = 1;
            $scope.new_user = initial_data;
            $scope.social_networks = [];
            // Invited, with token
            $scope.is_invited = false;

            // eula modal dlg show/hide flag
            $scope.eulaVisible = false;

            // Block registration form untill user gets resolved
            $scope.allowRegister = false;
            userService.getUser().then(function (user) {
                $scope.allowRegister = !user.authenticated;
            });

            if ($stateParams.token) {
                if ($.inArray($stateParams.token, ['facebook', 'vk', 'twitter']) > -1) {
                    $scope.user_social = $stateParams.token;
                }
                else {
                    getEmailByToken($stateParams.token);
                }
            }


            $scope.getSocialAuthPipeline = function () {

                jsonRPC.request('users.get_social_auth_pipeline').then(
                    function (response) {
                        if (response.result) {
                            if (response.result.logged_in) {

                                if (!$rootScope.user.authenticated) {
                                    $window.location.reload();
                                }
                                else {
                                    $state.go('home');
                                }
                            }
                            else {

                                angular.forEach($scope.new_user, function (value, field) {
                                    if (angular.isDefined(response.result[field])) {
                                        $scope.new_user[field] = response.result[field];
                                    }
                                });

                                $scope.new_user.social_email = '';
                                if (response.result.hasOwnProperty('email')) {
                                    $scope.new_user.social_email = response.result.email;
                                }

                                if (angular.isObject(response.result.errors)) {
                                    $scope.handleErrors($scope.signupForm, response.result.errors);
                                }

                                //angular.extend($scope.new_user, response.result);
                                var dstr = $scope.new_user.date_of_birth.split("-"),
                                    day = parseInt(dstr[2]),
                                    month = parseInt(dstr[1]),
                                    year = parseInt(dstr[0]),
                                    validBirthDate = !isNaN(day) && !isNaN(month) && !isNaN(year);

                                if (validBirthDate) {
                                    $scope.signupForm.select_day.$setViewValue(day);
                                    $scope.signupForm.select_month.$setViewValue(month);
                                    $scope.signupForm.select_year.$setViewValue(year);
                                }
                                $scope.social_registration = true;
                            }
                        }
                    },
                    function (response) {
                        console.log("Rpc error:", response);
                    }
                );

            };

            $scope.socialAuthPopup = function (backend) {

                var url = RESTANGULAR_BASE_URL + backend.associate_url,
                    wnd = $window.open(
                        url,
                        backend.title,
                        "width=500, heigth=350, location=0, toolbar=0, menu=0"
                    ),
                    timer = setInterval(function () {
                    if (wnd && wnd.closed) {
                        try {
                            $scope.$apply(function () {
                                $scope.getSocialAuthPipeline();
                            });
                        }
                        finally {
                            clearInterval(timer);
                        }
                    }
                }, 50);
            };

            $scope.sendPhoneVerificationCode = function (step) {
                userService.sendPhoneVerificationCode($scope.new_user.username, $scope.new_user.phone).then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: data.error.data.msg
                            });
                        } else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Готово",
                                text: "Код подтверждения отправлен"
                            });
                            if (step) {
                                $scope.step = step;
                            }
                        }
                    },
                    function () {
                        // general RPC error
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Ошибка",
                            text: "Ошибка, попробуйте повторить запрос позже"
                        });
                    }
                );
            };

            $scope.goNextStep = function () {
                return ($scope.step == 1) ? $scope.check_signup() : $scope.signup();
            };

            $scope.check_signup = function () {

                var deferred = $q.defer();

                jsonRPC.request('users.check_signup_form', $scope.new_user).then(function (data) {
                        if (data.error) {
                            if ($scope.isFormError(data.error)) {
                                deferred.reject(data.error.data);
                            }
                            else if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка регистрации",
                                    text: data.error.data.msg
                                });
                                deferred.reject();
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка регистрации",
                                    text: data
                                });
                            }
                        }
                        else {
                            if ($scope.new_user.phone) {
                                $scope.sendPhoneVerificationCode(2);
                                deferred.resolve();
                            }
                            else {
                                $scope.signup(deferred);
                            }
                        }
                    },
                    function () {
                        // general RPC error
                        deferred.reject();
                    }
                );
                return deferred.promise;

            };

            $scope.signup = function (firstDeffered) {

                var deferred = angular.isDefined(firstDeffered) ?  firstDeffered : $q.defer();
                jsonRPC.request('users.signup', $scope.new_user).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isFormError(data.error)) {
                                deferred.reject(data.error.data);
                            }
                            else if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data.error.data.msg
                                });
                                deferred.reject();
                            }
                            else {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: data
                                });
                            }
                        }
                        else {
                            $scope.new_user = initial_data;
                            $rootScope.reg_complete = true;

                            var credentials = {
                                username: initial_data.username,
                                password: initial_data.password,
                                confirmation_code: ''
                            };

                            // FLAG show notice email confirmation about on profile page
                            $rootScope.show_confirm_message = true; // by default

                            $rootScope.show_confirm_message = !($scope.new_user.email === $scope.new_user.invitee_email && $scope.is_invited);

                            if ($scope.new_user.email === $scope.new_user.social_email && $scope.social_registration) {
                                $rootScope.show_confirm_message = false;
                            }

                            // For T1044 - auto login after signup
                            var onSuccess = function(data){
                                if (data.error) {

                                    if(data.error.data.__all__[0] == 'inactive') {
                                        $state.go('401');
                                    }

                                    deferred.reject(data.error.data);
                                } else {
                                    if (data.result.success) {
                                        userService.setUserData(data.result);
                                        userService.setFriends(data.result.friends);
                                        userService.initialSubscribe();
                                        console.log('new session key', data.result.session_key);

                                        $rootScope.$emit("event:user.loggedIn", data.result);
                                        $state.go(data.result.url_redirect, {username: data.result.user.username});
                                        deferred.resolve();
                                    }
                                }
                            };
                            var onError = function(res) {
                                console.log("login error " + res);
                                deferred.reject();
                            };


                            // login
                            userService.login(credentials).then(onSuccess, onError);
                            /* deferred will be resolved in login callbacks */
                        }
                    },
                    function () {
                        // general RPC error
                        deferred.reject();
                    }
                );
                return deferred.promise;

            };

            function getEmailByToken(token) {
                var data = {
                    token: token
                };

                jsonRPC.request('people.get_email_by_token', data).then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: data.error.data.msg
                            });
                        }
                        else {
                            $scope.new_user.email = data.result;
                            $scope.new_user.invitee_email = data.result;
                            $scope.new_user.username = data.result.split('@')[0];
                            $scope.new_user.token = token;
                            $scope.is_invited = true;
                        }
                    }
                );
            }

            $scope.updateDays = function () {
                var max_day = 0;
                if ($scope.select_month == 2) {
                    if (!$scope.select_year % 400) {
                        max_day = 29;
                    }
                    else if (!$scope.select_year % 100) {
                        max_day = 28;
                    }
                    else if (!$scope.select_year % 4) {
                        max_day = 29;
                    }
                    else {
                        max_day = 28;
                    }
                }
                else if ($scope.select_month == 4 || $scope.select_month == 6 || $scope.select_month == 9 || $scope.select_month == 11) {
                    max_day = 30;
                }
                else {
                    max_day = 31;
                }
                $scope.Days = [];
                for (var i = 1; i <= max_day; i++) {
                    $scope.Days.push(i);
                }

                if ($scope.select_day > max_day) {
                    $scope.select_day = max_day;
                }
                $scope.updateBirthDay();
            };

            $scope.updateBirthDay = function () {

                if ($scope.select_year && $scope.select_month && $scope.select_day) {
                    $scope.new_user.date_of_birth =
                        $scope.select_year.toString() +
                        '-' +
                        $scope.select_month.toString() +
                        '-' +
                        $scope.select_day.toString();

                }
            };

            function initDate() {
                $scope.Years = [];
                var cur_year = new Date().getFullYear();
                for (var i = 0; i <= 100; i++) {
                    $scope.Years.push(cur_year - i);
                }

                var count = 0;
                $scope.Months = [];
                while (count < 12) $scope.Months.push({
                    id: count + 1,
                    name: moment().month(count++).format("MMMM")
                });
//                [
//                {id: 1, name: 'январь'},
//                {id: 2, name: 'февраль'},
//                {id: 3, name: 'март'},
//                {id: 4, name: 'апрель'},
//                {id: 5, name: 'май'},
//                {id: 6, name: 'июнь'},
//                {id: 7, name: 'июль'},
//                {id: 8, name: 'август'},
//                {id: 9, name: 'сентябрь'},
//                {id: 10, name: 'октябрь'},
//                {id: 11, name: 'ноябрь'},
//                {id: 12, name: 'декабрь'}
//            ];
                $scope.select_month = "";
                $scope.select_year = "";
                $scope.select_day = "";
                $scope.updateDays();
            }

            function getSocialAccounts() {
                $scope.social_accounts = [];
                jsonRPC.request('users.get_social_networks').then(
                    function (data) {
                        if (data.error) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: data.error.data.msg
                            });
                        }
                        else {
                            $scope.social_networks = data.result;
                            if ($scope.user_social) {
                                angular.forEach($scope.social_networks, function (network) {
                                    if (network.name == $scope.user_social) {
                                        $scope.socialAuthPopup(network);
                                    }
                                });
                            }
                        }
                    }
                );
            }

            /**
             * modal eula open flag set (show)
             */
            $scope.showEula = function() {
                $scope.eulaVisible = true;
            };

            /**
             * modal eula open flag unset (hide)
             * @param {bool} flag true - if user agree eul
             */
            $scope.hideEula = function(flag) {
                $scope.new_user.eula = flag || false;
                $scope.eulaVisible = false;
            };

            $scope.getSocialAuthPipeline();
            initDate();
            getSocialAccounts();

            $rootScope.$watch('loading', function(v, vOld){
                console.log("Loading changed: ", v, vOld);
            });
        }]);

})();
