(function(){
'use strict';

angular.module('app.controllers.userstatusesfavoritesctrl', ['app']).
  controller('UserStatusesFavoritesCtrl', ['$scope', function ($scope) {
  }]);
})();