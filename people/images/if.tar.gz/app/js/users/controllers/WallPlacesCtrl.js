(function(){
angular.module('app.controllers.wallplacesctrl', ['app']).controller('WallPlacesCtrl', [
    '$scope', '$rootScope', '$q', '$route', '$stateParams', 'userService', 'tagService', 'tagTypes', 'visibilityService', 'jsonRPC',
    function ($scope, $rootScope, $q, $route, $stateParams, userService, tagService, tagTypes, visibilityService, jsonRPC) {

        $scope.userPlaces = [];
        $scope.places_per_page = 10;
        $scope.currentPlacesPage = 1;

        $scope.listPlacesPage = function (page) {
            $scope.userPlacesShown = $scope.userPlaces.slice((page - 1) * $scope.places_per_page, page * $scope.places_per_page);
        };

        $scope.reloadUserPlaces = function () {

            $scope.userPlaces = [];
            jsonRPC.request('places.get_user_places', {username: $stateParams.username}).then(function (data) {
                if (data.error) {
                    if ($scope.isLogicError(data.error)) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Unable to get user places",
                            text: data.error.data.msg
                        });
                    }
                }
                else {
                    $scope.userPlaces = data.result;
                    $scope.noUserPlacesPages = parseInt(($scope.userPlaces.length + $scope.places_per_page - 1) / $scope.places_per_page);
                    $scope.currentPlacesPage = 1;
                    $scope.userPlacesShown = $scope.userPlaces.slice(0, $scope.places_per_page);

                    //var ids = _.map($scope.userPlacesShown, function (item) {
                    //    return item.id;
                    //});
                    //channelService.deleteChannel('Places').
                    //  addChannel('Places', ids).
                    //  sync();
                }
            });

        };


        $scope.reloadUserPlaces();
    }]);

})();