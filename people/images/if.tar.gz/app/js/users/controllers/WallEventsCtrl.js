(function(){
angular.module('app.controllers.walleventsctrl', ['app']).controller('WallEventsCtrl', [
    '$scope', '$rootScope', '$q', '$route', '$stateParams', 'userService', 'tagService', 'tagTypes', 'visibilityService', 'jsonRPC',
    function ($scope, $rootScope, $q, $route, $stateParams, userService, tagService, tagTypes, visibilityService, jsonRPC) {

        $scope.userEvents = [];
        $scope.events_per_page = 10;
        $scope.currentEventsPage = 1;

        $scope.listEventsPage = function (page) {
            $scope.userEventsShown = $scope.userEvents.slice((page - 1) * $scope.events_per_page, page * $scope.events_per_page);
        };

        $scope.reloadUserEvents = function () {
            $scope.userEvents = [];

            jsonRPC.request('events.get_user_events', {username: $stateParams.username}).then(function (data) {
                if (data.error) {
                    if ($scope.isLogicError(data.error)) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Unable to get user events",
                            text: data.error.data.msg
                        });
                    }
                }
                else {
                    $scope.userEvents = data.result;
                    $scope.noUserEventsPages = parseInt(($scope.userEvents.length + $scope.events_per_page - 1) / $scope.events_per_page);
                    $scope.currentEventPage = 1;
                    $scope.userEventsShown = $scope.userEvents.slice(0, $scope.events_per_page);
                    //var ids = _.map($scope.userEventsShown, function (item) {
                    //    return item.id;
                    //});
                    ////channelService.deleteChannel('Events__user').
                    ////  addChannel('Events__user', ids).
                    ////  sync();
                }
            });
        };

        $scope.reloadUserEvents();

    }]);

})();