(function () {
    'use strict';

    angular.module('app.controllers.userstreamctrl', ['app']).controller('UserStreamCtrl', [
        '$scope', '$rootScope', '$q', '$stateParams', 'userService', 'jsonRPC', 'channelService', 'streamCodes',
        'xPostsService', 'jqPaginationSettings', 'LoadItemsMode', 'contentItemsSourceService', 'contentEvents',
        'NotificationBlock', 'notificationBlockType',
        function ($scope, $rootScope, $q, $stateParams, userService, jsonRPC, channelService, streamCodes, xPostsService,
                  jqPaginationSettings, LoadItemsMode, contentItemsSourceService, contentEvents, NotificationBlock, notificationBlockType) {

            $scope.streamCodes = streamCodes;
            $scope.stream = [];

            /*
             OLD Pagination
            $scope.limit = jqPaginationSettings.streamLimit;
            $scope.total = 0;
            $scope.maxPage = 0;
            $scope.currentPage = $stateParams.page ? parseInt($stateParams.page, 10) : 1;
             */

            $scope.loadStream = function (options) {

                var deferred = $q.defer(),
                    
                    params = {
                        itemsCount: $scope.listViewOptions.visibleItemsCount,
                        mode: LoadItemsMode.APPEND,
                        force: options.force,
                        //contentType: 'messages', //???
                        //filterMode: 'userContent', // ???
                        offset_from: options.offsetFrom,
                        count: options.count,
                        with_total: true,
                        ts: options.ts,
                        source: {
                            fetcher: function(data){
                                return jsonRPC.request('user.get_stream', data);
                            }
                        },
                        fetcherParams: {
                            username: $stateParams.username
                        }
                    };

                contentItemsSourceService.loadItems(params).then(
                    function (data) {
                        $scope.stream = data.items;
                        $scope.listViewOptions.totalItems = data.total;
                        console.log("Data items:",  data.items);
                        if(data.items){
                            console.log("item[0]:",  data.items[0]);
                        }
                        console.log("Total stream lenth:",  $scope.listViewOptions.totalItems);

                        if (options.force) {
                            $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.stream});
                        }
                        else {
                            $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.stream});
                        }

                        deferred.resolve(data);
                    },
                    function () {
                        deferred.reject();
                    }).finally(function () {
                        $rootScope.loading = false;
                    });
                return deferred.promise;
            };

            /*
            $scope.loadStream = function () {
                var data = {
                    username: $stateParams.username,
                    page: $scope.currentPage,
                    page_size: $scope.limit,
                    with_total: true
                };

                jsonRPC.request('user.get_stream', data).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Get stream data error",
                                    text: data.error.data.msg
                                });
                            }
                            $scope.loaded = true;
                        }
                        else {
                            if (!data.result.items.length) {
                                $scope.loaded = true;
                                return;
                            }

                            $scope.stream = data.result.items;
                            $scope.total = data.result.total;
                            $scope.loaded = true;

                            if (!$scope.maxPage) $scope.maxPage = Math.ceil(parseInt($scope.total, 10) / $scope.limit);

                        }
                    },
                    function () {
                        // general RPC error
                        $scope.loaded = true;
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Server error",
                            text: "Sorry, error occurred while submitting. Please try again later."
                        });
                    }
                );
            };
             */

            $scope.getDiscussionState = function (post) {
                return xPostsService.getDiscussionStateByType(post, 'user');
            };

            //$scope.loadStream();


            $scope.listViewOptions = {
                checkOnLoad: true,
                totalItems: 0,
                maxColumns: 1,
                appendItemsCount: 5,
                visibleItemsCount: 10,
                itemComponent: NotificationBlock,
                itemComponentProps: {
                    mode: notificationBlockType.FULL
                },
                scrollContainerId: 'user-content-wrap',
                itemSelector: '.list-entry',
                loadItems: $scope.loadStream,
                compareItemsPredicate: $scope.compareItems
            };
        }]);
})();
