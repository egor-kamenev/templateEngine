(function(){
angular.module('app.controllers.userctrl', ['app']).controller('UserCtrl', [
    '$scope', '$state', '$rootScope', '$stateParams', 'userService', 'channelService', 'socketio',
    'userbanService', 'UserProfile', 'breadcrumbService', 'visibilityService','VisibilityTypes',
    function ($scope, $state, $rootScope, $stateParams, userService, channelService, socketio,
              userbanService, UserProfile, breadcrumbService, visibilityService,
              VisibilityTypes) {

        $scope.isCurrentStateHasXWall = function () {
            var state = $state.$current.self;
            return state && state.name === 'user';
        };

        //function _getCurrentState() {
        //    return breadcrumbService.currentState($scope);
        //}
        //
        //$scope.currentState = _getCurrentState();
        //$rootScope.$on('$stateChangeSuccess', function () {
        //    $scope.currentState = _getCurrentState();
        //});

        $rootScope.$onRootScope('reloadUserData', function () {
            userService.getProfileByUsername(
                $stateParams.username,
                function (data) {
                    angular.extend($scope.userObject, data);
                },
                function () {
                    $rootScope.$emit("flash", {
                        type: "error",
                        title: "Error",
                        text: "Error retrieving profile data."
                    });
                }
            );
        });

        $scope.showSectionVisibility = false;
        $scope.profileOwner = $stateParams.username;
        $scope.isOwnProfile = userService.isAuthenticated() && (userService.getUsername() === $scope.profileOwner);
        $scope.userObject = {
            "username": $stateParams.username
        };

        $scope.discussionSettingsDialogActive = false;
//        $scope.isNewFriendshipOpen = false;

        $scope.$on('$destroy', function () {
            console.log('destroy!');
            if ($scope.channelUser && $scope.channelOnline && $scope.channelOffline) {
                channelService.unsubscribe($scope.channelUser)
                    .unsubscribe($scope.channelOnline)
                    .unsubscribe($scope.channelOffline)
                    .sync();
                socketio.getSocket().removeListener($scope.channelUser, updateUserData);
            }
        });

        var updateUserData = function (data) {
            console.log('user channel', data);
            angular.extend($scope.userObject, data.content);
            $scope.profileAvatar = data.content.avatar_profile;
        };

        $rootScope.$onRootScope('event:user:online', function (data) {
            console.log('online', data);
            $scope.userObject.online = true;
        });
        $rootScope.$onRootScope('event:user:offline', function (data) {
            console.log('offline', data);
            $scope.userObject.online = false;
        });

        //var listenSocket = function () {
        //    $scope.channelUser = channelService.getChannelName('user', $scope.userObject.id);
        //    $scope.channelOnline = channelService.getChannelName('online', $scope.userObject.id);
        //    $scope.channelOffline = channelService.getChannelName('offline', $scope.userObject.id);
        //    channelService.subscribe($scope.channelUser)
        //        .subscribe($scope.channelOnline)
        //        .subscribe($scope.channelOffline)
        //        .sync();
        //    socketio.getSocket().on($scope.channelUser, updateUserData);
        //};

        if (!$scope.isOwnProfile) {
            angular.extend($scope.userObject, UserProfile.profile);
            $scope.profileAvatar = UserProfile.profile.avatar_profile;
        }
        else {
            $scope.userObject = $scope.user;
            $scope.userObject.last_location = UserProfile.profile.last_location;
        }

        $scope.username = $stateParams.username;

        // Limit available section's visibility types
        if (userService.isIncompletedUser()) {
            $scope.allowedSectionVisibilities = [VisibilityTypes.OWNER];
        }

        $scope.changeSectionVisibility = function (visibility) {
            visibilityService.switchSectionVisibility($state.current.data.privacySectionAlias, visibility);
            $scope.section_visibility = visibility;
            if ($scope.isOwnProfile) {
                $rootScope.user.section_visibilities[$state.current.data.privacySectionAlias] = visibility.visibility;
            }
        };


        $scope.isSectionAvailable = function (sectionName) {
            return $scope.isOwnProfile || UserProfile.sections.indexOf(sectionName) != -1;
        };

        $scope.isClosedProfile = function () {
            return UserProfile.sections.length === 0;
        };


        $scope.$on('$stateChangeSuccess', function (event, toState) {
            // wrap section privacy in object with nested 'visibility' attributed
            // because select-visibility directive works with objects privacy as well,
            // and awaits entity object which doesn't exists for profile section
            $scope.section_visibility = {
                alias: toState.data.privacySectionAlias,
                visibility:$state.$current.locals.resolve.$$values.sectionPrivacy
            };

            $scope.showSectionVisibility = angular.isDefined(toState.data.privacySectionAlias) && !!$scope.section_visibility;
        });

    }]);

})();
