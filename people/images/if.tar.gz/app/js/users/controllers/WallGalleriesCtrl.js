(function(){
angular.module('app.controllers.wallgalleriesctrl', ['app']).controller('WallGalleriesCtrl', [
    '$scope', '$rootScope', '$q', '$route', '$stateParams', 'userService', 'tagService', 'tagTypes', 'visibilityService', 'jsonRPC', 'galleriesService',
    function ($scope, $rootScope, $q, $route, $stateParams, userService, tagService, tagTypes, visibilityService, jsonRPC, galleriesService) {
        $scope.galleries_num = 0;
        $scope.photos_num = 0;

        $scope.attachGallery = function (gallery_id, message_index) {

            var message = $scope.wallMessages[message_index];

            var data = {
                gallery_id: gallery_id,
                message: message.id
            };

            jsonRPC.request('wall.attach_gallery', data).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Attach error",
                                text: data.error.data.msg
                            });
                        }
                    }

                    else {
                        // reloadgalleries
                        reloadMessageGalleries(message_index);
                        $scope.$emit("flash", {
                            type: "success",
                            title: "Success",
                            text: "Gallery attached"
                        });
                    }
                },
                function () {
                    // general RPC error
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Server error",
                        text: "Sorry, error occurred while submitting. Please try again later."
                    });
                }
            );

        };

        $scope.reloadRecentGalleries = function () {

            galleriesService.getGalleries($scope.wall_owner, true).then(
                function (galleries) {
                    $scope.recentGalleries = galleries;
                    //var ids = _.map($scope.recentGalleries, function (item) {
                    //    return item.id;
                    //});
                    //channelService.deleteChannel('Galleries').
                    //  addChannel('Galleries', ids).
                    //  sync();

                },
                function () {
                    $scope.recentGalleries = [];
                    //channelService.deleteChannel('Galleries');
                }
            );

            galleriesService.getSummary($scope.wall_owner).then(
                function (summary) {
                    $scope.galleries_num = summary.galleries_num;
                    $scope.photos_num = summary.photos_num;

                },
                function () {
                    $scope.galleries_num = 0;
                    $scope.photos_num = 0;
                }
            );

        };
        $scope.reloadRecentGalleries();

    }]);

})();