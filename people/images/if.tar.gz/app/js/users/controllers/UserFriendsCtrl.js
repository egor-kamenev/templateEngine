(function () {
    'use strict';

    angular.module('app.controllers.userfriendsctrl', ['app']).controller('UserFriendsCtrl', [
        '$scope', '$q', '$rootScope', '$stateParams', 'jsonRPC', 'tagService', 'tagTypes', 'userService', '$timeout',
        'contentItemsSourceService', 'contentEvents', 'contentSettings', 'rFriendListItem',
        function ($scope, $q, $rootScope, $stateParams, jsonRPC, tagService, tagTypes, userService, $timeout,
                  contentItemsSourceService, contentEvents, contentSettings, rFriendListItem) {
            contentItemsSourceService.setForceFlag(true, contentSettings.CONTENT_TYPES.FRIENDS);

            $scope.friends = [];
            $scope.invitations = [];

            $scope.username = $stateParams.username;
            $scope.isOwnProfile = $rootScope.user.authenticated && $rootScope.user.username == $scope.username;

            $scope.tagsEditor = tagService.getTagSelector('friendship_tags');

            $scope.username = $stateParams.username;
            $scope.dataSource = [];

            $scope.loadFriends = function (options) {
                var deferred = $q.defer();

                //$rootScope.loading = true;

                if (!options.ts) {
                    options.ts = moment().valueOf();
                }

                var params = {
                    itemsCount: $scope.listViewOptions.visibleItemsCount,
                    mode: options.mode,
                    force: options.force,
                    contentType: contentSettings.CONTENT_TYPES.FRIENDS,
                    filterMode: 'userContent',
                    offset_from: options.offsetFrom,
                    count: options.count,
                    with_total: true,
                    ts: options.ts,
                    source: {
                        fetcher: function (data) {
                            return jsonRPC.request('people.get_friends', data);
                        }
                    },
                    fetcherParams: {
                        username: $scope.username
                    }
                };

                contentItemsSourceService.loadItems(params).then(
                    function (data) {
                        $scope.friends = contentItemsSourceService.getCurrentItemsSource(params.contentType, params.filterMode);
                        $scope.listViewOptions.totalItems = data.total;

                        if (options.force) {
                            $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.friends});
                        }
                        else {
                            $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.friends});
                        }

                        deferred.resolve(data);
                    },
                    function () {
                        deferred.reject();
                    }).finally(function () {
                        //$rootScope.loading = false;
                    });

                return deferred.promise;
            };

            $scope.listViewOptions = {
                checkOnLoad: true,
                totalItems: 0,
                maxColumns: 3,
                //itemComponentName: 'rFriendListItem',
                itemComponent: rFriendListItem,
                appendItemsCount: 50,
                visibleItemsCount: 100,
                scrollContainerId: 'user-content-wrap',
                loadItems: $scope.loadFriends
            };

            $rootScope.$onRootScope("friendAdded", function () {
                console.log('friend added');
                $scope.friends = userService.friends;
            });

            $rootScope.$onRootScope("reloadFriends", function () {
                $scope.loadFriends({force: true});
            });

            $rootScope.$onRootScope("friendshipBroken", function (e, friendshipID) {
                var removedFriend = _.find($scope.friends, function (f) {
                    return f.id == friendshipID;
                });

                if (removedFriend) {
                    contentItemsSourceService.setForceFlag(true, contentSettings.CONTENT_TYPES.FRIENDS);
                    $scope.friends = _.without($scope.friends, removedFriend);
                    $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.friends});
                }
            });
        }]);

})();
