(function () {
    'use strict';

    angular.module('app.controllers.usersubscriptionsctrl', ['app']).controller('UserSubscriptionsCtrl', [
        '$q', '$scope', '$rootScope', 'subscriptionsService', 'channelService', 'socketio', 'StreamCode',
        '$stateParams', 'contentType', 'contentItemsSourceService', 'LoadItemsMode', 'contentSettings', 'contentEvents',
        'rEventListItem', 'rPlaceListItem', 'rUserListItem',
        function ($q, $scope, $rootScope, subscriptionsService, channelService, socketio, StreamCode,
                  $stateParams, contentType, contentItemsSourceService, LoadItemsMode, contentSettings, contentEvents,
                  rEventListItem, rPlaceListItem, rUserListItem) {

            $scope.dataSource = [];

            var itemsTemplates = {};
            itemsTemplates[contentSettings.CONTENT_TYPES.EVENTS] = rEventListItem;
            itemsTemplates[contentSettings.CONTENT_TYPES.PLACES] = rPlaceListItem;
            itemsTemplates[contentSettings.CONTENT_TYPES.USERS] = rUserListItem;
            itemsTemplates[contentSettings.CONTENT_TYPES.FRIENDS] = rUserListItem;


            //var reloadSubscriptionsTimestamp = null;
            //var minReloadInterval = moment.duration(500, 'milliseconds').asMilliseconds();

            //function sortSubscriptions(subs) {
            //    return _.sortBy(subs, function (e) {
            //        return e.id;
            //    });
            //}

            $scope.isUsersSubscriptions = function () {
                return contentType === contentSettings.CONTENT_TYPES.USERS;
            };
            $scope.isEventsSubscriptions = function () {
                return contentType === contentSettings.CONTENT_TYPES.EVENTS;
            };
            $scope.isPlacesSubscriptions = function () {
                return contentType === contentSettings.CONTENT_TYPES.PLACES;
            };
            $scope.isFriendsSubscriptions = function () {
                return contentType === contentSettings.CONTENT_TYPES.FRIENDS;
            };

            function pushSubscribe(sub) {
                console.log('add', $scope.dataSource, sub);
                if (!_.contains(_.pluck($scope.dataSource, 'id'), sub.id)) {
                    $scope.dataSource.push(sub.entity);
                    //$scope.dataSource = sortSubscriptions($scope.dataSource);
                    $scope.$apply();
                }
            }

            function delSubscribe(sub) {
                console.log('del', $scope.dataSource, sub);
                if (_.contains(_.pluck($scope.dataSource, 'id'), sub.id)) {
                    $scope.dataSource = _.reject($scope.dataSource, function (e) {
                        return e.id === sub.id;
                    });
                    $scope.$apply();
                }
            }

            var socketListened = false;

            $scope.loadItems = function (options) {
                var deferred = $q.defer();

                if (!options.ts) {
                    options.ts = moment().valueOf();
                }

                var params = {
                    itemsCount: $scope.listViewOptions.visibleItemsCount,
                    mode: options.mode,
                    force: options.force,
                    contentType: contentType,
                    offset_from: options.offsetFrom,
                    count: options.count,
                    with_total: true,
                    ts: options.ts,
                    source: {
                        fetcher: subscriptionsService.getSubscriptions,
                        itemSelector: function (item) {
                            return item.entity;
                        }
                    },
                    fetcherParams: {
                        content_type: contentType
                    }
                };

                contentItemsSourceService.loadItems(params).then(
                    function (data) {
                        $scope.dataSource = data.items;
                        $scope.listViewOptions.totalItems = data.total;

                        if (options.force) {
                            $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.dataSource});
                        }
                        else {
                            $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.dataSource});
                        }

                        if (!socketListened) {
                            socketListened = true;
                            listenSocket();
                        }

                        deferred.resolve(data);
                    },
                    function () {
                        deferred.reject();
                    }).finally(function () {
                        $rootScope.loading = false;
                    });

                return deferred.promise;
            };

            $scope.$onRootScope("event_subscriptionToggled", function () {
                var params = {
                    offsetFrom: 0,
                    count: $scope.listViewOptions.visibleItemsCount,
                    mode: LoadItemsMode.APPEND,
                    force: true
                };

                $scope.loadItems(params);
            });


            var updateData = function (data) {
                console.log('update data', data);
                if (data.content.entity_model === 'event') {
                    if (data.code === StreamCode.CREATED) {
                        pushSubscribe(data.content);
                    } else if (data.code === StreamCode.DELETED) {
                        delSubscribe(data.content);
                    }
                }
            };

            var listenSocket = function () {
                $scope.channelName = channelService.getChannelName('subscriptions');
                channelService.subscribe($scope.channelName).sync();
                socketio.getSocket().on($scope.channelName, updateData);
            };

            $scope.$on('$destroy', function () {
                console.log('destroy!');
                if ($scope.channelName) {
                    channelService.unsubscribe($scope.channelName).sync();
                }
            });

            $scope.listViewOptions = {
                checkOnLoad: true,
                totalItems: 0,
                maxColumns: 3,
                appendItemsCount: 50,
                visibleItemsCount: 100,
                //itemComponentName: itemsTemplates[contentType],
                itemComponent: itemsTemplates[contentType],
                scrollContainerId: 'user-content-wrap',
                loadItems: $scope.loadItems
            };
        }
    ])
    ;

})();