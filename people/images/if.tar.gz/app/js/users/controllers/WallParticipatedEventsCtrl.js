(function(){
angular.module('app.controllers.wallparticipatedeventsctrl', ['app']).controller('WallParticipatedEventsCtrl', [
    '$scope', '$rootScope', '$q', '$route', '$stateParams', 'userService', 'tagService', 'tagTypes', 'visibilityService', 'jsonRPC', 'galleriesService', 'channelService',
    function ($scope, $rootScope, $q, $route, $stateParams, userService, tagService, tagTypes, visibilityService, jsonRPC) {

        $scope.userParticipateEvents = [];
        $scope.participate_events_per_page = 10;
        $scope.currentParticipateEventsPage = 1;

        $scope.listParticipateEventsPage = function (page) {
            $scope.userParticipateEventsShown = $scope.userParticipateEvents.slice((page - 1) * $scope.participate_events_per_page, page * $scope.participate_events_per_page);
        };

        $scope.reloadParticipateUserEvents = function () {

            $scope.userParticipateEvents = [];

            jsonRPC.request('events.get_user_participate_events', {username: $stateParams.username}).then(function (data) {
                if (data.error) {
                    if ($scope.isLogicError(data.error)) {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Unable to get user events",
                            text: data.error.data.msg
                        });
                    }
                }
                else {

                    $scope.userParticipateEvents = data.result;
                    $scope.noUserParticipateEventsPages = parseInt(($scope.userParticipateEvents.length + $scope.participate_events_per_page - 1) / $scope.participate_events_per_page);
                    $scope.currentParticipateEventPage = 1;
                    $scope.listParticipateEventsPage(1);

                    //var ids = _.map($scope.userParticipateEvents, function (item) {
                    //    return item.id;
                    //});
                    //channelService.deleteChannel('Events__participated').
                    //  addChannel('Events__participated', ids).
                    //  sync();
                }
            });

        };

        $scope.reloadParticipateUserEvents();

    }]);

})();