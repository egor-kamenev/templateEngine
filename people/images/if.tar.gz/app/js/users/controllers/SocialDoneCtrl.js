(function(){
'use strict';

angular.module('app.controllers.socialdonectrl', [])
  .controller('SocialDoneCtrl', ['$scope', '$window', function ($scope, $window) {

        $window.close();

    }]);

})();