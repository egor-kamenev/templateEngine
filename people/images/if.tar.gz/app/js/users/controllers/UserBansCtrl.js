(function () {
    'use strict';
    angular.module('app.controllers.userbansctrl', ['app']).controller('UserBansCtrl', ['$scope', function ($scope) {
    }]);
})();