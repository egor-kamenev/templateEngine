(function(){
angular.module('app.controllers.detailctrl', []).controller('DetailCtrl', [
    '$scope', '$rootScope', '$q', '$route', '$stateParams', 'userService', 'tagService', 'tagTypes', 'visibilityService', 'jsonRPC',
    function ($scope, $rootScope, $q, $route, $stateParams, userService, tagService, tagTypes, visibilityService, jsonRPC) {
        $scope.isNewMessageVisible = false;
        var initialMessage = {
            body: ''
        };

        $scope.message = angular.copy(initialMessage);

        $scope.closeNewMessageDialog = function () {
            $scope.isNewMessageVisible = false;
        };

        $scope.openNewMessageDialog = function () {
            if (!$scope.user.authenticated) {
                $scope.openRegModal('/' + $scope.wall_owner.username);
                return;
            }
            $scope.isNewMessageVisible = true;
        };

        $scope.sendMessage = function () {
            var deferred = $q.defer();
            var data = angular.copy($scope.message);
            data.users = [
                {id: $scope.userGeneralInfo.id}
            ];

            jsonRPC.request('messages.send_message', data).then(
                function (data) {
                    if (data.error) {
                        if ($rootScope.isFormError(data.error)) {
                            deferred.reject(data.error.data);
                        }
                        else if ($rootScope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Send message error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }
                    }
                    else {
                        $scope.message = angular.copy(initialMessage);
                        $scope.$emit("flash", {
                            type: "success",
                            title: "Message was went successful"
                        });
                        deferred.resolve();
                    }
                },
                function () {
                    deferred.reject();
                }
            );
            $scope.closeNewMessageDialog();
            return deferred.promise;
        };

    }]);

})();