(function(){
angular.module('app.controllers.userwallctrl', ['app']).controller('UserWallCtrl', [
    '$scope', '$state', 'UserProfile', function ($scope, $state, UserProfile) {
        $scope.sectionVisible = UserProfile.sections.indexOf($state.current.data.privacySectionAlias) != -1;
        $scope.canAddXPosts = function () {
            return $scope.isOwnProfile;
        };
    }]);

})();