(function () {
    'use strict';

    angular.module('app.controllers.usersubscribersctrl', ['app']).controller('UserSubscribersCtrl', [
        '$q', '$scope', 'subscriptionsService', '$stateParams', '$rootScope', 'contentType',
        'contentItemsSourceService', 'contentEvents', 'rUserListItem',
        function ($q, $scope, subscriptionsService, $stateParams, $rootScope, contentType, contentItemsSourceService,
                  contentEvents, rUserListItem) {

            $scope.dataSource = [];

            //$scope.maxColumns = 3;
            //$scope.totalItems = 0;
            //$scope.currentItemTemplate = 'rUserListItem';

            //$scope.appendItemsCount = 50;
            //$scope.visibleItemsCount = 100;

            $scope.loaded = false;

            $scope.loadItems = function (options) {
                var deferred = $q.defer();

                if (!options.ts) {
                    options.ts = moment().valueOf();
                }

                var params = {
                    itemsCount: $scope.listViewOptions.visibleItemsCount,
                    mode: options.mode,
                    force: options.force,
                    contentType: contentType,
                    offset_from: options.offsetFrom,
                    count: options.count,
                    with_total: true,
                    ts: options.ts,
                    source: {
                        fetcher: subscriptionsService.getSubscribersByParams
                    },
                    fetcherParams: {
                        content_type: contentType
                    }
                };

                contentItemsSourceService.loadItems(params).then(
                    function (data) {
                        $scope.loaded = true;
                        $scope.dataSource = data.items;
                        $scope.listViewOptions.totalItems = data.total;

                        if (options.force) {
                            $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.dataSource});
                        }
                        else {
                            $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.dataSource});
                        }

                        deferred.resolve(data);
                    },
                    function () {
                        deferred.reject();
                    }).finally(function () {
                        $rootScope.loading = false;
                    });

                return deferred.promise;
            };


            $scope.listViewOptions = {
                checkOnLoad: true,
                totalItems: 0,
                maxColumns: 3,
                appendItemsCount: 50,
                visibleItemsCount: 100,
                //itemComponentName: 'rUserListItem',
                itemComponent: rUserListItem,
                scrollContainerId: 'user-content-wrap',
                loadItems: $scope.loadItems
            };

        }]);

})();