(function () {
    'use strict';
    angular.module('app.controllers.userinterestsctrl', ['app']).controller('UserInterestsCtrl', [
        '$scope', '$rootScope', '$stateParams', '$q', '$state', 'jsonRPC', 'userService', 'tagService', 'tagTypes', 'filtersService',
        function ($scope, $rootScope, $stateParams, $q, $state, jsonRPC, userService, tagService, tagTypes, filtersService) {

            $scope.newInterests = {
                tags: []
            };
            $scope.tagsEditor = tagService.getTagSelector();
            $scope.username = $stateParams.username;

            $scope.reloadInterests = function () {
                $scope.interests = [];
                userService.getInterests($scope.username).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Get interests error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.interests = data.result;
                        }
                    },
                    function () {
                        $scope.$emit("flash", {
                            type: "error",
                            title: "Get interests error",
                            text: "Get interests error"
                        });
                    }
                );
            };

            $scope.addNewInterests = function () {

                //var deferred = $q.defer();
                var data = {
                    'interests': tagService.convertTagsToRPCData($scope.newInterests.tags)
                };

                jsonRPC.request('users.add_interests', data).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Done",
                                text: "Interests were added"
                            });
                            $scope.newInterests = {
                                tags: []
                            };
                            $scope.reloadInterests();
                        }
                    }
                );
            };

            $scope.removeInterest = function (name) {

                if (!$scope.isOwnProfile) return;

                var data = {
                    'name': name
                };

                jsonRPC.request('users.remove_interest', data).then(
                    function (data) {
                        if (data.error) {
                            if ($scope.isLogicError(data.error)) {
                                $scope.$emit("flash", {
                                    type: "error",
                                    title: "Error",
                                    text: data.error.data.msg
                                });
                            }
                        }
                        else {
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Done",
                                text: "Interest was removed"
                            });
                            $scope.reloadInterests();
                        }
                    }
                );
            };

            $scope.showUsed = function (interest) {

                if (!interest.show_used) {
                    //var deferred = $q.defer();
                    var data = {
                        'name': interest.name
                    };
                    jsonRPC.request('tags.get_objects_used', data).then(
                        function (data) {
                            if (data.error) {
                                if ($scope.isLogicError(data.error)) {
                                    $scope.$emit("flash", {
                                        type: "error",
                                        title: "Error",
                                        text: data.error.data.msg
                                    });
                                }
                            }
                            else {
                                interest.objects_used = data.result;
                            }
                        }
                    );
                }
                interest.show_used = !interest.show_used;
            };

            $scope.goToFilteredObjects = function (class_name, tag) {
                var filter_tag = angular.copy(tag),
                    typeToFilterMapping = {
                        'User': 'users',
                        'Event': 'events',
                        'UserPlace': 'places'
                    },
                    contentType = typeToFilterMapping[class_name];

                if (contentType) {
                    // filter tag is a little bit different from the object tag
                    // it's id is a tag name, and it has a type.
                    filter_tag.id = tag.name;
                    filter_tag.tag_type = filtersService.term_type_tag;

                    filtersService.resetFilters();
                    filtersService.setGlobalTags([filter_tag]);
                    $rootScope.switchFilterContentType(contentType);
                    $state.go('content', filtersService.toParams());

                }
                else {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Тип данных не поддерживается фильтром"
                    });
                }
            };

            $scope.reloadInterests();
        }]);

})();
