(function () {
    'use strict';

    angular.module('app.controllers.usercontentctrl', [])
        .directive('autoSizedContainer', [
            '$window', '$timeout',
            function ($window, $timeout) {
                return {
                    restrict: 'AE',
                    replace: false,
                    scope: false,
                    link: function (scope, element) {
                        function resizeElement() {
                            var bottomMargin = 20;
                            $(element).height($('body').height() - $(element).offset().top - bottomMargin);
                        }

                        angular.element(document).ready(function () {
                            $timeout(resizeElement, 0);
                        });

                        angular.element($window).bind('resize', _.debounce(function () {
                            resizeElement();
                        }, 100));
                    }
                };
            }
        ])
        .controller('UserContentCtrl', [
            '$rootScope', '$scope', '$stateParams', '$q', 'contentType', 'contentEvents', 'contentSettings',
            'contentItemsSourceService', '$timeout', 'rEventListItem', 'rPlaceListItem', 'rUserListItem',
            function ($rootScope, $scope, $stateParams, $q, contentType, contentEvents, contentSettings,
                      contentItemsSourceService, $timeout, rEventListItem, rPlaceListItem, rUserListItem) {

                //clear previous items (T914)
                contentItemsSourceService.getCurrentItemsSource(contentType).length = 0;

                $scope.username = $stateParams.username;

                var itemsTemplates = {};
                itemsTemplates[contentSettings.CONTENT_TYPES.EVENTS] = rEventListItem;
                itemsTemplates[contentSettings.CONTENT_TYPES.PLACES] = rPlaceListItem;
                itemsTemplates[contentSettings.CONTENT_TYPES.USERS] = rUserListItem;

                $scope.dataSource = [];

                var request_timestamp = null;
                var updateInterval = 10000;

                function getRequestTimestamp() {
                    var now = moment().valueOf();
                    if (request_timestamp === null || (now - request_timestamp) >= updateInterval) {
                        request_timestamp = now;
                    }
                    return request_timestamp;
                }

                $scope.loadItems = function (options) {
                    var deferred = $q.defer();
                    $rootScope.loading = true;
                    if (!options.ts) {
                        options.ts = getRequestTimestamp();
                    }

                    var params = {
                        itemsCount: $scope.listViewOptions.visibleItemsCount,
                        mode: options.mode,
                        force: options.force,
                        contentType: contentType,
                        //filterMode: 'userContent',
                        offset_from: options.offsetFrom,
                        count: options.count,
                        filters: {
                            owner: $scope.username
                        },
                        ts: options.ts,
                        with_total: true
                    };

                    contentItemsSourceService.loadItems(params).then(
                        function (data) {
                            $scope.dataSource = contentItemsSourceService.getCurrentItemsSource(contentType);
                            $scope.listViewOptions.totalItems = data.total;

                            if (options.force) {
                                $scope.$broadcast(contentEvents.OBJECTS_RELOADED, {items: $scope.dataSource});
                            }
                            else {
                                $scope.$broadcast(contentEvents.OBJECTS_LOADED, {items: $scope.dataSource});
                            }

                            deferred.resolve(data);
                        },
                        function () {
                            deferred.reject();
                        }).finally(function () {
                            $rootScope.loading = false;
                        });

                    return deferred.promise;
                };

                $scope.listViewOptions = {
                    checkOnLoad: true,
                    totalItems: 0,
                    maxColumns: 3,
                    appendItemsCount: 50,
                    visibleItemsCount: 100,
                    //itemComponentName: itemsTemplates[contentType],
                    itemComponent: itemsTemplates[contentType],
                    scrollContainerId: 'user-content-wrap',
                    loadItems: $scope.loadItems
                };
            }
        ]);

})();