(function(){
'use strict';

angular.module('app.controllers.userstatusesctrl', ['app']).
    controller('UserStatusesCtrl', ['$scope', '$q', 'jsonRPC', 'userService', 'tagService', 'permissionRequired', function ($scope, $q, jsonRPC, userService, tagService, permissionRequired) {

        var initialStatus = {
            status: {
                tags: []
            }
        };
        $scope.newStatus = angular.copy(initialStatus);

        $scope.tagsEditor = tagService.getTagSelector();

        $scope.statusHistory = [];
        $scope.statusFavorites = [];

        $scope.currentStatus = {};
        $scope.currentStatus.id = -1;
        $scope.currentStatus.text = '';
        $scope.currentStatus.tags = [];

        // History pagination
        $scope.currentPage = 1;
        $scope.history_per_page = 5;

        $scope.listPage = function (page) {
            $scope.shownHistory = $scope.statusHistory.slice((page - 1) * $scope.history_per_page, page * $scope.history_per_page);
        };

        $scope.addStatus = permissionRequired('statuses.add_status', function () {

            var deferred = $q.defer();
            var data = angular.copy($scope.newStatus);
            data.tags = tagService.convertTagsToRPCData(data.tags);

            jsonRPC.request('statuses.add_status', data).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isFormError(data.error)) {
                            deferred.reject(data.error.data);
                        }
                        else if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Add status error",
                                text: data.error.data.msg
                            });
                            deferred.reject();
                        }
                    }
                    else {
                        // New status becomes active
                        $scope.currentStatus.text = $scope.newStatus.text;
                        $scope.currentStatus.tags = $scope.newStatus.tags;

                        $scope.favStatus = '';
                        // Reset form state to initial
                        $scope.newStatus = angular.copy(initialStatus);


                        $scope.$emit("flash", {
                            type: "success",
                            title: "Success",
                            text: "Status set successfully"
                        });

                        $scope.reloadHistory();
                        deferred.resolve();
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Add status error",
                        text: "Add status error"
                    });
                    deferred.reject();
                }
            );
            return deferred.promise;
        });


        $scope.toggleFav = permissionRequired('statuses.change_status', function (status_id) {

            var data = {
                status_id: status_id
            };

            jsonRPC.request('statuses.toggle_favorite', data).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Toggle favorite status error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        for (var i in $scope.statusHistory) {
                            if ($scope.statusHistory[i].id == status_id) {
                                $scope.statusHistory[i].favorite = data.result;
                                break;
                            }
                        }
                        $scope.reloadFavorites();
                        $scope.$emit("flash", {
                            type: "success",
                            title: "Done",
                            text: "Favorite flag switched"
                        });
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Toggle favorite status error",
                        text: "Toggle favorite status error"
                    });
                }
            );
        });

        $scope.setStatus = permissionRequired('statuses.change_status', function (status_id) {

            var data = {
                status_id: status_id
            };

            jsonRPC.request('statuses.set_active', data).then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Set status error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        for (var i in $scope.statusHistory) {
                            if ($scope.statusHistory[i].id == status_id) {
                                $scope.currentStatus = angular.copy($scope.statusHistory[i]);
                                $scope.reloadHistory();
                                break;
                            }
                        }

                        $scope.$emit("flash", {
                            type: "success",
                            title: "Done",
                            text: "Status set"
                        });

                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Set status error",
                        text: "Set status error"
                    });
                }
            );

        });

        $scope.reloadFavorites = function () {
            $scope.statusFavorites = [];
            for (var i in $scope.statusHistory) {
                if ($scope.statusHistory[i].favorite) {
                    $scope.statusFavorites.push($scope.statusHistory[i]);
                }
            }
        };

        $scope.reloadHistory = function () {
            $scope.statusHistory = [];

            jsonRPC.request('statuses.get_history').then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Get status history error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        $scope.statusHistory = data.result;
                        $scope.noHistoryPages = parseInt(($scope.statusHistory.length + $scope.history_per_page - 1) / $scope.history_per_page);
                        $scope.listPage(1);
                        $scope.reloadFavorites();
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Get status history error",
                        text: "Get status history error"
                    });
                }
            );
        };

        $scope.reloadCurrent = function () {

            $scope.currentStatus.text = '';
            $scope.currentStatus.tags = [];

            jsonRPC.request('statuses.get_current').then(
                function (data) {
                    if (data.error) {
                        if ($scope.isLogicError(data.error)) {
                            $scope.$emit("flash", {
                                type: "error",
                                title: "Get status error",
                                text: data.error.data.msg
                            });
                        }
                    }
                    else {
                        $scope.currentStatus.id = data.result.id;
                        $scope.currentStatus.text = data.result.text;
                        $scope.currentStatus.tags = data.result.tags;
                    }
                },
                function () {
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Get status error",
                        text: "Get status error"
                    });
                }
            );
        };

        $scope.reloadHistory();
        $scope.reloadCurrent();
    }]);

})();
