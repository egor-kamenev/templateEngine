(function(){
angular.module('users.services.location', [])
    .service('userLocationService',
    [
        '$rootScope', '$location', 'jsonRPC', 'languages', '$q', 'permissionRequired',
        function ($rootScope, $location, jsonRPC, languages, $q, permissionRequired) {
            var self = this;

            var showLocationWarningMinInterval = 1000;
            var warningMessageLastTime = null;

            this._location = null;
            this._isGeolocationDetected = null;
            this._geolocationFailedNotified = false;
            this._geolocationDenied = false;
            this._geolocationBlocked = false;

            var showWarningMessage = function (positionError, ignorePreviousMessages) {
                var nowTs = moment().valueOf();
                var dt = nowTs - (warningMessageLastTime || 0);
                warningMessageLastTime = nowTs;

                if ((!self._geolocationFailedNotified || ignorePreviousMessages === true) && dt > showLocationWarningMinInterval) {
                    self._geolocationFailedNotified = true;
                    $rootScope.$emit("flash", {
                        type: "error",
                        title: "Ошибка",
                        text: "Включите поддержку определения местоположения в браузере"
                    });
                }
            };

            var onError = function (positionError, warningMessageAllowed) {
                if (warningMessageAllowed !== false && USE_BROWSER_GEOLOCATION_API === true) {
                    showWarningMessage(positionError);
                }
            };

            var onSuccess = function (position) {

            };

            this._defaultLocateOptions = {
                timeout: 10000,
                maximumAge: 0,
                enableHighAccuracy: true,

                success: onSuccess,
                error: onError,
                showWarningMessage: true,

                fallbackByIP: false
            };


            var checkIsGeolocationAvailable = function () {
                return USE_BROWSER_GEOLOCATION_API === true && !!navigator.geolocation;
            };

            var getCurrentPositionUsingGeolocation = function (force, options) {
                var deferred = $q.defer();

                self._isGeolocationDetected = checkIsGeolocationAvailable();
                var geolocationOptions = angular.extend({}, self._defaultLocateOptions, options);
                if (self._isGeolocationDetected && (force === true || !self._location || self._location.isRaw)) {
                    self._geolocationBlocked = true;
                    navigator.geolocation.getCurrentPosition(
                        function (position) {
                            self._geolocationBlocked = false;
                            if (position && position.coords) {
                                var result = {
                                    latitude: position.coords.latitude,
                                    longitude: position.coords.longitude,
                                    accuracy: position.coords.accuracy,
                                    timestamp: position.timestamp,
                                    isRaw: false
                                };

                                if (angular.isFunction(geolocationOptions.success)) {
                                    geolocationOptions.success(result);
                                }

                                deferred.resolve(result);
                            }
                            else {
                                if (geolocationOptions.fallbackByIP === true) {
                                    return getCurrentPositionByIP(force, geolocationOptions);
                                }

                                deferred.resolve(null);
                            }
                        },
                        function (positionError) {
                            self._geolocationBlocked = false;
                            console.log('geolocation failed:', positionError);

                            if (positionError.code === positionError.PERMISSION_DENIED) {
                                self._geolocationDenied = true;
                            }

                            if (geolocationOptions.fallbackByIP === true) {
                                return getCurrentPositionByIP(force, geolocationOptions);
                            }

                            if (angular.isFunction(geolocationOptions.error)) {
                                geolocationOptions.error(positionError);
                            }

                            deferred.reject(positionError);
                        },
                        geolocationOptions);
                }
                else {
                    if (self._isGeolocationDetected) {
                        deferred.resolve(self._location);
                    }
                    else {
                        deferred.reject(null);
                    }
                }

                return deferred.promise;
            };

            var getCurrentPositionByIP = function (force, options) {
                var deferred = $q.defer();

                if (force === true || !self._location || !self._location.isRaw) {
                    jsonRPC.request('users.get_ip_location').then(
                        function (response) {
                            if (response.error) {
                                console.log('geolocation by IP failed:', error);

                                if (angular.isFunction(options.error)) {
                                    options.error(response.error);
                                }

                                deferred.reject(error);
                            }
                            else {

                                var result = {
                                    latitude: response.result.lat,
                                    longitude: response.result.lng,
                                    isRaw: true
                                };

                                if (angular.isFunction(options.success)) {
                                    options.success(result);
                                }

                                deferred.resolve(result);
                            }
                        },
                        function (error) {
                            console.log('geolocation by IP failed:', error);

                            if (angular.isFunction(options.error)) {
                                options.error(error);
                            }

                            deferred.reject(error);
                        }
                    );
                }
                else {
                    deferred.resolve(self._location);
                }

                return deferred.promise;
            };

            var getGeolocationDetected = function(){
                if (self._isGeolocationDetected === null) {
                    self._isGeolocationDetected = checkIsGeolocationAvailable();
                }
                return self._isGeolocationDetected;
            };

            return {
                addUserLocation: permissionRequired('users.add_userlocationhistory', function (place_id, visibility) {
                    var data = {place_id: place_id, visibility: visibility};
		    return jsonRPC.request('events.check_in', data);
                }),
                getUserLocation: function (force, options) {
                    return getCurrentPositionUsingGeolocation(force, options).then(function (position) {
                        self._location = position;
                        return position;
                    });
                },
                //getUserLocationByIP: function (force, options) {
                //    return getCurrentPositionByIP(force, options).then(function (position) {
                //        self._location = position;
                //        return position;
                //    });
                //},
                showWarningIfGeolocationNotAvailable: function () {
                    if (USE_BROWSER_GEOLOCATION_API === true) {
                        if (self._isGeolocationDetected === null) {
                            self._isGeolocationDetected = checkIsGeolocationAvailable();
                        }

                        if (!self._isGeolocationDetected || self._geolocationDenied) {
                            showWarningMessage(null, true);
                        }
                    }
                },
                get userLocation() {
                    return self._location;
                },
                //get geolocationBlocked() {
                //    return self._geolocationBlocked;
                //},
                //get geolocationDenied() {
                //    return self._geolocationDenied;
                //},
                //get geolocationDetected() {
                //    return getGeolocationDetected();
                //},
                get geolocationAvailable(){
                    return !self._geolocationDenied && !self._geolocationBlocked && getGeolocationDetected();
                }
            };
        }
    ]);

})();