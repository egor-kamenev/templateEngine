(function () {
    'use strict';
    angular.module('users.services', ['ui.router.util'])
        .service('userService', [
            '$rootScope', '$location', 'jsonRPC', 'languages', '$q', 'channelService', 'socketio',
            function ($rootScope, $location, jsonRPC, languages, $q, channelService, socketio) {

                var self = this;

                self.userDefer = $q.defer();
                self.userDeferResolved = false;

                // T1133
                // this.permissions_map = {};
                // this.permissions_cache = [];
                // this.roles_cache = [];
                this.roles = [];
                this.permissions = [];

                this.birthdate_notification_shown = false;
                this.register_notification_shown = false;
                this.social_association_notifications_shown = false;
                this.social_registration_notifications_shown = false;
                this.initSubscribed = false;

                this._lastUsedFilter = null;
                this._cachedUsers = [];
                this._cachedStreamUsers = [];

                $rootScope.$onRootScope('event:socketio.connected', function () {
                    console.log('listen socket connected', self.user, socketio.getSocket());
                    self.initialSubscribe();
                });

                // This promise becomes resolved after login is checked
                var hold = false;
                this.getUser = function (force) {
                    var force_reload = force || false;

                    if (!hold && (force_reload || (!force_reload && !self.userDeferResolved))) {
                        hold = true;
                        jsonRPC.request('users.check_login').then(
                            function (response) {
                                if (!response.error) {

                                    angular.extend(self.user, response.result.user);

                                    self.user.last_location = {};
                                    self.user.interests = [];
                                    self.user.used_friendship_tags = [];

                                    if (response.result.user && response.result.user.last_location) {
                                        angular.extend(self.user.last_location, response.result.user.last_location);
                                    }

                                    angular.extend(self.user.interests, response.result.interests);
                                    angular.extend(self.user.used_friendship_tags, response.result.used_friendship_tags);

                                    // T1133
                                    // self.permissions_map = response.result.roles_permissions_map;
                                    // self.rebuildPermissionsCache();
                                    self.roles = response.result.roles;
                                    self.permissions = response.result.permissions;

                                    $rootScope.user = self.user;
                                    self.setFriends(response.result.friends);

                                    self.userDefer.resolve(self.user);
                                    self.userDeferResolved = true;
                                    hold = false;
                                    $rootScope.$emit("checkedLogin", self.user, response.result);
                                }
                            }
                        );
                    }

                    return self.userDefer.promise;
                };

                this.needsReloading = function (f) {
                    return !angular.equals(self._lastUsedFilter, f);
                };

                this.saveCache = function (users) {
                    self._cachedUsers = angular.copy(users);
                };

                this.getCache = function () {
                    return self._cachedUsers;
                };
                this.saveStreamCache = function (users) {
                    self._cachedStreamUsers = angular.copy(users);
                };

                this.getStreamCache = function () {
                    return self._cachedStreamUsers;
                };

                this.getObjectsByParams = function (params) {
                    // @deprecated users.filter_users
                    return jsonRPC.request('users.map_filter_users', params);
                };

                this.getObjects = function (filters, forceReload, page, pageSize, withTotal) {

                    var data = {
                        filters: filters,
                        page: page, //@deprecated
                        page_size: pageSize, //@deprecated
                        with_total: withTotal
                    };

                    if (self.needsReloading(filters) || forceReload) {
                        self._lastUsedFilter = angular.copy(filters);
                        return self.getObjectsByParams(data);
                    }
                    // wtf? cash logic in contentItemsSourceService.itemsSourceShouldBeUpdated
                    var deferred = $q.defer();
                    deferred.resolve({result: self.getCache()});
                    return deferred.promise;

                };

                this.getStream = function (filters, forceReload, page, pageSize, withTotal) {

                    var data = {
                        filters: filters,
                        page: page,
                        page_size: pageSize,
                        with_total: withTotal
                    };
                    if (self.needsReloading(filters) || forceReload) {
                        self._lastUsedFilter = angular.copy(filters);
                        return jsonRPC.request('users.stream_users', data);
                    }

                    var deferred = $q.defer();
                    deferred.resolve({result: self.getStreamCache()});
                    return deferred.promise;
                };

                this.getUserSelector = function () {
                    return {
                        choices: [],
                        query: function(searchTerm) {
                            console.log("SEARCH TERM", searchTerm);
                            var selector = this;
                            if (searchTerm.length < 3) return;
                            self.getDiscoverableUsers(searchTerm).then(
                                function (response) {
                                    selector.choices = angular.copy(response.result);
                                },
                                function () {
                                    selector.choices = [];
                                }
                            );
                        }
                    };
                };

                function showBirthdayNotification() {
                    if (self.user.authenticated && !self.user.age && !self.birthdate_notification_shown) {

                        $rootScope.$emit("flash", {
                            type: "warning",
                            title: "Birth date not set",
                            text: "In order to view all events you have to set your birthdate"
                        });

                        self.birthdate_notification_shown = true;
                    }
                }

                function showRegisterNotification() {
                    if (!self.user.authenticated && !self.register_notification_shown) {

                        $rootScope.$emit("flash", {
                            type: "warning",
                            title: "Please register",
                            text: "In ourder to view all events you have to <button class='btn btn-link' ng-click='openLoginPrompt(\"/map\")'>login</button> or <a ui-sref='signup'>register</a>"
                        });

                        self.register_notification_shown = true;
                    }
                }

                this.user = {
                    'authenticated': false
                };
                this.isAuthenticated = function () {
                    return self.user.authenticated;
                };

                this.getUsername = function () {
                    if (self.isAuthenticated()) {
                        return self.user.username;
                    } else {
                        return "Guest";
                    }
                };

                this.showUserNotifications = function () {

                    var current_path = $location.path();

                    // Pages where we show notifications
                    var notification_pages = [
                        '/events',
                        '/map'
                    ];

                    if (self.user.authenticated) {
                        notification_pages.push('/' + self.user.username + '/profile');
                        notification_pages.push('/' + self.user.username + '/calendar');
                    }

                    var page_shows_notifications = notification_pages.indexOf(current_path) >= 0;

                    if (page_shows_notifications) {
                        showBirthdayNotification();
                        showRegisterNotification();
                    }

                };

                this.getGeneralInfo = function (username) {

                    var data = {
                        username: username,
                        with_status: false,
                        with_bookmark: false,
                        with_relation: false
                    };

                    return jsonRPC.request('users.get_general_info', data);

                    /*jsonRPC.request('users.get_general_info', {
                     username: username
                     }).then(function (data) {
                     if (data.error) {
                     callback({});
                     } else {
                     callback(data.result);
                     }
                     });*/

                };


                this.getDiscoverableUsers = function (searchText) {
                    var data = {text: searchText};
                    return jsonRPC.request('users.get_discoverable_users', data);
                };

                this.getLanguage = function () {
                    if (self.isAuthenticated() && self.user.preffered_language) {
                        return self.user.preffered_language;
                    } else {
                        //IE doesn't support navigator.language (it supports .userLanguage)
                        var language = (navigator.language) ? navigator.language : navigator.userLanguage;
                        //converts en-US to en
                        language = language.replace(/-.*$/g, '');
                        // to ['ru', en']
                        var languageCodes = $.map(languages, function (e) {
                            return e.code;
                        });

                        if (languageCodes.indexOf(language) == -1) {
                            language = languages[0].code;
                        }
                        return language;
                    }
                };

                //this.checkLogin = function (onSuccess, onError) {
                //this.checkLogin = function () {
                //    if (!self.userDeferResolved) {
                //        jsonRPC.request('users.check_login').then(
                //            function (response) {
                //                if (!response.error) {
                //                    angular.extend(self.user, response.result.user);
                //
                //                    self.user.last_location = {};
                //                    self.user.interests = [];
                //                    self.user.used_friendship_tags = [];
                //
                //                    angular.extend(self.user.last_location, response.result.last_location);
                //                    angular.extend(self.user.interests, response.result.interests);
                //                    angular.extend(self.user.used_friendship_tags, response.result.used_friendship_tags);
                //
                //                    self.permissions_map = response.result.roles_permissions_map;
                //                    self.rebuildPermissionsCache();
                //
                //                    $rootScope.user = self.user;
                //                    self.setFriends(response.result.friends);
                //
                //                    self.userDefer.resolve(self.user);
                //                    self.userDeferResolved = true;
                //                    $rootScope.$broadcast("checkedLogin", self.user, response.result);
                //                }
                //            }
                //        );
                //    }
                //};

                //this.isValidUser = function (username) {
                //    return jsonRPC.request('users.is_valid_user', {username: username});
                //};

                this.logout = function () {

                    return this.getUser().then(function () {
                        self.userDefer = $q.defer();
                        self.userDeferResolved = false;
                        return jsonRPC.request('users.logout');
                    });

                };

                this.login = function (credentials) {
                    self.userDefer = $q.defer();
                    self.userDeferResolved = false;
                    return jsonRPC.request('users.login', credentials);
                };

                this.setUserData = function (data) {
                    self.user = data.user;
                    // T1133
                    // self.permissions_map = data.roles_permissions_map;
                    // self.rebuildPermissionsCache();
                    $rootScope.user = self.user;
                    // T1045 notify about user data changed
                    $rootScope.$emit('userProfileChanged', self.user);
                    if (self.userDeferResolved) {
                        self.userDefer = $q.defer();
                    }
                    self.userDefer.resolve(self.user);
                    self.userDeferResolved = true;
                };

                this.setFriends = function (data) {
                    if (data) {
                        self.friends = data;
                    }
                };

                //this.isFriend = function (userID) {
                //    if (self.friends) {
                //        var fNum, fObj;
                //        for (fNum in self.friends) if (self.friends.hasOwnProperty(fNum)) {
                //            fObj = self.friends[fNum];
                //            if (fObj.id === userID) {
                //                return true;
                //            }
                //        }
                //    }
                //    return false;
                //};

                //this.addFriend = function (friend) {
                //    //self.friends.push(friend);
                //    /*var i = -1, el, exist = false;
                //    while (++i < self.friends.length) {
                //        el = self.friends[i];
                //        if (el.id === friend.id) {
                //            exist = true;
                //            break;
                //        }
                //    }
                //    if (!exist) {
                //        channelService.subscribe('online', friend.id);
                //        channelService.subscribe('offline', friend.id);
                //        channelService.sync();
                //    }*/
                //};

                this.removeFriend = function (friend) {
                    var i = -1, el, exist = false;
                    while (++i < self.friends.length) {
                        el = self.friends[i];
                        if (el.id === friend.id) {
                            exist = true;
                            break;
                        }
                    }
                    if (exist) {
                        self.friends.splice(i, 1);
                        channelService.unsubscribe('online', friend.id);
                        channelService.unsubscribe('offline', friend.id);
                        channelService.sync();
                    }
                };

                this.initialSubscribe = function () {
                    console.log('initial subscribe');
                    if (self.user.authenticated) {
                        if (self.friends) {
                            var fNum, fObj;
                            for (fNum in self.friends) if (self.friends.hasOwnProperty(fNum)) {
                                fObj = self.friends[fNum];
                                if (fObj.is_subscribe) {
                                    channelService.subscribe('online', fObj.id);
                                    channelService.subscribe('offline', fObj.id);
                                }
                            }
                        }
                        channelService.subscribe('messages').subscribe('notification').subscribe('friends').subscribe('online').subscribe('profile').sync();
                    }
                };

                this.hasRole = function (role) {
                    return self.roles.indexOf(role) !== -1;
                };

                this.hasPerm = function (perm) {
                    perm = _.isArray(perm) ? perm : [perm];
                    return _.every(perm, function (val) {
                        return self.permissions.indexOf(val) !== -1;
                    });
                };

                this.getSocialAccounts = function (onSuccess, onError, associated) {

                    return jsonRPC.request('users.get_social_accounts', {
                        associated: associated
                    }).then(function (response) {

                            if (response.result) {
                                if (onSuccess) {
                                    onSuccess(response.result);
//                            console.info(response.result);
                                }
                                return response.result;
                            }
                        },
                        onError
                    );

                };

                //this.changePassword = function (confirmation_code, new_password, username) {
                //    var data = {
                //        username: username,
                //        confirmation_code: confirmation_code,
                //        new_password: new_password
                //    };
                //    return jsonRPC.request('users.change_password_code', data);
                //};

                this.changePasswordByContact = function (confirmation_code, new_password1, new_password2, contact_value, contact_type) {
                    var data = {
                        contact_value: contact_value,
                        contact_type: contact_type,
                        confirmation_code: confirmation_code,
                        new_password1: new_password1,
                        new_password2: new_password2
                    };
                    return jsonRPC.request('users.change_password_code', data);
                };

                this.sendPasswordRestoreCode = function (val, type) {
                    var data = {
                        contact_value: val,
                        contact_type: type
                    };
                    return jsonRPC.request('users.send_restore_code', data);
                };

                this.sendPhoneVerificationCode = function (username, phone_number) {
                    var data = {
                        username: username,
                        phone_number: phone_number
                    };
                    return jsonRPC.request('users.send_phone_confirmation_code', data);
                };

                this.sendLoginConfirmationCode = function (username, type) {
                    var data = {
                        username: username,
                        contact_type: type
                    };
                    return jsonRPC.request('users.send_login_confirmation_code', data);
                };

                this.getNotAssociatedSocialAccounts = function (onSuccess, onError) {
                    return this.getSocialAccounts(onSuccess, onError, false);
                };

                //this.getAssociatedSocialAccounts = function (onSuccess, onError) {
                //    return this.getSocialAccounts(onSuccess, onError, true);
                //};

                this.getRequiredRole = function (perm) {

                    for (var role in self.permissions_map) {

                        var perm_value = self.permissions_map[role].permissions[perm];
                        if (perm_value === true || perm_value === false) {
                            return role;
                        }
                    }

                    return false;

                };

                this.getProfileByUsername = function (username, callbackSuccess, callbackError) {
                    jsonRPC.request('users.get_profile_by_username', {
                        username: username
                    }).then(function (data) {
                        if (data.error) {
                            callbackError(data.result);
                        } else {
                            callbackSuccess(data.result);
                        }
                    });
                };

                // T1133
                // // Build permissions and groups cache
                // this.rebuildPermissionsCache = function () {
                //
                //     self.permissions_cache = [];
                //     self.roles_cache = [];
                //
                //     angular.forEach(self.permissions_map, function (data, role) {
                //         if (data.active) {
                //             self.roles_cache.push(role);
                //         }
                //
                //         angular.forEach(data.permissions, function (val, permission) {
                //             if (val) {
                //                 self.permissions_cache.push(permission);
                //             }
                //         });
                //     });
                // };

                this.getInterests = function (username) {

                    // Todo: return resolved promise if user is not authenticated
                    if (!username) {
                        username = self.user.username;
                    }
                    var data = {
                        username: username
                    };
                    return jsonRPC.request('users.get_interests', data);
                };


                this.isIncompletedUser = function () {
                    if (self.user.authenticated) {
                        return self.hasRole("IncompletedUsers") && !self.hasRole("Users");
                    }
                    return false;
                };
                // T1133
                // this.rebuildPermissionsCache();

            }]);

})();
