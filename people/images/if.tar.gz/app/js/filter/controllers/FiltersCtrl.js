(function () {
    'use strict';

    angular.module('app.controllers.filtersctrl', ['app']).constant('filtersEvents', {
        LOAD_COMPLETE: 'event__filtersLoadComplete',
        UPDATED: 'event__filtersUpdated',
        RESETED: 'event__filtersReseted'
    }).controller('FiltersCtrl', [
        '$scope', '$state', '$stateParams', '$rootScope', '$q', 'contentSettings', 'tagService', 'userService',
        'filtersService', 'favoritesService', 'placesService',
        'predefinedFilters', 'eventsService', 'visibilityService', 'VisibilityTypes', 'streamCodes', 'StreamGroup',
        'filtersEvents', '$parse', '$timeout', 'filtersTagTypes',
        function ($scope, $state, $stateParams, $rootScope, $q, contentSettings, tagService, userService,
                  filtersService, favoritesService, placesService, predefinedFilters, eventsService, visibilityService,
                  VisibilityTypes, streamCodes, StreamGroup, filtersEvents, $parse, $timeout, filtersTagTypes) {
            $scope.model = {
                eventsFilter: {
                    dateTimeFrom: null,
                    dateTimeTo: null
                    //formattedDateTimeFrom: null,
                    //formattedDateTimeTo: null
                }
            };
            var filtersInitialized = $q.defer(),
                filtersInitializedPromise = filtersInitialized.promise,
                skipFiltersUpdatedEvent = false;

            function convertFilterTags(f){
                /*
                 Predefined filters have latin ID
                 And localized (russian) names.
                 
                 Before sending pre-defined tags to backed we have 
                 to conver tag IDs to tag names
                 */

                var fNew = angular.copy(f);
                _.map(fNew.eventsTags, function(tag){
                    if (tag.tag_type == filtersTagTypes.PRE_DEFINED){
                        tag.name = tag.id;
                        delete tag.id;
                    }
                });

                _.map(fNew.placeTags, function(tag){
                    if (tag.tag_type == filtersTagTypes.PRE_DEFINED){
                        tag.name = tag.id;
                        delete tag.id;
                    }
                });

                _.map(fNew.usersTags, function(tag){
                    if (tag.tag_type == filtersTagTypes.PRE_DEFINED){
                        tag.name = tag.id;
                        delete tag.id;
                    }
                });
                return fNew;
            }
            $scope.init = function (skipEvent) {
                skipFiltersUpdatedEvent = !!skipEvent;
            };


            var datetimeOptions = {
                minView: 'minute',
                minuteStep: 5,
                weekStart: 1
            };

            $scope.datetimeOptionsLeft = angular.extend({}, datetimeOptions, {dropdownSelector: '#filters-datetime-dropdown-left'});
            $scope.datetimeOptionsRight = angular.extend({}, datetimeOptions, {dropdownSelector: '#filters-datetime-dropdown-right'});

            
            $scope.filterSelector = {
                choices: [],
                query: function(searchTerm) {
                    var selector = this;
                    if (searchTerm) {
                        tagService.getAllTags(searchTerm).then(
                            function (response) {
                                // WTF?
                                // _.map(response.result, function (tag) {
                                //     tag.tag_type = filtersTagTypes.TAG;
                                //     tag.id = tag.name;
                                //     return tag.name;
                                // });
                                selector.choices = response.result;
                            },
                            function () {
                                selector.choices = [];
                            }
                        );
                    }
                    // return immidiately with default options
                    else {
                        selector.choices = [];
                        var ct = $scope.currentFilterContentType;
                        if (ct) {
                            angular.forEach(filtersService.getPredefinedFilters(ct), function (group) {
                                angular.forEach(group.children, function(item) {
                                    item.group = group.name;
                                    selector.choices.push(item);
                                });
                            });
                        }
                    }
                }
            };

            var tagsSources = {};
            tagsSources[contentSettings.CONTENT_TYPES.EVENTS] = '';

            var selectFiltersTags = function (contentType) {
                switch (contentType) {
                    case contentSettings.CONTENT_TYPES.EVENTS:
                        return $scope.filters ? $scope.filters.eventsTags : null;
                    case contentSettings.CONTENT_TYPES.PLACES:
                        return $scope.filters ? $scope.filters.placesTags : null;
                    case contentSettings.CONTENT_TYPES.USERS:
                        return $scope.filters ? $scope.filters.usersTags : null;
                    default:
                        console.log('Incorrect content type');
                        return null;
                }
            };

            $scope.filters = {
                tags: selectFiltersTags($scope.currentFilterContentType)
            };

            $scope.$onRootScope(filtersEvents.RESETED, function () {
                $scope.filters.tags = selectFiltersTags($scope.currentFilterContentType);
            });

            $scope.$watch('currentFilterContentType', function (value) {
                $scope.filters.tags = selectFiltersTags(value);
            });

            $scope.filterIsSet = function () {
                var len = 0;
                len += $scope.filters.tags ? $scope.filters.tags.length : 0;
                len += $scope.model.eventsFilter.dateTimeFrom ? 1 : 0;
                len += $scope.model.eventsFilter.dateTimeTo ? 1 : 0;
                return len;
            };

            $scope.resetDateFrom = function () {
                $scope.model.eventsFilter.dateTimeFrom = null;
            };

            $scope.resetDateTo = function () {
                $scope.model.eventsFilter.dateTimeTo = null;
            };

            $scope.removeFilterTag = function (t) {
                $scope.filters.tags = _.without($scope.filters.tags, t);
            };
            $scope.resetFilters = function () {

                $scope.model.eventsFilter = {
                    dateTimeFrom: null,
                    dateTimeTo: null
                    //formattedDateTimeFrom: null,
                    //formattedDateTimeTo: null
                };

                filtersService.resetFilters();
                $rootScope.$emit(filtersEvents.RESETED);
            };

            $scope.refreshFilters = function () {
                var filters = filtersService.getContentFilters($rootScope.currentFilterContentType);
                $rootScope.$emit(filtersEvents.UPDATED, {value: convertFilterTags(filters), old: convertFilterTags(filters)});
            };

            // $location can be changed by pressing 'back' - track it here
            $rootScope.$on('$locationChangeSuccess', function () {
                // Changed by filters - no need to update filter params
                if (filtersService.isLocationModifiedByFilters()) {
                    filtersService.setLocationModifiedByFilters(false);
                }
                else { // By user - update filter params
                    filtersService.syncWithLocation();
                }
            });

            // Load all filters:
            // pre-defined filters for each content type
            // + server-side filters
            function initializeFilterWidgets() {

                var f = [];
                var contentTypes = filtersService.getSupportedContentTypes();

                return userService.getUser().then(function () {
                    var isAuthenticated = userService.isAuthenticated();
                    angular.forEach(contentTypes, function (ct) {
                        f = predefinedFilters[ct] || [];
                        f = _.filter(f, function (filter) {
                            return filter.availableToAnonymous || isAuthenticated;
                        });

                        angular.forEach(f, function (fltr) {
                            angular.forEach(fltr.children, function (ff) {
                                if (!ff.tag_type) {
                                    ff.tag_type = filtersTagTypes.PRE_DEFINED;
                                }
                            });
                        });

                        filtersService.setPredefinedFilters(f, ct);
                    });

                    // Server-side filters are based on the following config:
                    // content-type + array of promises to load.
                    var backendFilters = {
                        users: userService.isAuthenticated() ? [$rootScope.user.used_friendship_tags, $rootScope.user.interests] : []
                        //places: SystemTags.PlacesTags, //[tagService.getTypeTags('place_tags', '')],
                        //events: SystemTags.EventsTags //[tagService.getTypeTags('event_tags', '')]
                    };

                    _.forEach(backendFilters, function (tags, ct) {
                        var pf = filtersService.getPredefinedFilters(ct);
                        filtersService.setPredefinedFilters(pf.concat(
                            [{name: "Тэги", children: tags}]
                        ), ct);
                    });

                    filtersService.initFromURLAndCookies().then(function () {
                        $rootScope.$emit(filtersEvents.LOAD_COMPLETE);
                        watchModels();
                    });

                    //toResolve = [];

                    //angular.forEach(backendFilters, function (fltr, ct) {
                    //    angular.forEach(fltr, function (filter_promise, i) {
                    //        toResolve.push(resolveTagPromise(filter_promise, ct));
                    //    });
                    //});
                    //
                    //return $q.all(toResolve);
                });
            }

            //function resolveTagPromise(p, ct) {
            //    var defer = $q.defer();
            //
            //    var processTags = function (items) {
            //        _.map(items, function (tag) {
            //            tag.tag_type = filtersService.term_type_pre_defined_tag;
            //            tag.id = tag.name;
            //        });
            //
            //        var pf = filtersService.getPredefinedFilters(ct);
            //        filtersService.setPredefinedFilters(pf.concat(
            //            [{name: "Тэги", children: items}]
            //        ), ct);
            //        defer.resolve();
            //    };
            //
            //    if (p) {
            //        if (angular.isArray(p)) {
            //            processTags(p);
            //        }
            //        else {
            //            p.then(function (response) {
            //                processTags(response.result);
            //            });
            //        }
            //    } else {
            //        defer.reject();
            //    }
            //
            //    return defer.promise;
            //}

            function watchModels() {
                filtersInitializedPromise.then(function(){

                if(skipFiltersUpdatedEvent){
                    return;
                }

                function updateLocation(v) {
                    if (angular.isArray(v)) {
                        filtersService.updateURL();
                    }
                }

                //function checkTimeRange() {
                //
                //    var v1 = $scope.filters.eventsTimeFrom,
                //        v2 = $scope.filters.eventsTimeTo,
                //        needsCheck = angular.isDefined(v1) && v1 != null
                //            && angular.isDefined(v2) && v2 != null;
                //
                //    if (needsCheck) {
                //
                //        var t1 = v1.split(":"),
                //            t2 = v2.split(":"),
                //            h1 = parseInt(t1[0]),
                //            m1 = parseInt(t1[1]),
                //            h2 = parseInt(t2[0]),
                //            m2 = parseInt(t2[1]),
                //            tm1 = h1 * 60 + m1,
                //            tm2 = h2 * 60 + m2;
                //
                //        $scope.timeSelectionInvalid = tm1 >= tm2;
                //    }
                //    else {
                //        $scope.timeSelectionInvalid = false;
                //    }
                //}

                // T1042 and T1043
                // $scope.$watch('filters.eventsCategory', function (v) {
                //     updateLocation(v);
                // }, true);
                //
                // $scope.$watch('filters.eventsRelated', function (v) {
                //     updateLocation(v);
                // }, true);
                //
                // $scope.$watch('filters.eventsState', function (v) {
                //     updateLocation(v);
                // }, true);

                function isTagsEquals(val, valOld) {
                    if ((!val && !valOld) || (angular.isArray(val) !== angular.isArray(valOld)) || val.length !== valOld.length) {
                        return false;
                    }
                    var equals = true;
                    angular.forEach(val, function (tag) {
                        if (equals) {
                            equals = _.some(valOld, function (tag2) {
                                return tag2.name === tag.name && tag2.tag_type == tag.tag_type;
                            });
                        }
                    });

                    return equals;
                }

                $scope.$watch('model.eventsFilter.dateTimeFrom', function (value) {
                    if (value) {
                        var momentDateTime = moment(value);
                        if (momentDateTime.isValid()) {
                            var unixDateTime = momentDateTime.unix();
                            if ($scope.model.eventsFilter.dateTimeTo) {
                                var timestampTo = moment($scope.model.eventsFilter.dateTimeTo).unix();
                                if (timestampTo < unixDateTime) {
                                    $scope.model.eventsFilter.dateTimeFrom = $scope.model.eventsFilter.dateTimeTo;
                                    unixDateTime = timestampTo;
                                }
                            }

                            filtersService.setEventsDateTimeFrom(unixDateTime);
                            filtersService.updateURL();
                        }
                    }
                    else {
                        filtersService.setEventsDateTimeFrom(null);
                        filtersService.updateURL();
                    }
                });

                $scope.$watch('model.eventsFilter.dateTimeTo', function (value) {
                    if (value) {
                        var momentDateTime = moment(value);
                        if (momentDateTime.isValid()) {
                            var unixDateTime = momentDateTime.unix();
                            if ($scope.model.eventsFilter.dateTimeFrom) {
                                var timestampFrom = moment($scope.model.eventsFilter.dateTimeFrom).unix();
                                if (timestampFrom > unixDateTime) {
                                    $scope.model.eventsFilter.dateTimeTo = $scope.model.eventsFilter.dateTimeFrom;
                                    unixDateTime = timestampFrom;
                                }
                            }

                            filtersService.setEventsDateTimeTo(unixDateTime);
                            filtersService.updateURL();
                        }
                    }
                    else {
                        filtersService.setEventsDateTimeTo(null);
                        filtersService.updateURL();
                    }

                });
                
                $scope.$watch('filters.tags', function (value, valueOld) {
                    if (angular.isArray(value) && !isTagsEquals(value, valueOld)) {
                        switch ($scope.currentFilterContentType) {
                            case contentSettings.CONTENT_TYPES.EVENTS:
                                filtersService.setEventsTags(value);
                                break;
                            case contentSettings.CONTENT_TYPES.PLACES:
                                filtersService.setPlacesTags(value);
                                break;
                            case contentSettings.CONTENT_TYPES.USERS:
                                filtersService.setUsersTags(value);
                                break;
                            default:
                                console.log('Incorrect content type');
                                break;
                        }
                        $timeout(filtersService.updateURL, 0);
                    }
                }, true);

                });
            }

            function watchFilters() {

                if ($scope.watchingFilters) {
                    return;
                }
                $scope.watchingFilters = true;
                //if (FiltersCtrlSettingsService.watchingFiltersControllersIds.length === 0) {
                //    FiltersCtrlSettingsService.watchingFiltersControllersIds.push(ctrlId);
                //}

                $scope.$watch(filtersService.getFilters, function (fVal, fValOld) {


                    angular.extend($scope.filters, angular.copy(fVal));
                    $scope.filters.tags = selectFiltersTags($scope.currentFilterContentType);


                    $scope.model.eventsFilter.dateTimeFrom = fVal.eventsDateTimeFrom ?
                        moment.unix(fVal.eventsDateTimeFrom).toDate() : null;

                    if (fVal.eventsDateTimeFrom) {
                        $scope.model.eventsFilter.dateTimeFrom = moment.unix(fVal.eventsDateTimeFrom).toDate();
                    }

                    if (fVal.eventsDateTimeTo) {
                        $scope.model.eventsFilter.dateTimeTo = moment.unix(fVal.eventsDateTimeTo).toDate();
                    }

                    angular.forEach($scope.forceReload, function (value, key) {
                        $scope.forceReload[key] = true;
                    });

                    if (!skipFiltersUpdatedEvent) {
                        console.warn("FILTERS CHANGED: ", !_.isEqual(fVal, fValOld), fVal, fValOld);
                        $rootScope.$emit(filtersEvents.UPDATED, {value: convertFilterTags(fVal), old: convertFilterTags(fValOld)});
                    }

                    filtersInitialized.resolve(true);

                }, true);
            }

            var filterModeWatcher = $scope.$watch('currentFilterMode', function () {
                if (filtersService.isLoadComplete()) {
                    watchFilters();
                }
                else {
                    $scope.$onRootScope(filtersEvents.LOAD_COMPLETE, function () {
                        watchFilters();
                    });
                }
                filterModeWatcher();
            });

            initializeFilterWidgets();

            //initializeFilterWidgets().then(function () {
            //    filtersService.initFromURLAndCookies().then(function () {
            //        $rootScope.$broadcast(filtersEvents.LOAD_COMPLETE);
            //        watchModels();
            //    });
            //});

        }]);

})();
