(function () {
    'use strict';
    angular.module('app.services.filters', []).service('filtersService', [
        '$rootScope', '$state', '$stateParams', '$cookies', '$cookieStore', '$q', '$location', 'jsonRPC',
        'placesService', 'predefinedFilters', 'contentSettings', '$window', 'filtersTagTypes',
        function ($rootScope, $state, $stateParams, $cookies, $cookieStore, $q, $location, jsonRPC,
                  placesService, predefinedFilters, contentSettings, $window, filtersTagTypes) {
            $window.filtersService = this;
            // Initialization from cookies or url can be done
            // once only, this flag is for checking.
            this._init_url_and_cookie_done = false;

            // Internal objects to store all filter params
            this._filters = {};

            // Each website section (users, events, etc..)
            // can have it's own pre-defined filters
            this._pre_defined_filters = {};

            // $location can be changed by filersService (with updateURL)
            // or by user (by pressing 'back' for example)
            this._location_changed_by_filters = false;

            // T1028
            // // Select2 filter elements can have different meanings.
            // // Item can be a tag, or a search word, so we assing types to each item
            // // to distinguish then
            // this.term_type_tag = 0;
            // this.term_type_search_word = 1;
            // this.term_type_pre_defined = 2;
            // this.term_type_pre_defined_tag = 3;

            this._dateFormat = "YYYY-MM-DD";
            this._timeFormat = "HH:mm";

            var self = this,
                initialFilter = {

                    // Primary filters (content-type independant)
                    centerPlace: null,

                    // Users filters
                    usersTags: [],

                    // Place filters
                    placesTags: [],

                    // Events filters
                    eventsTags: [],
                    eventsDateTimeFrom: null,
                    eventsDateTimeTo: null,

                    // new filters
                    eventsCategory: [],
                    eventsRelated: [],
                    eventsState: [],

                    //eventsDateFrom: null,
                    //eventsDateTo: null,

                    //eventsTimeFrom: null,
                    //eventsTimeTo: null,

                    placesCategory: [],
                    placesRelated: [],
                    placesState: [],

                    currentPage: 1
                };

            // URL prefix for pre-defined filters
            var p1 = '__';
            // URL prefix for tags
            var p2 = '#';

            // URL prefix for pre defined tags
            var p3 = '^';


            this.isLocationModifiedByFilters = function () {
                return self._location_changed_by_filters;
            };

            this.setLocationModifiedByFilters = function (val) {
                self._location_changed_by_filters = val;
            };


            function getDateTagIDs() {
                var dateTagsIds = [];

                angular.forEach(predefinedFilters.events, function (fltr) {
                    angular.forEach(fltr.children, function (f) {
                        if (f.dateRelated) {
                            dateTagsIds.push(f.id);
                        }
                    });
                });
                return dateTagsIds;
            }

            this.updateURL = function () {

                var fParams = self.toParams(),
                    lParams = $location.search(),
                    updatedSearch = !angular.equals(fParams, lParams);

                if (updatedSearch) {
                    $location.search(self.toParams());
                    self.setLocationModifiedByFilters(true);
                }
                $location.path($rootScope.currentFilterContentType);
            };

            this.getSupportedContentTypes = function () {
                return ['events', 'places', 'users'];
            };

            this.getSupportedModes = function () {
                return ['map', 'list', 'stream'];
            };

            this.isLoadComplete = function () {
                return self._init_url_and_cookie_done;
            };

            this.resetFilters = function () {
                var cp = angular.copy(self._filters.centerPlace);
                self._filters = angular.copy(initialFilter);
                self._filters.centerPlace = cp;
            };

            /*
             Used to watch filters changes.
             */
            this.getFilters = function () {
                return self._filters;
            };

            /*
             Returns a part of filters which corresponds to a specific content type.
             */
            this.getContentFilters = function (content_type) {
                var ret = {};
                for (var f in self._filters) {
                    if (!f.indexOf(content_type) && self._filters[f]) {
                        ret[f] = self._filters[f];
                    }
                }
                // Add global filters
                if (self.getCurrentMode() == 'map') {
                    ret.centerPlace = self._filters.centerPlace;
                    ret.isMap = true;
                }
                return ret;
            };

            function isTagsEquals(val, valOld) {
                if ((!val && !valOld) || (angular.isArray(val) !== angular.isArray(valOld)) || val.length !== valOld.length) {
                    return false;
                }
                var equals = true;
                angular.forEach(val, function (tag) {
                    if (equals) {
                        equals = _.some(valOld, function (tag2) {
                            return tag.tag_type == tag2.tag_type &&
                                ((tag.tag_type == filtersTagTypes.PRE_DEFINED && tag.name == tag2.id) ||
                                (tag.name == tag2.name));
                        });
                    }
                });

                return equals;
            }

            function findAmongPredfined(tag){

                var tagName = tag.name.toLowerCase(),
                    predefFilters = self.getPredefinedFilters(self.getCurrentContentType());

                return _.find(_.flatten(_.pluck(predefFilters, 'children')), function(fltr){
                    return fltr.name.toLowerCase() == tagName;
                });
            }

            function setTags(tagsSource, value) {

                if(angular.isArray(value) && !isTagsEquals(tagsSource, value)){

                    // Some tags that users may enter manually 
                    // can be among predefined tags
                    value = _.map(value, function(tag){
                        var predef = findAmongPredfined(tag);
                        return predef === undefined ? tag : predef;
                    });

                    var tags = _.map(value, function (tag) {
                        var newTag = {
                            tag_type: tag.tag_type
                        };
                        if (tag.tag_type == filtersTagTypes.PRE_DEFINED){
                            newTag.id = tag.id;
                            newTag.name = tag.name;
                        }
                        else {
                            newTag.name = tag.name;
                        }
                        return newTag;
                    });
                    tagsSource.length = 0;
                    tagsSource.splice.apply(tagsSource, [0, 0].concat(tags));
                    return true;
                    
                }
                return false;
            }

            this.searchByTag = function (ct, tag) {
                var filterTag = angular.copy(tag);
                filterTag.id = tag.name;
                filterTag.tag_type = filtersTagTypes.TAG;

                switch (ct) {
                    case contentSettings.CONTENT_TYPES.EVENTS:
                        self.setEventsTags([filterTag]);
                        break;
                    case contentSettings.CONTENT_TYPES.PLACES:
                        self.setPlacesTags([filterTag]);
                        break;
                    case contentSettings.CONTENT_TYPES.USERS:
                        self.setUsersTags([filterTag]);
                        break;
                    default:
                        self.setGlobalTags([filterTag]);
                }

                if (!$state.includes('content')) {
                    $rootScope.switchFilterContentType(ct);
                    $state.go('content', angular.extend(self.toParams(), {content: ct}));
                }
            };

            this.setGlobalTags = function (tags) {
                self.setPlacesTags(tags);
                self.setEventsTags(tags);
                self.setUsersTags(tags);
            };

            //// USERS
            //this.setUsersScope = function (v) {
            //    self._filters.usersScope = angular.copy(v);
            //};

            this.setUsersTags = function (v) {
                setTags(self._filters.usersTags, v);
            };


            //// Places
            //this.setPlacesScope = function (v) {
            //    self._filters.placesScope = angular.copy(v);
            //};

            this.setPlacesTags = function (v) {
                setTags(self._filters.placesTags, v);
            };


            //// Events
            //this.setEventsCategory = function (v) {
            //    self._filters.eventsCategory = angular.copy(v);
            //};


            //this.setEventsScope = function (v) {
            //    self._filters.eventsScope = angular.copy(v);
            //};

            this.setEventsTags = function (v) {
                if (setTags(self._filters.eventsTags, v)) {
                    this.resetDateTimeRange();
                }
            };

            this.setCenterPlace = function (place) {

                if (!angular.isDefined(place.center)) {
                    console.error("ERROR: Invalid center: ", place);
                }
                self._filters.centerPlace = angular.copy(place);
            };

            this.getCenterPlace = function () {
                return self._filters.centerPlace;
            };

            //this.setEventsDateFrom = function (v) {
            //    if (v) {
            //        self._filters.eventsDateFrom = v;
            //        self.resetDateStateTags();
            //    }
            //    else {
            //        self._filters.eventsDateFrom = null;
            //    }
            //    self.updateFiltersDateTimes(contentSettings.CONTENT_TYPES.EVENTS);
            //};

            this.mapPageChange = function (page) {
                $rootScope.$broadcast('mapPageChange', page);
            };

            //this.setEventsDateTo = function (v) {
            //    if (v) {
            //        self._filters.eventsDateTo = v;
            //        self.resetDateStateTags();
            //    }
            //    else {
            //        self._filters.eventsDateTo = null;
            //    }
            //    self.updateFiltersDateTimes(contentSettings.CONTENT_TYPES.EVENTS);
            //};

            /*this.setEventsTimeFrom = function (v) {
             if (v) {
             self._filters.eventsTimeFrom = v;
             self.resetDateStateTags();
             }
             else {
             self._filters.eventsTimeFrom = null;
             }
             self.updateFiltersDateTimes(contentSettings.CONTENT_TYPES.EVENTS);
             };
             this.getEventsTimeFrom = function () {
             return self._filters.eventsTimeFrom;
             };
             */

            /*
             this.setEventsTimeTo = function (v) {
             if (v) {
             self._filters.eventsTimeTo = v;
             self.resetDateStateTags();
             }
             else {
             self._filters.eventsTimeTo = null;
             }
             self.updateFiltersDateTimes(contentSettings.CONTENT_TYPES.EVENTS);
             };*/

            //this.setEventsDateTimeFrom = function (value) {
            //    self.eventsDateTimeFrom = angular.copy(value);
            //};

            //this.setEventsDateTimeTo = function (value) {
            //    self.eventsDateTimeTo = angular.copy(value);
            //};
            //
            //this.getEventsDateTimeFrom = function () {
            //    return self.eventsDateTimeFrom;
            //};
            //
            //this.getEventsDateTimeTo = function () {
            //    return self.eventsDateTimeTo;
            //};
            //
            //this.getEventsTimeTo = function () {
            //    return self._filters.eventsTimeTo;
            //};
            //
            //this.updateFiltersDateTimes = function (contentType) {
            //    self._filters[contentType + 'DateTimeTo'] = self.buildDateTime(self._filters[contentType + 'DateTo'], self._filters[contentType + 'TimeTo']);
            //    self._filters[contentType + 'DateTimeFrom'] = self.buildDateTime(self._filters[contentType + 'DateFrom'], self._filters[contentType + 'TimeFrom']);
            //};


            this.buildDateTime = function (date, time) {
                var dateTimeStr = null;

                if (date) {
                    var momentDate = moment(date);
                    if (momentDate.isValid()) {
                        dateTimeStr = momentDate.format(this._dateFormat);
                    }
                }

                if (time) {
                    if (dateTimeStr) {
                        dateTimeStr += ' ' + time;
                    }
                    else {
                        var momentTime = moment(time, this._timeFormat);
                        return momentTime.isValid() ? momentTime.unix() : null;
                    }
                }

                return dateTimeStr ? moment(dateTimeStr).unix() : null;
            };

            this.setEventsDateTimeFrom = function (v) {
                if (v) {
                    self._filters.eventsDateTimeFrom = moment.unix(v).unix();
                    self.resetDateStateTags();
                }
                else {
                    self._filters.eventsDateTimeFrom = null;
                }
            };

            this.setEventsDateTimeTo = function (v) {
                if (v) {
                    self._filters.eventsDateTimeTo = moment.unix(v).unix();
                    self.resetDateStateTags();
                }
                else {
                    self._filters.eventsDateTimeTo = null;
                }
            };

            //this.getEventsDateTimeTo = function () {
            //    return self._filters.eventsDateTimeTo;
            //};
            //
            //this.getDateTimeComponents = function (v) {
            //
            //    var m = moment.unix(v);
            //    return [m.toDate(), m.hour(), m.minute()];
            //
            //};

            this.resetDateTimeRange = function () {
                var dateTagIDs = getDateTagIDs(),
                    eventTagsIDs = _.map(self._filters.eventsTags, function (tag) {
                        return tag.id;
                    }),
                    hasDateTags = _.intersection(dateTagIDs, eventTagsIDs).length > 0;

                // Settine date tags resets time rage filter
                if (hasDateTags) {
                    self._filters.eventsDateTimeFrom = null;
                    self._filters.eventsDateTimeTo = null;
                }

            };

            this.resetDateStateTags = function () {

                var dateTagIDs = getDateTagIDs();

                angular.forEach(self._filters.eventsTags, function (tag, i) {

                    var tagIsDateRelated = dateTagIDs.indexOf(tag.id) != -1;

                    if (tagIsDateRelated) {
                        self._filters.eventsTags.splice(i, 1);
                    }
                });

            };

            //// Global functions
            this.setPredefinedFilters = function (f, filter_type) {
                if (filter_type) {
                    self._pre_defined_filters[filter_type] = angular.copy(f);
                }
                else {
                    self._pre_defined_filters = angular.copy(f);
                }
            };

            this.getPredefinedFilters = function (content_type) {

                return self._pre_defined_filters[content_type] || [];

            };

            /*
             this.loadBackendData = function(){


             //Some filters require backend data.
             //Every backend request returns as a promise.
             //loadBackendData resolves after all required promises are resolved.


             var promises = [],
             location = $stateParams['centerPlace'];

             if(location){

             promises.push(self.loadPlaceByLatLng(location));

             var res = location.split(":"),
             hasPlaceID = (res.length == 8);

             if(hasPlaceID){
             promises.push(self.loadPlaceByID(res[7], res[6]));
             }
             else{
             promises.push(self.loadPlaceByLatLng(location));
             }

             }

             return $q.all(promises);

             };
             */

            this.getCurrentMode = function () {
                return $rootScope.currentFilterMode;
            };

            this.getCurrentContentType = function () {
                /*
                 Returns filters current content type - users/places/events.
                 Current content type depends on current state.
                 */
                return $rootScope.currentFilterContentType;
            };

            this.parseParamsToFilters = function (paramsSource) {

                var filters = angular.copy(initialFilter),
                    contentType = self.getCurrentContentType();

                function filterNameTags(tag_id) {

                    var id_is_valid = false,
                        fltrTag = {};

                    // Pre-defined filter
                    if (!tag_id.indexOf(p1) && tag_id.indexOf(p1, tag_id.length - p1.length) !== -1) {

                        id = tag_id.substring(p1.length, tag_id.length - p1.length);

                        angular.forEach(self.getPredefinedFilters(contentType), function (f) {
                            angular.forEach(f.children, function (fltr) {
                                if (fltr.id == id && fltr.tag_type == filtersTagTypes.PRE_DEFINED) {
                                    id_is_valid = true;
                                    fltrTag = fltr;
                                }
                            });
                        });
                        if (id_is_valid) {
                            tags.push({
                                name: fltrTag.name,
                                id: fltrTag.id,
                                tag_type: filtersTagTypes.PRE_DEFINED,
                            });
                        }
                    }
                    // Tag
                    else if (!tag_id.indexOf(p2)) {
                        // TODO: check tag validity (can be made on backed only :( )
                        id = tag_id.substring(p2.length);
                        tags.push({
                            name: id,
                            tag_type: filtersTagTypes.TAG
                        });
                    }
                    // Pre-loaded tag
                    // id and name are the same
                    else if (!tag_id.indexOf(p3)) {
                        id = tag_id.substring(p3.length);

                        angular.forEach(self.getPredefinedFilters(contentType), function (f) {
                            angular.forEach(f.children, function (fltr) {
                                if (fltr.name == id && fltr.tag_type == filtersTagTypes.PRE_DEFINED_TAG) {
                                    id_is_valid = true;
                                    fltrTag = fltr;
                                }
                            });
                        });
                        if (id_is_valid) {
                            tags.push({
                                name: id,
                                tag_type: filtersTagTypes.PRE_DEFINED_TAG
                            });
                        }
                    }
                    // Text search
                    else {
                        tags.push({
                            name: tag_id,
                            tag_type: filtersTagTypes.WORD
                        });
                    }
                }

                for (var f_name in paramsSource) {

                    var url_params = paramsSource[f_name];

                    if (f_name == 'centerPlace' && url_params) {

                        var p = url_params.split(":"),
                            pointHasBounds = p.length >= 6;

                        filters.centerPlace = {
                            center: {
                                'latitude': parseFloat(p[0]),
                                'longitude': parseFloat(p[1])
                            }
                        };

                        if (pointHasBounds) {
                            filters.centerPlace.bounds = {
                                northEast: {
                                    lat: parseFloat(p[2]),
                                    lng: parseFloat(p[3])
                                },
                                southWest: {
                                    lat: parseFloat(p[4]),
                                    lng: parseFloat(p[5])
                                }
                            };
                        }
                    }
                    // Datetime from
                    else if (f_name == 'dt1' && url_params) {
                        filters.eventsDateTimeFrom = parseInt(url_params);
                    }
                    else if (f_name == 'dt2' && url_params) {
                        filters.eventsDateTimeTo = parseInt(url_params);
                    }
                    else if (f_name == 'show' && url_params) {
                        var isValidMode = self.getSupportedModes().indexOf(url_params) >= 0;
                        if (isValidMode) {
                            $rootScope.currentFilterMode = url_params;
                        }
                    }
                    else if (f_name == 'page' && url_params) {
                        url_params = parseInt(url_params, 10);
                        var isValidPage = url_params > 0 && angular.isNumber(url_params);
                        if (isValidPage) {
                            filters.currentPage = url_params;
                        }
                    }
                    else if (url_params) {

                        var id, tags = [],
                            tag_ids = url_params.split(','),
                            filterName = contentType + f_name[0].toUpperCase() + f_name.substring(1);

                        if (filters.hasOwnProperty(filterName)) {
                            angular.forEach(tag_ids, filterNameTags);
                            if (filterName.indexOf('Tags') !== -1 && isTagsEquals(self._filters[filterName], tags)) {
                                filters[filterName] = angular.copy(self._filters[filterName]);
                            }
                            else if (typeof tags !== 'undefined') {
                                filters[filterName] = tags;
                            }
                        }
                    }
                }

                return filters;
            };

            this.syncWithLocation = function () {
                /*
                 User can change current window.location by pressing 'back'
                 In this case we have to sync current filter parameters with the old ones
                 from old window.location.
                 */
                var params = $location.search(),
                    parsedParams = self.parseParamsToFilters(params),
                    currentParams = self.getFilters(),
                    needsToUpdate = !angular.equals(parsedParams, currentParams);
                if (needsToUpdate) {
                    self._filters = parsedParams;
                }

            };

            this.initFromURLAndCookies = function () {
                /*
                 Used to initialize internal _filters object with values from url or cookies.
                 */

                var defer = $q.defer();

                if (self._init_url_and_cookie_done) {
                    defer.resolve();
                    return defer.promise;
                }

                //var params_source = _.some($stateParams) ? $stateParams : $cookies;
                self._filters = angular.copy(self.parseParamsToFilters($stateParams));
                
                self._init_url_and_cookie_done = true;
                defer.resolve();

                return defer.promise;
            };

            this.toParams = function () {
                /*
                 Converts _filters parameters to url parameters:
                 users?filter=__friends__&scope=__all__&tags=%23Tag%201

                 Return value should be used in $location.search()
                 */

                var params = {};

                function paramBelongsToStateTags(tag) {
                    // Predefined tag
                    if (tag.tag_type == filtersTagTypes.PRE_DEFINED) {
                        //return p1 + tag.name + p1;
                        return p1 + tag.id + p1;
                    }
                    // Custom tag
                    else if (tag.tag_type == filtersTagTypes.TAG) {
                        return p2 + tag.name;
                    }
                    else if (tag.tag_type == filtersTagTypes.PRE_DEFINED_TAG) {
                        return p3 + tag.name;
                    }
                    else {
                        return tag.name;
                    }
                }


                for (var f_name in self._filters) {
                    var content_type = self.getCurrentContentType(),
                        mode = self.getCurrentMode(),
                        isMapMode = mode == 'map',
                        paramName = f_name.replace(content_type, '').toLowerCase(),
                        paramBelongsToState = !f_name.indexOf(content_type),
                        valid = self._filters[f_name] && paramBelongsToState;

                    if (f_name == 'centerPlace' && self._filters[f_name] && isMapMode) {
                        var c = self._filters.centerPlace,
                            p = angular.isDefined(c.center) ? c.center : c, // center
                            ne = c.bounds.northEast, // bounds
                            sw = c.bounds.southWest;

                        params[f_name] = p.latitude + ":" + p.longitude + ":" + ne.lat +
                        ":" + ne.lng +
                        ":" + sw.lat +
                        ":" + sw.lng;
                    }
                    /*else if (f_name == 'eventsDateFrom' && valid) {
                     params['d1'] = moment(self._filters.eventsDateFrom).format(self._dateFormat);
                     }
                     else if (f_name == 'eventsDateTo' && valid) {
                     params['d2'] = moment(self._filters.eventsDateTo).format(self._dateFormat);
                     }
                     else if (f_name == 'eventsTimeFrom' && valid) {
                     params['t1'] = self._filters[f_name];
                     }
                     else if (f_name == 'eventsTimeTo' && valid) {
                     params['t2'] = self._filters[f_name];
                     }
                     */
                    else if (f_name == 'eventsDateTimeFrom' && valid) {
                        params.dt1 = self._filters[f_name];
                    }
                    else if (f_name == 'eventsDateTimeTo' && valid) {
                        params.dt2 = self._filters[f_name];
                    }
                    else if (f_name == 'currentPage' && !isMapMode) {
                        params.page = self._filters[f_name];
                    }

                    // Multiple selections
                    else if (self._filters[f_name] && valid && self._filters[f_name].length) {

                        //params[paramName] = self._filters[f_name].join(',');

                        // if params belongs to 'places' but we are in the 'users'
                        // state - skip it.
                        if (paramBelongsToState) {
                            var tag_ids = _.map(self._filters[f_name], paramBelongsToStateTags);
                            params[paramName] = tag_ids.join(',');
                        }


                    }
                }

                // Add display mode
                params.show = $rootScope.currentFilterMode;
                return params;
            };

            this.resetFilters();

        }])
        .constant('predefinedFilters', {
            events: [
                {
                    name: "Отношение",
                    availableToAnonymous: false,
                    children: [
                        {
                            name: "создавал",
                            id: "owner"
                        },
                        {
                            name: "участвовал",
                            id: "participated"
                        },
                        {
                            name: "обсуждал",
                            id: "discussed"
                        },
                        {
                            name: "подписан",
                            id: "subscribed"
                        }
                    ]
                },
                {
                    name: "Статус",
                    availableToAnonymous: true,
                    children: [
                        {
                            name: "закончились",
                            id: "past",
                            dateRelated: true
                        },
                        {
                            name: "проходят сейчас",
                            id: "now",
                            dateRelated: true
                        },
                        {
                            name: "не начались",
                            id: "future",
                            dateRelated: true
                        }
                    ]
                },
                {
                    name: "Дата",
                    availableToAnonymous: true,
                    children: [
                        {
                            name: "вчера",
                            id: "yesterday",
                            dateRelated: true
                        },
                        {
                            name: "сегодня",
                            id: "today",
                            dateRelated: true
                        },
                        {
                            name: "завтра",
                            id: "tomorrow",
                            dateRelated: true
                        },
                        {
                            name: "послезавтра",
                            id: "atomorrow",
                            dateRelated: true
                        }
                    ]
                },
                {
                    name: "Время",
                    availableToAnonymous: true,
                    children: [
                        {
                            name: "Утро",
                            id: "morning",
                            dateRelated: true
                        },
                        {
                            name: "День",
                            id: "day",
                            dateRelated: true
                        },
                        {
                            name: "Вечер",
                            id: "evening",
                            dateRelated: true
                        },
                        {
                            name: "Ночь",
                            id: "night",
                            dateRelated: true
                        }
                    ]
                },
                {
                    name: "Теги",
                    availableToAnonymous: true,
                    useForTags: 'event_tags',
                    children: [
                        {tag_type: 3, id: "встреча", name: "встреча"},
                        {tag_type: 3, id: "встреча выпускников", name: "встреча выпускников"},
                        {tag_type: 3, id: "выпускной", name: "выпускной"},
                        {tag_type: 3, id: "выставка", name: "выставка"},
                        {tag_type: 3, id: "день рождения", name: "день рождения"},
                        {tag_type: 3, id: "дом", name: "дом"},
                        {tag_type: 3, id: "занятие спортом", name: "занятие спортом"},
                        {tag_type: 3, id: "концерт", name: "концерт"},
                        {tag_type: 3, id: "корпоратив", name: "корпоратив"},
                        {tag_type: 3, id: "обед", name: "обед"},
                        {tag_type: 3, id: "охота", name: "охота"},
                        {tag_type: 3, id: "пикник", name: "пикник"},
                        {tag_type: 3, id: "представление", name: "представление"},
                        {tag_type: 3, id: "презентация", name: "презентация"},
                        {tag_type: 3, id: "прогулка", name: "прогулка"},
                        {tag_type: 3, id: "работа", name: "работа"},
                        {tag_type: 3, id: "рыбалка", name: "рыбалка"},
                        {tag_type: 3, id: "свидание", name: "свидание"},
                        {tag_type: 3, id: "собрание", name: "собрание"},
                        {tag_type: 3, id: "событие", name: "событие"},
                        {tag_type: 3, id: "танцы", name: "танцы"},
                        {tag_type: 3, id: "ужин", name: "ужин"},
                        {tag_type: 3, id: "утренник", name: "утренник"},
                        {tag_type: 3, id: "учеба", name: "учеба"},
                        {tag_type: 3, id: "юбилей", name: "юбилей"}
                    ]
                }
            ],
            places: [
                {
                    name: "Отношение",
                    availableToAnonymous: false,
                    children: [
                        {
                            name: "создавал",
                            id: "owner"
                        },
                        {
                            name: "посещал",
                            id: "visited"
                        },
                        {
                            name: "обсуждал",
                            id: "discussed"
                        },
                        {
                            name: "подписан",
                            id: "subscribed"
                        }
                    ]
                },
                {
                    name: "Теги",
                    availableToAnonymous: true,
                    useForTags: 'place_tags',
                    children: [
                        {tag_type: 3, id: "bar", name: "бар"},
                        {tag_type: 3, id: "city", name: "город"},
                        {tag_type: 3, id: "house", name: "дом"},
                        {tag_type: 3, id: "country-house", name: "загородный дом"},
                        {tag_type: 3, id: "cafe", name: "кафе"},
                        {tag_type: 3, id: "cinema", name: "кинотеатр"},
                        {tag_type: 3, id: "club", name: "клуб"},
                        {tag_type: 3, id: "music-hall", name: "концертный зал"},
                        {tag_type: 3, id: "museum", name: "музей"},
                        {tag_type: 3, id: "office", name: "офис"},
                        {tag_type: 3, id: "pub", name: "паб"},
                        {tag_type: 3, id: "park", name: "парк"},
                        {tag_type: 3, id: "nature", name: "природа"},
                        {tag_type: 3, id: "restaurant", name: "ресторан"},
                        {tag_type: 3, id: "sports-building", name: "спортивное сооружение"},
                        {tag_type: 3, id: "stadium", name: "стадион"},
                        {tag_type: 3, id: "theatre", name: "театр"},
                        {tag_type: 3, id: "mall", name: "торговый центр"},
                        {tag_type: 3, id: "transport", name: "транспорт"},
                        {tag_type: 3, id: "institution", name: "учебное заведение"}
                    ]
                }
                // T468
                // ,
                // {
                //     name: "Статус:", availableToAnonymous: true, children: [
                //     {
                //         name: "только активные",
                //         id: "active"
                //     }
                // ]
                // }
            ],
            users: [
                {
                    name: "Отношения",
                    availableToAnonymous: false,
                    children: [
                        {
                            name: "мои друзья",
                            id: "friends"
                        },
                        {
                            name: "мои подписки",
                            id: "subscribed"
                        },
                        {
                            name: "друзья моих друзей",
                            id: "friends_of_friends"
                        }
                    ]
                },
                {
                    name: "Пол",
                    availableToAnonymous: true,
                    children: [
                        {
                            name: "мужчины",
                            id: "male"
                        },
                        {
                            name: "женщины",
                            id: "female"
                        }
                    ]
                },
                {
                    name: "Статус",
                    availableToAnonymous: true,
                    children: [
                        {
                            name: "онлайн",
                            id: "online"
                        }
                    ]
                },
                {
                    name: "Теги",
                    availableToAnonymous: true,
                    useForTags: 'friendship_tags',
                    children: [
                        {tag_type: 3, id: "друзья", name: "друзья"},
                        {tag_type: 3, id: "член семьи", name: "член семьи"},
                        {tag_type: 3, id: "родственники", name: "родственники"},
                        {tag_type: 3, id: "коллеги", name: "коллеги"},
                        {tag_type: 3, id: "в отношениях", name: "в отношениях"},
                        {tag_type: 3, id: "бывшие", name: "бывшие"}
                    ]
                }

            ]
        });

})();
