(function () {
    'use strict';
    angular.module('app.react.infinitescrolldirective', []).directive('rContentInfiniteScroll', [
        '$q', '$window', 'contentEvents', 'InfiniteListViewComponent',
        function ($q, $window, contentEvents, InfiniteListViewComponent) {
            return {
                restrict: 'AE',
                replace: false,
                scope: {
                    options: '=',
                    items: '='
                },
                link: function (scope, element) {

                    var defaultOptions = {
                        items: [],
                        //viewport: null,
                        //itemComponentName: null,
                        //loadItems: null,
                        visibleItemsCount: 100,
                        appendItemsCount: 50,
                        checkOnLoad: false,
                        totalItems: 0,
                        maxColumns: 3,
                        itemSelector: '.masonry-brick',
                        key: 'content-listview'
                    };

                    function getProps() {
                        var props = angular.extend({}, defaultOptions, scope.options);

                        if (angular.isArray(scope.items)) {
                            props.items = scope.items;
                        }

                        if (scope.options && scope.options.scrollContainerId) {
                            props.viewport = document.getElementById(scope.options.scrollContainerId);
                        }

                        return props;
                    }

                    scope.props = getProps();

                    var renderComponent = function (props) {
                        props = props || getProps();
                        var factory = React.createFactory(InfiniteListViewComponent);
                        React.render(factory(props), element[0]);
                    };

                    renderComponent();

                    scope.$watch('options', function () {
                        renderComponent();
                    });


                    scope.$on(contentEvents.OBJECTS_LOADED, function (e, args) {
                        var props = getProps();
                        props.items = args.items;
                        renderComponent(props);
                    });

                    scope.$on(contentEvents.OBJECTS_RELOADED, function (e, args) {
                        var props = getProps();
                        props.updateLayout = true;
                        props.items = angular.isArray(args.items) ? args.items : [];
                        renderComponent(props);
                    });

                    scope.$on('$destroy', function () {
                        React.unmountComponentAtNode(element[0]);
                    });
                }
            };
        }]);
})();