(function () {
    'use strict';
    angular.module('app.react.mapinfinitescrolldirective', []).directive('rMapContentInfiniteScroll', [
        '$q', '$window', 'reactComponentsFactoryService', 'contentEvents', '$rootScope', 'mapEvents',
        function ($q, $window, reactComponentsFactoryService, contentEvents, $rootScope, mapEvents) {
            return {
                restrict: 'AE',
                replace: false,
                scope: {
                    items: '=',
                    options: '='
                    //itemComponentName: '=',
                    //visibleItemsCount: '=',
                    //scrollContainerId: '@',
                    //maxColumns: '='
                },
                link: function (scope, element) {
                    //var scrollContainer = document.getElementById(scope.);
                    var defaultOptions = {
                        //items: [],
                        //viewport: null,
                        //itemComponentName: null,

                        visibleItemsCount: 100,
                        appendItemsCount: 50,
                        checkOnLoad: false,
                        totalItems: 0,
                        maxColumns: 1,
                        itemSelector: '.masonry-brick',
                        key: 'map-content-listview'
                    };

                    var overloadedOptions = {
                        loadItems: null,
                        maxColumns: 1
                    };

                    function getProps() {
                        //return {
                        //    viewport: scrollContainer,
                        //    itemComponentName: scope.itemComponentName,
                        //    visibleItemsCount: Number(scope.visibleItemsCount),
                        //    items: angular.isArray(scope.items) ? scope.items : [],
                        //    maxColumns: scope.maxColumns,
                        //    key: 'map-content-listview'
                        //};

                        var props = angular.extend({}, defaultOptions, scope.options, overloadedOptions);

                        if (angular.isArray(scope.items)) {
                            props.items = scope.items;
                        }

                        if (scope.options && scope.options.scrollContainerId) {
                            props.viewport = document.getElementById(scope.options.scrollContainerId);
                        }

                        return props;
                    }

                    scope.props = getProps();

                    var renderComponent = function (props) {
                        props = props || getProps();
                        var factory = reactComponentsFactoryService.getByComponentName('InfiniteListViewComponent');
                        React.render(React.createElement(factory, props), element[0]);
                    };

                    renderComponent();

                    scope.$watchGroup('options', function () {
                        renderComponent();
                    });

                    scope.$onRootScope(mapEvents.OBJECTS_CHANGED, function (e, args) {
                        var props = getProps();
                        props.updateLayout = true;
                        props.items = angular.isArray(args.mapObjects) ? args.mapObjects : [];
                        renderComponent(props);
                    });

                    scope.$onRootScope(mapEvents.SCROLL_TO_OBJECT, function (event, args) {
                        if (args && args.obj) {
                            var props = getProps();
                            props.updateLayout = true;
                            props.selectedItem = args.obj;
                            renderComponent(props);
                        }
                    });

                    scope.$on('$destroy', function () {
                        React.unmountComponentAtNode(element[0]);
                    });
                }
            };
        }]);
})();