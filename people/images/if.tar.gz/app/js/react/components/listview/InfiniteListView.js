(function () {
    /** @jsx React.DOM */

    angular.module('app.react.components.infinitelistview', [])
        .value('ScrollDirection', {
            'TOP': 1,
            'BOTTOM': -1,
            'NONE': 0
        })
        .value('ScrollSettings', {
            MIN_UPDATE_INTERVAL: 60000
        })
        .factory('InfiniteListViewComponent', [
            '$q', '$window', '$timeout', 'reactComponentsFactoryService',
            'ScrollDirection', '$rootScope', 'LoadItemsMode', 'ScrollSettings',
            function ($q, $window, $timeout, reactComponentsFactoryService,
                      ScrollDirection, $rootScope, LoadItemsMode, ScrollSettings) {
                return React.createClass({
                    displayName: 'InfiniteListView',

                    propTypes: {
                        //items: React.PropTypes.array.isRequired, //items to display (all items will be rendered)
                        items: React.PropTypes.array, //items to display (all items will be rendered)
                        totalItems: React.PropTypes.number.isRequired, //total amount of the items on the server
                        //itemComponentName: React.PropTypes.string, //item template name (type of react component)
                        itemComponent: React.PropTypes.func.isRequired, //item template name (type of react component)
                        itemComponentProps: React.PropTypes.object, //item component default properties
                        visibleItemsCount: React.PropTypes.number.isRequired, //total amount of the visible items
                        appendItemsCount: React.PropTypes.number, //how many items will be requested from server
                        loadItems: React.PropTypes.func, //function for the data source updating (loadItems(offsetFrom, count, ts, mode))
                        viewport: React.PropTypes.object, //scrollable container
                        checkOnLoad: React.PropTypes.bool, //check items count on component load
                        updateLayout: React.PropTypes.bool, //should update infinite layout on componentDidUpdate
                        maxColumns: React.PropTypes.number, //max count of the all columns in the layout
                        selectedItem: React.PropTypes.object, //listView will be scrolled to this object after update
                        itemSelector: React.PropTypes.string, //selectors of the items in list view
                        compareItemsPredicate: React.PropTypes.func //function to compare items
                    },
                    getDefaultProps: function () {
                        return {
                            items: [],
                            totalItems: 0,
                            //itemComponentName: null,
                            //visibleItemsCount: 100,
                            appendItemsCount: 50,
                            loadItems: null,
                            viewport: null,
                            height: null,
                            showInfo: true,
                            checkOnLoad: false,
                            updateLayout: false,
                            maxColumns: null,
                            itemSelector: '.masonry-brick',
                            compareItemsPredicate: function (x, y) {
                                return x.id === y.id && x.entity_type === y.entity_type;
                            }
                        };
                    },
                    getDefaultState: function () {
                        return {
                            offsetTop: 0,
                            offsetBottom: 0
                        };
                    },
                    getInitialState: function () {
                        return this.getDefaultState(this.props);
                    },
                    getDefaultComponentData: function () {
                        return {
                            ts_from: null,
                            skipReachStartEvent: 0,
                            initLayoutOnUpdate: false,
                            skipChangeHeightEvent: false,
                            skipScrollEvent: false,
                            lastChangedHeight: null,
                            reachedEndScrollTop: null,
                            itemsQueue: [],
                            activeRequests: [],
                            uniqueIndex: 0,
                            reachedEnd: false,
                            reachedStart: true,
                            maxScrollTop: null,
                            showFooter: false,
                            itemsRefreshed: true,
                            renderedItemsCount: null,
                            lastUpdateTimeOnScrollTop: null,
                            lastUpdateTimeOnScrollBottom: null,
                            scrollerOptions: {
                                scrollBoundary: 10,
                                scrollResponseBoundary: 10,
                                scrollingX: false,
                                alwaysScroll: true,
                                scrollbars: true,
                                updateOnChanges: true,
                                updateOnWindowResize: true,
                                maxFlingDuration: 500
                            }
                        };
                    },
                    componentData: null,
                    shouldComponentUpdate: function (nextProps, nextState) {
                        var self = this;

                        return nextProps.totalItems !== this.props.totalItems ||
                                //nextProps.itemComponentName !== this.props.itemComponentName ||
                            nextProps.itemComponent !== this.props.itemComponent ||
                            nextProps.visibleItemsCount !== this.props.visibleItemsCount ||
                            nextProps.appendItemsCount !== this.props.appendItemsCount ||
                            nextState.offsetTop !== this.state.offsetTop ||
                            nextState.offsetBottom !== this.state.offsetBottom ||
                            nextState.reachedEnd !== this.state.reachedEnd ||
                            nextState.reachedStart !== this.state.reachedStart ||
                            ((nextProps.items && nextProps.items.length) || 0) !== this.componentData.renderedItemsCount ||
                            nextProps.maxColumns !== this.props.maxColumns ||
                            (nextProps.items && nextProps.items.length) !== (this.props.items && this.props.items.length) ||
                            _.some(nextProps.items, function (x) {
                                return !_.some(self.props.items, function (y) {
                                    //Проверка элементов - либо через предикат из defaultProps, либо можно передать другую функцию
                                    return self.props.compareItemsPredicate(x, y);
                                });
                            });
                    },
                    componentWillReceiveProps: function (nextProps) {
                        if (nextProps.updateLayout === true) {
                            this.componentData.itemsRefreshed = true;
                        }
                        //Если изменился itemsTemplate
                        //if (nextProps.itemComponentName !== this.props.itemComponentName) {
                        if (nextProps.itemComponent !== this.props.itemComponent) {
                            this.initComponent(nextProps);
                            this.resetLayout(false);
                        }

                        //Если на карте выбран объект, то скролим к нему
                        if (nextProps.selectedItem) {
                            this.scrollToItem(nextProps.selectedItem);
                        }
                    },
                    //Перезагрузка и перестроение всех элементов списка
                    resetLayout: function (skipScroll) {
                        this.componentData.activeRequests.length = 0;
                        this.componentData.reachedEnd = false;
                        this.componentData.reachedStart = true;

                        //Сброс лайоута
                        if (this.componentData.infiniteLayout) {
                            this.componentData.infiniteLayout.reloadItems(true);
                            this.componentData.infiniteLayout.layout();
                            this.componentData.infiniteLayout.flipTop();
                        }

                        //Скрол в начало списка
                        if (!skipScroll && this.componentData.scroller) {
                            this.componentData.skipReachStartEvent += 1;
                            this.componentData.scroller.scrollTo(null, 0);
                        }

                        var self = this;
                        $timeout(function () {
                            self.componentData.itemsRefreshed = false;
                            self.componentData.initLayoutOnUpdate = false;
                        }, 10);
                    },
                    initComponent: function (props) {
                        props = props || this.props;
                        this.componentData = angular.extend(this.componentData, this.getDefaultComponentData());

                        var state = this.getDefaultState(props);
                        this.setState(state);

                        if (props.checkOnLoad && angular.isFunction(props.loadItems)) {
                            $rootScope.loading = true;
                            var self = this;
                            this.loadMoreItems(ScrollDirection.NONE, true).then(function () {
                                $rootScope.loading = false;
                                self.componentData.initLayoutOnUpdate = true;
                            });
                        }
                    },
                    //Метод вызывается, когда достигнут конец списка и нужно догрузить еще элементы
                    //Parameters:
                    //scrollDirection - направление скрола списка (TOP, BOTTOM, NONE)
                    //reset - флаг, нужно ли загрузить элементы, начиная с самого первого
                    loadMoreItems: function (scrollDirection, reset) {
                        var deferred = $q.defer(), offsetFrom;

                        if (angular.isFunction(this.props.loadItems)) {
                            if (!reset) {
                                //Вычисление offset, начиная с которого будут запрашиваться элементы из сервиса
                                switch (scrollDirection) {
                                    case ScrollDirection.TOP:
                                        offsetFrom = this.state.offsetTop - this.props.appendItemsCount;
                                        break;
                                    case ScrollDirection.BOTTOM:
                                        offsetFrom = this.state.offsetTop + Math.min(this.props.appendItemsCount, this.props.items.length);
                                        break;
                                    case ScrollDirection.NONE:
                                        offsetFrom = this.state.offsetTop;
                                        break;
                                    default:
                                        console.error('Incorrect scroll direction', scrollDirection);
                                        return;
                                }
                            } else {
                                offsetFrom = 0;
                            }

                            //Сбрасываем timestamp, по которому запрашиваются элементы, если мы в начале списка или
                            //если он до этого не был установлен
                            if (!this.componentData.ts_from || offsetFrom < 0) {
                                this.componentData.ts_from = moment().valueOf();
                                if (offsetFrom < 0) {
                                    offsetFrom = 0;
                                }
                            }

                            //Timestamp для отображения в конце списка
                            //if (!this.componentData.ts_from_bottom || scrollDirection === ScrollDirection.BOTTOM) {
                            //    this.componentData.ts_from_bottom = moment().valueOf();
                            //}

                            var self = this;
                            //Уникальный ID запроса для того, чтобы сохранить его в очереди
                            var requestId = this.componentData.uniqueIndex++;

                            //Проверяем есть ли в процессе аналогичный запрос (с такими же offset и timestamp)
                            var activeRequest = _.chain(this.componentData.activeRequests).where(function (x) {
                                return x.from === offsetFrom && x.ts === self.componentData.ts_from;
                            }).first().value();

                            //Если аналогичный запрос уже отправлен и ожидается ответ, то возвращаем его из очереди
                            if (activeRequest) {
                                console.log('get from active requests', activeRequest);
                                return activeRequest.promise;
                            }

                            //Добавляем в очередь текущий запрос
                            this.componentData.activeRequests.push({
                                id: requestId,
                                from: offsetFrom,
                                ts: this.componentData.ts_from,
                                promise: deferred.promise
                            });

                            this.componentData.requestInProgress = true;

                            //Количество элементов, которые нужно загрузить
                            //var count = Math.max(this.props.appendItemsCount, this.props.visibleItemsCount - this.props.items.length);
                            var count = this.props.visibleItemsCount;

                            //Режим добавления элементом в список - в конце или в начало
                            var mode = scrollDirection === ScrollDirection.TOP ? LoadItemsMode.PREPEND : LoadItemsMode.APPEND;

                            var options = {
                                offsetFrom: offsetFrom,
                                count: count,
                                ts: this.componentData.ts_from,
                                mode: mode
                            };

                            this.props.loadItems(options)
                                .then(function (data) {
                                    //Если компонент уже не DOM дереве, то ничего не делаем
                                    if (!self.isMounted()) {
                                        return;
                                    }

                                    //Если получены элементы, то добавляем новые объекты в очередь,
                                    //чтобы при обновлении ListView добавить их в layout
                                    if (data.count > 0) {
                                        var newItems = null;
                                        if (mode === LoadItemsMode.APPEND) {
                                            newItems = data.items.slice(data.count * (-1));
                                        } else {
                                            newItems = data.items.slice(0, data.count);
                                        }
                                        self.componentData.itemsQueue.push({
                                            mode: mode,
                                            items: newItems
                                        });
                                    }

                                    var offsetBottom;
                                    if (angular.isNumber(data.offset)) {
                                        offsetBottom = data.offset + data.items.length - 1;
                                        self.setState({
                                            offsetTop: data.offset,
                                            offsetBottom: offsetBottom
                                        });
                                    } else {
                                        offsetBottom = self.state.offsetTop + data.items.length - 1;
                                        self.setState({offsetBottom: offsetBottom});
                                    }

                                    deferred.resolve(data);
                                }, function () {
                                    deferred.reject();
                                })
                                .finally(function () {
                                    //Удаляем выполненный запрос из очереди
                                    _.remove(self.componentData.activeRequests, function (request) {
                                        return request.id === requestId;
                                    });
                                    self.componentData.requestInProgress = false;
                                });
                        } else {
                            deferred.resolve(this.props.items);
                        }

                        return deferred.promise;
                    },
                    componentDidUpdate: function (prevProps) {
                        if (this.isMounted()) {
                            var self = this;
                            //Если изменилось максимальное количество колонок для ListView, то сбрасываем
                            //настройки infiniteLayout - это вызовет перестроение списка
                            if (this.props.maxColumns !== prevProps.maxColumns) {
                                this.componentData.infiniteLayout.reset({
                                    itemSelector: this.props.itemSelector,
                                    addItemsByOrder: false,
                                    maxColumns: this.props.maxColumns,
                                    topOffset: 5,
                                    container: this.state.viewport
                                });
                            } else if (this.componentData.infiniteLayout) {
                                //Обновляем список элементов в InfiniteLayout
                                this.componentData.infiniteLayout.reloadItems(true);

                                //Если элементы списка обновились (например, перезагрузка всех элементов),
                                //то сбрасываем весь layout и скроллим в начало списка
                                if (this.componentData.initLayoutOnUpdate || (this.componentData.itemsRefreshed && this.componentData.renderedItemsCount > 0)) {
                                    var skipScroll = this.componentData.itemsRefreshed;
                                    if (this.componentData.itemsRefreshed) {
                                        this.componentData.itemsRefreshed = false;
                                    }
                                    this.componentData.initLayoutOnUpdate = false;

                                    $timeout(function () {
                                        self.resetLayout(skipScroll);
                                    }, 0);
                                }
                                //Если в результате выполнения loadItems появились новые элементы в itemsQueue,
                                //то берем поочередно эти объекты и добавляем в конец или начало списка
                                else if (this.componentData.itemsQueue.length > 0) {
                                    angular.forEach(this.componentData.itemsQueue, function (queueItem) {
                                        if (queueItem.items.length > 0) {
                                            //Получаем DOM элементы по ID добавленных объектов
                                            var items = _.where(_.map(queueItem.items, function (item) {
                                                var id = self.getItemId(item);
                                                if (self.refs[id] && self.refs[id].isMounted()) {
                                                    return self.refs[id].getDOMNode();
                                                }
                                                return null;
                                            }), function (item) {
                                                return item !== null;
                                            });
                                            if (items.length > 0) {
                                                if (queueItem.mode === LoadItemsMode.APPEND) {
                                                    self.componentData.skipChangeHeightEvent = true;
                                                    self.componentData.infiniteLayout.append(items, true);
                                                    self.componentData.infiniteLayout.flipTop();
                                                }
                                                else {
                                                    self.componentData.skipChangeHeightEvent = true;
                                                    self.componentData.infiniteLayout.prepend(items, true);
                                                    self.componentData.infiniteLayout.flipTop();
                                                }
                                            }
                                        }
                                    });
                                }
                            }
                            this.componentData.itemsQueue.length = 0;

                            //if (prevProps.itemComponentName !== this.props.itemComponentName && this.componentData.scroller){
                            if (prevProps.itemComponent !== this.props.itemComponent && this.componentData.scroller) {
                                $timeout(function () {
                                    self.componentData.skipReachStartEvent += 1;
                                    self.componentData.scroller.scrollTo(null, 0);
                                }, 0);
                            }
                        }
                    },
                    //Метод для скрола списка к заданному объекту (используется на карте)
                    scrollToItem: function (item) {
                        console.log('scroll to', item);
                        var itemId = this.getItemId(item);
                        if (itemId && this.refs[itemId] && this.refs[itemId].isMounted()) {
                            var itemNode = this.refs[itemId].getDOMNode();
                            this.componentData.scroller.scrollTo(null, itemNode.offsetTop, 2500);
                        }
                    },
                    //Вызывается, когда достигнуто начало списка
                    onReachedStart: function () {
                        //Если есть активные запросы или задано, что нужно пропустить этот ивент, то ничего не делаем
                        if (this.componentData.requestInProgress || !this.isMounted() || this.componentData.skipScrollEvent ||
                            this.componentData.skipReachStartEvent > 0 || !angular.isFunction(this.props.loadItems)) {
                            if (this.componentData.skipReachStartEvent > 0) {
                                this.componentData.skipReachStartEvent -= 1;
                            }
                            return;
                        }

                        this.componentData.reachedStart = true;
                        var self = this;
                        $('.top-loader', this.getDOMNode()).show();

                        this.componentData.skipScrollEvent = true;
                        //Выравниваем столбцы по высоте (анимированно)
                        this.componentData.infiniteLayout.alignColumnsTo({top: 30}, {
                            animate: true,
                            duration: 300,
                            animateRows: 8
                        }, function () {
                            var nowTs = moment().valueOf();
                            var dt = nowTs - self.componentData.lastUpdateTimeOnScrollTop;
                            //Когда мы в начале списка, то при скроле обновляем элементы не чаще, чем раз в ScrollSettings.MIN_UPDATE_INTERVAL ms
                            if (((self.componentData.lastUpdateTimeOnScrollTop === null || dt >= ScrollSettings.MIN_UPDATE_INTERVAL) &&
                                self.state.offsetTop === 0) ||
                                self.state.offsetTop !== 0) {
                                $('.top-loader .loader-indicator', self.getDOMNode()).show();
                                self.componentData.lastUpdateTimeOnScrollTop = nowTs;
                                //console.log('loading....');

                                //Callback, когда все столбы выровнены - начинаем дозагрузку жлементов в начало списка
                                self.loadMoreItems(ScrollDirection.TOP).finally(function () {
                                    //Плавно прокручиваем список вниз, чтобы было видно добавленные элементы
                                    self.componentData.scroller.scrollBy(0, -75, 1000);
                                    self.componentData.skipScrollEvent = false;

                                    $('.top-loader', self.getDOMNode()).hide();
                                    $('.top-loader .loader-indicator', self.getDOMNode()).hide();

                                    if (self.componentData.scroller.scrollTop === 0) {
                                        self.componentData.infiniteLayout.alignColumnsTo({top: 5}, {
                                            animate: true,
                                            duration: 300,
                                            animateRows: 8
                                        });
                                    }
                                });
                            }
                            else {
                                self.componentData.lastUpdateTimeOnScrollTop = nowTs;
                                self.componentData.skipScrollEvent = false;
                                $('.top-loader', self.getDOMNode()).hide();
                            }
                        });
                    },
                    onReachedEnd: function () {
                        if (this.componentData.requestInProgress || !this.isMounted() ||
                            this.componentData.skipScrollEvent || !angular.isFunction(this.props.loadItems)) {
                            return;
                        }

                        this.componentData.reachedEndScrollTop = this.componentData.scroller.scrollTop;
                        this.componentData.reachedEnd = true;
                        this.componentData.skipReachStartEvent += 1;

                        var self = this;
                        $timeout(function () {
                            self.componentData.skipReachStartEvent -= 1;
                        }, 5000);

                        var handler = function () {
                            self.componentData.scroller.removeEventListener('scrollend', handler);


                            var nowTs = moment().valueOf();
                            var dt = nowTs - self.componentData.lastUpdateTimeOnScrollBottom;
                            var isOnBottom = self.state.offsetBottom >= (self.props.totalItems - 1);
                            //Когда мы в конце списка, то при скроле обновляем элементы не чаще, чем раз в ScrollSettings.MIN_UPDATE_INTERVAL ms
                            if (((self.componentData.lastUpdateTimeOnScrollBottom === null || dt >= ScrollSettings.MIN_UPDATE_INTERVAL) && isOnBottom) || !isOnBottom) {
                                self.componentData.lastUpdateTimeOnScrollBottom = nowTs;
                                //console.log('loading....');
                                $('.bottom-loader .loader-indicator', self.getDOMNode()).show();
                                self.loadMoreItems(ScrollDirection.BOTTOM).finally(function () {
                                    if (self.state.offsetBottom < (self.props.totalItems - 1)) {
                                        self.componentData.scroller.scrollBy(0, 75, 1000);
                                    }

                                    $('.bottom-loader', self.getDOMNode()).hide();
                                    $('.bottom-loader .loader-indicator', self.getDOMNode()).hide();

                                    $timeout(function () {
                                        var height = self.componentData.infiniteLayout.height();
                                        height = Math.max(height, self.state.viewport.offsetHeight);
                                        if (height !== self.componentData.lastChangedHeight) {
                                            self.componentData.scroller.updateDimensions(null, height);
                                        }
                                    }, 100);
                                });
                            }
                            else {
                                self.componentData.lastUpdateTimeOnScrollBottom = nowTs;
                                self.componentData.skipScrollEvent = false;
                                $('.bottom-loader', self.getDOMNode()).hide();
                            }
                        };

                        $('.bottom-loader', this.getDOMNode()).show();
                        this.componentData.scroller.addEventListener('scrollend', handler);
                    },
                    onScroll: function (data) {
                        if (this.componentData.skipScrollEvent) {
                            return;
                        }

                        if (data.scrollTop > 0) {
                            this.componentData.reachedStart = false;
                        }
                        else if (data.scrollTop < 0 && this.componentData.reachedStart && !this.componentData.requestInProgress) {
                            this.onReachedStart();
                        }
                    },
                    onScrollEnd: function () {
                        if (this.componentData.skipScrollEvent) {
                            return;
                        }

                        this.componentData.reachedEndScrollTop = null;

                        if (this.componentData.reachedEnd) {
                            this.componentData.reachedEnd = false;
                            var self = this;
                            self.componentData.scroller.scrollBy(0, -1);
                        }
                    },
                    cleanup: function () {
                        if (this.componentData.scroller) {
                            this.componentData.scroller.destroy(true);
                        }
                        if (this.componentData.infiniteLayout) {
                            this.componentData.infiniteLayout.cleanup();
                        }
                    },
                    componentWillUnmount: function () {
                        this.cleanup();
                        if (this.componentData.objectChangedListener) {
                            this.componentData.objectChangedListener();
                        }
                    },
                    componentWillMount: function () {
                        //Если компонент не был заново создан, то очищаем предыдущие properties
                        if (this.componentData !== null) {
                            this.cleanup();
                        }
                        this.componentData = this.getDefaultComponentData();
                    },
                    componentDidMount: function () {
                        var layoutNode = $(this.refs.itemsLayout.getDOMNode());
                        var self = this;

                        //Получаем контейнер для скрола
                        var viewport = this.state.viewport;
                        if (!viewport) {
                            if (this.props.viewport) {
                                viewport = this.props.viewport;
                            }
                            else {
                                viewport = this.refs.itemsLayout.getDOMNode();
                            }
                            this.setState({viewport: viewport});
                        }

                        //Инициализация FTScroller и добавление events listeners
                        var scroller = new FTScroller(viewport, this.componentData.scrollerOptions);
                        scroller.addEventListener('scroll', _.debounce(this.onScroll, 100));
                        scroller.addEventListener('scrollend', _.debounce(this.onScrollEnd, 100));
                        scroller.addEventListener('reachedstart', this.onReachedStart);
                        scroller.addEventListener('reachedend', this.onReachedEnd);

                        this.componentData.scroller = scroller;

                        //Инициализация InfiniteLayout
                        this.componentData.infiniteLayout = layoutNode.infiniteLayout({
                            itemSelector: this.props.itemSelector,
                            addItemsByOrder: false,
                            maxColumns: this.props.maxColumns,
                            topOffset: 5,
                            container: viewport
                        });

                        //Обрабатываем событие heightChanged InfiniteLayout, чтобы сохранить позицию скрола
                        layoutNode.on($window.infiniteLayout.Events.heightChanged, this.onLayoutHeightChanged);

                        this.initComponent();

                        this.componentData.objectChangedListener = $rootScope.$on('objectChanged', function () { // update react list when ask do autocheckin
                            if (self.isMounted()) {
                                self.forceUpdate();
                            }
                        });

                    },
                    //Вызывается при изменении высоты InfiniteLayout
                    onLayoutHeightChanged: function (e, args) {
                        if (args && angular.isNumber(args.value) && angular.isNumber(args.oldValue)) {
                            var dx = args.value - args.oldValue;

                            if (this.componentData.skipChangeHeightEvent) {
                                this.componentData.skipChangeHeightEvent = false;
                            }
                            else if (this.componentData.scroller) {
                                //Вычисляем изменение высоты списка и просчитываем положение, куда нужно
                                //проскролить, чтобы остаться в том же месте, что и до изменения высоты
                                this.componentData.lastChangedHeight = args.value;

                                //Отключаем возможность скролирования, пока не перейдем в нужное положение
                                this.componentData.scroller.setDisabledInputMethods({
                                    scroll: true
                                });
                                this.componentData.skipScrollEvent = true;

                                var self = this;
                                var onScrollHandler = function () {
                                    //После того, как переместили скрол на нужную позицию, проверяем положение скрола
                                    //и устанавливаем новые размеры для контейнера
                                    self.componentData.scroller.removeEventListener('scrollend', onScrollHandler);
                                    if (self.componentData.scroller.scrollTop !== scrollTo) {
                                        self.componentData.scroller.scrollTo(0, scrollTo);
                                    }
                                    self.componentData.scroller.updateDimensions(null, Math.max(args.value, self.state.viewport.offsetHeight));
                                    self.componentData.scroller.setDisabledInputMethods({
                                        scroll: false
                                    });
                                    self.componentData.skipScrollEvent = false;
                                };

                                var scrollTo = (this.componentData.reachedEndScrollTop || this.componentData.scroller.scrollTop) + dx;
                                this.componentData.scroller.addEventListener('scrollend', onScrollHandler);
                                this.componentData.scroller.scrollTo(0, scrollTo);
                            }
                        }
                    },
                    //Возвращает строку с информацией об отображаемых объектах (использовалась для дебага)
                    getFooter: function () {
                        var itemsCount = angular.isArray(this.props.items) ? this.props.items.length : 0;
                        var totalNodes = this.isMounted() ? $(this.getDOMNode()).find('*').length : 0;
                        return 'visible: ' + this.state.offsetTop + '-' + (this.state.offsetTop + itemsCount) +
                            ' (' + itemsCount + ')' + ' ; total dom nodes: ' + totalNodes +
                            ' ; total items: ' + this.props.totalItems;
                    },
                    //Возвращает сообщение, которое отображается в начале списка при скроле
                    getTopMessage: function () {
                        //TODO: translate
                        if (this.state.offsetTop > 0) {
                            return 'Впереди ' + this.state.offsetTop + ' элементов';
                        }
                        else {
                            //var ts = Math.max(this.componentData.ts_from_bottom, this.componentData.ts_from);
                            var time = moment(this.componentData.ts_from);
                            var message = 'Вы в начале списка, начните скроллить вверх, чтобы обновить.';
                            if (time.isValid()) {
                                message += ' Время последнего обновления: ' + time.format('HH:mm:ss');
                            }
                            return message;
                        }
                    },
                    //Возвращает сообщение, которое отображается в конце списка при скроле
                    getBottomMessage: function () {
                        if (this.props.items) {
                            //TODO: translate
                            var offsetBottom = this.state.offsetTop + this.props.items.length - 1;
                            if (offsetBottom < (this.props.totalItems - 1)) {
                                return 'Позади ' + (this.props.totalItems - offsetBottom) + ' элементов';
                            }
                        }

                        //var ts = Math.max(this.componentData.ts_from_bottom, this.componentData.ts_from);
                        //var ts = Math.max(this.componentData.ts_from_bottom, this.componentData.ts_from);
                        //var formattedTime = moment(ts).format('HH:mm:ss');
                        //return 'Вы в конце списка, продолжайте скроллить вниз, чтобы обновить. Время последнего обновления: ' + formattedTime;
                        return null;
                    },
                    //Получение id объекта в refs
                    getItemId: function (item) {
                        return 'listview-item-' + item.id;
                    },
                    //Формирование списка компонентов-элементов списка
                    getItemsComponents: function () {
                        //var listViewItem = React.createFactory(reactComponentsFactoryService.getByComponentName(this.props.itemComponentName));
                        var listViewItem = React.createFactory(this.props.itemComponent);
                        var itemsCount = angular.isArray(this.props.items) ? this.props.items.length : 0;
                        var items = [];

                        for (var i = 0; i < itemsCount; i++) {
                            var item = this.props.items[i];
                            var itemId = this.getItemId(item);

                            var props = {
                                ref: itemId,
                                key: itemId,
                                item: item
                            };

                            items.push(listViewItem(_.defaults(props, this.props.itemComponentProps || {})));
                        }

                        return items;
                    },
                    render: function () {
                        var items = this.getItemsComponents();

                        //Если изменилось количество объектов по сравнения с предыдущих рендерингом, то запоминаем это
                        //и обновляем layout после того, как рендеринг завершится (см. DidUpdate)
                        //this.componentData.renderedItemsCount = items && items.length > 0 ? items.length : 0;
                        var count = items && items.length > 0 ? items.length : 0;
                        if (count === 0 && count !== this.componentData.renderedItemsCount) {
                            this.componentData.itemsRefreshed = true;
                        }
                        this.componentData.renderedItemsCount = count;

                        //Можно использовать для дебага
                        //console.log(this.getFooter());
                        $window.listView = this;

                        return (
                            <div className='infinite-listview'>
                                <div className='listview-loader top-loader'>
                                    <div className='loader-indicator'></div>
                                    <div className="listview-message message-top">{this.getTopMessage()}</div>
                                </div>
                                <div ref="itemsLayout">{items}</div>
                                <div className='listview-loader bottom-loader'>
                                    <div className='loader-indicator'></div>
                                    <div className="listview-message message-bottom">{this.getBottomMessage()}</div>
                                </div>
                            </div>
                        );
                    }
                });
            }
        ]);
})();
