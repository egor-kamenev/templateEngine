(function () {
    (function (window, Math, $) {
        'use strict';

        var $window = $(window);
        var oldInfinity = window.infiniteLayout;
        var infiniteLayout = window.infiniteLayout = {};


        // ListView Class
        // ==============

        infiniteLayout.Events = {
            layoutUpdated: '__infinite_layout_updated',
            itemsReloaded: '__infinite_layout_items_reloaded',
            itemsAppended: '__infinite_layout_items_appended',
            itemsPrepended: '__infinite_layout_items_prepended',
            heightChanged: '__infinite_layout_height_changed'
        };

        infiniteLayout.defaultOptions = {
            itemsSelector: null,
            columnWidth: null,
            hSpace: 0,
            vSpace: 0,
            addItemsByOrder: true,
            topOffset: 0,
            offsetLeft: 0,
            offsetRight: 0,
            maxColumns: null,
            stretchWidth: true,
            horizontalAlign: 'center'
        };

        function ListView(container, options) {
            options = mergeOptions(options);

            this.$el = $(container);

            this.columns = [];
            this.items = options.items || [];
            this.options = options;
            this._height = null;
            this.columnWidth = options.columnWidth;

            DOMEvent.attach(this);

            this.$el.data('infiniteLayout', this);
        }

        ListView.prototype.reset = function (options) {
            this.options = mergeOptions(options);
            this.columnWidth = options.columnWidth;
            this.reloadItems(true);
            this.layout();
        };

        ListView.prototype.alignColumnsTo = function (position, options, callback) {
            //console.log('infiniteLayout align columns', position, this);

            options = options || {};

            if (this.columns.length === 0 || this.items.length === 0) {
                if (typeof callback === 'function') {
                    callback();
                }
                return;
            }

            var itemsCount = 0;
            for (var i = 0; i < this.columns.length; i++) {
                itemsCount += this.columns[i].items.length;
            }
            if (itemsCount !== this.items.length) {
                this.layout();
            }

            var dx = this.columns[0].left - (typeof  position.left === 'number' ? position.left : this.columns[0].left);
            if (!options.animate) {
                this.columns.forEach(function (column) {
                    column.top = typeof position.top === 'number' ? position.top : column.top;
                    column.left -= dx;
                    column.updatePosition();
                });
                if (typeof callback == 'function') {
                    callback();
                }
            }
            else {
                position.dx = dx;
                animateColumnPosition(0, this.columns, position, options, false, callback);
            }

            //console.log('infiniteLayout align columns finished', position, this);
        };

        ListView.prototype.height = function () {
            var columnsHeight = [0];
            for (var i = 0; i < this.columns.length; i++) {
                columnsHeight.push(this.columns[i].actualBottom());
            }
            return Math.max.apply(null, columnsHeight);
        };

        ListView.prototype.append = function (items, skipColumnAlign) {
            //console.log('infiniteLayout append items', items, this);

            if (this.columns.length === 0 && items && items.length > 0) {
                this.layout(items);
            }
            else {
                var startColumnIndex = getStartColumnIndex(this.columns);

                for (var i = 0; i < items.length; i++) {
                    var item = new ListViewItem(items[i]);
                    if (isDuplicateItem(item, this.columns)) {
                        continue;
                    }

                    var columnIndex = 0;
                    if (this.options.addItemsByOrder) {
                        columnIndex = startColumnIndex++ % this.columns.length;
                    }
                    else {
                        var minColumnHeight = null;
                        for (var j = 0; j < this.columns.length; j++) {
                            var height = this.columns[j].actualBottom();
                            if (minColumnHeight === null || minColumnHeight > height) {
                                minColumnHeight = height;
                                columnIndex = j;
                            }
                        }
                    }
                    this.columns[columnIndex].append(items[i], false);
                }
            }

            if (!skipColumnAlign) {
                this.flipTop();
            }
            else {
                updateListViewHeight(this);
            }

            //console.log('infiniteLayout append items finished', this);

            this.$el.triggerHandler({
                type: infiniteLayout.Events.itemsAppended,
                target: this.$el[0]
            });
        };

        ListView.prototype.prepend = function (items, skipColumnAlign) {
            //console.log('infiniteLayout prepend items', items.length);
            if (this.columns.length === 0 && items && items.length > 0) {
                //TODO: reverse items
                this.layout(items);
            }
            else {
                var startColumnIndex = getStartColumnIndex(this.columns, true);

                for (var i = items.length - 1; i > -1; i--) {
                    var item = new ListViewItem(items[i]);
                    if (isDuplicateItem(item, this.columns)) {
                        continue;
                    }

                    var columnIndex = 0;
                    if (this.options.addItemsByOrder) {
                        columnIndex = startColumnIndex--;
                        if (startColumnIndex < 0) {
                            startColumnIndex = this.columns.length - 1;
                        }
                    }
                    else {
                        var maxColumnTop = null;
                        for (var j = this.columns.length - 1; j >= 0; j--) {
                            var top = this.columns[j].actualTop();
                            if (maxColumnTop === null || maxColumnTop < top) {
                                maxColumnTop = top;
                                columnIndex = j;
                            }
                        }
                    }

                    this.columns[columnIndex].prepend(items[i], false);
                }
            }

            if (!skipColumnAlign) {
                this.flipTop();
            }
            else {
                updateListViewHeight(this);
            }

            this.$el.triggerHandler({
                type: infiniteLayout.Events.itemsPrepended,
                target: this.$el[0]
            });
        };

        ListView.prototype.flipTop = function () {
            //console.log('infiniteLayout flip top');
            var top = null;
            for (var n = 0; n < this.columns.length; n++) {
                var columnTop = this.columns[n].actualTop();
                if (top === null || columnTop < top) {
                    top = columnTop;
                }
            }
            if (top !== null) {
                var self = this;
                this.columns.forEach(function (column) {
                    column.top = column.items.length > 0 ? (column.items[0].top - top) : self.options.topOffset;
                    column.updatePosition();
                });
            }

            updateListViewHeight(this);
        };

        function isDuplicateItem(item, columns) {
            for (var i = 0; i < columns.length; i++) {
                var column = columns[i];
                for (var j = 0; j < column.items.length; j++) {
                    if (column.items[j].id !== item.id && column.items[j].$el[0] === item.$el[0]) {
                        return true;
                    }
                }
            }
            return false;
        }

        ListView.prototype.reloadItems = function (force) {
            //console.log('infiniteLayout reload items, force:', force);
            if (force) {
                if (this.options.itemSelector) {
                    this.items = $(this.options.itemSelector, this.$el);
                }
                else {
                    this.items = this.$el.children();
                }
            }
            else {
                var len = this.items.length;
                while (len--) {
                    if (!$.contains(document, this.items[len])) {
                        this.items.splice(len, 1);
                    }
                }
            }

            var itemsCountInColumns = 0;
            for (var i = 0; i < this.columns.length; i++) {
                itemsCountInColumns += this.columns[i].items.length;
            }
            if (this.items.length > itemsCountInColumns) {

            }

            this.columns.forEach(function (column, i, columns) {
                var len = column.items.length;
                while (len--) {
                    if (!$.contains(document, column.items[len].$el[0]) || isDuplicateItem(column.items[len], columns)) {
                        column.items[len].cleanup();
                        column.items.splice(len, 1);
                    }
                }
            });

            //updateListViewHeight(this);

            this.$el.triggerHandler({
                type: infiniteLayout.Events.itemsReloaded,
                target: this.$el[0]
            });
        };

        ListView.prototype.layout = function (items) {
            //console.log('infiniteLayout layout', this);
            if (this.columns.length > 0) {
                this.columns.forEach(function (column) {
                    column.remove();
                });
                this.columns.length = 0;
            }

            items = items || this.items;

            var firstItemsWidth = items.length > 0 ? $(items[0]).outerWidth(true) : 0;

            var freeSpace = this.$el.width();
            if (!freeSpace && typeof this.options.container !== 'undefined') {
                freeSpace = $(this.options.container).width();
            }
            freeSpace = freeSpace - this.options.offsetLeft - this.options.offsetRight;
            var columnWidth = typeof this.options.columnWidth === 'number' ? this.options.columnWidth : firstItemsWidth;

            if (columnWidth !== 0) {
                var index = 0;
                while (freeSpace >= columnWidth && (this.options.maxColumns === null || index < this.options.maxColumns)) {
                    freeSpace -= columnWidth;
                    this.columns.push(new ListViewColumn(this, index++, columnWidth));
                }
                if (freeSpace > 0) {
                    var appendSpace = Math.floor(freeSpace / this.columns.length);
                    for (var i = 0; i < this.columns.length; i++) {
                        this.columns[i].width += appendSpace;
                    }
                }
                if (this.columns.length > 0) {
                    this.append(items);
                }
            }

            updateListViewHeight(this);
            //console.log('infiniteLayout layout finished', this);
            this.$el.triggerHandler({
                type: infiniteLayout.Events.layoutUpdated,
                target: this.$el[0]
            });
        };

        ListView.prototype.find = function (findObj) {
        };

        ListView.prototype.cleanup = function () {
            DOMEvent.detach(this);

            this.columns.forEach(function (column) {
                column.remove();
            });
            this.columns.length = 0;
            //TODO: cleanup columns and items
        };

        // ListViewColumn Class
        // ==============

        function ListViewColumn(listView, columnIndex, width) {
            this.top = listView.options.topOffset;
            this.width = width;
            this.columnIndex = columnIndex;
            this.items = [];

            this.parent = listView;

            this.updatePosition();
        }


        // ListViewColumn manipulation
        // ---------------------

        ListViewColumn.prototype.append = function (obj, skipUpdate) {
            if (!obj) {
                return null;
            }

            var item = new ListViewItem(obj, this, false);

            if (!skipUpdate) {
                updateCoords(item, this.actualBottom(), this.left);
            }

            //this.width = Math.max(this.width, item.width);
            this.items.push(item);

            return item;
        };

        ListViewColumn.prototype.prepend = function (obj, skipUpdate) {
            if (!obj) {
                return null;
            }

            var item = new ListViewItem(obj, this, true);

            if (!skipUpdate) {
                var columnTop = this.actualTop();
                var itemTop = this.items.length > 0 ? (columnTop - item.height - (this.parent.options.vSpace || 0)) : this.parent.options.topOffset;
                updateCoords(item, itemTop, this.left);
            }

            //this.width = Math.max(this.width, item.width);
            this.items.splice(0, 0, item);

            return item;
        };

        ListViewColumn.prototype.actualTop = function () {
            if (this.items.length > 0) {
                return this.items[0].top;
            }
            else {
                return 0;
            }
        };

        ListViewColumn.prototype.actualBottom = function () {
            if (this.items.length > 0) {
                return this.items[this.items.length - 1].bottom;
            }
            else {
                return 0;
            }
        };

        ListViewColumn.prototype.updatePosition = function (yOffset) {
            var listView = this.parent;
            var left = this.parent.options.offsetLeft;
            if (this.columnIndex === 0) {
                left = this.left || left;
            }
            else {
                for (var i = 0; i < this.columnIndex && i < listView.columns.length; i++) {
                    left += listView.columns[i].width + (i === 0 ? listView.columns[0].left : 0) + (listView.options.hSpace || 0);
                }
            }

            this.left = left;
            yOffset = yOffset || listView.options.topOffset;
            for (var j = 0; j < this.items.length; j++) {
                var top = j > 0 ? (this.items[j - 1].bottom + (listView.options.vSpace || 0)) : (this.top + yOffset);
                var columnLeft;

                switch (listView.options.horizontalAlign) {
                    case 'left':
                        columnLeft = this.left;
                        break;
                    case 'right':
                        columnLeft = this.left + this.width - this.items[j].width;
                        break;
                    case 'center':
                        //default:
                        columnLeft = this.left + this.width / 2 - this.items[j].width / 2;
                        break;
                }
                if (columnLeft < this.left) {
                    columnLeft = this.left;
                }
                else if (columnLeft > (this.left + this.width)) {
                    columnLeft = this.left + this.width;
                }

                updateCoords(this.items[j], top, columnLeft);
            }
        };


        ListViewColumn.prototype.remove = function () {
            this.items.forEach(function (item) {
                item.cleanup();
            });
            this.items.length = 0;
        };

        var DOMEvent = (function () {
            var eventIsBound = false,
                resizeTimeout = null,
                boundViews = [];

            function resizeHandler() {
                if (resizeTimeout) clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(resizeAll, 200);
            }

            function resizeAll() {
                for (var i = 0; i < boundViews.length; i++) {
                    boundViews[i].layout();
                }
            }

            return {
                attach: function (listView) {
                    if (!eventIsBound) {
                        $window.on('resize', resizeHandler);
                        eventIsBound = true;
                    }
                    boundViews.push(listView);
                },
                detach: function (listView) {
                    var index, length;
                    for (index = 0, length = boundViews.length; index < length; index++) {
                        if (boundViews[index] === listView) {
                            boundViews.splice(index, 1);
                            if (boundViews.length === 0) {
                                $window.off('resize', resizeHandler);
                                eventIsBound = false;
                            }
                            return true;
                        }
                    }
                    return false;
                }
            };
        }());


        // ListViewItem class
        // ==============

        var uniqueListViewItemID = 0;

        function ListViewItem(obj, parent, prepend) {
            this.$el = $(obj);
            this.id = uniqueListViewItemID++;
            this.top = 0;
            this.bottom = 0;
            this.width = 0;
            this.height = 0;

            this.parent = parent;

            if (parent && parent instanceof ListViewColumn) {
                updateCoords(this, prepend ? 0 : parent.top, parent.left);
            }
        }

        ListViewItem.prototype.clone = function () {
            var item = new ListViewItem(this.$el);
            item.top = this.top;
            item.bottom = this.bottom;
            item.width = this.width;
            item.height = this.height;
            return item;
        };

        ListViewItem.prototype.remove = function () {
            this.$el.remove();
            this.cleanup();
        };

        ListViewItem.prototype.cleanup = function () {
            this.parent = null;
        };

        // Helpers
        // ==============

        function mergeOptions(options) {
            var copy = {};
            for (var attr in infiniteLayout.defaultOptions) {
                if (infiniteLayout.defaultOptions.hasOwnProperty(attr)) {
                    copy[attr] = infiniteLayout.defaultOptions[attr];
                }
            }
            for (var attrOptions in options) {
                if (options.hasOwnProperty(attrOptions)) {
                    copy[attrOptions] = options[attrOptions];
                }
            }
            return copy;
        }

        function updateListViewHeight(listView) {
            var maxColumnHeight = listView.height();
            if (maxColumnHeight !== listView._height) {
                var oldHeight = listView._height;

                if (typeof listView.options.container !== 'undefined') {
                    maxColumnHeight = Math.max(maxColumnHeight, $(listView.options.container).height());
                }
                listView._height = maxColumnHeight;
                listView.$el.height(maxColumnHeight);


                listView.$el.triggerHandler({
                    type: infiniteLayout.Events.heightChanged,
                    target: listView.$el[0]
                }, {
                    value: listView._height,
                    oldValue: oldHeight
                });
            }
        }

        function updateCoords(listItem, top, left) {
            var $el = listItem.$el;

            listItem.top = top;
            listItem.left = left;
            listItem.height = $el.outerHeight(true);
            listItem.bottom = listItem.top + listItem.height;
            listItem.width = $el.outerWidth(true);

            $el.css({left: listItem.left, top: listItem.top, position: 'absolute'});
        }

        function getStartColumnIndex(columns, prepend) {
            var startColumnIndex = null;
            if (columns && columns.length > 0) {
                var minItemsCount = null;
                if (prepend) {
                    var len = columns.length;
                    while (len--) {
                        var count = columns[len].items.length;
                        if (minItemsCount === null || count <= minItemsCount) {
                            minItemsCount = count;
                            startColumnIndex = len;
                        }
                    }
                }
                else {
                    columns.forEach(function (column, index) {
                        var count = column.items.length;
                        if (minItemsCount === null || count < minItemsCount) {
                            minItemsCount = count;
                            startColumnIndex = index;
                        }
                    });
                }
            }
            else {
                startColumnIndex = prepend ? (columns.length - 1) : 0;
            }
            return startColumnIndex;
        }

        function animateColumnPosition(index, columns, position, options, onlyThisColumn, cb) {
            var col = columns[index];
            if (col) {
                var duration = typeof options.duration !== 'undefined' ? options.duration : 'slow';
                var top = typeof position.top === 'number' ? position.top : col.top;
                var dy = col.top - top;
                var rowCount = typeof options.animateRows === 'number' ? options.animateRows : col.items.length;
                rowCount = Math.min(rowCount, col.items.length);

                var itemsToAnimate = col.items.slice(0, rowCount).map(function (item) {
                    return item.$el[0];
                });

                var callbackIndex = 0;
                var callback = function () {
                    if (options.together && callbackIndex++ === 0) {
                        animateColumnPosition(index + 1, columns, position, options, onlyThisColumn, cb);

                        col.top = top;
                        col.left -= position.dx;
                        col.updatePosition();

                        if ((onlyThisColumn || index >= (columns.length - 1)) && typeof cb === 'function') {
                            cb();
                        }
                    }
                    else if (!options.together && callbackIndex++ === Math.max((itemsToAnimate.length - 1), 0)) {
                        if (!onlyThisColumn && index < (columns.length - 1)) {
                            animateColumnPosition(index + 1, columns, position, options, onlyThisColumn, cb);
                        }

                        col.top = top;
                        col.left -= position.dx;
                        col.updatePosition();

                        if ((onlyThisColumn || index >= (columns.length - 1)) && typeof cb === 'function') {
                            cb();
                        }
                    }
                };

                //console.log('animate col', index, 'top: -=' + dy, 'left:-=', position.dx);
                if (itemsToAnimate.length === 0) {
                    callback();
                }
                else if (options.together) {
                    $(itemsToAnimate).animate({
                        top: '-=' + dy,
                        left: '-=' + position.dx
                    }, duration);
                    callback();
                }
                else {
                    $(itemsToAnimate).animate({
                        top: '-=' + dy,
                        left: '-=' + position.dx
                    }, duration, callback);
                }
            }
        }

        // Export
        // ======

        // Classes:
        infiniteLayout.ListView = ListView;
        infiniteLayout.ListViewColumn = ListViewColumn;
        infiniteLayout.ListViewItem = ListViewItem;

        //jQuery plugin
        function registerPlugin(infiniteLayout) {
            var ListView;
            if (infiniteLayout) {
                ListView = infiniteLayout.ListView;

                $.fn.infiniteLayout = function (options) {
                    return new ListView(this, options);
                };
            }
            else {
                delete $.fn.listView;
            }
        }

        registerPlugin(infiniteLayout);

        // Destroy own packaging:
        infiniteLayout.noConflict = function () {
            window.infiniteLayout = oldInfinity;
            registerPlugin(oldInfinity);
            return infiniteLayout;
        };

    })(window, Math, jQuery);
})();