(function(){
angular.module('app.react.factoryservice', [])
    .service('reactComponentsFactoryService', [
        '$injector', '$window',
        function ($injector, $window) {
            var factories = {};

            this.getByComponentName = function (componentName) {
                if (!factories[componentName]) {
                    var reactComponent = $injector.get(componentName) || $window[componentName];
                    if (!reactComponent) {
                        throw Error('Cannot find react component ' + componentName);
                    }

                    //factories[componentName] = React.createFactory(reactComponent);
                    factories[componentName] = reactComponent;
                }

                return factories[componentName];
            };
        }
    ]);
})();