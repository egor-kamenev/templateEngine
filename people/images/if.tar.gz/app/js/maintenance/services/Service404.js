(function(){
angular.module('maintenance.Service404', []).
service('Service404',[function(){

    // Default message
    this._message = "Not found";
    var self = this;

    this.getMessage = function(){
        return self._message;
    };

    this.setMessage = function(m){
        self._message = m;
    };

}]);

})();