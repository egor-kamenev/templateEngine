(function(){
'use strict';

angular.module('app.controllers.ctrl401ctrl', [])
  .controller('401Ctrl', ['$scope', function ($scope) {
        $scope.message = 'К сожалению, Ваш аккаунт заблокирован. Обратиться в поддержку';
  }]);

})();