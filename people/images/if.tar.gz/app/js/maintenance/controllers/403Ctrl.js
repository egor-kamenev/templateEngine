(function(){
'use strict';

angular.module('app.controllers.ctrl403ctrl', [])
  .controller('403Ctrl', ['$scope', 'Service404', function ($scope, Service404) {

        $scope.message = Service404.getMessage();
    }]);

})();