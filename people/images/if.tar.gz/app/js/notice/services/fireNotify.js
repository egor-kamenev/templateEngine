(function () {
    'use strict';
    var TRANSALTE_TYPE = ['needLogin', 'needAcceptedEmail'];
    angular.module('notice.services', [])
        .constant('MESSAGE_CONFIG', {
            needAcceptedEmail: {
                translateMessage: ['EMAIL_NEED_CONFIRM_MESSAGE', ''],
                translateTitle: ['EMAIL_NEED_CONFIRM_TITLE', '']
            },
            needLogin: {
                translateMessage: ['USER_WITHOUT_PERMISSION_MESSAGE', ''],
                translateTitle: ['USER_SET_STATUS', '']
            }
        })
        .factory('fireNotify', ['$compile', '$rootScope', '$translate', '$q', 'MESSAGE_CONFIG', function ($compile, $rootScope, $translate, $q, MESSAGE_CONFIG) {
            var stack = [];
            var CHECKED_FIELDS = ['title', 'text', 'type', 'addclass', 'animation'];

            function msgInStack(msg) {
                return _.where(stack, _.pick(msg, CHECKED_FIELDS)).length > 0;
            }

            function addToStack(msg) {
                stack.push(msg);
            }

            function removeFromStack(msg) {
                _.remove(stack, function (rec) {
                    return _.isEqual(_.pick(msg, CHECKED_FIELDS), _.pick(rec, CHECKED_FIELDS));
                })
            }

            function translateMessage(params) {
                var deferred = $q.defer();
                if (TRANSALTE_TYPE.indexOf(params.type) != -1) {
                    var msgObj = MESSAGE_CONFIG[params.type];

                    $translate([
                        params.text,
                        msgObj.translateMessage[0],
                        msgObj.translateTitle[0]
                    ]).then(function(translations){
                        var text = '<a data-ui-sref="userSettings.profile({username:user.username})">' +
                            translations[msgObj.translateMessage[0]] + '</a>';

                        if (params.text) {
                            text = '<legend>' + (params.useTranslate ? $translate(params.text) : params.text) + '</legend><br/>' + text;
                        }

                        deferred.resolve({
                            type: 'error',
                            text: text,
                            title: translations[msgObj.translateTitle[0]]
                        });
                    });
                } else {
                    deferred.resolve(params);
                }

                return deferred.promise;
            }

            return function (raw_msg, scope) {
                var default_notify = {
                    title: '',
                    text: '',
                    type: 'notice',
                    history: false,
                    addclass: '',
                    after_init: _.noop,
                    after_close: _.noop,
                    after_open: _.noop
                };


                //var msg = translateMessage(raw_msg).then(function(msg){
                translateMessage(raw_msg).then(function(msg){
                    msg = angular.extend(default_notify, msg);
                    if (msgInStack(msg)) {
                        return;
                    }

                    console.info("NOTICE", msg);

                    addToStack(msg);
                    var noticeScope = (scope || $rootScope).$new(false);

                    new PNotify({
                        title: msg.title,
                        text: msg.text,
                        type: msg.type,
                        history: msg.history,
                        animation: 'none',
                        stack: false,
                        addclass: msg.addclass,

                        after_init: function (pNotify) {
                            $compile(pNotify.container)(noticeScope);

                            // fire message callback if exists
                            msg.after_init(pNotify);
                        },

                        after_close: function (pNotify) {
                            removeFromStack(msg);
                            noticeScope.$destroy();

                            // fire message callback if exists
                            msg.after_close(pNotify);
                        },

                        after_open: function (pNotify) {
                            // fire message callback if exists
                            msg.after_open(pNotify);
                        },

                        buttons: {
                            closer: true,
                            labels: {
                                close: "Close"
                            }
                        }
                    });

                });


            };
        }]);
})();
