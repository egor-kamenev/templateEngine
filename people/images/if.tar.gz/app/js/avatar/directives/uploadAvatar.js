(function () {
    'use strict';

    angular.module('avatar.uploadavatar', ['app', 'app.utils.imageuploader']).directive('uploadAvatar', [
        function () {

            var scope = {
                entity: '='
            };

            function link(scope, element, attributes, controller) {
            }

            function Controller($scope) {
                $scope.loadingFiles = false;

                // TODO make global filter
                //$scope.onlyOriginalImages = function (item) {
                //    return !item.name.match(/^(large|medium|small|micro):/);
                //};
                var uploadFail = function(){
                    $scope.$emit("flash", {
                        type: "error",
                        title: "Avatar not updated",
                        text: "Error upload avatar to server"
                    });
                };

                $scope.options = {
                    url: RESTANGULAR_BASE_URL + 'api/users/upload_avatar/',
                    singleFileUploads: true,
                    limitMultiFileUploads: 1,
                    maxNumberOfFiles: 1,
                    acceptFileTypes: /(\.|\/)(gif|jpe?g|png)$/i,
                    maxFileSize: 3145728,        // 3 Mb
                    fail: uploadFail,
                    cancel: function () {
                        $scope.closeUploadDialog();
                    },
                    done: function (response) {
                        if(typeof response.result !== 'undefined' && response.result == 'success'){
                            $scope.$emit("flash", {
                                type: "success",
                                title: "Success",
                                text: "Avatar uploaded"
                            });
                            $scope.closeUploadDialog();
                            angular.extend($scope.entity, response);
                            $scope.$emit('avatarUploadDone', response);
                        } else {
                            uploadFail();
                        }
                    }
                };

                $scope.openUploadDialog = function () {
                    $scope.entity.isUploadAvatarDialog = true;
                };

                $scope.closeUploadDialog = function () {
                    $scope.entity.isUploadAvatarDialog = false;
                };

            }

            Controller.$inject = ['$scope'];

            return ({
                scope: scope,
                controller: Controller,
                link: link,
                restrict: "AE",
                replace: true,
                templateUrl: '/static/partials/avatar/upload_avatar.html'
            });

        }]);

})();