(function () {
    'use strict';

    angular.module('app', [
        'templates',
        'tag.services',
        'ui.router',
        'ui.select',
        'blueimp.fileupload',
        'ui.mask',
        "ui.date",
        'rpc',
        // 'ui.rpcUIState',
        'ngLocale',
        'ngCookies',
        'leaflet-directive',
        'socketio',
        'services',
        'events.services',
        'messages.services',
        'channel.services',
        //'deferred.services',
        'events.filters',
        'events.eventForm',
        'friends.services',
        'visibility.services',
        'places.services',
        'map.services',
        'users.services',
        'app.controllers.wallmessagectrl',
        'app.controllers.walleventsctrl',
        'app.controllers.wallparticipatedeventsctrl',
        'app.controllers.wallplacesctrl',
        //'app.controllers.wallfriendsctrl',
        'app.controllers.wallgalleriesctrl',
        'app.controllers.userstreamctrl',
        'app.controllers.xpostsdiscussion',
        'app.controllers.contentctrl',
        'app.controllers.filtersctrl',

//    'app.controllers.userinfoctrl',
        'app.controllers.indexctrl',
//        'app.controllers.calendarctrl',
        'app.controllers.eventctrl',
        'app.controllers.eventcreatectrl',
        'app.controllers.eventstreamctrl',
        'app.controllers.eventparticipantsctrl',
        'app.controllers.eventbansctrl',
        'app.controllers.eventsubscribersctrl',
        'app.controllers.invitesctrl',
        'app.controllers.placestreamctrl',
        'app.controllers.placeparticipantsctrl',
        'app.controllers.placebansctrl',
        'app.controllers.placesubscribersctrl',
        'app.controllers.placeeventsctrl',
//    'app.controllers.placehistoryctrl',
        'forms.directives',
        'app.controllers.eventresourcesctrl',
        'app.controllers.eventresourcesbytypectrl',
        'app.controllers.eventresourcesbytypetoolsctrl',
        'app.controllers.eventplaceshistoryctrl',
        'app.controllers.resourcerequestsctrl',
        'app.controllers.placectrl',
        'app.controllers.newplacectrl',
        'app.controllers.detailctrl',
        'app.controllers.ctrl404ctrl',
        'app.controllers.ctrl403ctrl',
        'app.controllers.ctrl401ctrl',
        'app.controllers.signupctrl',
        'app.controllers.favoritesctrl',
        'app.controllers.galleriesctrl',
        'app.controllers.photoctrl',
        'app.controllers.verifyemailctrl',
        'app.controllers.messagesctrl',
        'app.controllers.userctrl',
        'app.controllers.userwallctrl',
        'app.controllers.userstatusesfavoritesctrl',
        'app.controllers.userinterestsctrl',
        'app.controllers.usersubscribersctrl',
        'app.controllers.usersubscriptionsctrl',
        'friends.controllers.invitationsfriendsctrl',
        'app.controllers.userfriendsctrl',
        'app.controllers.usercontentctrl',
        'app.controllers.userbansctrl',
        'app.directives.newfriendshipmodal',
        'app.directives.confirmdialog',
        'app.services.filters',
        'app.directives.dateTimePicker',
        'galleries.multiupload.directive',
        'galleries.preview.directive',
        'galleries.slideshow.directive',
        'galleries.attach.directive',
        'galleries.detach.directive',
        'galleries.edit.directive',
        'galleries.photoedit.directive',
        'places.directives',
        'visibility.directives',
        'app.ngBlur',
        'event.checkInOut',
        'event.checkInOutService',
        'event.cancelVisit',
        'tag.widget',
        'tag.input',
        'places.placeForm',
        'places.placeCheckInOut',
        'places.hostEvent.directive',
        'bookmarks.services',
        'bookmarks.doBookmark',
        'likes.services',
        'likes.doLike',
        'events.placeChanges',
        'favorites.services',
        'favorites.doFavorite',
        'utils.settings',
        'maintenance.Service404',
        'contacts.service',
        'complains.doComplain',
        'complains.service',
        //'infinite-scroll',
        'subscriptions.doSubscribe',
        'subscriptions.service',
        'userban.services',
        'userban.addUserban.directive',
        'app.controllers.userbanctrl',
        'auth',
        'app.togglePopup',
        'app.currentState',
        'messages',
        'bookmarks',
        'app.settings',
        'sticky',
        'app.controllers.statusctrl',
        'status.activeStatus.directive',
        'status.services',
        'app.controllers.socialdonectrl',
        'utils.uploadImage',
        'users.welcome',
        'users.closeProfile',
        'users.toIgnore',
        'users.userAvatar',
        'places.saveuserplace',
        'avatar.uploadavatar',
        'app.services.xposts',
        'app.directives.xwall',
        'pascalprecht.translate',
        'app.controllers.translatectrl',
        'app.utils.breadcrumb',
        'app.utils.breadcrumb.service',
        'app.utils.imagecropper',
        'app.xwall.discussion.settings',
        'app.utils.postform',
        'app.utils.imagesfilters',
        'app.utils.invitordatetimepicker',
        'app.mailPreview',
        'users.services.location',
        'app.utils.xmlhttpservice',
        'app.utils.asyncscriptloader',
        'app.services.contentsettingsservice',
        'app.utils.scroll',
        'app.services.contentitemssourceservice',
        'app.jqPagination',
        'app.react',
        'app.react_stream_objects',
        'app.react_stream',
        'notice.services',
        'app.react.factoryservice',
        'app.react.components.infinitelistview',
        'app.react.infinitescrolldirective',
        'app.react.mapinfinitescrolldirective'
    ])
        .config(['$translateProvider', function ($translateProvider) {
            //use the static-files loader to load JSON files from a path with language files
            $translateProvider.useStaticFilesLoader({
                prefix: '/static/languages/',
                suffix: '.json'
            });

            $translateProvider.registerAvailableLanguageKeys(['en', 'ru']);
            $translateProvider.fallbackLanguage(['en', 'ru']);

            $translateProvider.useLocalStorage();
            // todo: use user language right from the start
            $translateProvider.use("en");
        }])
        .config(['$provide', function ($provide) {
            $provide.decorator('$rootScope', ['$delegate', function ($delegate) {

                Object.defineProperty($delegate.constructor.prototype, '$onRootScope', {
                    value: function (name, listener) {
                        var unsubscribe = $delegate.$on(name, listener);
                        this.$on('$destroy', unsubscribe);
                        return unsubscribe;
                    },
                    enumerable: false
                });
                return $delegate;
            }]);
        }])
        .config(["$urlRouterProvider", function ($urlRouterProvider) {
            $urlRouterProvider
                .when('/users/:user/subscriptions', '/users/:user/subscriptions/subscribers')
                .when('/', '/events?show=list');

            $urlRouterProvider.rule(function ($injector, $location) {

                var path = $location.path(),
                    search = $location.search(),
                    params;
                if (path[path.length - 1] != '/') {
                    return;
                }
                if (Object.keys(search).length === 0) {
                    return path.slice(0, -1);
                }
                params = [];
                angular.forEach(search, function (v, k) {
                    params.push(k + '=' + v);
                });
                return path.slice(0, -1) + '?' + params.join('&');
            });
        }])
        .config(["$locationProvider", function ($locationProvider) {
            $locationProvider
                .html5Mode(true)
                .hashPrefix('!');
        }])
        .config(["jsonRPCProvider", function (jsonRPCProvider) {
            jsonRPCProvider.setup({
                endPoint: JSON_RPC_ENDPOINT,
                namespace: 'v1'
            });
        }])
        .config(["socketioProvider", function (socketioProvider) {
            socketioProvider.setup({
                webSocketSwfLocation: '/static/flash/WebSocketMain.swf',
                webSocketDebug: true
            });
        }])
        .config(["$httpProvider", function ($httpProvider) {
            $httpProvider.defaults.transformRequest.push(function (data, headers) {
                var injector = angular.injector(['ngCookies']);
                var c = injector.get('$cookies');
                if (c.csrftoken) {
                    headers()['X-CSRFToken'] = c.csrftoken;
                }

                return data;
            });

            $httpProvider.defaults.useXDomain = true;

            // CORS setup: may be unnecessary
            delete $httpProvider.defaults.headers.common['X-Requested-With'];
            $httpProvider.defaults.withCredentials = true;
        }])
        .config(['$stateProvider', '$translateProvider', 'contentSettings', function ($stateProvider, $translateProvider, contentSettings) {
            /*
             * Note: $translateProvider injected here for load eula template by $translateProvider.use()
             */

            function loadRootPost(sourceWall) {

                return ['$q', '$rootScope', '$state', '$stateParams', '$filter', 'xPostsService', 'eventsService', 'placesService', 'Service404', 'userService', function ($q, $rootScope, $state, $stateParams, $filter, xPostsService, eventsService, placesService, Service404, userService) {
                    var
                    // Source wall object type
                        objectIsEvent = sourceWall == 'event',
                        objectIsPlace = sourceWall == 'place',
                        objectIsUser = sourceWall == 'user',
                        objectIsPhoto = sourceWall == 'photo',
                        source, params,
                        postID = $stateParams.post_id,
                        deferred = $q.defer();

                    if (objectIsEvent) {
                        source = eventsService.getEvent;
                        params = $stateParams.event_alias;
                    }
                    else if (objectIsPlace) {
                        source = placesService.getPlace;
                        params = $stateParams.place_alias;
                    }
                    else if (objectIsPhoto) {
                        source = xPostsService.getPhotoByID;
                        params = $stateParams.photo_id;
                    }
                    else if (objectIsUser) {

                        source = function () {
                            var dummyD = $q.defer(),
                                data = {
                                    owner: {username: $stateParams.username}
                                };
                            userService.getProfileByUsername(
                                $stateParams.username,
                                function (response) {
                                    angular.extend(data, response);
                                    dummyD.resolve(data);
                                },
                                function () {
                                    $rootScope.$emit("flash", {
                                        type: "error",
                                        title: "Error",
                                        text: "Error retrieving profile data."
                                    });
                                    dummyD.reject();
                                }
                            );
                            return dummyD.promise;
                        };
                        params = $stateParams.username;

                    }

                    source(params).then(
                        function (object) {

                            if (object.error) {

                                if ($rootScope.isLogicError(object.error)) {
                                    deferred.reject();
                                    Service404.setMessage(object.error.data.msg);
                                    $state.go('404');
                                }
                                else if ($rootScope.isPermissionDenied(object.error)) {
                                    deferred.reject();
                                    Service404.setMessage("Нет доступа к объекту обсуждения");
                                    $state.go('403');
                                }

                            }
                            else {
                                var locator = {};
                                if (objectIsEvent) {
                                    object = object.result;
                                    locator = {'event': object.id};
                                }
                                else if (objectIsPlace) {
                                    object = object.result;
                                    locator = {'place': object.id};
                                }
                                else if (objectIsUser) {
                                    locator = {'username': object.owner.username};
                                }
                                else if (objectIsPhoto) {
                                    locator = {'photo': object.id};
                                }

                                return xPostsService.getPostByID(locator, postID).then(
                                    function (post) {
                                        if (post.error) {
                                            if ($rootScope.isLogicError(post.error)) {
                                                Service404.setMessage(post.error.data.msg);
                                                $state.go('404');
                                                deferred.reject();

                                            }
                                            else if ($rootScope.isPermissionDenied(post.error) || $rootScope.isContentBanned(post.error)) {
                                                Service404.setMessage("Нет доступа к посту");
                                                $state.go('403');
                                                deferred.reject();

                                            }

                                        }
                                        else {
                                            deferred.resolve(
                                                {
                                                    object: object,
                                                    post: post
                                                }
                                            );
                                        }
                                    },
                                    function (response) {
                                        if (response.status == 403) {
                                            if ($rootScope.isContentBanned(response.data)) {
                                                Service404.setMessage($filter('translate')('EXCEPT_POST_BANNED'));
                                            }
                                            else if ($rootScope.isContentOnModeration(response.data)) {
                                                Service404.setMessage($filter('translate')('EXCEPT_POST_WAITING_MODERATION'));
                                            }
                                            else if ($rootScope.isPermissionDenied(response.data)) {
                                                Service404.setMessage($filter('translate')('EXCEPT_POST_NO_PERMISSION'));
                                            }
                                            $state.go('403');
                                        }
                                        else {
                                            deferred.reject();
                                            Service404.setMessage($filter('translate')('EXCEPT_POST_NOT_FOUND'));
                                            $state.go('404');
                                        }
                                    }
                                );
                            }
                        },
                        function () {
                            deferred.reject();
                            Service404.setMessage("Объект не найден");
                            $state.go('404');
                        }
                    );

                    return deferred.promise;
                }];
            }

            $stateProvider.__oldState = $stateProvider.state;
            $stateProvider.state = function (name, definition) {
                function MixedState(options) {
                    var mixins = options.mixins;
                    if (!!options.mixins) {
                        delete options.mixins;
                        _.each(mixins, function (mix) {
                            _.merge(options, mix, function (a, b) {
                                if (_.isArray(a)) {
                                    return a.concat(b);
                                }
                            });
                        });
                    }

                    return options;
                }

                return $stateProvider.__oldState(name, MixedState(definition));
            };

            var restrictUserProfileOwnerAccessMixin = {
                resolve: {
                    restrictOwnerAccess: ['$q', "isProfileOwner",
                        function ($q, isProfileOwner) {
                            var deferred = $q.defer();
                            (isProfileOwner) ? deferred.resolve("granted") : deferred.reject({state: 403});
                            return deferred.promise;
                        }]
                }
            };

            var restrictUserProfilePrivacyAccessMixin = {
                resolve: {
                    restrictPrivacyAccess: ['$q', "isProfileOwner", "UserProfile",
                        function ($q, isProfileOwner, UserProfile) {
                            var deferred = $q.defer();
                            if (!isProfileOwner) {
                                var hasPrivacyConfig = !!this.data && !!this.data.privacySectionAlias;
                                var sectionVisible = hasPrivacyConfig && UserProfile.sections.indexOf(this.data.privacySectionAlias) != -1;
                                if (UserProfile.isDiscoverable && sectionVisible) {
                                    console.info("restrictPrivacyAccess", "OK");
                                    deferred.resolve();
                                } else {
                                    console.info("restrictPrivacyAccess", "403");
                                    deferred.reject({state: 403});
                                }
                            } else {
                                deferred.resolve("granted");
                            }

                            return deferred.promise;
                        }]
                }
            };

            var restrictUnauthorizedAccessMixin = function (permissions) {
                return {
                    resolve: {
                        restrictUnauthorizedAccess: [
                            "$q", "$state", "AppState", "userService", "fireNotify",
                            function ($q, $state, AppState, userService, fireNotify) {
                                var deferred = $q.defer();
                                if (permissions && permissions.length) {
                                    console.info("restrictUnauthorizedAccessMixin", "check", permissions);
                                    userService.getUser().then(function () {
                                        var hasPerm = userService.hasPerm(permissions);
                                        if (hasPerm) {
                                            deferred.resolve("granted");
                                        } else {
                                            deferred.reject(function (event, toState, toParams, fromState, fromParams) {
                                                event.preventDefault();
                                                $state.go(AppState.isLoaded() && fromState || "content");
                                                //todo: make notice more verbose
                                                fireNotify({
                                                    type: "needAcceptedEmail",
                                                    useTranslate: true
                                                });
                                            });
                                        }
                                    });
                                } else {
                                    console.info("restrictUnauthorizedAccessMixin", "granted1", permissions);
                                    deferred.resolve("granted");
                                }

                                return deferred.promise;
                            }
                        ]
                    }
                };
            };

            var userProfileSectionPrivacyMixin = {
                resolve: {
                    sectionPrivacy: [
                        '$state', '$stateParams', '$q', '$rootScope', 'visibilityService', 'authenticatedUser', 'isProfileOwner',
                        function ($state, $stateParams, $q, $rootScope, visibilityService, authenticatedUser, isProfileOwner) {
                            if (isProfileOwner) {
                                return authenticatedUser.section_visibilities[this.data.privacySectionAlias];
                            }

                        }
                    ]
                }
            };


            $stateProvider
                .state('root', {
                    abstract: true,
                    templateUrl: "/static/partials/index.html",
                    resolve: {
                        authenticatedUser: ["userService", function (userService) {
                            return userService.getUser();
                        }]
                    },
                    data: {
                        breadcrumbCaption: 'PAGE_TITLE_HOME'
                    }
                });

            $stateProvider
                .state('about', {
                    parent: "root",
                    url: '/about',
                    templateUrl: "/static/partials/doc/about.html",
                    title: 'PAGE_TITLE_ABOUT'
                })
                .state('eula', {
                    parent: "root",
                    url: '/eula',
                    templateUrl: "/static/partials/doc/eulas/ru.html",
                    title: 'PAGE_TITLE_EULA'
                })
                .state('contacts', {
                    parent: "root",
                    url: '/contacts',
                    templateUrl: "/static/partials/doc/contacts.html",
                    title: 'PAGE_TITLE_CONTACTS'
                })
                .state('copyright', {
                    parent: "root",
                    url: '/copyright',
                    templateUrl: "/static/partials/doc/copyright.html",
                    title: 'PAGE_TITLE_COPYRIGHT'
                });


            $stateProvider.state('content', {
                parent: "root",
                url: '/{content:(?:events|places|users)}?show?tags?centerPlace?use_location?dt1?dt2?category?related?state?page',
                reloadOnSearch: false,
                views: {
                    "@root": {
                        controller: "ContentCtrl",
                        templateUrl: "/static/partials/content/content.html"
                    },
                    // T1042
                    "filters@root": {
                        controller: "FiltersCtrl",
                        templateUrl: "/static/partials/content/filters.html"
                    }
                },
                data: {
                    contentCaptions: {
                        events: 'PAGE_TITLE_CONTENT_CONTENT_EVENTS',
                        places: 'PAGE_TITLE_CONTENT_CONTENT_PLACES',
                        users: 'PAGE_TITLE_CONTENT_CONTENT_USERS'
                    },
                    modeCaptions: {
                        map: 'PAGE_TITLE_CONTENT_MODE_MAP',
                        stream: 'PAGE_TITLE_CONTENT_MODE_STREAM',
                        list: 'PAGE_TITLE_CONTENT_MODE_LIST'
                    },
                    breadcrumbSiblings: function (state, $rootScope) {
                        var content = $rootScope.currentFilterContentType || $rootScope.$state.params.content;
                        switch (content) {
                            case 'users':
                                return ['events', 'places'];
                            case 'events':
                                return ['users', 'places'];
                            case 'places':
                                return ['users', 'events'];
                            default:
                                return ['users', 'events', 'places'];
                        }
                    },
                    breadcrumbCaption: function (state, $rootScope, viewScope, $injector, data) {
                        var content = $rootScope.currentFilterContentType || $rootScope.$state.params.content;
                        var mode = $rootScope.currentFilterMode || $rootScope.$state.params.show;

                        var captionHtml = '"' + data.contentCaptions[content] + '" | translate';
                        var modeHtml = '"' + data.modeCaptions[mode] + '" | translate';
                        var $parse = $injector.get('$parse');
                        return $parse(captionHtml)(viewScope) + ' - ' + $parse(modeHtml)(viewScope);
                    }
                }
            });

            // new event
            $stateProvider.state('new_event', {
                parent: "root",
                url: '/new_event',
                controller: 'EventCreateCtrl',
                templateUrl: '/static/partials/events/create.html',
                title: 'PAGE_TITLE_NEW_EVENT',
                mixins: [
                    restrictUnauthorizedAccessMixin([
                        'events.add_event'
                    ])
                ]
            });

            $stateProvider.state('event', {
                abstract: true,
                parent: "root",
                url: '/events/:event_alias',
                title: '[[eventName]]',
                views: {
                    "": {
                        controller: 'EventCtrl',
                        templateUrl: '/static/partials/events/event-base.html'
                    },
                    "section-tools": {}
                },
                data: {
                    breadcrumbParentState: 'content',
                    breadcrumbCaption: function (scope) {
                        return scope.eventName;
                    }
                }
            });

            $stateProvider.state('event.wall', {
                url: '?page',
                views: {
                    "@event": {
                        templateUrl: '/static/partials/events/wall.html',
                        controller: 'EventWallCtrl'
                    },
                    "section-tools@event": {
                        templateUrl: '/static/partials/events/wall-tools.html'
                    }
                },
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_WALL"
                }
            });


            $stateProvider.state('event.post', {
                resolve: {
                    rootPost: loadRootPost('event')
                },
                url: '/posts/:post_id?page',
                title: 'PAGE_EVENT_TITLE_POST',
                views: {
                    "@event": {
                        templateUrl: '/static/partials/wall/xpost_discussion.html',
                        controller: 'xPostDiscussion'
                    },
                    "section-tools@event": {
                        templateUrl: '/static/partials/wall/xpost-tools.html',
                        controller: 'xPostDiscussion'
                    }
                },
                data: {
                    breadcrumbParentState: 'event.wall'
                }
            });

            $stateProvider.state('event.stream', {
                url: '/stream?page',
                controller: 'EventStreamCtrl',
                templateUrl: '/static/partials/events/stream.html',
                title: 'PAGE_TITLE_EVENT_STREAM',
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_STREAM"
                }
            });

            $stateProvider.state('event.route', {
                url: '/route?page',
                title: 'PAGE_TITLE_EVENT_ROUTE',
                views: {
                    "@event": {
                        controller: 'EventPlacesHistoryCtrl',
                        templateUrl: '/static/partials/events/places.html'
                    },
                    "section-tools@event": {
                        templateUrl: '/static/partials/events/places-tools.html'
                    }
                },
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_ROUTE"
                }
            });

            $stateProvider.state('event.participants', {
                url: '/participants?page',
                templateUrl: '/static/partials/events/participants.html',
                controller: 'EventParticipantsCtrl',
                title: 'PAGE_TITLE_EVENT_PARTICIPANTS',
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_PARTICIPANTS"
                }
            });

            $stateProvider.state('event.albums', {
                url: '/albums',
                templateUrl: '/static/partials/events/albums.html',
                controller: 'EventAlbumsCtrl',
                title: 'PAGE_TITLE_EVENT_ALBUMS',
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_ALBUMS"
                }
            });

            $stateProvider.state('event.photo', {
                url: '/posts/:post_id/photo/:photo_id?page',
                resolve: {
                    rootPost: loadRootPost('event')
                },
                templateUrl: '/static/partials/galleries/photo.html',
                controller: 'PhotoCtrl',
                title: 'PAGE_TITLE_EVENT_PHOTO',
                data: {
                    breadcrumbParentState: 'event.albums',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_PHOTO"
                }
            });

            $stateProvider.state('event.subscribers', {
                url: '/subscribers?page',
                templateUrl: '/static/partials/events/subscribers.html',
                controller: 'EventSubscribersCtrl',
                title: 'PAGE_TITLE_EVENT_SUBSCRIBERS',
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_SUBSCRIBERS"
                }
            });

            $stateProvider.state('event.bans', {
                url: '/bans?page',
                templateUrl: '/static/partials/events/bans.html',
                controller: 'EventBansCtrl',
                title: 'PAGE_TITLE_EVENT_BANS',
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_BANS"
                }
            });

            $stateProvider.state('eventResources', {
                url: '/resources',
                parent: 'event',
                controller: 'EventResourcesCtrl',
                templateUrl: '/static/partials/events/event_resources.html',
                title: 'PAGE_TITLE_EVENT_RESOURCES',
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: 'PAGE_TITLE_EVENT_RESOURCES'
                }
            });

            $stateProvider.state('event.ResourcesByType', {
                url: '/resources/:resource_type?openModal',
                title: 'PAGE_TITLE_EVENT_RESOURCES_BY_TYPE',
                views: {
                    "@event": {
                        templateUrl: '/static/partials/events/event_resources_by_type.html',
                        controller: 'EventResourcesByTypeCtrl'
                    },
                    "section-tools@event": {
                        templateUrl: '/static/partials/events/resources_by_type-tools.html',
                        controller: 'EventResourcesByTypeToolsCtrl'
                    }
                },
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: 'PAGE_TITLE_EVENT_RESOURCES_BY_TYPE'
                }
            });

            $stateProvider.state('event.requests', {
                url: '/requests?page',
                controller: 'ResourceRequestsCtrl',
                templateUrl: '/static/partials/events/resource_requests.html',
                title: 'PAGE_TITLE_EVENT_RESOURCE_REQUESTS',
                data: {
                    breadcrumbParentState: 'event',
                    breadcrumbCaption: "PAGE_TITLE_EVENT_REQUESTS"
                }
            });

            $stateProvider.state('new_place', {
                parent: "root",
                url: '/new_place',
                controller: 'newPlaceCtrl',
                templateUrl: '/static/partials/places/newplace.html',
                title: 'PAGE_TITLE_NEW_PLACE',
                data: {
                    breadcrumbParentState: 'content'
                },
                mixins: [
                    restrictUnauthorizedAccessMixin([
                        'events.add_userplace'
                    ])
                ]
            });

            $stateProvider.state('place', {
                abstract: true,
                parent: "root",
                url: '/places/:place_alias',
                title: 'PAGE_TITLE_PLACE',
                views: {
                    "": {
                        controller: 'PlaceCtrl',
                        templateUrl: '/static/partials/places/place-base.html'
                    },
                    "section-tools": {}
                },
                data: {
                    breadcrumbParentState: 'content',
                    breadcrumbCaption: function (scope) {
                        return scope.placeName;
                    }
                }
            });

            $stateProvider.state('place.wall', {
                url: '?page',
                views: {
                    "@place": {
                        templateUrl: '/static/partials/places/wall.html',
                        controller: 'PlaceWallCtrl'
                    },
                    "section-tools@place": {
                        templateUrl: '/static/partials/places/wall-tools.html'
                    }
                },
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: "PAGE_TITLE_WALL"
                }
            });

            $stateProvider.state('place.post', {
                resolve: {
                    rootPost: loadRootPost('place')
                },
                url: '/posts/:post_id?page',
                title: 'PAGE_TITLE_PLACE_POST',
                views: {
                    "@place": {
                        templateUrl: '/static/partials/wall/xpost_discussion.html',
                        controller: 'xPostDiscussion'
                    },
                    "section-tools@place": {
                        templateUrl: '/static/partials/wall/xpost-tools.html',
                        controller: 'xPostDiscussion'
                    }
                },
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: "Пост"
                }
            });

            $stateProvider.state('place.stream', {
                url: '/stream?page',
                controller: 'PlaceStreamCtrl',
                templateUrl: '/static/partials/places/stream.html',
                title: 'PAGE_TITLE_PLACE_STREAM',
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: "PAGE_TITLE_PLACE_STREAM"
                }
            });

            $stateProvider.state('place.participants', {
                url: '/participants?page',
                controller: 'PlaceParticipantsCtrl',
                templateUrl: '/static/partials/places/participants.html',
                title: 'PAGE_TITLE_PLACE_PARTICIPANTS',
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: "PAGE_TITLE_PLACE_PARTICIPANTS"
                }
            });

            $stateProvider.state('place.events', {
                url: '/events?page',
                controller: 'PlaceEventsCtrl',
                templateUrl: '/static/partials/places/events.html',
                title: 'PAGE_TITLE_PLACE_EVENTS',
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: "PAGE_TITLE_PLACE_EVENTS"
                }
            });

            $stateProvider.state('place.albums', {
                url: '/albums',
                title: 'PAGE_TITLE_PLACE_ALBUMS',
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: "PAGE_TITLE_PLACE_ALBUMS"
                },
                views: {
                    "@place": {
                        templateUrl: '/static/partials/places/albums.html',
                        controller: 'PlaceAlbumsCtrl'
                    }
                }
            });

            $stateProvider.state('place.photo', {
                url: '/posts/:post_id/photo/:photo_id?page',
                resolve: {
                    rootPost: loadRootPost('place')
                },
                templateUrl: '/static/partials/galleries/photo.html',
                controller: 'PhotoCtrl',
                title: 'PAGE_TITLE_PLACE_PHOTO',
                data: {
                    breadcrumbParentState: 'place.albums',
                    breadcrumbCaption: 'PAGE_TITLE_PLACE_PHOTO'
                }
            });

            // место / список забаненных юзеров в обсуждении
            $stateProvider.state('place.bans', {
                url: '/bans?page',
                controller: 'PlaceBansCtrl',
                templateUrl: '/static/partials/places/bans.html',
                title: 'PAGE_TITLE_PLACE_BANS',
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: 'PAGE_TITLE_PLACE_BANS'
                }
            });

            // место / список подписчиков
            $stateProvider.state('place.subscribers', {
                url: '/subscribers?page',
                controller: 'PlaceSubscribersCtrl',
                templateUrl: '/static/partials/places/subscribers.html',
                title: 'PAGE_TITLE_PLACE_SUBSCRIBERS',
                data: {
                    breadcrumbParentState: 'place',
                    breadcrumbCaption: 'PAGE_TITLE_PLACE_SUBSCRIBERS'
                }
            });

            $stateProvider
                .state('user', {
                    abstract: true,
                    parent: "root",
                    url: '/users/:username',
                    title: 'PAGE_TITLE_USER',
                    resolve: {
                        UserProfile: ['$q', '$rootScope', '$state', '$stateParams', '$filter', 'Service404', 'userService', 'authenticatedUser',
                            function ($q, $rootScope, $state, $stateParams, $filter, Service404, userService, authenticatedUser) {
                                var defer = $q.defer();
                                if (authenticatedUser.username != $stateParams.username) {
                                    userService.getProfileByUsername(
                                        $stateParams.username,
                                        function (data) {
                                            defer.resolve({
                                                isDiscoverable: data.is_discoverable,
                                                sections: data.sections || [],
                                                profile: data
                                            });
                                        },
                                        function () {
                                            $rootScope.$emit("flash", {
                                                type: "error",
                                                title: "Ошибка",
                                                text: "Ошибка загрузки профиля"
                                            });

                                            Service404.setMessage($filter('translate')('EXCEPT_USER_NOT_FOUND'));
                                            $state.go('404');

                                        }
                                    );
                                }
                                else {
                                    defer.resolve({
                                        isDiscoverable: authenticatedUser.is_discoverable,
                                        sections: authenticatedUser.sections || [],
                                        section_visibilities: authenticatedUser.section_visibilities || [],
                                        profile: authenticatedUser
                                    });
                                }
                                return defer.promise;
                            }],
                        isProfileOwner: ['$stateParams', 'authenticatedUser',
                            function ($stateParams, authenticatedUser) {
                                return authenticatedUser.username == $stateParams.username;
                            }]
                    },
                    views: {
                        "@root": {
                            controller: 'UserCtrl',
                            templateUrl: '/static/partials/users/user-base.html'
                        },
                        "section-tools": {}
                    },
                    data: {
                        breadcrumbParentState: 'users',
                        breadcrumbCaption: "PAGE_TITLE_WALL"
                    }
                });

            $stateProvider.state('user.post', {
                resolve: {
                    rootPost: loadRootPost('user')
                },
                url: '/posts/:post_id?page',
                views: {
                    "@user": {
                        templateUrl: '/static/partials/wall/xpost_discussion.html',
                        controller: 'xPostDiscussion'
                    },
                    "section-tools@user": {
                        templateUrl: '/static/partials/wall/xpost-tools.html',
                        controller: 'xPostDiscussion'
                    }
                },
                data: {
                    breadcrumbParentState: 'user',
                    breadcrumbCaption: "PAGE_TITLE_POST",
                    privacySectionAlias: 'wall'
                },
                mixins: [
                    restrictUserProfilePrivacyAccessMixin
                ]
            });

            $stateProvider.state('user.photo', {
                url: '/posts/:post_id/photo/:photo_id?page',
                resolve: {
                    rootPost: loadRootPost('user')
                },
                templateUrl: '/static/partials/galleries/photo.html',
                controller: 'PhotoCtrl',
                title: 'PAGE_TITLE_EVENT_PHOTO',
                data: {
                    breadcrumbParentState: 'user.post',
                    privacySectionAlias: 'wall'
                },
                mixins: [
                    restrictUserProfilePrivacyAccessMixin
                ]
            });

            $stateProvider
                .state('user.wall', {
                    url: '?page',
                    title: 'PAGE_TITLE_USER',
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/users/user.html',
                            controller: 'UserWallCtrl'
                        }
                    },
                    data: {
                        breadcrumbParentState: 'users',
                        breadcrumbCaption: "PAGE_TITLE_WALL",
                        privacySectionAlias: 'wall'
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.stream', {
                    url: '/stream?page',
                    title: 'PAGE_TITLE_USER_STREAM',
                    data: {
                        breadcrumbParentState: 'user',
                        privacySectionAlias: 'stream'
                    },
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/users/stream.html',
                            controller: 'UserStreamCtrl'
                        }
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.albums', {
                    url: '/albums?page',
                    title: 'PAGE_TITLE_USER_ALBUMS',
                    data: {
                        breadcrumbParentState: 'user',
                        //privacySectionAlias: 'albums'
                        privacySectionAlias: 'wall'
                    },
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/galleries/galleries.html',
                            controller: 'GalleriesCtrl'
                        }
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.friends', {
                    url: '/friends',
                    title: 'PAGE_TITLE_FRIENDS',
                    data: {
                        breadcrumbParentState: 'user',
                        privacySectionAlias: 'friends'
                    },
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/users/friends.html',
                            controller: 'UserFriendsCtrl'
                        },
                        "section-tools": {
                            templateUrl: '/static/partials/users/friends-tools.html',
                            controller: 'InvitationsFriendsCtrl'

                        }
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.statuses', {
                    url: '/statuses?page',
                    title: 'PAGE_TITLE_USER_STATUSES',
                    data: {
                        breadcrumbParentState: 'user',
                        privacySectionAlias: 'statuses'
                    },
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/users/statuses.html',
                            controller: 'StatusCtrl'
                        },
                        "section-tools": {
                            templateUrl: '/static/partials/users/statuses-tools.html'
                        }
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.interests', {
                    url: '/interests',
                    title: 'PAGE_TITLE_USER_INTERESTS',
                    data: {
                        breadcrumbParentState: 'user',
                        privacySectionAlias: 'interests'
                    },
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/users/interests.html',
                            controller: 'UserInterestsCtrl'
                        }
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.events', {
                    url: '/events?page',
                    title: 'PAGE_TITLE_USER_EVENTS',
                    data: {
                        breadcrumbParentState: 'user',
                        privacySectionAlias: 'events'
                    },
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/users/user-content.html',
                            controller: 'UserContentCtrl',
                            resolve: {
                                contentType: function () {
                                    return contentSettings.CONTENT_TYPES.EVENTS;
                                }
                            }
                        },
                        "section-tools": {
                            templateUrl: '/static/partials/users/events-tools.html'
                        }
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.places', {
                    url: '/places?page',
                    title: 'PAGE_TITLE_USER_PLACES',
                    data: {
                        breadcrumbParentState: 'user',
                        privacySectionAlias: 'events'
                    },
                    views: {
                        "@user": {
                            templateUrl: '/static/partials/users/user-content.html',
                            controller: 'UserContentCtrl',
                            resolve: {
                                contentType: function () {
                                    return contentSettings.CONTENT_TYPES.PLACES;
                                }
                            }
                        },
                        "section-tools": {
                            templateUrl: '/static/partials/users/places-tools.html'
                        }
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                })
                .state('user.wallmessage', {
                    url: '/wall/:messageid',
                    controller: 'WallMessageCtrl',
                    templateUrl: '/static/partials/users/wall_message.html',
                    title: 'PAGE_TITLE_USER_WALLMESSAGE',
                    data: {
                        ownerOnly: true,
                        breadcrumbParentState: 'user'
                    },
                    mixins: [
                        restrictUserProfilePrivacyAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                });

            $stateProvider
                .state('userPrivate', {
                    parent: "user",
                    abstract: true,
                    url: "",
                    template: '<div data-ui-view></div>',
                    mixins: [
                        restrictUserProfileOwnerAccessMixin,
                        userProfileSectionPrivacyMixin
                    ]
                });

            $stateProvider
                .state('userSubscriptions', {
                    parent: "userPrivate",
                    abstract: true,
                    url: '/subscriptions',
                    template: '<div data-ui-view></div>',
                    title: 'PAGE_TITLE_USER_SUBSCRIPTIONS',
                    data: {
                        breadcrumbParentState: 'user',
                        breadcrumbSiblings: [
                            'userSubscriptions.subscribers',
                            'userSubscriptions.events',
                            'userSubscriptions.places',
                            'userSubscriptions.users',
                            'userSubscriptions.friends'
                        ]
                    }
                })
                .state('userSubscriptions.subscribers', {
                    url: '/subscribers?page',
                    templateUrl: '/static/partials/users/subscribers.html',
                    controller: 'UserSubscribersCtrl',
                    resolve: {
                        contentType: function () {
                            return contentSettings.CONTENT_TYPES.USERS;
                        }
                    },
                    title: 'PAGE_TITLE_USER_SUBSCRIPTIONS_SUBSCRIBERS'
                })
                .state('userSubscriptions.events', {
                    url: '/events?page',
                    templateUrl: '/static/partials/users/user-subscriptions.html',
                    controller: 'UserSubscriptionsCtrl',
                    resolve: {
                        contentType: function () {
                            return contentSettings.CONTENT_TYPES.EVENTS;
                        }
                    },
                    title: 'PAGE_TITLE_USER_SUBSCRIPTIONS_EVENTS'
                })
                .state('userSubscriptions.places', {
                    url: '/places?page',
                    templateUrl: '/static/partials/users/user-subscriptions.html',
                    controller: 'UserSubscriptionsCtrl',
                    resolve: {
                        contentType: function () {
                            return contentSettings.CONTENT_TYPES.PLACES;
                        }
                    },
                    title: 'PAGE_TITLE_USER_SUBSCRIPTIONS_PLACES'
                })
                .state('userSubscriptions.users', {
                    url: '/users?page',
                    templateUrl: '/static/partials/users/user-subscriptions.html',
                    controller: 'UserSubscriptionsCtrl',
                    resolve: {
                        contentType: function () {
                            return contentSettings.CONTENT_TYPES.USERS;
                        }
                    },
                    title: 'PAGE_TITLE_USER_SUBSCRIPTIONS_USERS'
                })
                .state('userSubscriptions.friends', {
                    url: '/friends?page',
                    templateUrl: '/static/partials/users/user-subscriptions.html',
                    controller: 'UserSubscriptionsCtrl',
                    resolve: {
                        contentType: function () {
                            return contentSettings.CONTENT_TYPES.FRIENDS;
                        }
                    },
                    title: 'PAGE_TITLE_USER_SUBSCRIPTIONS_FRIENDS'
                });

            $stateProvider
                .state('userBans', {
                    parent: "userPrivate",
                    url: '/bans',
                    templateUrl: '/static/partials/userban/userban.html',
                    title: 'PAGE_TITLE_USER_BANS',
                    data: {
                        breadcrumbParentState: 'user',
                        breadcrumbSiblings: [
                            'userBans.from',
                            'userBans.to'
                        ]
                    }
                })
                .state('userBans.from', {
                    url: '/from?page',
                    templateUrl: '/static/partials/userban/userbans.html',
                    controller: 'UserbanCtrl',
                    resolve: {
                        bansFrom: function () {
                            return true;
                        }
                    },
                    title: 'From'
                })
                .state('userBans.to', {
                    url: '/to?page',
                    templateUrl: '/static/partials/userban/userbans.html',
                    controller: 'UserbanCtrl',
                    resolve: {
                        bansFrom: function () {
                            return false;
                        }
                    },
                    title: 'To'
                });

            $stateProvider
                .state('user.favorites', {
                    parent: "userPrivate",
                    url: '/favorites?page',
                    templateUrl: '/static/partials/favorites/favorites.html',
                    controller: 'FavoritesCtrl',
                    title: 'PAGE_TITLE_USER_FAVORITES',
                    data: {
                        ownerOnly: true,
                        breadcrumbParentState: 'user'
                    }
                });

            $stateProvider
                .state('signup', {
                    url: '/signup?token',
                    parent: "root",
                    views: {
                        // base
                        '@root': {
                            templateUrl: '/static/partials/users/signup.html',
                            controller: 'SignupCtrl'
                        },
                        // EULA view only
                        'eulaView@signup': {
                            templateUrl: function () {
                                var locale = $translateProvider.use();
                                var target = 'en'; // en by default
                                // TODO we must check locale with existing locale lists or views
                                if (locale == 'ru') {
                                    target = locale;
                                } // else - default
                                return '/static/partials/doc/eulas/' + target + '.html';
                            }
                        }
                    },
                    title: 'PAGE_TITLE_SIGNUP',
                    data: {
                        breadcrumbParentState: 'root'
                    },
                    mixins: [
                        restrictUnauthorizedAccessMixin()
                    ]
                })
                .state('social-login', {
                    url: '/social/login',
                    templateUrl: '/static/partials/users/social_login.html',
                    controller: 'SocialLoginCtrl',
                    title: 'PAGE_TITLE_SOCIAL_LOGIN',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                })
                .state('social-done', {
                    url: '/social/done',
                    templateUrl: '/static/partials/users/social_done.html',
                    controller: 'SocialDoneCtrl',
                    title: 'PAGE_TITLE_SOCIAL_DONE',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                })
                .state('social-error', {
                    url: '/social/error',
                    templateUrl: '/static/partials/users/social_error.html',
                    controller: 'SocialDoneCtrl',
                    title: 'PAGE_TITLE_SOCIAL_ERROR',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                })
                .state('social-reg-done', {
                    url: '/social/registration',
                    templateUrl: '/static/partials/users/social_done.html',
                    controller: function ($state, $rootScope) {
                        $state.go('userSettings.profile', {username: $rootScope.user.username});
                    },
                    title: 'PAGE_TITLE_SOCIAL_REGISTRATION_DONE',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                })
                .state('verify_email', {
                    url: '/contacts/verify_email/:email/:key',
                    controller: 'VerifyEmailCtrl',
                    templateUrl: '/static/partials/contacts/verify_result.html',
                    title: 'PAGE_TITLE_VERIFY_EMAIL',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                });

            $stateProvider
                .state('invites', {
                    url: '/invite/{action:(?:accept|reject)}?token',
                    templateUrl: '/static/partials/events/invites.html',
                    controller: 'InvitesCtrl',
                    title: 'PAGE_TITLE_ACCEPT_REJECT_INVITE',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                });

            //IMPORTANT: keep this state last!! as 403 handler has wildcard path!!
            $stateProvider
                .state('404', {
                    url: '/404',
                    templateUrl: '/static/partials/maintenance/404.html',
                    controller: '404Ctrl',
                    title: 'PAGE_TITLE_ERROR_404',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                })
                .state('403', {
                    parent: "root",
                    url: '*path',
                    templateUrl: '/static/partials/maintenance/403.html',
                    //controller: '403Ctrl',
                    title: 'PAGE_TITLE_ERROR_403',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                })
                .state('401', {
                    url: '/401',
                    templateUrl: '/static/partials/maintenance/401.html',
                    controller: '401Ctrl',
                    title: 'PAGE_TITLE_ERROR_401',
                    data: {
                        breadcrumbParentState: 'root'
                    }
                });

        }])
        .factory('permissionRequired', ['$rootScope', 'userService', '$q', function ($rootScope, userService, $q) {
            /**
             * Note: @param notifyFn added for T1109
             * If user have not requested permission, and this parameter was passed and equals to type function
             * Then callback will be called and <self/this> will passed as first an argument
             * That function useful if you need execute some code before $q.reject() statement. (e.g. $rootScope.emit('flash'))
             */
            return function (perm, f, notifyFn) {
                return function () {
                    if (userService.hasPerm(perm)) {
                        return f.apply(this, arguments);
                    }
                    if (typeof notifyFn === 'function') {
                        // notify function will complete notification by herself
                        notifyFn(this);
                    } else {
                        $rootScope.$emit('checkEmailConfirmation');
                    }

                    console.log('Permission required:', perm);
                    // must be rejected always
                    return $q.reject();
                };
            };
        }])
        .factory('verifiedEmailRequired', ['$rootScope', 'userService', '$q', function ($rootScope, userService, $q) {
            return function (f) {
                return function () {
                    var deferred = $q.defer(),
                        args = arguments;
                    userService.getUser().then(function (user) {
                        if (user.has_verified_email) {
                            deferred.resolve(f.apply(this, args));
                        }
                        else {
                            $rootScope.$emit('checkEmailConfirmation');
                            deferred.reject();
                        }
                    });
                    return deferred.promise;

                };
            };
        }])
        .factory('banHttpInterceptor', ['$q', '$rootScope', '$injector', function ($q, $rootScope, $injector) {
            return {
                response: function (response) {
                    if (response.data.USER_BANNED) {
                        $rootScope.$emit('event:user.loggedOut', {});
                        $injector.get('userService').setUserData(response.data.result);
                        $injector.get('Service404').setMessage('Вас забанили. Если вы хотите узнать причину, обратитесь в службу поддержки.');
                        $injector.get('$state').go('401');
                        return $q.reject(response);
                    }
                    return response;
                }
            };
        }])
        .config(function ($httpProvider) {
            $httpProvider.interceptors.push('banHttpInterceptor');
        })
        .factory('errorsHttpInterceptor', ['$q', '$rootScope', function ($q, $rootScope) {
            return {
                response: function (response) {
                    if (response.data.error && $rootScope.isNotFound(response.data.error)) {
                        $rootScope.$emit("flash", {
                            type: "error",
                            title: "Not found",
                            text: response.data.error.data.msg
                        });
                    }
                    return response;
                }
            };
        }])
        .config(function ($httpProvider) {
            $httpProvider.interceptors.push('errorsHttpInterceptor');
        })
        .config(['$interpolateProvider', function ($interpolateProvider) {
            $interpolateProvider.startSymbol('[[');
            $interpolateProvider.endSymbol(']]');
        }])
        .config(function(uiSelectConfig) {
            uiSelectConfig.theme = 'select2';
        })
        .controller('AuthCtrl', ['$scope', 'userService', function ($scope, userService) {

            $scope.hasPerm = function (perm) {
                return userService.hasPerm(perm);
            };

            $scope.hasRole = function (role) {
                return userService.hasRole(role);
            };

        }])
        .directive('errors', function () {
            var title_tpl = '<h4>{{ title }}</h4>';
            var wrap_tpl = '<div class="error-block"></div>';
            var error_tpl = '<span class="help-inline" ng-repeat="error in errors">{{ error }}</span>';
            return {
                restrict: 'E',
                scope: {
                    errors: '=source'
                },
                compile: function (el) {
                    var html = angular.element(wrap_tpl);
                    var title = el.text();
                    if (title)
                        html.append(title_tpl);

                    html.append(error_tpl);
                    el.html(html);

                    return function (scope, tEl) {
                        scope.title = title;
                        scope.$watch('errors', function (errors) {
                            tEl.html((errors && errors.length) && html || "");
                        });

                    };
                }
            };
        })
        .run(
        [
            '$rootScope', '$location', '$cookies', '$compile', '$q', 'userService', 'languages', 'socketio', '$translate',
            'eventsService', 'messageService', 'channelService', '$state', 'filtersService', '$window', 'StreamCode',
            'messageTypes', 'messageTypeAliases', 'breadcrumb', 'breadcrumbService', '$filter', '$timeout', 'StreamGroup', 
            'notificationBlockType', 'NotificationBlock', 'fireNotify',
            function ($rootScope, $location, $cookies, $compile, $q, 
                userService, languages, socketio, $translate, eventsService, 
                messageService, channelService, $state, filtersService, 
                $window, StreamCode, messageTypes, messageTypeAliases, 
                breadcrumb, breadcrumbService, $filter, $timeout, 
                StreamGroup, notificationBlockType, NotificationBlock, fireNotify) {
                //angular.element('#initial-loading').remove();

                // HACK: we need true modal window class/directive
                window.setInterval(function () {
                    if ($(".light-modal.active").length) {
                        $("body").addClass("light-modal-opened");
                    } else {
                        $("body").removeClass("light-modal-opened");
                    }
                }, 100);

                window.onbeforeunload = function confirmExit() {
                    socketio.getSocket().socket.disconnect();
                    return null;
                };

                $rootScope.languages = languages;
                $rootScope.messageTypes = messageTypes;
                $rootScope.StreamGroup = StreamGroup;

                $rootScope.loading = true;

                $rootScope.isPasswordRestoreOpen = false;
                $rootScope.isChangePasswordPromptOpen = false;
                $rootScope.isVerifyContactsModalOpen = false;
                $rootScope.isFiltersSidebarEnabled = false;
                $rootScope.isUserLocationFormOpen = false;

                // something wrong with backend
                $rootScope.backendFailed = false;
                // How many times the backaend has failed.
                // This is required for progressive retry countdown.
                $rootScope.backendFailedNum = 0;

                $rootScope.user = {
                    authenticated: false
                };

                function _getCurrentState() {
                    return breadcrumbService.currentState($rootScope);
                }

                $rootScope.currentState = _getCurrentState();

                $rootScope.currentFilterMode = 'map';
                $rootScope.currentFilterContentType = 'events';

                $rootScope.switchFilterContentType = function (s) {

                    // T776
                    // If user switches from the state other than 'content'
                    // map will be shown
                    if (!$state.includes('content')) {
                        $rootScope.currentFilterMode = 'map';
                    }
                    $rootScope.currentFilterContentType = s;
                    $location.path(s);
                    var searchParams = filtersService.toParams();
                    angular.extend(searchParams, {show: $rootScope.currentFilterMode});
                    $location.search(searchParams);
                };

                $rootScope.switchFilterMode = function (s) {

                    $rootScope.currentFilterMode = s;
                    var searchParams = filtersService.toParams();
                    angular.extend(searchParams, {show: s});
                    $location.search(searchParams);

                    // T776
                    // If user switches from the state other than 'content'
                    // events will be shown
                    if (!$state.includes('content')) {
                        $rootScope.currentFilterContentType = 'events';
                        $location.path('events');
                    }
                };

                $rootScope.inContentState = function () {
                    return $state.includes('content');
                };

                $rootScope.goHome = function () {
                    $rootScope.switchFilterMode('map');
                    $rootScope.switchFilterContentType('events');
                };

                $rootScope.isRequiredField = function (f) {
                    return f && f.$dirty && f.$invalid && f.$error.required;
                };

                $rootScope.hasError = function (f) {
                    return f && f.$dirty && f.$invalid;
                };

                $rootScope.hasCustomError = function (f, errorCode) {
                    return f && f.$invalid && f.$error[errorCode];
                };

                $rootScope.isFormError = function (error) {
                    return error.code == 32101;
                };

                $rootScope.isRegularUserRoleRequired = function (error) {
                    return error && (error.code == 32107);
                };

                $rootScope.isLogicError = function (error) {
                    return error.code == 32100;
                };

                $rootScope.isPermissionDenied = function (error) {
                    return error.code == 32102;
                };

                $rootScope.isContentBanned = function (error) {
                    return error.code == 32104;
                };

                $rootScope.isContentOnModeration = function (error) {
                    return error.code == 32105;
                };

                $rootScope.isNotFound = function (error) {
                    return error.code == 32103;
                };


                $rootScope.openChangePasswordPrompt = function () {
                    $rootScope.isChangePasswordPromptOpen = true;
                };

                $rootScope.closeChangePasswordPrompt = function () {
                    $rootScope.isChangePasswordPromptOpen = false;
                };


                $rootScope.hasPerm = function (perm) {
                    return userService.hasPerm(perm);
                };

                $rootScope.hasRole = function (role) {
                    return userService.hasRole(role);
                };
                // T1133
                // $rootScope.accessRequired = function (perm, next_url, hide_modal) {
                //     if (!userService.hasPerm(perm)) {
                //         var required_role = userService.getRequiredRole(perm);
                //         if (required_role == "Users") {
                //             if (userService.hasRole('IncompletedUsers')) {
                //                 if (!hide_modal) {
                //                     openVerifyContactsModal();
                //                 }
                //             }
                //             else {
                //                 if (!hide_modal) {
                //                     openRegModal(next_url);
                //                 }
                //                 //return true;
                //             }
                //         }
                //         else {
                //             if (!hide_modal) {
                //                 openRegModal(next_url);
                //             }
                //             //return true;
                //         }
                //         return true;
                //     }
                //     return false;
                // };

                $rootScope.confirm = function (msg) {
                    $rootScope.deferredConfirm = $q.defer();
                    $rootScope.confirmDialogActive = true;
                    $rootScope.confirmDialogMessage = msg;
                    return $rootScope.deferredConfirm.promise;

                };

                $rootScope.$safeApply = function ($scope, fn) {
                    if (fn === undefined) return;

                    if ($scope.$$phase) {
                        //don't worry, the value gets set and AngularJS picks up on it...
                        fn();
                    }
                    else {
                        //this will fire to tell angularjs to notice that a change has happened
                        //if it is outside of it's own behaviour...
                        $scope.$apply(fn);
                    }
                };

                /*
                 $rootScope.routesMap = {};
                 angular.forEach($route.routes, function (route_config, path) {
                 if (route_config.routeName) $rootScope.routesMap[route_config.routeName] = path;
                 });
                 */
                $rootScope.$onRootScope("flash", function (e, msg, scope) {
                    fireNotify(msg,scope);
                });

                function buildBreadcrumbs(useTranslate) {
                    var breadcrumbs = [];
                    var path = breadcrumb.getStatesSequence();
                    var viewScope = breadcrumb.getLastViewScope();

                    angular.forEach(path, function (state) {
                        breadcrumbs.push({
                            data: breadcrumbService.buildBreadcrumbData(state, viewScope, useTranslate)
                        });
                    });

                    if (breadcrumbs.length) {
                        breadcrumbs[breadcrumbs.length - 1].data.active = true;
                    }

                    if (viewScope.rootPost && viewScope.rootPost.title) {
                        breadcrumbs.push({
                            data: {
                                link: $location.url(),
                                caption: viewScope.rootPost.title
                            }
                        });
                    }

                    return breadcrumbs;
                }

                function __updateBreadcrumbs() {
                    $rootScope.breadcrumbs = buildBreadcrumbs(true);
                }

                $rootScope.$onRootScope('breadcrumbDataUpdated', __updateBreadcrumbs);
                $rootScope.$onRootScope('changedLanguage', __updateBreadcrumbs);
                $rootScope.$on('$viewContentLoaded', __updateBreadcrumbs);
                $rootScope.$on('$locationChangeSuccess', __updateBreadcrumbs);

                $rootScope.breadcrumbs = buildBreadcrumbs(true);

                //Set page title based on current route's data
                var updatePageTitle = function (currentRoute, scope) {
                    var title = breadcrumbService.getStateCaption(currentRoute, scope, true, true);
                    if ($rootScope.title !== title) {
                        $rootScope.title = title;
                    }
                };

                $rootScope.goToEmailVerification = function () {
                    $state.go('userSettings.profile', {username: $rootScope.user.username});
                };

                $rootScope.$onRootScope('needLogin', function () {
                    fireNotify({
                        title: 'Необходима авторизация',
                        type: 'error',
                        text: 'Для выполнения действия необходимо - <a data-ui-sref="auth.login">авторизация</a> или <a data-ui-sref="signup">регистрация</a> если вы еще не зарегистрированы.'
                    });
                });

                $rootScope.$onRootScope('checkEmailConfirmation', function (event, args) {
                    if (!userService.isAuthenticated()) {
                        return;
                    }

                    var message = args ? args.warningMessage : null;
                    var useTranslate = !(args && args.translate === false);

                    if (args && args.permission) {
                        var permission = args ? args.permission : null;

                        if (!$rootScope.hasPerm(permission)) {
                            fireNotify({
                                type: 'needAcceptedEmail',
                                text: message,
                                useTranslate: useTranslate
                            });
                        }
                    }
                    else {
                        userService.getUser().then(function (user) {
                            if (user && user.has_verified_email !== true) {
                                fireNotify({
                                    type: 'needAcceptedEmail',
                                    text: message,
                                    useTranslate: useTranslate
                                });
                            }
                        });
                    }
                });

                $rootScope.$on("$viewContentLoaded", function (event) {
                    updatePageTitle(event.currentScope.$state.current, event.currentScope);
                });

                $rootScope.$onRootScope("changedLanguage", function (event) {
                    updatePageTitle(event.currentScope.$state.current, event.currentScope);
                });

                $rootScope.changeLanguage = function (language) {
                    $cookies.django_language = language;
                    $rootScope.language = language;
                    $rootScope.$emit('changedLanguage', language);
                };

                $rootScope.$onRootScope('changedLanguage', function (event, language) {
                    if ($translate.use() !== language) {
                        $translate.use(language);
                    }
                });

                var langInit = function () {
                    $rootScope.changeLanguage(userService.getLanguage());
                };

                $rootScope.bunAccept = function (bun_id) {
                    messageService.accept(bun_id).then(
                        function () {
                            $rootScope['bun_show_' + bun_id] = false;
                        }
                    );
                };

                $rootScope.bunReject = function (bun_id) {
                    messageService.reject(bun_id).then(
                        function () {
                            $rootScope['bun_show_' + bun_id] = false;
                        }
                    );
                };


                $rootScope.bunBan = function (bun_id) {
                    messageService.ban(bun_id).then(
                        function () {
                            $rootScope['bun_show_' + bun_id] = false;
                        }
                    );
                };

                $rootScope.bunPostpone = function (bun_id) {
                    messageService.postpone(bun_id).then(
                        function () {
                            $rootScope['bun_show_' + bun_id] = false;
                        }
                    );
                };

                var flashFromSocket = function (data) {
                    $rootScope.$emit("flash", {
                        type: "success",
                        title: "WS notification",
                        text: data.content
                    });
                };

                $rootScope.markAsRead = function (msgIDs, withMessages) {

                    if (!msgIDs.length) {
                        return;
                    }

                    if (angular.isObject(msgIDs[0])) {
                        msgIDs = _.pluck(msgIDs, 'id');
                    }

                    console.log("Mark as read: ", msgIDs);

                    messageService.markAsRead(msgIDs, withMessages).then(
                        function (response) {
                            if (response.error) {
                                $rootScope.$emit("flash", {
                                    type: "error",
                                    title: "Ошибка",
                                    text: response.error.message
                                });
                            }
                            else {
                                if (withMessages) {
                                    // show new unread messages as preview
                                    $rootScope.onNewMessages(response.result, true);
                                } else {
                                    // slice previous loaded messages and show it in preview
                                    $rootScope.unreadMessages = _.reject($rootScope.unreadMessages, function (m) {
                                        return msgIDs.indexOf(m.id) >= 0;
                                    });
                                    $rootScope.$emit('mailPreviewChanged');
                                }
                            }
                        },
                        // Error
                        function () {
                            $rootScope.$emit("flash", {
                                type: "error",
                                title: "Ошибка",
                                text: "Ошибка, повторите запрос позже."
                            });
                        }
                    );
                };

                $rootScope.onNewMessages = function (data, ignoreNotification) {
                    if (!data) {
                        return;
                    }

                    var res = data.inbox || [],
                        notifications = [];

                    if (ignoreNotification !== true) {
                        notifications.push.apply(notifications, res.slice(0, data.new_count));
                    }

                    // for debug
                    //PNotify.prototype.options.delay = 900000;
                    var component = React.createFactory(NotificationBlock);

                    $timeout(function () {
                        $rootScope.$apply(function () {
                            $rootScope.unreadMessages = res;
                            $rootScope.$emit('mailPreviewChanged');

                            angular.forEach(notifications, function (ntf, i) {
                                fireNotify({
                                    title: 'Уведомление',
                                    after_open: function (pNotify) {
                                        React.render(
                                            component({
                                                item: ntf,
                                                mode: notificationBlockType.COMPACT
                                            }),
                                            pNotify.container[0]
                                        );
                                    }
                                });

                            });

                        });
                    });


                };

                $rootScope.$onRootScope('checkedLogin', function (event, user, response) {
                    langInit();

                    // process new messages
                    $rootScope.onNewMessages(response.messages, true);

                    if (socketio.getSocket()) {
                        userService.initialSubscribe();
                    }


                    var flashFromFriend = function (data) {
                        console.log("flashFromFriend:", data);
                        // T477 wtf???
                        // if (userService.isFriend(data.user_id)) {
                        //     flashFromSocket(data);
                        // }
                        flashFromSocket(data);
                        if (data.status === "online") {
                            $rootScope.$emit('event:user:online', data.user_id);
                        } else if (data.status === "offline") {
                            $rootScope.$emit('event:user:offline', data.user_id);
                        }
                    };

                    var channelOnlineName = channelService.getChannelName('online');
                    socketio.getSocket().on(channelOnlineName, flashFromFriend);
                    // socketio.getSocket().on('offline:private', flashFromFriend);

                    var channelMessageName = channelService.getChannelName('messages'),
                        channelFriendName = channelService.getChannelName('friends'),
                        channelProfileName = channelService.getChannelName('profile'); // T990

                    socketio.getSocket().on(channelMessageName, $rootScope.onNewMessages);

                    socketio.getSocket().on(channelFriendName, function (data) {
                        console.log(data);
                        if (data.code == StreamCode.FRIENDSHIP_ACCEPTED) {
                            userService.addFriend(data.content);
                            $rootScope.$emit("friendAdded");
                        }
                        console.log(StreamCode.FRIENDSHIP_CANCELED);
                        if (data.code == StreamCode.FRIENDSHIP_CANCELED) {
                            userService.removeFriend(data.content);
                            $rootScope.$emit("friendRemoved");
                        }
                    });

                    // T990
                    socketio.getSocket().on(channelProfileName, function (data) {
                        console.log("Update user profile", data);
                        if (data) {
                            userService.setUserData(data);
                        }
                    });

                });

                //      $rootScope.$on("loggedIn", function (event) {
                $rootScope.$onRootScope("event:user.loggedIn", function (e, response) {
                    console.log('loggedIn', response);
                    langInit();

                    // process new messages
                    $rootScope.onNewMessages(response.messages, true);
                });

                // This queue contans all failed requests to the backend
                // After retry timeout expires requests from this queue are called again
                $rootScope.failedRequests = [];

                $rootScope.retryState = function () {

                    // Switching to another state failed
                    if (angular.isObject($rootScope.failedState)) {
                        $state.go($rootScope.failedState.instance, $rootScope.failedState.params).then(
                            function () {
                                $rootScope.resetFailedState();
                            },
                            function (state) {
                                // retrying state failed
                            }
                        );
                    }
                    // Request to the backend failed
                    else if ($rootScope.failedRequest) {
                        $rootScope.$emit('retryRequest');
                    }

                };

                $rootScope.resetFailedRequest = function () {
                    $rootScope.failedRequest = false;
                    $rootScope.backendFailed = false;
                    $rootScope.backendFailedNum = 0;
                    _.map($rootScope.failedRequests, function (r) {
                        r[2].reject();
                    });
                    $rootScope.failedRequests = [];

                };

                $rootScope.resetFailedState = function () {
                    $rootScope.backendFailed = false;
                    $rootScope.backendFailedNum = 0;
                    $rootScope.failedState = null;
                };


                $rootScope.$on("$stateChangeError", function (event, toState, toParams, fromState, fromParams, error) {
                    console.info("$stateChangeError", event, error, fromState, toState);
                    var redirects = {
                        "404": "404",
                        "403": "403"
                    };

                    if (_.isFunction(error)) {
                        error(event, toState, toParams, fromState, fromParams);
                        return;
                    }

                    if (error.redirectTo) {
                        event.preventDefault();
                        $state.go(redirectTo);
                    } else {
                        if (error && !!error.state) {
                            var redirectTo = redirects["" + error.state];
                            if (!!redirectTo) {
                                event.preventDefault();
                                $state.transitionTo(redirectTo, {}, {reload: false})
                            }
                        }
                    }
                });


                $rootScope.$on("$routeChangeSuccess", function () {
                    userService.showUserNotifications();
                });

                $rootScope.$on("$locationChangeSuccess", function (event) {
                    $rootScope.loading = false;
                    updatePageTitle(event.currentScope.$state.current, event.currentScope);
                });


                $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                    $rootScope.loading = false;

                    $rootScope.currentState = _getCurrentState();
                    // Remember the last state so we can go back
                    $state.previous = {
                        state: fromState,
                        name: fromState.name,
                        params: fromParams
                    };

                    $rootScope.resetFailedRequest();
                    $rootScope.resetFailedState();
                });

                $rootScope.$state = $state;


                // Blueimp custom processAction
                var genPrefixName = function (prefix, source) {
                    return prefix + ':' + source.replace(/^(original|large|big|medium|small|micro):/, '');
                };

                $.blueimp.fileupload.prototype.processActions.duplicateImage = function (data) {
                    data.files.push(data.files[data.index]);
                    return data;
                };

                // Converts image to canvas; returns new canvas element
                function convertImageToCanvas(image) {
                    var canvas = document.createElement("canvas");
                    canvas.width = image.width;
                    canvas.height = image.height;
                    canvas.getContext("2d").drawImage(image, 0, 0);
                    return canvas;
                }

                $.blueimp.fileupload.prototype.processActions.saveImageWithPrefix = function (data, options) {
                    if (options.disabled) {
                        return data;
                    }
                    if (!data.canvas) {
                        data.canvas = convertImageToCanvas(data.img);
                    }
                    var that = this,
                        file = data.files[data.index],
                        dfd = $.Deferred();
                    if (data.canvas.toBlob) {
                        data.canvas.toBlob(
                            function (blob) {
                                if (!blob.name) {
                                    if (file.type === blob.type) {
                                        blob.name = genPrefixName(options.prefix, file.name);
                                    } else if (file.name) {
                                        blob.name = genPrefixName(options.prefix, file.name.replace(
                                            /\..+$/,
                                            '.' + blob.type.substr(6)
                                        ));
                                    }
                                }
                                // Don't restore invalid meta data:
                                if (file.type !== blob.type) {
                                    delete data.imageHead;
                                }
                                // of the original file in the files list:
                                data.files[data.index] = blob;
                                dfd.resolveWith(that, [data]);
                            },
                            options.type || file.type,
                            options.quality
                        );
                    } else {
                        return data;
                    }
                    return dfd.promise();
                };

                $.blueimp.fileupload.prototype.processActions.setAsPreviewImage = function (data, options) {
                    var img = (options.canvas && data.canvas) || data.img;
                    var index = data.index;
                    if (img && !options.disabled) {
                        for (var i = 0; i < data.files.length; i += 1) {
                            var original_name = data.files[index].name.replace(/^(original|large|big|medium|small|micro):/, '');
                            if (options.prefix + ':' + original_name == data.files[i].name) {
                                index = i;
                                break;
                            }
                        }
                        data.files[index][options.name || 'preview'] = data.files[data.index].preview;
                    }
                    return data;
                };

                $.blueimp.fileupload.prototype.processActions.progressIncrement = function (data) {
                    $rootScope.$emit('thumbnail-generated', data);
                    return data;
                };

            }])
        .constant('MEDIA_URL', RESTANGULAR_BASE_URL + 'assets/')
        .constant('StreamCode', {
            CREATED: 0,
            CHANGED: 1,
            DELETED: 2,
            ACCEPTED: 3,
            DECLINED: 4,
            STARTED: 5,
            FINISHED: 6,
            BLOCKED_TO_COMPLAIN: 7,
            BLOCKED_TO_COMPLAIN_FOREVER: 8,
            UNBLOCKED_TO_COMPLAIN: 9,
            BIRTHDAY_TOMORROW: 10,
            BIRTHDAY_TODAY: 11
        }).constant('CheckInState', {
            UNCONFIRMED: 0,
            CONFIRMED: 1
        }).constant('EventUserState', {
            CHECKED_IN: 0,
            CHECKED_OUT: 1,
            INTENDED: 2,
            UNREAD_BUN_REQUEST: 3,
            READ_BUN_REQUEST: 4,
            WAS_NOT_THERE: 5
        }).constant('StreamGroup', {
            BY_CODE: 0,
            BY_CODE_AND_SUBJECT: 1,
            BY_CODE_AND_OBJECT: 2
        }).constant('UserPhoneVerifyState', {
            NEW: 0,
            SENDING: 1,
            SENT: 2,
            SUCCESS: 3,
            FAIL: 4
        });

    angular.module('services', [])
        .factory("AppState", ["$rootScope", function ($rootScope) {
            // keep false until at least one state will be successfully loaded
            var APPSTATE = false;

            var cancelAppStateUpodating = $rootScope.$on("$stateChangeSuccess", function () {
                // set appstate to loaded state
                APPSTATE = true;
                cancelAppStateUpodating();
            });

            return {
                isLoaded: function () {
                    return APPSTATE === true;
                }
            }
        }])
        .value({
            tagTypeLabels: {
                0: "custom",
                1: "place",
                2: "event",
                3: "interest",
                4: "status"
            },
            tagTypes: {
                custom: 0,
                place: 1,
                event: 2,
                interest: 3,
                status: 4,
                friendship: 5
            },
            eventUserStates: {
                checkedIn: 0,
                checkedOut: 1,
                intended: 2,
                unreadBunRequest: 3,
                readBunRequest: 4,
                wasNotThere: 5
            },
            languages: [
                {
                    code: 'ru',
                    name: 'Русский'
                },
                {
                    code: 'en',
                    name: 'English'
                }
            ],
            xStates: {
                new: 100,
                sent: 101,
                read: 102,
                accepted: 200,
                rejected: 201,
                postponed: 202,
                baned: 203,
                redirected: 204,
                cancelled: 300,
                revised: 301,
                edited: 302,
                deleted: 400
            },
            messageTypes: {
                DIALOG: 1,
                MODERATION: 2,
                BAN: 3,
                FRIENDSHIP: 4,
                INVITE: 5,
                NOTICE: 6,
                SUBSCRIPTION: 7,
                BUN: 8
            },
            messageTypeAliases: {
                1: 'dialog',
                2: 'moderation',
                3: 'ban',
                4: 'friendship',
                5: 'invite',
                6: 'notice',
                7: 'subscription',
                8: 'bun'
            },
            notificationBlockType: {
                FULL: 1,
                COMPACT: 2,
                STREAM: 3
            },
            noticeTypes: {
                EVENT_START: 1,
                EVENT_DISABLE: 2,
                EVENT_ASK_STATUS: 3,
                BIRTHDAY_TOMORROW: 4,
                BIRTHDAY_TODAY: 5,
                CONVERSATION_DELETED: 6,
                OBJECT_DELETED: 7
            },
            noticeTypeAliases: {
                1: 'event_started',
                2: 'event_disabled',
                3: 'event_ask_status',
                4: 'birthday_tomorrow',
                5: 'birthday_today'
            },
            eventStateCodes: {
                ANNOUNCED: 0,       // ts_start > now()
                STARTED: 1,       // ts_start <= now()
                CANCELED: 2,       // v1.events.disable_event called
                FINISHED: 3,       // ts_finish <= now() and event was on STARTED state
                STOPPED: 4        // v1.events.finish_event called
            },
            dateTimeFormat: {
                COMMON: "DD MMM YYYY",
                COMMON_WITH_TIME: "DD MMM YYYY HH:mm",
                WEEKDAY_WITH_TIME: 'HH:mm dddd, DD MMMM, YYYY'
            },
            streamCodes: {

                0: "created",
                1: "changed",
                2: "deleted",
                3: "accepted",
                4: "declined",
                5: "started",
                6: "finished",
                7: "blocked_to_complain",
                8: "blocked_to_complain_forever",
                9: "unblocked_to_complain",
                10: "birthday_tomorrow",
                11: "birthday_today"
            },
            jqPaginationSettings: {
                limit: 5,
                limit_tile: 6,
                streamLimit: 25
            },
            photoSettings: {
                //20
                PHOTO_ALBUM_STREAM_PREVIEW_LENGTH: 3
            },
            blueimpPhotoProcessQueue: [
                // original
                {
                    action: 'loadImage',
                    fileTypes: /^image\/(gif|jpeg|jpg|png)$/,
                    maxFileSize: 20000000 // 20MB
                },
                {action: 'saveImageWithPrefix', prefix: 'original'},
                {action: 'progressIncrement'},

                // large
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    minWidth: 800, maxWidth: 800
                },
                {action: 'saveImageWithPrefix', prefix: 'large'},
                {action: 'progressIncrement'},

                // big
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    minWidth: 600, maxWidth: 600
                },
                {action: 'saveImageWithPrefix', prefix: 'big'},
                {action: 'progressIncrement'},

                // medium
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    minWidth: 480, maxWidth: 480
                },
                {action: 'saveImageWithPrefix', prefix: 'medium'},
                {action: 'setImage'}, // mark it for browser preview
                {action: 'setAsPreviewImage', prefix: 'original'}, // attach this preview to original file
                {action: 'progressIncrement'},

                // small
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    minWidth: 280, maxWidth: 280
                },
                {action: 'saveImageWithPrefix', prefix: 'small'},
                {action: 'progressIncrement'},

                // micro
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    minWidth: 120, maxWidth: 120
                },
                {action: 'saveImageWithPrefix', prefix: 'micro'},
                //{action: 'setImage'}, // mark it for browser preview
                //{action: 'setAsPreviewImage', prefix: 'original'}, // attach this preview to original file
                {action: 'progressIncrement'}
            ],
            blueimpAvatarProcessQueue: [
                // original
                {
                    action: 'loadImage',
                    fileTypes: /^image\/(gif|jpeg|jpg|png)$/,
                    maxFileSize: 20000000 // 20MB
                },
                {action: 'saveImageWithPrefix', prefix: 'original'},

                // large
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 120, minWidth: 120,
                    maxHeight: 120, minHeight: 120
                },
                {action: 'saveImageWithPrefix', prefix: 'large'},

                // medium
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 70, minWidth: 70,
                    maxHeight: 70, minHeight: 70
                },
                {action: 'saveImageWithPrefix', prefix: 'medium'},

                // small
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 48, minWidth: 48,
                    maxHeight: 48, minHeight: 48
                },
                {action: 'saveImageWithPrefix', prefix: 'small'},
                {action: 'setImage'}, // mark it for browser preview
                {action: 'setAsPreviewImage', prefix: 'original'}, // attach this preview to original file

                // micro
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 36, minWidth: 36,
                    maxHeight: 36, minHeight: 36
                },
                {action: 'saveImageWithPrefix', prefix: 'micro'}
            ],
            blueimpBackgroundProcessQueue: [
                // original
                {
                    action: 'loadImage',
                    fileTypes: /^image\/(gif|jpeg|jpg|png)$/,
                    maxFileSize: 20000000 // 20MB
                },
                {action: 'saveImageWithPrefix', prefix: 'original'},

                // large
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 1280, minWidth: 1280,
                    maxHeight: 240, minHeight: 240
                },
                {action: 'saveImageWithPrefix', prefix: 'large'},

                // medium
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 1024, minWidth: 1024,
                    maxHeight: 120, minHeight: 120
                },
                {action: 'saveImageWithPrefix', prefix: 'medium'},

                // small
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 800, minWidth: 800,
                    maxHeight: 100, minHeight: 100
                },
                {action: 'saveImageWithPrefix', prefix: 'small'},

                // micro
                {action: 'duplicateImage'},
                {
                    action: 'resizeImage',
                    maxWidth: 320, minWidth: 320,
                    maxHeight: 100, minHeight: 100
                },
                {action: 'saveImageWithPrefix', prefix: 'micro'},
                {action: 'setImage'}, // mark it for browser preview
                {action: 'setAsPreviewImage', prefix: 'original'} // attach this preview to original file
            ],
            filtersTagTypes: {
                TAG: 0,
                WORD: 1,
                PRE_DEFINED: 2,
                PRE_DEFINED_TAG: 3
            }
    });
})();
