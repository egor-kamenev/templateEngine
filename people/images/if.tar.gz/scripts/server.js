var util = require('util'),
    express = require('express'),
    http = require('http'),
    port = 8000;

var index = function (req, res) {
    res.render(__dirname + '/../app/index.html');
};

var app = express()
    .engine('.html', require('ejs').renderFile)
    .use("/static", express.static(__dirname + "/../app"))
    .get('/', index)
    .get('*', index);


http.createServer(app).listen(port, function () {
    console.log('Express server listening on port ' + port);
});

