var udp = require('./utils/udp-server'),
    fs = require('fs'),
    moment = require('moment');


exports.config = {
  allScriptsTimeout: 11000,

  specs: [
      //'e2e/access_to_closed_profile.js'
      'e2e/*.js'
  ],

  capabilities: {
    'browserName': 'chrome'
//    'browserName': 'phantomjs'
//    'browserName': 'firefox'
  },

    //baseUrl: 'http://127.0.0.1:8000/',
  baseUrl: 'http://local.webpasta.ru:5000/',


  framework: 'jasmine',

  jasmineNodeOpts: {
    defaultTimeoutInterval: 300000
  },
  seleniumAddress: 'http://127.0.0.1:4444/wd/hub',
  allScriptsTimeout: 60000,

  onPrepare: function(){
      global.UDPServer = new udp();
      global.ADMIN_URL = 'http://local.webpasta.ru:8000';
      global.TEST_API = {
          protocol: 'https',
          host: 'ai1test.webpasta.ru',
          post: 443,
          caFile: [ fs.readFileSync('../phabricator.whiteteam.pem') ]
      };
      global.evtDate = function(daysOffset){
          if(typeof hour === 'undefined'){
              hour = 12;
          }
          if(typeof minute === 'undefined'){
              minute = 0;
          }
          return moment().add(daysOffset, 'days').hour(hour).minute(minute).seconds(0).format("DD.MM.YYYY HH:MM");
      };
      
      /* For local backend
      global.TEST_API = {
          protocol: 'http',
          host: 'local.webpasta.ru',
          post: 8000,
          caFilePath: null
      };
       */

  }
};
