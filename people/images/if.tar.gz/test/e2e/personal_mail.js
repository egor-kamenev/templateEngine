'use strict';

var  OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 25,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 35,
        'password': 'hackme'
    },
    USER3 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 32,
        'password': 'hackme'
    },
    USER4 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 35,
        'password': 'hackme'
    },
    USER5 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 31,
        'password': 'hackme'
    },
    USER6 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 35,
        'password': 'hackme'
    },
    USER7 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 30,
        'password': 'hackme'
    },
    USER8 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222267',
        'age': 36,
        'password': 'hackme'
    },
    USER9 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222267',
        'age': 32,
        'password': 'hackme'
    },
    USER10 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222267',
        'age': 31,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 2, 15),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 2, 30),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT4 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT5 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 1, 30),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': true,
        'visibility': '4'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Visibility = require('../utils/visibility.js'),
    Settings = require('../utils/settings.js'),
    Friendship = require('../utils/friendship.js'),
    Participation = require('../utils/participation.js'),
    moment = require('moment'),
    Comments = require('../utils/comments.js'),
    Signup = require('../utils/signup.js'),
    EVENT_MIN_START_OFFSET = 2;

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

});

describe("Register users: ", function() {
    
    it("registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('OWNER:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });

    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

    it("registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

    it("registrate USER3", function() {
        Signup.registerUserUntilDone(USER3).then(function(userData){
            USER3.username = userData.username;
            USER3.email = userData.email;
            console.log('USER3:', USER3.username);
            Signup.verifyEmail(USER3);
        });
    });

    it("registrate USER4", function() {
        Signup.registerUserUntilDone(USER4).then(function(userData){
            USER4.username = userData.username;
            USER4.email = userData.email;
            console.log('USER4:', USER4.username);
            Signup.verifyEmail(USER4);
        });
    });

    it("registrate USER5", function() {
        Signup.registerUserUntilDone(USER5).then(function(userData){
            USER5.username = userData.username;
            USER5.email = userData.email;
            console.log('USER5:', USER5.username);
            Signup.verifyEmail(USER5);
        });
    });

    it("registrate USER6", function() {
        Signup.registerUserUntilDone(USER6).then(function(userData){
            USER6.username = userData.username;
            USER6.email = userData.email;
            console.log('USER6:', USER6.username);
            Signup.verifyEmail(USER6);
        });
    });

    it("registrate USER7", function() {
        Signup.registerUserUntilDone(USER7).then(function(userData){
            USER7.username = userData.username;
            USER7.email = userData.email;
            console.log('USER7:', USER7.username);
            Signup.verifyEmail(USER7);
        });
    });

    it("registrate USER8", function() {
        Signup.registerUserUntilDone(USER8).then(function(userData){
            USER8.username = userData.username;
            USER8.email = userData.email;
            console.log('USER8:', USER8.username);
            Signup.verifyEmail(USER8);
        });
    });

    it("registrate USER9", function() {
        Signup.registerUserUntilDone(USER9).then(function(userData){
            USER9.username = userData.username;
            USER9.email = userData.email;
            console.log('USER9:', USER9.username);
            Signup.verifyEmail(USER9);
        });
    });

    it("registrate USER10", function() {
        Signup.registerUserUntilDone(USER10).then(function(userData){
            USER10.username = userData.username;
            USER10.email = userData.email;
            console.log('USER10:', USER10.username);
            Signup.verifyEmail(USER10);
        });
    });

});

describe("Personal mail available in the user's profile: ", function(){
    it("check user profile personal mail part", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        element(by.xpath("//button[@data-protractor-id='userMessages']")).click();

        expect(element(by.xpath("//*[@data-protractor-id='userMessagesAllMail']")).isDisplayed()).toBeTruthy();
        expect(element(by.xpath("//*[@data-protractor-id='userMessagesDialogues']")).isDisplayed()).toBeTruthy();
        expect(element(by.xpath("//*[@data-protractor-id='userMessagesNotices']")).isDisplayed()).toBeTruthy();
        expect(element(by.xpath("//*[@data-protractor-id='userMessagesInvites']")).isDisplayed()).toBeTruthy();
        expect(element(by.xpath("//*[@data-protractor-id='userMessagesFriendship']")).isDisplayed()).toBeTruthy();

        Auth.logOut();
    });

});

describe("Only authorized user can see personal mail part: ", function(){

    it("Open user personal mauil unauthorized user", function(){
        browser.get('/users/' + OWNER.username + '/messages/private');
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');
    });

});

describe("When you click on the menu item 'personal mail' must make the transition to the section of the profile 'personal mail' / 'dialogues': ", function(){

    it("Open user personal mail unauthorized user", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        element(by.xpath("//button[@data-protractor-id='userTopMenu']")).click();
        //element(by.xpath("//button[@data-protractor-id='toggleMessages']")).click();

        element(by.xpath("//a[@data-protractor-id='userMessages']")).click();

        expect(browser.getCurrentUrl()).toContain('/users/' + OWNER.username + '/messages/private');

        Auth.logOut();
    });

});

describe("Test users dialogs:", function(){

    it("send a message from your page", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get('/users/' + OWNER.username + '/messages/private');
        browser.waitForAngular();
        element(by.xpath("//*[@data-protractor-id='sendPrivateMessage']")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[contains(@class,'select2-choice') and contains(@class,'select2-default')]")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(USER.username);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + USER.username + "']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//textarea[@name='body']")).sendKeys('Hello world!');
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//form[@name='messageForm']")).submit();

        Auth.logOut();
    });

    it("send message from user profile page", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='sendUserMessage']")).click();

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//textarea[@name='body']")).sendKeys('Hello world2!');
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//form[@name='messageForm']")).submit();

        Auth.logOut();
    });

    it("user check hint count not readed messages", function(){
        Auth.loginAsUser(USER.username, USER.password);

        element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).getText().then(function(value){
            expect(value).toMatch(/1/);
        });

        Auth.logOut();
    });

    it("reply owner", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='sendUserMessage']")).click();

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//textarea[@name='body']")).sendKeys('Reply to owner');
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//form[@name='messageForm']")).submit();

        Auth.logOut();

        //element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        //element(by.xpath("//button[@data-protractor-id='toggleMessages']")).click();

        //element(by.xpath("//a[@data-protractor-id='messagesDialog']")).click();
        //element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

        //element(by.xpath("//div[@data-ui-view='']//button[@data-do-send-message='']")).click();
        /*
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);


        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[contains(@class,'select2-choice') and contains(@class,'select2-default')]")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(OWNER.username);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + OWNER.username + "']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//textarea[@name='body']")).sendKeys('Hello world OWNER!');
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//form[@name='messageForm']")).submit();

        Auth.logOut();
         */
    });

    it("owner check hint count not readed messages", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).getText().then(function(value){
            expect(value).toMatch(/1/);
        });

        Auth.logOut();


    });

    it("Check message from owner", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/messages/private');
        browser.waitForAngular();

        element.all(by.xpath("//*[@data-protractor-id='protractor-message_dialog_created']")).then(function(messages){
            expect(messages.length == 1).toBe(true);
        });

        Auth.logOut();

    });

    it("Check the number of thread messages", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/messages/private');
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='expandThread:"+ OWNER.username +"']")).click();
        element.all(by.xpath("//*[@data-protractor-id='protractor-message_dialog_created']")).then(function(messages){
            expect(messages.length == 3).toBe(true);
        });
        Auth.logOut();
    });

    it("check hint count if messages are readed", function(){

        expect(
            element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).isPresent()
        ).toBeFalsy();

    });

});

describe("Test ban notice: ", function(){

    it("create event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Events.createNew(EVENT);
        console.log('EVENT:', EVENT.name);
        Auth.logOut();
    });

    it("comment event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Comments.addComment('/events/' + EVENT.name, null, 'Hello!!!');
        Auth.logOut();
    });

    it("ban user", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//li[@data-protractor-id='togglePostSettings']/button")).click();
        element(by.xpath("//button[contains(@class,'ban-user') and contains(@data-add-userban,'')]")).click();

        element(by.xpath("//input[@id='comment']")).sendKeys('Задолбал!');
        selectDropdownbyValue(element(by.name('expire')), '3');
        element(by.xpath("//form[@name='banUserForm']")).submit();
        //Auth.logOut();
    });

    it("unban user", function(){
        browser.get('/users/' + USER.username+ '/bans/from');
        browser.waitForAngular();
        element(by.xpath("//*[@data-protractor-id='removeBan" + OWNER.username + "']")).click();
        Auth.logOut();
    });

    it("check hint count", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).getText().then(function(value){
            expect(value).toMatch(/2/);
        });
    });

    it("check notices", function(){
        browser.get('/users/' + OWNER.username + '/messages/notice');
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='banFrom" + USER.username + "Cancelled']")
            ).isPresent()

        ).toBeTruthy();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-userban_created']")
            ).isPresent()

        ).toBeTruthy();
    });
    
    it("check unread messages number", function(){
        expect(
            element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).isPresent()
        ).toBeFalsy();

        Auth.logOut();

    });
   
});

describe("Test notification of the beginning, end, change of events: ", function(){

    it("create EVENT2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);

        EVENT2.ts_start = moment().add(EVENT_MIN_START_OFFSET, 'm').format("DD.MM.YYYY HH:mm");
        EVENT2.ts_finish = moment().add(EVENT_MIN_START_OFFSET+1, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT2).then(function(event){
            EVENT2.url = event.url;
            EVENT2.name = event.name;
            console.log("Event2 url: ", EVENT2.url);
            console.log('EVENT2 name:', EVENT2.name);
        });
        Auth.logOut();
    });

    it("event participants", function(){
        Participation.intendedToGoEvent(USER3, EVENT2);
    });

    it("edit event", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/events/' + EVENT2.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        selectDropdownbyValue(element(by.xpath("//select[@name='age_restriction']")), '0');
        element(by.xpath("//textarea[@id='description']")).sendKeys('Add description');
        element(by.xpath("//form[@name='eventForm']")).submit();
        
        Auth.logOut();
    });

    it("wait for event to complete", function(){
        var timeout = (EVENT_MIN_START_OFFSET+1) * 60000;
        console.log("Waiting ", timeout/1000.0, " seconds for event to complete....");
        browser.sleep(timeout);
    });

    it("check hint count", function(){
        Auth.loginAsUser(USER3.username, USER3.password);

        element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).getText().then(function(value){
            expect(value).toMatch(/3/);
        });
    });

    it("check notices", function(){
        //Auth.loginAsUser(USER3.username, USER3.password);

        browser.get('/users/' + USER3.username + '/messages/notice');
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_finished']")
            ).isPresent()

        ).toBeTruthy();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_started']")
            ).isPresent()

        ).toBeTruthy();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_changed']")
            ).isPresent()

        ).toBeTruthy();
        //Auth.logOut();
    });

    it("check hint count", function(){
        expect(
            element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).isPresent()
        ).toBeFalsy();

        Auth.logOut();
    });

});

describe("Test notification of the cancellation events: ", function(){

    it("create EVENT3", function(){
        Auth.loginAsUser(USER4.username, USER4.password);
        Events.createNew(EVENT3);
        console.log('EVENT3:', EVENT3.name);
        Auth.logOut();
    });

    it("event participants", function(){
        Participation.intendedToGoEvent(USER5, EVENT3);
    });

    it("disable event", function(){
        Auth.loginAsUser(USER4.username, USER4.password);
        browser.get('/events/' + EVENT3.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='disableEvent']")).click();

        element(by.xpath("//button[@data-ng-click='yes()']")).click();

        Auth.logOut();
    });

    it("check hint count", function(){
        Auth.loginAsUser(USER5.username, USER5.password);

        element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).getText().then(function(value){
            expect(value).toMatch(/1/);
        });

    });

    it("check notices", function(){
        browser.get('/users/' + USER5.username + '/messages/notice');
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_changed']")
            ).isPresent()

        ).toBeTruthy();
    });

    it("check hint count", function(){
        expect(
            element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).isPresent()
        ).toBeFalsy();
        Auth.logOut();
    });
    
});

describe("Test invites: ", function(){

    it("create EVENT5", function(){
        Auth.loginAsUser(USER6.username, USER6.password);

        Events.createNew(EVENT5).then(function(event){
            EVENT5.url = event.url;
            EVENT5.name = event.name;
            console.log("Event5 url: ", EVENT5.url);
            console.log('EVENT5 name:', EVENT5.name);
        });
        Auth.logOut();
    });

    it("USER7 get invite to event", function(){
        Participation.intendedToGoEventByInvitetion(USER7, EVENT5);
    });

    it("USER8 get invite to event", function(){
        Participation.intendedToGoEventByInvitetion(USER8, EVENT5);
    });

    it("give invitation", function(){
        Auth.loginAsUser(USER6.username, USER6.password);
        Events.giveInvitations(EVENT5, [USER7.username, USER8.username]);
        Auth.logOut();
    });

    it("check hint count", function(){
        Auth.loginAsUser(USER7.username, USER7.password);

        element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).getText().then(function(value){
            expect(value).toMatch(/1/);
        });

        Auth.logOut();
    });

    it("check hint count", function(){
        Auth.loginAsUser(USER6.username, USER6.password);

        expect(
            element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).isPresent()
        ).toBeTruthy();


        Auth.logOut();

    });

});

describe("Test friendship messages", function(){

    it("send friendship USER9 to USER10", function(){
        Friendship.beFriends(USER9, USER10);
    });

    it("Check friendship request", function(){

        Auth.loginAsUser(USER10.username, USER10.password);

        browser.get('/users/' + USER10.username + '/messages/friendship');
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-friendship_request_created']")
            ).isPresent()

        ).toBeTruthy();

    });

    it("check hint count", function(){

        expect(
            element(by.xpath("//*[@data-protractor-id='unreadMessagesNumber']")).isPresent()
        ).toBeTruthy();

        Auth.logOut();
    });

});

describe("Should be unable to send messages to blocked users:", function(){

    it("admin block user", function(){

        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        //browser.get(ADMIN_URL + '/admin/users/user/');
        browser.get(ADMIN_URL + '/admin/users/user/?q=' + USER.username + '&all=');
        
        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        //ptor.driver.findElement(protractor.By.id('searchbar')).sendKeys(USER.username);
        //ptor.driver.findElement(protractor.By.id('changelist-search')).submit();

        ptor.driver.findElement(protractor.By.xpath('//table[@id="result_list"]//a[text()="' + USER.username +'"]')).click();

        ptor.driver.findElement(protractor.By.xpath("//a[@class='ban_button']")).click();
        driver.switchTo().alert().accept();

        browser.ignoreSynchronization = false;

    });

    it("try send message to baned user", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get('/users/' + OWNER.username + '/messages/private');
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='sendPrivateMessage']")).click();
        //element(by.xpath("//button[@data-protractor-id='toggleMessages']")).click();

        //element(by.xpath("//a[@data-protractor-id='messagesDialog']")).click();
        //element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

        //element(by.xpath("//div[@data-ui-view='']//button[@data-do-send-message='']")).click();
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[contains(@class,'select2-choice') and contains(@class,'select2-default')]")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(USER.username);

        expect(element(by.xpath("//ul[@class='select2-results']//li[text()='No matches found']")).isPresent()).toBe(true);
       
        Auth.logOut();

    });

});


describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
