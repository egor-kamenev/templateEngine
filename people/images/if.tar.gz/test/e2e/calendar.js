'use strict';

var moment = require('moment');

var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Garik',
        'last_name': 'Harlamov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222011',
        'age': 22,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user',
        'first_name': 'Har',
        'last_name': 'Mantu',
        'email': 'bigboss@mail.com',
        'phone': '+79111222011',
        'day': moment().format("D"),
        'month': moment().format("M"), 
        'age': 27,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'выставка',
        'description': 'Event description2',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'дом',
        'description': 'Event description3',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT4 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'description': 'Event description4',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': true,
        'visibility': '4'
    },
    EVENT5 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'выпускной',
        'description': 'Event description5',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT6 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'занятие спортом',
        'description': 'Event description6',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    };

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Comments = require('../utils/comments.js'),
    Places = require('../utils/places.js'),
    Friendship = require('../utils/friendship.js'),
    Signup = require('../utils/signup.js'),
    Albums = require('../utils/albums.js'),
    Settings = require('../utils/settings.js'),
    Participation = require('../utils/participation.js');

browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

});

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users: ", function() {
    
    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('OWNER:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });

    it("Registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

    it("Registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });
    
});

describe("Check privacy section calendar: ", function(){

    it("ownder check sections", function() {

        Auth.loginAsUser(OWNER.username, OWNER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]/button")).click();
        expect(element(by.xpath("//a[@data-protractor-id='userCalendar']")).isDisplayed()).toBe(true);

        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        expect(element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]/button")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userCalendar']")).isPresent()).toBe(false);

        Auth.logOut();

    });

    it("Default calendar should be opened for the current week and have day, monthe buttons", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]/button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-button-agendaWeek') and contains(@class,'fc-state-active')]")).isPresent()).toBe(true);
        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-button-month') and contains(@class,'fc-button')]")).isPresent()).toBe(true);
        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-button-agendaDay') and contains(@class,'fc-button')]")).isPresent()).toBe(true);
        

        Auth.logOut();

    });

});

describe("Events that are created by the user: ", function(){

    it("create event", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT.ts_start = moment().add(3, 'h').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT);
        console.log('EVENT:', EVENT.name);
        Auth.logOut();
        
    });

    it("event should be in calendar", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        browser.driver.sleep(2000);

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT.name + "')]")).isPresent()).toBe(true);
        element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT.name + "')]")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventName']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventAuthor']")).getText().then(function(value){
            expect(value).toEqual(OWNER.first_name + ' ' + OWNER.last_name);
        });

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventName']")).getText().then(function(value){
            expect(value).toEqual(EVENT.name);
        });

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventPlace']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@data-protractor-id='popupEventDescription']")).getText().then(function(value){
            expect(value).toEqual(EVENT.description);
        });
            
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).all(by.repeater('tag in tags')).get(0).getText().then(function(tag){
            expect(tag).toEqual(EVENT.tag);
        });

        browser.driver.sleep(1000);

        Auth.logOut();

    });

});

describe("Events that for which he went: ", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT2.ts_start = moment().add(4, 'm').format("DD.MM.YYYY HH:mm");
        EVENT2.ts_finish = moment().add(5, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT2);
        console.log('EVENT2:', EVENT2.name);
        Auth.logOut();
        
    });

    it("intended to go event", function(){
        Participation.intendedToGoEvent(USER, EVENT2);
    });

    it("Wait for event started and ended", function(){
        browser.driver.sleep(360000); // 6 minutes wait
    });

    it("event should be in calendar", function(){

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT2.name + "')]")).isPresent()).toBe(true);
        element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT2.name + "')]")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventName']")).isDisplayed()).toBe(true);
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventAuthor']")).getText().then(function(value){
            expect(value).toEqual(OWNER.first_name + ' ' + OWNER.last_name);
        });

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventPlace']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@data-protractor-id='popupEventDescription']")).getText().then(function(value){
            expect(value).toEqual(EVENT2.description);
        });
            
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).all(by.repeater('tag in tags')).get(0).getText().then(function(tag){
            expect(tag).toEqual(EVENT2.tag);
        });

        browser.driver.sleep(1000);

        Auth.logOut();

    });

});

describe("Events that are going to go on: ", function(){

    it("create event", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT3.ts_start = moment().add(3, 'h').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT3);
        console.log('EVENT3:', EVENT3.name);
        Auth.logOut();
        
    });

    it("intended to go event", function(){
        Participation.intendedToGoEvent(USER, EVENT3);
    });

    it("event should be in calendar", function(){

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT3.name + "')]")).isPresent()).toBe(true);
        element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT3.name + "')]")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventName']")).isDisplayed()).toBe(true);
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventAuthor']")).getText().then(function(value){
            expect(value).toEqual(OWNER.first_name + ' ' + OWNER.last_name);
        });

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventPlace']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@data-protractor-id='popupEventDescription']")).getText().then(function(value){
            expect(value).toEqual(EVENT3.description);
        });
            
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).all(by.repeater('tag in tags')).get(0).getText().then(function(tag){
            expect(tag).toEqual(EVENT3.tag);
        });

        browser.driver.sleep(1000);

        Auth.logOut();

    });

});

describe("Events that for which there is an invitation: ", function(){

    it("create event", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT4.ts_start = moment().add(4, 'h').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT4);
        console.log('EVENT4:', EVENT4.name);
        Auth.logOut();
        
    });

    it("get invitation", function(){
        Participation.intendedToGoEventByInvitetion(USER, EVENT4);
    });

    it("give invitation", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.giveInvitations(EVENT4.name, [USER.username]);
        Auth.logOut();

    });

    it("event should be in calendar", function(){

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT4.name + "')]")).isPresent()).toBe(true);
        element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT4.name + "')]")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventName']")).isDisplayed()).toBe(true);
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventAuthor']")).getText().then(function(value){
            expect(value).toEqual(OWNER.first_name + ' ' + OWNER.last_name);
        });

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventPlace']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@data-protractor-id='popupEventDescription']")).getText().then(function(value){
            expect(value).toEqual(EVENT4.description);
        });
            
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).all(by.repeater('tag in tags')).get(0).getText().then(function(tag){
            expect(tag).toEqual(EVENT4.tag);
        });

        browser.driver.sleep(1000);

        Auth.logOut();

    });

});

describe("Event that is subscribed: ", function(){

    it("create event", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT5.ts_start = moment().add(15, 'h').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT5);
        console.log('EVENT5:', EVENT5.name);
        Auth.logOut();
        
    });

    it("subscribe to event", function(){

        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT5.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='subscribeEvent']")).click();
        element(by.xpath("//form[@name='subscriptionForm']")).submit();

        Auth.logOut();

    });

    it("event should be in calendar", function(){

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT5.name + "')]")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventName']")).isDisplayed()).toBe(true);
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventAuthor']")).getText().then(function(value){
            expect(value).toEqual(OWNER.first_name + ' ' + OWNER.last_name);
        });

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventPlace']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@data-protractor-id='popupEventDescription']")).getText().then(function(value){
            expect(value).toEqual(EVENT5.description);
        });
            
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).all(by.repeater('tag in tags')).get(0).getText().then(function(tag){
            expect(tag).toEqual(EVENT5.tag);
        });

        browser.driver.sleep(1000);

        Auth.logOut();

    }); 

});

describe("Event that is bookmarked: ", function(){

    it("create event", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT6.ts_start = moment().add(2, 'h').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT6);
        console.log('EVENT6:', EVENT6.name);
        Auth.logOut();
        
    });

    it("bookmark to event", function(){

        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT6.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='bookmarkEvent']")).click();
        
        Auth.logOut();

    });

    it("event should be in calendar", function(){

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT6.name + "')]")).isPresent()).toBe(true);
        element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT6.name + "')]")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventName']")).isDisplayed()).toBe(true);
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventAuthor']")).getText().then(function(value){
            expect(value).toEqual(OWNER.first_name + ' ' + OWNER.last_name);
        });

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//a[@data-protractor-id='popupEventPlace']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@data-protractor-id='popupEventDescription']")).getText().then(function(value){
            expect(value).toEqual(EVENT6.description);
        });
            
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).all(by.repeater('tag in tags')).get(0).getText().then(function(tag){
            expect(tag).toEqual(EVENT6.tag);
        });

        browser.driver.sleep(1000);

        Auth.logOut();

    });

});

describe("Friends birthday in calendar", function(){

    it("create frienship", function(){
        Friendship.beFriends(USER, USER2);
    });

    it("user should be in calendar", function(){

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + USER2.username + "')]")).isPresent()).toBe(true);

        element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + USER2.username + "')]")).click();

        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        Auth.logOut();

    });

});

describe("Test filters: ", function(){

    it("off friend birthday filter", function(){
        
        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + USER2.username + "')]")).isPresent()).toBe(true);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(1).click();

        browser.driver.sleep(2000);

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + USER2.username + "')]")).isPresent()).toBe(false);

        Auth.logOut();

    });

    it("off user events filter", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT.name + "')]")).isPresent()).toBe(true);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(0).click();

        browser.driver.sleep(2000);

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT.name + "')]")).isPresent()).toBe(false);

        Auth.logOut();

    });

    it("off user intended to go filter", function(){  

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT3.name + "')]")).isPresent()).toBe(true);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(3).click();
        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(3).click();

        browser.driver.sleep(2000);

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT3.name + "')]")).isPresent()).toBe(false);

        Auth.logOut();

    });

    it("off users hase invitation to event filter", function(){ 

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT4.name + "')]")).isPresent()).toBe(true);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(2).click();

        browser.driver.sleep(2000);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(2).click();

        browser.driver.sleep(2000);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(2).click();

        browser.driver.sleep(2000);

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT4.name + "')]")).isPresent()).toBe(false);

        Auth.logOut();

    });

    it("off users subscribed events filter", function(){  

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT5.name + "')]")).isPresent()).toBe(true);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(4).click();

        browser.driver.sleep(2000);

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT5.name + "')]")).isPresent()).toBe(false);

        Auth.logOut();

    });

    it("off users bookmarked events filter", function(){ 

        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userCalendar']")).click();

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT6.name + "')]")).isPresent()).toBe(true);

        element.all(by.xpath("//li[@class='select2-search-choice']//a")).get(5).click();

        browser.driver.sleep(2000);

        expect(element(by.xpath("//div[@id='events_calendar']//span[contains(@class,'fc-event-title') and contains(text(),'" + EVENT6.name + "')]")).isPresent()).toBe(false);

        Auth.logOut();

    });

});


