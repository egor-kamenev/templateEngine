'use strict';

var REG_USER = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'test@mail.com',
        'age': 30,
        'password': 'hackme'
    },
    REG_USER2 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'phone': '+79111' + Math.floor(Math.random()*1000000),
        'email': 'test@mail.com',
        'age': 32,
        'password': 'hackme'
    },
    TEST_PASSWORD_NEW = 'qwerty';

var Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    UserMail = require('../utils/userMail.js');

var selectDropdownbyNum = function (element, optionNum) {
    if (optionNum) {
        var options = element.all(by.tagName('option')).then(
            function(options) {
                options[optionNum].click();
            }
        );
    }
};

describe("Change password with email: ", function(){

    it("register test user", function(){
        Signup.registerUserUntilDone(REG_USER).then(function(userData){
            console.log('REG_USER.username', userData.username);
            console.log('REG_USER.email', userData.email);
            REG_USER.username = userData.username;
            REG_USER.email = userData.email;
        });
    });
   
    it("should ask link for change password", function(){
        element(by.xpath("//button[@data-protractor-id='loginSignupToggle']")).click();
        element(by.xpath("//a[@data-protractor-id='loginUser']")).click();
        element(by.xpath("//a[@data-protractor-id='authRecovery']")).click();

        browser.waitForAngular();

        element(by.id('value')).sendKeys(REG_USER.email);
        element(by.name('sendRestoreCodeForm')).submit();
        browser.waitForAngular();

        browser.wait(function() {
            return element(by.className('ui-pnotify')).isPresent().then(function(result){
                return !result;
            });
        }, 40000);

    });

    it("get recovery link", function(){
        var mailer = new UserMail(REG_USER.email),
            flow = protractor.promise.controlFlow(),
            urlPattern = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;

        flow.execute(mailer.getAllMail).then(function(value){
            var recovery_url = value[0].body.match(urlPattern)[0].split('/').splice(3).join('/');
            recovery_url = '/' + recovery_url.split("\\")[0].split("]")[0];

            browser.get(recovery_url);
            browser.waitForAngular();

            element(by.id('new_password1')).sendKeys(TEST_PASSWORD_NEW);
            element(by.id('new_password2')).sendKeys(TEST_PASSWORD_NEW);
            element(by.name('changePasswordForm')).submit();
            browser.waitForAngular();
            
            expect(browser.getCurrentUrl()).toContain('/auth/login');
            
        });
    });

    it("try login with new password", function(){
        Auth.loginAsUser(REG_USER.username, TEST_PASSWORD_NEW);
        Auth.logOut();
    });

});

 /* T573
describe("Change password with phone: ", function(){

    it("register test user", function(){
        Signup.registerUserUntilDone(REG_USER2).then(function(userData){
            console.log('REG_USER2:', userData.username);
            REG_USER2.username = userData.username;
            REG_USER2.email = userData.email;
        });
    });
    
    it("login as registered user and add phone", function(){
        Auth.loginAsUser(REG_USER2.username, REG_USER2.password);
        Signup.addPhone(REG_USER2);
        Auth.logOut();
    });

    it("should ask code for change password", function(){

        browser.wait(function() {
            return element(by.className('ui-pnotify')).isPresent().then(function(result){
                return !result;
            });
        }, 40000);

        element(by.xpath("//button[@data-protractor-id='loginSignupToggle']")).click();
        element(by.xpath("//a[@data-protractor-id='loginUser']")).click();
        element(by.xpath("//a[@data-protractor-id='authRecovery']")).click();

        browser.waitForAngular();
        console.log("Phone: ", REG_USER2.phone);
        element(by.id('value')).sendKeys(REG_USER2.phone);
        selectDropdownbyNum(element(by.id('type')), 1);
        element(by.name('sendRestoreCodeForm')).submit();
        browser.waitForAngular();

        var mailer = new UserMail(null, REG_USER2.phone),
            flow = protractor.promise.controlFlow();
           
        flow.execute(mailer.getAllSms).then(function(value){
            console.log("ALL SMS: number", value.length);
            for(var i = 0; i < value.length; i++){
                console.log("SMS: ", i, value[i], value[i].msg);
            }
            var code = value[0].msg.match(/:\s+(\d+)/)[1];
            console.log("CODE:", code);

            element(by.id('confirmation_code')).sendKeys(code);
            element(by.id('new_password1')).sendKeys(TEST_PASSWORD_NEW);
            element(by.id('new_password2')).sendKeys(TEST_PASSWORD_NEW);
            element(by.name('changePasswordForm')).submit();

            browser.waitForAngular();
            expect(browser.getCurrentUrl()).not.toContain('/auth/login');

        });
    });

    it("try login with new password", function(){
        Auth.loginAsUser(REG_USER2.username, TEST_PASSWORD_NEW);
    });

    it("Tests finished - log out", function(){
        Auth.logOut();
    });

});

*/
