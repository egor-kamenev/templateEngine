'use strict';

var path = require('path'),
    OWNER = {
        'username': 'ownerComplain',
        'first_name': 'Owner',
        'last_name': 'Tester',
        'email': 'ownercomplain@mail.com',
        'phone': '+79111223001',
        'age': 30,
        'password': 'hackme'
    },
    USER1 = {
        'username': 'user1Complain',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1complain@mail.com',
        'phone': '+79111223002',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user2Complain',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2complain@mail.com',
        'phone': '+79111223003',
        'age': 25,
        'password': 'hackme'
    },
    INCOMPLETED_USER = {
        'username': 'incompleted',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'incompleted@mail.com',
        'phone': '+79111223003',
        'age': 25,
        'password': 'hackme'
    },
    TRUSTED_USER = {
        'username': 'trusted',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'trusted@mail.com',
        'phone': '+79111223003',
        'age': 25,
        'password': 'hackme'
    },
    EVENT1 = {
        'name': 'eventcomplain1',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test complain1',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'eventcomplain2',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test complain2',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'eventcomplaindecline',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test complain3',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE = {
        'name': 'placecomplain11',
        'visibility': '4'
    }, 
    ALBUM = {
        'title': 'Test album',
        'tag': 'albumtag',
        'visibility': '4',
        uploadPhotoPath: path.resolve(__dirname, '..', 'test_data', "photo.jpg")
    },
    POST = {
        'body': "Test post body",
        'url': ""
    },
    EVENT1_URL,
    EVENT2_URL,
    EVENT3_URL,
    PLACE_URL,
    TWICE_COMPLAN_POST_BODY = "Complain me twice";

var Auth = require('../utils/auth.js'),
    Admin = require('../utils/admin.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Comments = require('../utils/comments.js'),
    Signup = require('../utils/signup.js'),
    Visibility = require('../utils/visibility.js'),
    Albums = require('../utils/albums.js'),
    Settings = require('../utils/settings.js'),
    TagSelector = require('../utils/tagSelector.js');

var complainButtonLocator = by.xpath('//button[@data-do-complain]');

var selectDropdownbyNum = function (element, optionNum) {
    if (optionNum) {
        var options = element.findElements(by.tagName('option')).then(
            function(options) {
                options[optionNum].click();
            }
        );
    }
};

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register users: ", function(){

    it("register OWNER", function(){
        Signup.registerUserUntilDone(OWNER).then(
            function (user) {
                console.log("OWNER USERNAME: ", user.username);

                OWNER.username = user.username;
                OWNER.email = user.email;
                Signup.verifyEmail(OWNER);
            }
        );
    });

    it("register incompleted user", function(){
        Signup.registerUserUntilDone(INCOMPLETED_USER).then(
            function (user) {
                console.log("INCOMPLETED USERNAME: ", user.username);

                INCOMPLETED_USER.username = user.username;
                INCOMPLETED_USER.email = user.email;
            }
        );
        
    });

    it("register USER1", function(){
        Signup.registerUserUntilDone(USER1).then(
            function (user) {
                console.log("USER1 USERNAME: ", user.username);

                USER1.username = user.username;
                USER1.email = user.email;

                Signup.verifyEmail(USER1);
            }
        );
    });

    it("register USER2", function(){
        Signup.registerUserUntilDone(USER2).then(
            function (user) {
                console.log("USER2 USERNAME: ", user.username);

                USER2.username = user.username;
                USER2.email = user.email;

                Signup.verifyEmail(USER2);
            }
        );
    });

});

describe("Set user1 & user2 role to Advanced users: ", function(){

    it("Set user1 role to AdvancedUser", function(){
        Admin.setUserRole(USER1.username, "AdvancedUsers");
    });

    it("Set user2 role to AdvancedUser", function(){
        Admin.setUserRole(USER2.username, "AdvancedUsers");
    });

});



describe("Add content: ", function(){

    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });
        
    it("Create event1", function(){
        Events.createNewUnique(EVENT1).then(function(event){
            EVENT1_URL = event.url;
            EVENT1.name = event.name;
            console.log("EVENT1_URL: ", EVENT1_URL);
        });
    });

    it("Create event2", function(){
        Events.createNewUnique(EVENT2).then(function(event){
            EVENT2_URL = event.url;
            EVENT2.name = event.name;
            console.log("EVENT2_URL: ", EVENT2_URL);

        });
    });

    it("Create event3", function(){
        Events.createNewUnique(EVENT3).then(function(event){
            EVENT3_URL = event.url;
            EVENT3.name = event.name;
            console.log("EVENT3_URL: ", EVENT3_URL);
        });
    });
    
    it("Create place", function(){

        Places.createNewUnique(PLACE).then(function(place){
            console.log("PLACE URL:: ", place.url);
            PLACE_URL = place.url;
       });

    });

    
    it("Create photo album", function(){
        Albums.createNew(OWNER, ALBUM).then(function(album){
            ALBUM.url = album.albumUrl;
            ALBUM.photoUrl = album.photoUrl;
        });
    });

    it("Add post", function(){
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();
        
        expect(
            element(by.id('xPostBody')).isDisplayed()
        ).toBeTruthy();

        element(by.id('xPostBody')).sendKeys(POST.body);
        element(by.name('addXPostForm')).submit();

        var post = element(by.repeater("post in xPosts | orderBy:'-ts_published' track by post.id").row(0));

        expect( post.isDisplayed() ).toBeTruthy();

        post.element(by.xpath("(//a[@data-protractor-id='discussionLink'])[1]")).getAttribute("href").then(function(postUrl){
            console.log("POST URL: ", postUrl);
            POST.url = postUrl;
        });

        Auth.logOut();
    });


    it("add post replies", function(){

        var N_POSTS = 5;
        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get(POST.url);
        browser.waitForAngular();

        for(var i = 0; i < N_POSTS; i ++){
            element( by.id('xPostBody') ).sendKeys("Reply to post: " + (i+1) );
            element( by.name('addXPostForm') ).submit();
        }
        

        // Wait for the last post to appear
        browser.wait(function() {
            return element(by.repeater("post in xPosts | orderBy:'-ts_published' track by post.id")).getText().then(function(result){
                return result.indexOf("Reply to post: " + i) >= 0;
            });
        }, 20000);

        // The number of complain buttons must be the same as the number of posts
        browser.driver.findElements(by.xpath('//li//button[@data-do-complain]')).then(function(elements){
            expect(elements.length).toBe(N_POSTS);
        });

    });

});


describe("Decline complains: ", function(){

    it("User1 complains about event", function(){
        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get(EVENT3_URL);
        browser.waitForAngular();
        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath('//button[@data-do-complain]')).click();
        Auth.logOut();
    });

    it("admin declines user1 complain about event", function(){

        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        
        browser.get(ADMIN_URL +  '/admin/moderation/complaintask/');

        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        driver.findElement(protractor.By.xpath('//tr//td[text()="' + EVENT3.name +'"]/following-sibling::td[3]//button')).click();

        browser.ignoreSynchronization = false;

        browser.get('/');
        Auth.logOut();

    });

    it("user1 gets message from admin - his complain was declined", function(){

        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get('/users/' + USER1.username +  '/messages/notice');
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-complaintask_declined']")
            ).isPresent()
        ).toBeTruthy();


        Auth.logOut();

    });

});

describe("Do complains: ", function(){

    it("Incompleted user can't complain", function(){
        Auth.loginAsUser(INCOMPLETED_USER.username, INCOMPLETED_USER.password);
        browser.get(EVENT1_URL);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();

        expect(
            element(
                by.xpath('//*[@data-do-complain="event" and @data-protractor-id="noPermissionToComplain"]')
            ).isDisplayed()
        ).toBeTruthy();

        Auth.logOut();

    });

    it("Complain about event", function(){

        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get(EVENT1_URL);

        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath('//button[@data-do-complain]')).click();

    });

    it("can't complain twice about the same object", function(){
        browser.get(EVENT1_URL);
        browser.waitForAngular();
        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();

        expect(
            element(by.xpath('//button[@data-do-complain]')).getAttribute('disabled')
        ).toEqual('true');

        //expect(element(by.xpath('//button[@data-do-complain]')).isDisplayed() ).toBeFalsy();
    });

    it("Complain about place", function(){
        browser.get(PLACE_URL);
        browser.waitForAngular();
        element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        element(by.xpath('//button[@data-do-complain]')).click();
    });


    it("Complain about post", function(){
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();
        element(by.xpath('//button[@data-do-complain]')).click();
    });


    it("Complain about album", function(){
        browser.get(ALBUM.url);
        browser.waitForAngular();
        element(by.xpath('//button[@data-do-complain]')).click();
    });

    it("Complain about photo", function(){
        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();
        element(by.xpath('//button[@data-do-complain]')).click();
        Auth.logOut();
    });

    it("Ban contents", function(){
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        
        browser.get(ADMIN_URL +  '/admin/moderation/complaintask/');

        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        driver.findElement(protractor.By.id('action-toggle')).click();
        selectDropdownbyNum(driver.findElement(protractor.By.xpath('//select[@name="action"]')), 3);
        driver.findElement(protractor.By.xpath('//textarea')).sendKeys('ban');
        driver.findElement(protractor.By.xpath('//button[@onclick="doBan();"]')).click();

        browser.ignoreSynchronization = false;
        browser.get('/');
        Auth.logOut();

    });

    it("user gets message from admin - his complain was accepted", function(){

        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get('/users/' + USER1.username +  '/messages/notice');
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-complaintask_accepted']")
            ).isPresent()
        ).toBeTruthy();

        /*var messages = element(by.repeater("msg in messages"));

        messages.getText().then(function(text){
            expect(text).toContain("жалоба");
            expect(text).toContain("удовлетворена");
        });
         */
        Auth.logOut();

    });

    it("content owner gets message from admin - his content was blocked", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get('/users/' + OWNER.username +  '/messages/notice');
        browser.waitForAngular();
        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-complaintask_accepted']")
            ).isPresent()
        ).toBeTruthy();

        /*var messages = element(by.repeater("msg in messages"));

        messages.getText().then(function(text){
            expect(text.toLowerCase()).toContain("объект");
            expect(text.toLowerCase()).toContain("заблокирован");
        });
         */
        Auth.logOut();

    });


});


describe("Complains weight: ", function(){

    it("complain twice on the same content", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();
        element(by.id('xPostBody')).sendKeys(TWICE_COMPLAN_POST_BODY);
        element(by.name('addXPostForm')).submit();
        
        Auth.logOut();

        var liContainingPost = element(by.xpath('//div[contains(text(), "' + TWICE_COMPLAN_POST_BODY + '")]/../../../..'));

        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        liContainingPost.element(by.xpath('//button[@data-do-complain]')).click();

        Auth.logOut();


        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        liContainingPost.element(by.xpath('//button[@data-do-complain]')).click();
        
        Auth.logOut();

        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();

        browser.get(ADMIN_URL +  '/admin/moderation/complaintask/');

        var ptor = protractor.getInstance(),
            driver = ptor.driver;


        driver.findElement(protractor.By.xpath('//tr//td[text()="' + TWICE_COMPLAN_POST_BODY + '"]/following-sibling::td[2]')).getText().then(function(text){
            expect(text).toBe('2');

        });

        browser.ignoreSynchronization = false;

        browser.get('/');
        Auth.logOut();


    });
});

describe("Banned content is not viewable to users: ", function(){

    var expectedUrl = browser.baseUrl + '403';
    it("login as user", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Check banned event", function(){
        browser.get(EVENT1_URL);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toBe(expectedUrl);
    });

    it("Check banned place", function(){

        browser.get(PLACE_URL);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toBe(expectedUrl);
    });

    it("Check banned photo", function(){
        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toBe(expectedUrl);
    });

    it("Check banned album", function(){
        browser.get(ALBUM.url);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toBe(expectedUrl);
    });

    it("Check banned post", function(){
        browser.get(POST.url);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toBe(expectedUrl);
    });



    it("logout", function(){
        Auth.logOut();
    });

});

describe("Banned content is viewable to owner: ", function(){

    var expectedUrl = browser.baseUrl + '403';

    it("login as user", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("Check banned event", function(){
        browser.get(EVENT1_URL);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).not.toBe(expectedUrl);
    });

    it("Check banned place", function(){

        browser.get(PLACE_URL);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).not.toBe(expectedUrl);
    });


    it("Check banned photo", function(){
        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).not.toBe(expectedUrl);
    });

    it("Check banned album", function(){
        browser.get(ALBUM.url);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).not.toBe(expectedUrl);
    });


    it("Check banned post", function(){
        browser.get(POST.url);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).not.toBe(expectedUrl);
    });

    it("logout", function(){
        Auth.logOut();
    });

});

describe("Banned content is viewable to owner in his profile: ", function(){

    it("login as user", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("banned event visible in profile", function(){
    
        browser.get('/users/' + OWNER.username + '/events');
        browser.waitForAngular();

        element(by.xpath('//div[@data-ui-view]')).getText().then(function(text){
            expect(text.toLowerCase()).toContain(EVENT1.name.toLowerCase());
        });
            
    });

    it("banned place visible in profile", function(){
    
        browser.get('/users/' + OWNER.username + '/places');
        browser.waitForAngular();

        element(by.xpath('//div[@data-ui-view]')).getText().then(function(text){
            expect(text.toLowerCase()).toContain(PLACE.name.toLowerCase());
        });
            
    });

    it("banned album visible in profile", function(){
    
        browser.get('/users/' + OWNER.username + '/albums');
        browser.waitForAngular();

        element(by.css('.post-list')).getText().then(function(text){
            expect(text).toContain(ALBUM.title);
        });
            
    });


    it("banned post visible in profile", function(){
    
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        element(by.xpath('//div[@data-ui-view]')).getText().then(function(text){
            expect(text).toContain(POST.body);
        });
            
    });

    it("logout", function(){
        Auth.logOut();
    });

});


describe("Complain about content created by trusted user ", function(){

    it("register trusted user", function(){

        Signup.registerUserUntilDone(TRUSTED_USER).then(
            function (user) {
                console.log("Trusted USERNAME: ", user.username);

                TRUSTED_USER.username = user.username;
                TRUSTED_USER.email = user.email;
            }
        );

    });

    it("admin adds permissions to trusted user", function(){

        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        
        browser.get(ADMIN_URL +  '/admin/users/user/');

        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        driver.findElement(protractor.By.xpath('//a[text()="' + TRUSTED_USER.username + '"]')).click();

        var trustedGroupOption = driver.findElement(protractor.By.xpath('//option[text()="TrustedUsers"]')),
            addGroupsArrow = driver.findElement(protractor.By.id('id_groups_add_link')),
            userForm = driver.findElement(protractor.By.id('user_form'));
        
        expect(trustedGroupOption.isDisplayed()).toBeTruthy();
        trustedGroupOption.click();
        addGroupsArrow.click();
        userForm.submit();

        browser.ignoreSynchronization = false;

        browser.get('/');
        Auth.logOut();

    });

    it("trusted user creates content", function(){

        Auth.loginAsUser(TRUSTED_USER.username, TRUSTED_USER.password);
        Signup.verifyEmail(TRUSTED_USER);

        Events.createNewUnique(EVENT1).then(function(event){
            EVENT1_URL = event.url;
            EVENT1.name = event.name;
            console.log("Event from trusted user: ", EVENT1_URL);
        });

        Auth.logOut();

    });

    it("ojects created by trusted user are complainable", function(){
        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get(EVENT1_URL);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        expect( element(by.xpath('//button[@data-do-complain]')).isDisplayed() ).toBeTruthy();

        Auth.logOut();

    });

});


describe("complain block (temporary and permanent): ", function(){

    it("prepare posts to complain: register owner user", function(){

        Signup.registerUserUntilDone(OWNER).then(
            function(user){
                console.log("Complain block tests: owner username: ", user.username);
                OWNER.username = user.username;
                OWNER.email = user.email;
                Signup.verifyEmail(OWNER);

            }
        );
    });

    it("prepare posts to complain: add posts", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        
        var N_POSTS = 5;
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        for(var i = 0; i < N_POSTS; i ++){
            element( by.id('xPostBody') ).sendKeys("Post: " + (i+1));
            element( by.name('addXPostForm') ).submit();
        }
    });

    it("prepare event to complain", function(){

        Events.createNewUnique(EVENT1).then(function(event){
            EVENT1_URL = event.url;
            EVENT1.name = event.name;
            console.log("EVENT1_URL: ", EVENT1_URL);
        });
    });

    it("logout owner", function(){
        Auth.logOut();
    });

    it("Register user that will be blocked by complain stats", function(){

        Signup.registerUserUntilDone(USER1).then(
            function(user){
                console.log("Complain user username: ", user.username);
                USER1.username = user.username;
                USER1.email = user.email;
                Signup.verifyEmail(USER1);
                
        });
    });

    it("Make complains about created posts", function(){
        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        var N_POSTS = 5;

        for(var i = 0; i < N_POSTS; i ++){

            var postList = browser.findElement(
                by.css('.post-list')
            );
            
            var postComplain = browser.findElement(
                by.xpath('//*[@data-do-complain and not(@disabled)]')
            );

            browser.executeScript(scrollIntoView, postList);

            /*if(i > 2){
                browser.executeScript(scrollIntoView, postComplain);
            }*/
            
            postComplain.click();
            browser.waitForAngular();
        }
    });

    it("complain user logout", function(){
        Auth.logOut();
    });

    it("Admin approves all posts so all complains get declined", function(){
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        
        browser.get(ADMIN_URL +  '/admin/moderation/complaintask/');

        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        driver.findElement(protractor.By.id('action-toggle')).click();
        selectDropdownbyNum(driver.findElement(protractor.By.xpath('//select[@name="action"]')), 2);

        driver.findElement(protractor.By.id('changelist-form')).submit();

        browser.ignoreSynchronization = false;
        browser.get('/');
        Auth.logOut();

    });

    it("Login as complain user to get system messages", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/users/' + USER1.username +  '/messages/system');
        browser.waitForAngular();
    });

    it("Find message about temporary block", function(){

        var hasTempBlockMessage = protractor.promise.defer(),
            blockMsgText = "Вы временно лишились права жаловаться";

        element.all(by.repeater("msg in messages")).then(function(messages){
            var msgFound = false;

            messages.map(function(msg,i){

                msg.getText().then(function(msgTxt){
                    if(msgTxt.indexOf(blockMsgText) >=0 ){
                        msgFound = true;
                    }

                    if(i == messages.length -1){
                        hasTempBlockMessage.fulfill(msgFound);
                    }

                });
            });


        });
        
        hasTempBlockMessage.then(function(val){
            expect(val).toEqual(true);
        });

    });

    /*
    it("temporary blocked user can't complain", function(){
        browser.get(EVENT1_URL);
        browser.waitForAngular();
        
        expect(element(complainButtonLocator).isDisplayed()).toBeFalsy();
    });
     */
    it("user can complain again after block expires", function(){
        /*
         Important:
         to pass this test celery must be running.
         Here we are waiting untill celery task completes check and unlocks permission to complain.
        */
        var ptor = protractor.getInstance(),
            CELERY_TASK_INTERVAL = 120; // Seconds 

        ptor.sleep(CELERY_TASK_INTERVAL * 1000).then(function(){
            console.log("Celery wait complete");
        });

        // Permission to complain restored - buttons shown again
        browser.get(EVENT1_URL);
        browser.waitForAngular();
        
        expect(element(complainButtonLocator).isDisplayed()).toBeTruthy();

    });

    it("Find message about temporary unblock", function(){

        var hasTempBlockMessage = protractor.promise.defer(),
            blockMsgText = "Право жаловаться восстановлено";

        element.all(by.repeater("msg in messages")).then(function(messages){
            var msgFound = false;

            messages.map(function(msg,i){

                msg.getText().then(function(msgTxt){
                    if(msgTxt.indexOf(blockMsgText) >=0 ){
                        msgFound = true;
                    }

                    if(i == messages.length -1){
                        hasTempBlockMessage.fulfill(msgFound);
                    }

                });
            });


        });
        
        hasTempBlockMessage.then(function(val){
            expect(val).toEqual(true);
        });

        Auth.logOut();

    });

    it("prepare posts to complain the second time", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);

        var N_POSTS = 5;
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        for(var i = 0; i < N_POSTS; i ++){
            element( by.id('xPostBody') ).sendKeys("Post: " + (i + 1 + N_POSTS) );
            element( by.name('addXPostForm') ).submit();
        }
        Auth.logOut();

    });

    it("Make complains about created posts the second time - to get permanently blocked", function(){

        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        var N_POSTS = 5;

        for(var i = 0; i < N_POSTS; i ++){

            var postList = browser.findElement(
                by.css('.post-list')
            );
            
            var postComplain = browser.findElement(
                by.xpath('//*[@data-do-complain and not(@disabled)]')
            );

            browser.executeScript(scrollIntoView, postList);

            /*if(i > 2){
                browser.executeScript(scrollIntoView, postComplain);
            }*/
            
            postComplain.click();
            browser.waitForAngular();
        }

    });
    
    it("complain user logout", function(){
        Auth.logOut();
    });

    it("Admin approves all posts again so all complains get declined (this should permanently block user)", function(){
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        
        browser.get(ADMIN_URL +  '/admin/moderation/complaintask/');

        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        driver.findElement(protractor.By.id('action-toggle')).click();
        selectDropdownbyNum(driver.findElement(protractor.By.xpath('//select[@name="action"]')), 2);

        driver.findElement(protractor.By.id('changelist-form')).submit();

        browser.ignoreSynchronization = false;
        browser.get('/');
        Auth.logOut();

    });

    it("Find message about permanent block", function(){

        Auth.loginAsUser(USER1.username, USER1.password);

        var hasMessage = protractor.promise.defer(),
            blockMsgText = "Вы лишились права жаловаться навсегда";

        element.all(by.repeater("msg in messages")).then(function(messages){
            var msgFound = false;

            messages.map(function(msg,i){

                msg.getText().then(function(msgTxt){
                    if(msgTxt.indexOf(blockMsgText) >=0 ){
                        msgFound = true;
                    }

                    if(i == messages.length -1){
                        hasMessage.fulfill(msgFound);
                    }

                });
            });


        });
        
        hasMessage.then(function(val){
            expect(val).toEqual(true);
        });


    });

    it("permanently blocked user cant' complain", function(){

        browser.get(EVENT1_URL);
        browser.waitForAngular();

        expect(
            element(by.xpath('//button[@data-do-complain]')).getAttribute('disabled')
        ).toEqual('true');
        
        /*expect(
            element(complainButtonLocator).isDisplayed()
        ).toBeFalsy();*/

    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
