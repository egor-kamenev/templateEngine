var path = require('path');

var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 25,
        'password': 'hackme'
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 13, 40),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 11, 20),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Comments = require('../utils/comments.js'),
    Signup = require('../utils/signup.js');

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users: ", function() {
    
    it("registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });
    
    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('User:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

});

describe("Test place likes:", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE);
        Auth.logOut();
    });

    it("do like", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/places/' + PLACE.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='likePlace']")).click();
        Auth.logOut();
    });

    it("check place is liked", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/places/' + PLACE.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='likePlace']")).getAttribute('className')).toMatch(/liked/);
        expect(element(by.xpath("//button[@data-protractor-id='likePlace']")).getText()).toMatch(/1/);
        Auth.logOut();
    });

    it("should be able to select your Like repeatedly pressing", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/places/' + PLACE.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='likePlace']")).click();

        expect(element(by.xpath("//button[@data-protractor-id='likePlace']")).getAttribute('className')).not.toMatch(/liked/);
        expect(element(by.xpath("//button[@data-protractor-id='likePlace']")).getText()).toMatch(/0/);

        element(by.xpath("//button[@data-protractor-id='likePlace']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='likePlace']")).getAttribute('className')).toMatch(/liked/);
        expect(element(by.xpath("//button[@data-protractor-id='likePlace']")).getText()).toMatch(/1/);

        Auth.logOut();
    });

    it("liked count should be in list", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/places?tags=' + PLACE.name + '&show=list');
        browser.waitForAngular();

        expect(element(by.xpath("//button[contains(@data-do-like,'') and contains(@class,'like')]")).getText()).toMatch(/1/);
        Auth.logOut();
    });
});

describe("Test event likes:", function(){

    it("create open event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT);
        console.log('Event:', EVENT.name);

        Auth.logOut();
    });

    it("do like", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='likeEvent']")).click();
        Auth.logOut();
    });

    it("check event is liked", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        expect(element(by.xpath("//button[@data-protractor-id='likeEvent']")).getAttribute('className')).toMatch(/liked/);
        Auth.logOut();
    });

    it("should be able to select your Like repeatedly pressing", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='likeEvent']")).click();

        expect(element(by.xpath("//button[@data-protractor-id='likeEvent']")).getAttribute('className')).not.toMatch(/liked/);
        expect(element(by.xpath("//button[@data-protractor-id='likeEvent']")).getText()).toMatch(/0/);

        element(by.xpath("//button[@data-protractor-id='likeEvent']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='likeEvent']")).getAttribute('className')).toMatch(/liked/);
        expect(element(by.xpath("//button[@data-protractor-id='likeEvent']")).getText()).toMatch(/1/);
        Auth.logOut();
    });

    it("liked count should be in list", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/events?tags=' + EVENT.name + '&show=list');
        browser.waitForAngular();

        expect(element(by.xpath("//button[contains(@data-do-like,'') and contains(@class,'like')]")).getText()).toMatch(/1/);
        Auth.logOut();
    });

});

describe("Test post likes:", function(){

    it("create open event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT2);
        console.log('EVENT2:', EVENT2.name);
        Auth.logOut();
    });

    it("add comment to event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Comments.addComment('/events/' + EVENT2.name, null, 'test comment');
        Auth.logOut();
    })

    it("like post by owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT2.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='likePost']")).click();
        Auth.logOut();
    });

    it("chech like by user", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT2.name);
        browser.waitForAngular();

        expect(element(by.xpath("//button[@data-protractor-id='likePost']")).getText()).toMatch(/1/);
        Auth.logOut();
    });

});

describe("Test user likes:", function(){

    it("like user", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='userMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='likeUser']")).click();
        Auth.logOut();
    });

    it("check like", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='userMegaMenu']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='likeUser']")).getAttribute('className')).toMatch(/liked/);
        expect(element(by.xpath("//button[@data-protractor-id='likeUser']")).getText()).toMatch(/1/);
        Auth.logOut();
    });

    it("liked count should be in list", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get('/users?tags=' + USER.username + '&show=list');
        browser.waitForAngular();

        expect(element(by.xpath("//button[contains(@data-do-like,'') and contains(@class,'like')]")).getText()).toMatch(/1/);
        Auth.logOut();
    });

});
