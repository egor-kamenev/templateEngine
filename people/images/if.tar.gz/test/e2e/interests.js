'use strict';
var LOGIN_URL = '/auth/login',
    TEST_TAG = ["home", "rest"],
    Settings = require('../utils/settings.js'),
    interests = ["охота", "рыбалка", "работа"],
    Signup = require('../utils/signup.js'),
    Auth = require('../utils/auth.js'),
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 25,
        'password': 'hackme'
    };


describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Registrate: ", function() {
    
    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('User:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

});

describe("User interests: ", function() {

    it("interests link must be present", function(){
        Auth.loginAsUser(USER.username, USER.password);

        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();
                
        var interestLink = element(by.xpath("//a[@data-protractor-id='userInterests']"));
        expect(interestLink.isDisplayed()).toBe(true);
        expect(interestLink.getText()).toBe('Интересы');
        
        Auth.logOut();
    });
   
    it("fill interests", function(){
        Auth.loginAsUser(USER.username, USER.password);
        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();

        element(by.xpath("//a[@data-protractor-id='userInterests']")).click();

        var interestsInput = element(by.xpath("//div[@id='s2id_newInterests']"));
        
        expect(interestsInput.isDisplayed()).toBe(true);
        
        interestsInput.click();

        element(by.xpath("//div[@id='s2id_newInterests']//input")).sendKeys(interests[0]);
        element(by.xpath("//div[@id='select2-drop']")).click();

        element(by.xpath("//div[@id='s2id_newInterests']//input")).sendKeys(interests[1]);
        element(by.xpath("//div[@id='select2-drop']")).click();

        element(by.xpath("//div[@id='s2id_newInterests']//input")).sendKeys(interests[2]);
        element(by.xpath("//div[@id='select2-drop']")).click();


        element(by.xpath("//input[@type='submit']")).submit();
        browser.waitForAngular();
        Auth.logOut();
    });

    it("check user interests", function(){
        Auth.loginAsUser(USER.username, USER.password);
        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();
        
        element(by.xpath("//a[@data-protractor-id='userInterests']")).click();

        browser.waitForAngular();

        var elems = element.all(by.repeater('i in interests'));

        expect(elems.count()).toBe(3);
        //expect(elems.get(0).getText()).toBe(interests[0]);
        Auth.logOut();
    });
    
    it("try delete interest", function(){
        Auth.loginAsUser(USER.username, USER.password);
        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();

        element(by.xpath("//a[@data-protractor-id='userInterests']")).click();

        element(by.repeater('i in interests').row(0)).element(by.css('button.del-interest')).click();

        var elems = element.all(by.repeater('i in interests'));
        expect(elems.count()).toBe(2);
        Auth.logOut();
    });
   
});
