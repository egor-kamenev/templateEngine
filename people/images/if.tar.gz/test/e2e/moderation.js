'use strict';

var OWNER = {
        'username': 'ownerModeration',
        'first_name': 'Owner',
        'last_name': 'Tester',
        'email': 'ownermoderation@mail.com',
        'phone': '+79111224001',
        'age': 30,
        'password': 'hackme'
    },
    USER1 = {
        'username': 'user1Moderation',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1moderation@mail.com',
        'phone': '+79111224002',
        'age': 24,
        'password': 'hackme'
    },
    TRUSTED_USER = {
        'username': 'user1Moderation',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2moderation@mail.com',
        'phone': '+79111224003',
        'age': 24,
        'password': 'hackme'
    },
    EVENT1 = {
        'name': 'eventmoderation1',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'eventmoderation2',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '0',
        visibility_show_for_all: false

    },
    EVENT3 = {
        'name': 'eventmoderarion3',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE1 = {
        'name': 'placemoderation1',
        'visibility': '4',
        lat: '55.75408337131602',
        lng: '37.6205188035965'
    },
    PLACE2 = {
        'name': 'placemoderation2',
        'visibility': '0',
        visibility_show_for_all: false,
        lat: '55.75408337131602',
        lng: '37.6205188035965'
    },
    PLACE3 = {
        'name': 'placemoderation3',
        'visibility': '4',
        lat: '55.75408337131602',
        lng: '37.6205188035965'
    },
    PLACE4 = {
        'name': 'placemoderation4',
        'visibility': '4',
        lat: '55.75408337131602',
        lng: '37.6205188035965'
    },
    BAN_MESSAGE = 'ban';

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

var selectDropdownbyNum = function (element, optionNum) {
    if (optionNum) {
        var options = element.findElements(by.tagName('option')).then(
            function(options) {
                options[optionNum].click();
            }
        );
    }
};

var checkModeration = function (url, status) {
    browser.get(url);
    browser.waitForAngular();
    expect(element(by.xpath('//*[@data-protractor-id="isBeingModerated"]')).isPresent()).toBe(status);
};

var checkVisibility = function (url, expect_url) {
    browser.get(url);
    browser.waitForAngular();
    if(expect_url.indexOf("http://") == 0){
        expect(browser.getCurrentUrl()).toBe(expect_url);
    }
    else{
        expect(browser.getCurrentUrl()).toBe(browser.baseUrl + expect_url);
    }
};

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register users: ", function(){
    it("Register OWNER", function(){
        Signup.registerUserUntilDone(OWNER).then(
            function (user) {
                console.log("Owner username:", user.username);
                OWNER.username = user.username;
                OWNER.email = user.email;
                Auth.loginAsUser(OWNER.username, OWNER.password);
            }
        );
    });
    it("Verify OWNER", function() {
        Signup.verifyEmail(OWNER);
        Auth.logOut();
    });
    it("Register USER1", function(){
        Signup.registerUserUntilDone(USER1).then(
            function (user) {
                USER1.username = user.username;
                USER1.email = user.email;
                //Auth.loginAsUser(USER1.username, USER1.password);
            }
        );
    });
    it("Verify USER1", function() {
        Signup.verifyEmail(USER1);
        Auth.logOut();
    });
    it("Register TRUSTED_USER", function(){
        Signup.registerUserUntilDone(TRUSTED_USER).then(
            function (user) {
                TRUSTED_USER.username = user.username;
                TRUSTED_USER.email = user.email;

                //Auth.loginAsUser(TRUSTED_USER.username, TRUSTED_USER.password);
                //Signup.addPhone(TRUSTED_USER);
            }
        );
    });
    it("Verify TRUSTED_USER", function() {
        Signup.verifyEmail(TRUSTED_USER);
        //Signup.verifyPhone(TRUSTED_USER);
        Auth.logOut();
    });
    it("Set TRUSTED_USER as trusted", function() {
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();

        browser.get(ADMIN_URL + '/admin/users/user/?q=' + TRUSTED_USER.username + '&all=');

        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        driver.findElement(protractor.By.xpath('//a[text()="' + TRUSTED_USER.username + '"]')).click();

        var trustedGroupOption = driver.findElement(protractor.By.xpath('//option[text()="TrustedUsers"]')),
            addGroupsArrow = driver.findElement(protractor.By.id('id_groups_add_link')),
            userForm = driver.findElement(protractor.By.id('user_form'));

        expect(trustedGroupOption.isDisplayed()).toBeTruthy();
        trustedGroupOption.click();
        addGroupsArrow.click();
        userForm.submit();

        browser.ignoreSynchronization = false;

        browser.get('/');
        Auth.logOut();
    });
});

describe("Add content: ", function(){

    it("Set moderation settings", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'false');
        Settings.set('MODERATION_INSTANT_CHECK', 'true');
    });


    it("Create events", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNewUnique(EVENT1).then(function(e){
            console.log("Event1 url: ", e.url);
            EVENT1.url = e.url;
            EVENT1.name = e.name;
        });
        Events.createNewUnique(EVENT2).then(function(e){
            console.log("Event2 url: ", e.url);
            EVENT2.url = e.url;
            EVENT2.name = e.name;
        });
    });

    it("Create places", function(){

        Places.createNew(PLACE1).then(function(place){
            console.log("Place1 url: ", place.url);
            PLACE1.url = place.url;
        });

        Places.createNew(PLACE2).then(function(place){
            console.log("Place2 url: ", place.url);
            PLACE2.url = place.url;
        });


    });

    it("Add posts", function(){
        
        browser.get(EVENT2.url);
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys('normal comment');
        element(by.name('addXPostForm')).submit();
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys('fuck you');
        element(by.name('addXPostForm')).submit();
        browser.waitForAngular();

    });

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

    it("Check moderation statuses", function(){
        checkModeration(EVENT1.url, true);
        checkModeration(EVENT2.url, false);
        checkModeration(PLACE1.url, true);
        checkModeration(PLACE2.url, false);
    });

    it("Should be only one xPost - one with 'fuck' should not pass moderation", function(){
        browser.get(EVENT2.url);
        browser.waitForAngular();
        
        browser.findElements(by.xpath('//*[@data-protractor-id="xPostEntry"]')).then(
            function (elems) {
                expect(elems.length).toBe(1);
            }
        );
    });

    it("Owner logout", function(){
        Auth.logOut();
    });

});

describe("Do moderation: ", function(){

    it("Check visibility", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        // Moderated
        // checkVisibility(EVENT1.url, '403');
        // Private
        checkVisibility(EVENT2.url, '403');
        //checkVisibility(PLACE1.url, '403');
        checkVisibility(PLACE2.url, '403');
        Auth.logOut();
    });

    it("Do manual moderate", function(){
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();

        browser.get(ADMIN_URL + '/admin/moderation/pendingmanualstafftask/');
        /*
        browser.get('/admin/moderation/pendingmanualstafftask/').then(function(){
            console.log("Looking for ", EVENT1.name, " on admin page");
        });
         */
        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        driver.findElement(protractor.By.xpath('//td[text()="' + EVENT1.name + '"]/../td/button[@name="approve_content"]')).click();
        //driver.findElement(protractor.By.xpath('//td[text()="' + PLACE1.name + '"]/../td/button[@name="approve_content"]')).click();
        //driver.findElement(protractor.By.xpath('//td[contains(text(), "' + PLACE1.name + '")]/../td/button[@name="approve_content"]')).click();

        driver.findElement(protractor.By.xpath('//td[contains(text(), "' + PLACE1.name + '")]/../td/button[@name="ban_content"]')).click();
        driver.findElement(protractor.By.xpath('//textarea')).sendKeys(BAN_MESSAGE);
        driver.findElement(protractor.By.xpath('//button[@onclick="doBan();"]')).click();

        browser.ignoreSynchronization = false;
        browser.get('/');
        Auth.logOut();
    });

    it("Objects approved and must become visible", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        checkVisibility(EVENT1.url, EVENT1.url);
        checkVisibility(PLACE1.url, '403');
        Auth.logOut();
    });

    it("Check ban messages", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + OWNER.username + '/messages/notice');
        browser.waitForAngular();
        
        var elems = element.all(by.css('.timeline__entry'));
        expect(elems.count()).toBeGreaterThan(0);

        //expect(element(by.xpath('//p[contains(text(), "' + BAN_MESSAGE + '")]')).isDisplayed()).toBe(true);
    });
});

describe("Add trusted content: ", function(){
    it("Create content", function(){
        Auth.loginAsUser(TRUSTED_USER.username, TRUSTED_USER.password);
        Events.createNewUnique(EVENT3).then(function(e){
            console.log("Event3 url: ", e.url);
            EVENT3.url = e.url;
        });
        Places.createNewUnique(PLACE3).then(function(place){
            console.log("Place3 url: ", place.url);
            PLACE3.url = place.url;
        });
        //browser.sleep(5000);
        Auth.logOut();
    });
    it("Check visibility", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        checkVisibility(EVENT3.url, EVENT3.url);
        checkVisibility(PLACE3.url, PLACE3.url);
        Auth.logOut();
    });
});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
