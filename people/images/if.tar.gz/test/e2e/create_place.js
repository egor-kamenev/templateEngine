'use strict';

var REG_USER = {
        'username': 'TestRegUser',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'test@mail.com',
        'age': 30,
        'password': 'hackme'
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    };

var Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js'),
    Auth = require('../utils/auth.js');

browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

});

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});
   
describe("Create place ", function(){

    it("register test user", function(){
        Signup.registerUserUntilDone(REG_USER).then(function(userData){
            REG_USER.username = userData.username;
            REG_USER.email = userData.email;
            console.log('USER:', REG_USER.username);
        });
    });
    
    it("login as registered user", function(){
        Auth.loginAsUser(REG_USER.username, REG_USER.password);
    });

    it("confirm user email", function(){
        Signup.verifyEmail(REG_USER);
    });
    
    it("create place", function(){
        Places.createNewInMoscow(PLACE);
    });
    
});
