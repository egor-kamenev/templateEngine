'use strict';

var USER1 = {
        'username': 'user11',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1profile@mail.com',
        'phone': '+79111225002',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user12',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2profile@mail.com',
        'phone': '+79111225003',
        'age': 25,
        'password': 'hackme'
    },
    Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    Friendship = require('../utils/friendship.js'),
    Profile = require('../utils/profile.js'),
    initialFriendshipTags = ['друзья', 'коллеги'],
    additionalTag = 'родственники',
    defaultFriendshipTag = 'друзья';

function findReactElement(selector){
    return protractor.promise.filter(element.all(selector), function(e) {
        return e.isDisplayed();
    }).then(function(visibleElements) {
        expect(visibleElements.length).toBe(1);
        return visibleElements[0];
    });
}

describe("Register users:", function(){

    it("Register USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;
            console.log('User1:', USER1.username);
            Signup.verifyEmail(USER1);
        });
    });
    
    it("Register USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('User2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

});


describe("Friendship establishment: ", function(){
    
    it("friendship should open", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/users/' + USER2.username);
        browser.waitForAngular();
        element(by.xpath('//button[@data-protractor-id="sendFriendshipRequest"]')).click();
        // Wait for form to display
        expect(element(by.name('newFriendForm')).isDisplayed()).toBe(true);
    });

    it("friendship tags selectable, custom tags are not", function(){
        // Expand select2 
        element(by.id('s2id_friendship_tags')).click();
        // Select friendship tags
        element(by.xpath('//ul[@class="select2-results"]//div[text()="' + initialFriendshipTags[0] + '"]')).click();
        element(by.xpath('//ul[@class="select2-results"]//div[text()="' + initialFriendshipTags[1] + '"]')).click();

        element(by.xpath('//div[@id="s2id_friendship_tags"]//input')).sendKeys("customtag");

        // Click somewhere on the page to reset select2 focus
        element(by.tagName('body')).click();


        element(by.model('newFriend.message')).sendKeys("Lets be friends");

        // Friendhip tags selector can't contain custom tags
        expect(element(by.xpath('//div[text()="customtag"]')).isDisplayed()).toBeFalsy();

        element(by.name('newFriendForm')).submit();
        browser.waitForAngular();
    });

    it("all other attempts to send friendship request must fail", function(){
        browser.get('/users/' + USER2.username);
        browser.waitForAngular();
        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();
        element(by.xpath('//button[@data-protractor-id="sendFriendshipRequest"]')).click();
        expect(element(by.name('newFriendForm')).isDisplayed()).toBeFalsy();
    });

    it("user2 recieved friendship request", function(){
        Auth.logOut();

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/' + USER2.username + '/messages/friendship');

        browser.waitForAngular();

        // Sender login must be present in pendingRequests
        var reqList = element(by.id('user-content-wrap'));
        expect(reqList.getText()).toContain(USER1.last_name);

        // 

        expect(
            browser.isElementPresent(
                by.xpath('//li[@class="select2-search-choice"]//div[text()="' + initialFriendshipTags[0] + '"]')
            )
        ).toBeTruthy();

        expect(
            browser.isElementPresent(
                by.xpath('//li[@class="select2-search-choice"]//div[text()="' + initialFriendshipTags[1] + '"]')
            )
        ).toBeTruthy();


    });

    it("user2 can change friendship tags and send request back", function(){

        
        findReactElement(by.xpath('//*[@data-protractor-id="friendship-request-to-me-' + USER1.username + '"]//input[@class="select2-input"]'))
            .then(function(elm){
                elm.sendKeys("customtag");
                // Click somewhere on the page to reset select2 focus
                element(by.tagName('body')).click();
                
                // Friendhip tags selector can't contain custom tags
                expect(element(by.xpath('//div[text()="customtag"]')).isDisplayed()).toBeFalsy();


                // Remove one of the tags
                findReactElement(by.xpath('//li[@class="select2-search-choice"]//div[text()="' + initialFriendshipTags[1] + '"]//following-sibling::a')).then(function(tag){
                    tag.click();
                    
                    var tagLink = element(
                        by.xpath(
                            '//li[@class="select2-search-choice"]//div[text()="' + initialFriendshipTags[1] + '"]'
                        )
                    );
                    
                    tagLink.isPresent().then(function(present){
                        if(present){
                            expect(tagLink.isDisplayed()).toBeFalsy();
                        }
                    });
                    
                    findReactElement(by.xpath("(//*[@data-protractor-id='acceptFriendshipRequest'])")).then(function(btn){
                        
                        
                        btn.click();
                        
                        browser.get('/users/' + USER2.username + '/messages/friendship');
                        browser.waitForAngular();
                        
                        // expect user1 to be in sent requests
                        var reqList = element(by.id('user-content-wrap'));
                        expect(reqList.getText()).toContain(USER1.last_name);
                        Auth.logOut();
                    });
                    
                });
            });
    });
    

    it("the first user should get his request back with changed tags", function(){
        
        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get('/users/' + USER1.username + '/messages/friendship');
        browser.waitForAngular();

        // Sender login must be present in pendingRequests
        var reqList = element(by.id('user-content-wrap'));
        expect(reqList.getText()).toContain(USER2.last_name);

        expect(
            browser.isElementPresent(
                by.xpath('//li[@class="select2-search-choice"]//div[text()="' + initialFriendshipTags[0] + '"]')
            )
        ).toBeTruthy();

        expect(
            browser.isElementPresent(
                by.xpath('//li[@class="select2-search-choice"]//div[text()="' + initialFriendshipTags[1] + '"]')
            )
        ).toBeFalsy();

        findReactElement(by.xpath("(//*[@data-protractor-id='acceptFriendshipRequest'])")).then(function(btn){
            btn.click();
        });
    });

    it("users are friends", function(){

        Auth.loginAsUser(USER2.username, USER2.password);

        browser.get('/users/' + USER2.username + '/friends');
        browser.waitForAngular();

        expect(
            element(by.xpath('//*[@data-protractor-id="userBlock:' + USER1.username + '"]')).isPresent()
        ).toBeTruthy();
        

    });

    it("break friendship", function(){

        element(by.xpath("(//*[@data-protractor-id='breakFriendship:" + USER1.username + "'])")).click();
        element(by.xpath("(//*[@data-protractor-id='confirmYes'])")).click();
        expect(element(by.repeater('f in friends')).isPresent()).toBeFalsy();

    });

    it("sent request may be cancelled", function(){

        browser.get('/users/' + USER1.username);
        browser.waitForAngular();
        element(by.xpath('//button[@data-protractor-id="sendFriendshipRequest"]')).click();
        
        // Wait for form to display
        expect(element(by.name('newFriendForm')).isDisplayed()).toBe(true);
        // Expand select2 
        element(by.id('s2id_friendship_tags')).click();
        // Select friendship tags
        element(by.xpath('//ul[@class="select2-results"]//div[text()="' + initialFriendshipTags[0] + '"]')).click();
        element(by.xpath('//ul[@class="select2-results"]//div[text()="' + initialFriendshipTags[1] + '"]')).click();
        
        // Click somewhere on the page to reset select2 focus
        element(by.tagName('body')).click();
        
        element(by.model('newFriend.message')).sendKeys("Lets be friends (this will be cancelled)");

        element(by.name('newFriendForm')).submit();

        browser.get('/users/' + USER2.username + '/messages/friendship');
        browser.waitForAngular();

        var reqList = element(by.id('user-content-wrap'));
        expect(reqList.getText()).toContain(USER1.last_name);

        findReactElement(by.xpath('//*[@data-protractor-id="cancelFriendshipRequest"]//a'))
            .then(function(e){

                e.click();
                browser.waitForAngular();
                expect( 
                    element(by.xpath('//*[@data-protractor-id="cancelFriendshipRequest"]//a')).isPresent() 
                ).toBeFalsy();
            });

    });

    it("recieved request may be rejected", function(){
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="sendFriendshipRequest"]')).click();
        
        // Wait for form to display
        expect(element(by.name('newFriendForm')).isDisplayed()).toBe(true);
        // Expand select2 
        element(by.id('s2id_friendship_tags')).click();
        // Select friendship tags
        element(by.xpath('//ul[@class="select2-results"]//div[text()="' + initialFriendshipTags[0] + '"]')).click();
        element(by.xpath('//ul[@class="select2-results"]//div[text()="' + initialFriendshipTags[1] + '"]')).click();
        
        // Click somewhere on the page to reset select2 focus
        element(by.tagName('body')).click();
        
        element(by.model('newFriend.message')).sendKeys("Эта заявка должна быть отклонена получателем");

        element(by.name('newFriendForm')).submit();
        

        Auth.logOut();

        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/users/' + USER1.username + '/messages/friendship');

        browser.waitForAngular();

        findReactElement(by.xpath('//*[@data-protractor-id="rejectFriendshipRequest"]//a'))
            .then(function(rejectBtn){

                rejectBtn.click();
                browser.waitForAngular();
                
                var btn = element(
                    by.xpath('//*[@data-protractor-id="rejectFriendshipRequest"]//a')
                );

                btn.isPresent().then(function(present){
                    if(present){
                        expect(btn.isDisplayed()).toBeFalsy();
                    }
                });
            });
    });
    
    it("friendship request without tags means default friendship tag", function(){

        browser.get('/users/' + USER2.username);
        browser.waitForAngular();
        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();
        element(by.xpath('//button[@data-protractor-id="sendFriendshipRequest"]')).click();

        // Wait for form to display
        expect(element(by.name('newFriendForm')).isDisplayed()).toBe(true);

        element(by.model('newFriend.message')).sendKeys("Заявка на дружбу без тегов, тег дружбы должен выставиться автоматом");

        element(by.name('newFriendForm')).submit();

        browser.get('/users/' + USER1.username + '/messages/friendship');
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='friendship-request-from-me-"+ USER2.username+"']/..")
            ).getText()
        ).toContain(defaultFriendshipTag);

        findReactElement(by.xpath('//*[@data-protractor-id="cancelFriendshipRequest"]//a'))
            .then(function(e){
                
                e.click();
                browser.waitForAngular();
                expect( 
                    element(by.xpath('//*[@data-protractor-id="cancelFriendshipRequest"]//a')).isPresent() 
                ).toBeFalsy();
            });
        
    });

});

describe("Friendship relations: ", function(){

    var saveTagsButtons = element(by.xpath("(//*[@data-protractor-id='saveFriendshipTags'])")),
        tagsSelect2Input = element(by.xpath('//div[@id="s2id_friendship_tags"]//input'));
    
    it("make friendship", function(){
        Friendship.beFriends(USER1, USER2);
    });

    it("changing custom friendship tags doesn't affect friendship state", function(){

        Auth.loginAsUser(USER2.username, USER2.password);        
        browser.get('/users/' + USER2.username + '/friends');
    
        findReactElement(
            by.xpath("(//*[@data-protractor-id='changeFriendshipTags:" + USER1.username + "'])")
        ).then(function(changeTagsButtons){

            changeTagsButtons.click();

            findReactElement(
                by.xpath("//*[@id='s2id_friendship\\-tags\\-" + USER1.username + "']//input")
            ).then(function(tagsSelect2Input){

                tagsSelect2Input.sendKeys("customfriendshiptag");
                tagsSelect2Input.sendKeys(protractor.Key.ENTER);

                element(by.tagName('body')).click();

                findReactElement(
                    by.xpath("//*[@data-protractor-id='saveFriendshipTags:" + USER1.username + "']")
                ).then(function(saveTagsButtons){
                    saveTagsButtons.click();
                });
                

                findReactElement(
                    by.xpath("(//*[@data-protractor-id='changeFriendshipTags:" + USER1.username + "'])")
                ).then(function(changeTagsButtons){
                    expect(
                        changeTagsButtons.isDisplayed()
                    ).toBeTruthy();
                });


            });
        });
        Auth.logOut();

    });

    it("custom friendship tags are hidden for a friend on the other side or relation", function(){

        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get('/users/' + USER2.username + "/friends");
        browser.waitForAngular();

        var userFriendsContent = element(by.id('user-content-wrap'));
        expect(userFriendsContent.getText()).not.toContain('customfriendshiptag');
        Auth.logOut();

    });

    it("changing system friendship tags changes friendship state to unconfirmed and sends request back to a friend", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/' + USER2.username + "/friends");
        browser.waitForAngular();

        findReactElement(
            by.xpath("(//*[@data-protractor-id='changeFriendshipTags:" + USER1.username + "'])")
        ).then(function(changeTagsButtons){

            changeTagsButtons.click();

            findReactElement(
                by.xpath("//*[@id='s2id_friendship\\-tags\\-" + USER1.username + "']//input")
            ).then(function(tagsSelect2Input){

                tagsSelect2Input.click();
                
                element(by.xpath('//ul[@class="select2-results"]//div[text()="' + additionalTag + '"]')).click();
                element(by.tagName('body')).click();


                findReactElement(
                    by.xpath("//*[@data-protractor-id='saveFriendshipTags:" + USER1.username + "']")
                ).then(function(saveTagsButtons){
                    saveTagsButtons.click();
                });
                

                expect(
                    element(
                        by.xpath("(//*[@data-protractor-id='changeFriendshipTags:" + USER1.username + "'])")
                    ).isPresent()
                ).toBeFalsy();

            });
        });

    });
        
});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
