'use strict';

var USER1 = {
        'username': 'user1',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1profile@mail.com',
        'phone': '+79111225002',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user2',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2profile@mail.com',
        'phone': '+79111225003',
        'age': 25,
        'password': 'hackme'
    },
    Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    Friendship = require('../utils/friendship.js'),
    Profile = require('../utils/profile.js');


describe("Register users:", function(){

    it("Register USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;
            console.log('User1:', USER1.username);
            Signup.verifyEmail(USER1);
        });
    });
    
    it("Register USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('User2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

});

describe("Profile sections protection: ", function(){

    it("Set private profile", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        Profile.setDiscoverable(USER1.username, false);
        Auth.logOut();
    });

    it("should not give any access to profile sections to other users", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        var sections = Profile.getAllProfileSections(USER1);

        for(var i=0; i < sections.length; i++){
            var sectionURL = sections[i];
            if(sectionURL != '/users/' + USER1.username + '/'){
                browser.get(sectionURL);
                browser.waitForAngular();

                browser.getCurrentUrl().then(function(url){
                    console.log("Testing profile url: ", url);
                    expect(url).toContain('/403');
                });

            }
        }

    });

});

describe("Profile wall elements: ", function(){

    it("avatar must be present", function(){

        var userURL = '/users/' + USER1.username;
        browser.get(userURL);
        browser.waitForAngular();
        
        expect(
            browser.isElementPresent(
                by.xpath('//div[contains(concat(" ", normalize-space(@class), " "), " avatar ")]')
            )
        ).toBeTruthy();
    });

    it("nickname must be present", function(){
        expect(
            browser.isElementPresent(
                by.xpath("(//div[@data-protractor-id='profileUsername'])")
            )
        ).toBeTruthy();
        
    });

    it("nickname on the wall must match profile owner", function(){
        expect(
            element(by.xpath("(//div[@data-protractor-id='profileUsername'])")).getText()
        ).toContain(USER1.username); //
    });

    it("online status must be hidden", function(){
        expect(
            browser.isElementPresent(
                by.xpath('//div[contains(concat(" ", normalize-space(@class), " "), " state ")]')
            )
        ).toBeFalsy();
    });

    it("text status must be hidden", function(){
        expect(
            browser.isElementPresent(
                by.xpath('//div[contains(concat(" ", normalize-space(@class), " "), " status ")]')
            )
        ).toBeFalsy();
    });

    it("user tools must be hidden", function(){

        expect(
            browser.isElementPresent(
                by.xpath('//div[contains(concat(" ", normalize-space(@class), " "), " user-tools ")]')
            )
        ).toBeFalsy();

    });

    it("profile menu must be hidden", function(){

        expect(
            browser.isElementPresent(
                by.xpath('//div[contains(concat(" ", normalize-space(@class), " "), " profile-public-menu ")]')
            )
        ).toBeFalsy();

    });

});

describe("Search user with not discoverable profile: ", function(){

    it("user can't be found", function(){
        
        var searchURL = '/users?show=list&tags=' + USER1.username;
        browser.get(searchURL);
        browser.waitForAngular();
        
        expect(element(by.tagName('body')).getText()).not.toContain(USER1.username+' ');
    });

});

describe("Public profile: ", function(){

    it("all sections shoul be accessible", function(){

        Auth.loginAsUser(USER1.username, USER1.password);

        Profile.setDiscoverable(USER1.username, true);

        Auth.logOut();

        Auth.loginAsUser(USER2.username, USER2.password);
        var sections = Profile.getUserPublicProfileSections(USER1);

        for(var i=0; i < sections.length; i++){
            var sectionURL = sections[i];
            browser.get(sectionURL);
            browser.waitForAngular();
            expect(browser.getCurrentUrl()).not.toContain('/403');
        }
        Auth.logOut();

    });

});


describe("All profile sections should be viewable for friends: ", function(){

    it("Make user1 profile private", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        Profile.setDiscoverable(USER1.username, false);
        Auth.logOut();
    });

    it("create friendship", function(){
        Friendship.beFriends(USER1, USER2);
    });

    it("check user2 access to user1 profile - everything should be visible", function(){
        Auth.loginAsUser(USER2.username, USER1.password);
        var sections = Profile.getUserPublicProfileSections(USER1);

        for(var i=0; i < sections.length; i++){
            var sectionURL = sections[i];
            browser.get(sectionURL);
            browser.waitForAngular();
            expect(browser.getCurrentUrl()).not.toContain('/403');
        }
        Auth.logOut();

    });

});
