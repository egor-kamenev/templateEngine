var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 25,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 37,
        'password': 'hackme'
    },
    USER3 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 45,
        'password': 'hackme'
    },
    USER4 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 37,
        'password': 'hackme'
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE2 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE3 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE4 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE5 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': '23.2.2015 12:00',
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': '',
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '3',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': '23.2.2015 12:50',
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '3',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT4 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': '23.2.2015 11:35',
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '3',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT5 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': '',
        'ts_finish': '',
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '3',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT6 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': '23.2.2015 17:35',
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '3',
        'by_invitation': false,
        'visibility': '4'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Comments = require('../utils/comments.js'),
    Friendship = require('../utils/friendship.js'),
    Participation = require('../utils/participation.js'),
    Visibility = require('../utils/visibility.js'),
    Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js'),
    moment = require('moment'),
    EVENT_MIN_START_OFFSET = 2;

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register users: ", function() {
    
    it("registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });
    
    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('User:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

    it("registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

    it("registrate USER3", function() {
        Signup.registerUserUntilDone(USER3).then(function(userData){
            USER3.username = userData.username;
            USER3.email = userData.email;
            console.log('USER3:', USER3.username);
            Signup.verifyEmail(USER3);
        });
    });

    it("registrate USER4", function() {
        Signup.registerUserUntilDone(USER4).then(function(userData){
            USER4.username = userData.username;
            USER4.email = userData.email;
            console.log('USER4:', USER4.username);
            Signup.verifyEmail(USER4);
        });
    });

});

describe("Feed should be formed to:", function(){
    
    it("places", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE);

        element(by.xpath("//a[@data-protractor-id='placeStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length > 0).toBe(true);
            Auth.logOut();
        });
    });
    
    it("events", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT).then(function(event){
            EVENT.url = event.url;
            EVENT.name = event.name;
            console.log("Event url: ", EVENT.url);
            console.log('EVENT name:', EVENT.name);
        });

        element(by.xpath("//a[@data-protractor-id='eventStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length > 0).toBe(true);
            Auth.logOut();
        });
        
    });

    it("users", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='userStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length > 0).toBe(true);
            Auth.logOut();
        });
    });

});

describe("Measures should include events(create, started, finished):", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT2.ts_start = moment().add(EVENT_MIN_START_OFFSET, 'm').format("DD.MM.YYYY HH:mm");
        EVENT2.ts_finish = moment().add(EVENT_MIN_START_OFFSET+1, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT2).then(function(event){
            EVENT2.url = event.url;
            EVENT2.name = event.name;
            console.log("Event2 url: ", EVENT2.url);
            console.log('EVENT2 name:', EVENT2.name);
        });
    });

    it("wait for event to complete", function(){
        var timeout = (EVENT_MIN_START_OFFSET+1) * 60000;
        console.log("Waiting ", timeout/1000.0, " seconds for event to complete....");
        browser.sleep(timeout);
    });

    it("check count messages", function(){
        browser.get(EVENT2.url);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length == 3).toBe(true);
        });
        
    });

});

describe("Measures should include events(change date, cancel event):", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNew(EVENT3).then(function(event){
            EVENT3.url = event.url;
            EVENT3.name = event.name;
            console.log("Event3 url: ", EVENT3.url);
            console.log('EVENT3 name:', EVENT3.name);
        });
    });

    it("change date", function(){
        browser.get(EVENT3.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();
        selectDropdownbyValue(element(by.id('date1_minute')), '5');
        element(by.xpath("//form[@name='eventForm']")).submit();
    });

    it("cancel event", function(){
        browser.get(EVENT3.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='disableEvent']")).click();
        element(by.xpath("//button[@data-ng-click='yes()']")).click();    
    });

    it("check count messages", function(){
        browser.get(EVENT3.url);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length == 3).toBe(true);
        });

    });

});

describe("Measures should include events(add comments, check in /check out):", function(){


    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT4).then(function(event){
            EVENT4.url = event.url;
            EVENT4.name = event.name;
            console.log("Event4 url: ", EVENT4.url);
            console.log('EVENT4:', EVENT4.name);
        });
        Auth.logOut();
    });

    it("check in to event4", function(){
        Participation.eventCheckIn(USER, EVENT4);
    });

    it("check out to event4", function(){
        Participation.eventCheckOut(USER, EVENT4);
    });

    it("user add comment to event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        
        browser.get(EVENT4.url);
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys('Comment to event4! Hello world!');
        element(by.name('addXPostForm')).submit();
        Auth.logOut();
    });

    it("check count messages", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get(EVENT4.url);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length == 3).toBe(true);
            Auth.logOut();
        });
    });

});

describe("Places should include events(edit, add comment)", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE2).then(function(place){
            console.log("Place2 url: ", place.url);
            PLACE2.url = place.url;
        });

        //Auth.logOut();
    });
    
    it('edit place', function(){
        //Auth.loginAsUser(OWNER.username, OWNER.password);
        
        browser.get(PLACE2.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        element(by.xpath("//textarea[@id='place_description']")).sendKeys('This is best place!');
        element(by.xpath("//form[@name='placeForm']")).submit();
        Auth.logOut();
    });

    it("add comment", function(){

        Auth.loginAsUser(USER.username, USER.password);

        browser.get(PLACE2.url);
        browser.waitForAngular();
    
        element(by.id('xPostBody')).sendKeys('Comment to place2! Hello world!');
        element(by.name('addXPostForm')).submit();
        
        //Comments.addComment('/places/' + PLACE2.name, null, 'Comment to place2! Hello world!');
        Auth.logOut();
    });
    /*
    it("wait", function(){
        browser.driver.sleep(5000);
    });
     */
    it("check count messages", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get(PLACE2.url);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='placeStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length == 3).toBe(true);
            Auth.logOut();
        });
    });
    
});

describe("Places should include events(change place, lose actuality)", function(){


    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE3).then(function(place){
            console.log("Place3 url: ", place.url);
            PLACE3.url = place.url;
        });

        //Auth.logOut();
    });
    
    it('change latitude and longitude', function(){
        //Auth.loginAsUser(OWNER.username, OWNER.password);
        
        browser.get(PLACE3.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        var latitudeBorders = Array(55.61558902526749, 55.89225616635061),
            longitudeBorders = Array(37.437286376953125, 37.79296875);

        function randomInRange(min, max) {
            return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
        }
         
        PLACE3.lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
        PLACE3.lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);
        
        var placeForm = element(by.name('placeForm')),
            map = element(by.xpath('//div[@data-protractor-id="placeFormMap"]'));

        browser.actions().doubleClick(map).perform();

        element(by.model('place_lat')).clear();
        element(by.model('place_lng')).clear();

        element(by.model('place_lat')).sendKeys(PLACE3.lat);
        element(by.model('place_lng')).sendKeys(PLACE3.lng);

        placeForm.submit();
        browser.waitForAngular();
        //
        //Auth.logOut();
    });

    it('loose actuality', function(){
        //Auth.loginAsUser(OWNER.username, OWNER.password);
        
        browser.get(PLACE3.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        element(by.model("placeform.description")).clear();  
        element(by.model("placeform.description")).sendKeys("New place3 description");    

        element(by.name('placeForm')).submit();
        browser.waitForAngular();
        //Auth.logOut();
    });
    it("check count messages", function(){
        browser.get(PLACE3.url);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='placeStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length == 3).toBe(true);
            Auth.logOut();
        });
    });
    
});

describe("Places should include event(new event in this place)", function(){ 


    it("create event", function(){
        Auth.loginAsUser(USER4.username, USER4.password);

        EVENT5.ts_start = moment().add(EVENT_MIN_START_OFFSET, 'm').format("DD.MM.YYYY HH:mm");
        EVENT5.ts_finish = moment().add(EVENT_MIN_START_OFFSET+1, 'm').format("DD.MM.YYYY HH:mm");

        Events.createNew(EVENT5).then(function(event){
            EVENT5.url = event.url;
            EVENT5.name = event.name;
            console.log("Event5 url: ", EVENT5.url);
            console.log('EVENT5:', EVENT5.name);
        });
        Auth.logOut();
    });

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Places.createNewInMoscow(PLACE4).then(function(place){
            console.log("Place4 url: ", place.url);
            PLACE4.url = place.url;
            PLACE4.name = place.name;
        });

        Auth.logOut();
    });

    it("add place to event", function(){
        Auth.loginAsUser(USER4.username, USER4.password);
        browser.get(EVENT5.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE4.name);
        browser.waitForAngular();

        //browser.driver.sleep(5000);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE4.name + "']")).click();
        //browser.driver.sleep(2000);
        element(by.xpath("//form[@name='eventForm']")).submit();
        browser.waitForAngular();

        //browser.driver.sleep(2000);
        Auth.logOut();
    });

    it("wait for event to complete", function(){
        var timeout = (EVENT_MIN_START_OFFSET+1) * 60000;
        console.log("Waiting ", timeout/1000.0, " seconds for event5 to complete....");
        browser.sleep(timeout);
    });

    it("check count messages", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE4.name);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='placeStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length == 2).toBe(true);
            Auth.logOut();
        });
    });

});

describe("User should include events(comment place, comment event, comment him wall", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNew(EVENT6).then(function(event){
            EVENT6.url = event.url;
            EVENT6.name = event.name;
            console.log("Event6 url: ", EVENT6.url);
            console.log('EVENT6:', EVENT6.name);
        });
    });

    it("create place", function(){

        Places.createNewInMoscow(PLACE5).then(function(place){
            console.log("Place5 url: ", place.url);
            PLACE5.url = place.url;
            PLACE5.name = place.name;
        });

        Auth.logOut();
    });

    it("add comment to user trap", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys('release the kraken!');
        element(by.name('addXPostForm')).submit();
        browser.waitForAngular();
    });

    it("add comment to event", function(){
        browser.get(EVENT6.url);
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys('event post');
        element(by.name('addXPostForm')).submit();
        browser.waitForAngular();

        //Auth.loginAsUser(USER.username, USER.password);
        //Comments.addComment('/events/' + EVENT6.name, null, 'Comment to event!');    
        //Auth.logOut();
    });
    
    it("add comment to place", function(){
        browser.get(PLACE5.url);
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys('place post');
        element(by.name('addXPostForm')).submit();
        browser.waitForAngular();
        //Auth.logOut();
    });
    
    /*it('wait', function(){
        browser.driver.sleep(5000);
    });*/

    it("check count messages", function(){
        //Auth.loginAsUser(USER.username, USER.password);
        browser.get('/users/' + USER.username);
        browser.waitForAngular();
        
        element(by.xpath("//a[@data-protractor-id='userStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length).toBe(6);
            Auth.logOut();
        });
    });

});

describe("User should include events(friendship, change location, change status", function(){

    it("create friendship", function(){
        Friendship.beFriends(USER2, USER3);
    });

    it("create place to save user2 location", function(){
        Auth.loginAsUser(USER2.username, USER2.password);

        Places.createNewInMoscow(PLACE).then(function(place){
            console.log("Place url: ", place.url);
            PLACE.url = place.url;
            PLACE.name = place.name;
        });
    });

    it("change location", function(){
        //Auth.loginAsUser(USER2.username, USER2.password);
        browser.wait(function() {
            return element(by.className('ui-pnotify')).isPresent().then(function(result){
                return !result;
            });
        }, 20000);

        element(by.xpath("//button[@data-protractor-id='userProfile']")).click();
        element(by.xpath("//button[@id='save-location-history']")).click();

        browser.driver.sleep(2000);

        Visibility.setVisibility({visibility: '4'}, 'visibilityEntity');

        element(by.xpath("//div[@id='s2id_place']//a")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE.name);
        browser.driver.sleep(5000);

        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();
        element(by.xpath("//form[@name='userPlaceForm']")).submit();
        Auth.logOut();
    });

    it("change status", function(){
        Auth.loginAsUser(USER2.username, USER2.password);

        element(by.xpath("//li[contains(@class,'overflow-expander') and contains(@class, 'megamenu__item--with-submenu')]//button")).click();
        element(by.xpath("//a[@data-protractor-id='userStatuses']")).click();
        element(by.xpath("//li[contains(@class,'overflow-expander') and contains(@class, 'megamenu__item--with-submenu')]//button")).click();

        element(by.xpath("//button[@id='add-status']")).click();

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@id='s2id_status']//a")).click();
        element(by.xpath("//div[@id='select2-drop']//div[@class='select2-search']//input")).sendKeys('в крыму');
        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();

        browser.driver.sleep(2000);

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")).sendKeys('охота');
        
        browser.driver.sleep(1000);

        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();
        element(by.name('statusForm')).submit();
        
        browser.driver.sleep(2000);
        Auth.logOut();
    });
        /*
    it("wait", function(){
        browser.driver.sleep(5000);
    });
         */

    it("check count messages", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        
        element(by.xpath("//a[@data-protractor-id='userStream']")).click();

        element.all(by.repeater('item in (dataSource || stream) track by item.id')).then(function(events){
            expect(events.length).toBe(3);
            Auth.logOut();
        });
    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
