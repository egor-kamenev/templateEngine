'use strict';

var Auth = require('../utils/auth.js'),
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 27,
        'password': 'hackme'
    },
    FRIENDSHIP_TAGS = ['друзья', 'родственники'],
    MESSAGE = 'Hello world',
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js'),
    USER2 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 32,
        'password': 'hackme'
    };

var selectDropdownbyValue = function (element, optionValue) {
    element.all(by.xpath('option[@value = "' + optionValue + '"]')).click();
};
    
browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users: ", function() {
    
    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('User:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

    it("registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

});

describe("User profile: ", function() {
    
    it("check private sections visibility", function() {
        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

        expect(element(by.xpath("//a[@data-protractor-id='userMessages']")).isDisplayed()).toBe(true);
        
        element(by.xpath("//button[@data-protractor-id='toggleSubscribers']")).click();

        expect(element(by.xpath("//a[@data-protractor-id='userSubscriptionsSubscribers']")).isDisplayed()).toBe(true);

        element(by.xpath("//button[@data-protractor-id='toggleSubscribers']")).click();

        expect(element(by.xpath("//a[@data-protractor-id='userBans']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userBookmarks']")).isDisplayed()).toBe(true);
        Auth.logOut();
    });

    it("check public sections visibility", function() {
        Auth.loginAsUser(USER.username, USER.password);

        expect(element(by.xpath("//a[@data-protractor-id='userStream']")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userAlbums']")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userEvents']")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userInterests']")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userPlaces']")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userFriends']")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userStatuses']")).isPresent()).toBe(true);

        Auth.logOut();
    });

    it("check button privilege on pages", function(){
        Auth.loginAsUser(USER.username, USER.password);
        var privacyButton = element(by.xpath("//button[contains(@class,'privacy-all') and contains(@type,'button')]"));

        element(by.xpath("//a[@data-protractor-id='userStream']")).click();
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);
        
        element(by.xpath("//a[@data-protractor-id='userAlbums']")).click();
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        element(by.xpath("//a[@data-protractor-id='userEvents']")).click();
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        element(by.xpath("//a[@data-protractor-id='userInterests']")).click();
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class, 'overflow-expander')]/button")).click();
        
        element(by.xpath("//a[@data-protractor-id='userPlaces']")).click();
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        browser.navigate().refresh();

        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class, 'overflow-expander')]/button")).click();
        
        element(by.xpath("//a[@data-protractor-id='userFriends']")).click();
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        browser.navigate().refresh();
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class, 'overflow-expander')]/button")).click();
        
        element(by.xpath("//a[@data-protractor-id='userStatuses']")).click();
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);
        Auth.logOut();
    });
    
    it("check privilege on stream page", function(){
        Auth.loginAsUser(USER.username, USER.password);
        element(by.xpath("//a[@data-protractor-id='userStream']")).click();

        element(by.xpath("//button[@data-protractor-id='sectionVisibility']")).click();
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        
        element(by.xpath("//select[@data-ng-model='entity.visibility.value']")).click();

        selectDropdownbyValue(element(by.xpath("//select[@name='visibility']")), '0');
        element(by.xpath("//label[@data-protractor-id='showToAll']")).click();
        
        element(by.xpath("//button[@data-protractor-id='saveVisibility']")).click();
        Auth.logOut();
    });

    it("check stream page user", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/' + USER.username + '/stream');
        browser.waitForAngular();

        browser.getCurrentUrl().then(function(url) {
            expect(url).toMatch(/403/);
            Auth.logOut();
        });

    });

    it("try to look user private sections", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/'+ USER.username + '/calendar');
        browser.waitForAngular();
        

        browser.getCurrentUrl().then(function(url) {
            expect(url).toMatch(/403/);
        });
        
        browser.get('/users/'+ USER.username + '/messages/private');
        browser.waitForAngular();

        browser.getCurrentUrl().then(function(url) {
            expect(url).toMatch(/403/);
        });

        browser.get('/users/'+ USER.username + '/subscriptions/subscribers');
        browser.waitForAngular();
        
        browser.getCurrentUrl().then(function(url) {
            expect(url).toMatch(/403/);
        });

        browser.get('/users/'+ USER.username + '/bans');
        browser.waitForAngular();
        
        browser.getCurrentUrl().then(function(url) {
            expect(url).toMatch(/403/);
        });

        browser.get('/users/'+ USER.username + '/bookmarks/events');
        browser.waitForAngular();
        
        browser.getCurrentUrl().then(function(url) {
            expect(url).toMatch(/403/);
        });

        browser.get('/users/'+ USER.username + '/profile');
        browser.waitForAngular();
        
        browser.getCurrentUrl().then(function(url) {
            expect(url).toMatch(/403/);
            Auth.logOut();
        });

    });

    it("set user hide from everyone", function(){
       Auth.loginAsUser(USER.username, USER.password);

        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//a[@data-protractor-id='userSettings']")).click();

        browser.waitForAngular();

        browser.navigate().refresh();

        element(by.xpath("//input[@id='is_discoverable']/..")).click();
        element(by.xpath("//form[contains(@name,'settingsForm') and contains(@class,'form')]//input[@type='submit']")).click();
        
        Auth.logOut();
    });

    it("check user hide from everyone", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        expect(element(by.xpath("//nav[contains(@class,'profile-menu') and contains(@class,'nav--primary')]")).isPresent()).toBe(false);
        Auth.logOut();
    });

    it("send friendship request to user", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get("/users/" + USER2.username);

        element(by.xpath("//button[@data-protractor-id='sendFriendshipRequest']")).click();
        expect(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]")).isDisplayed()).toBe(true);
        
        element(by.xpath("//button[@id='cancel-friendship']")).click();
        expect(element(by.xpath("//button[contains(@class,'friendship')]//following::div[contains(@class,'light-modal')]")).isDisplayed()).toBe(false);
        
        element(by.xpath("//button[@data-protractor-id='sendFriendshipRequest']")).click();
        element(by.xpath("//div[@id='s2id_friendship_tags']//ul//li//input")).sendKeys(FRIENDSHIP_TAGS[0]);
        element(by.xpath("//div[@id='select2-drop']")).click();

        element(by.xpath("//div[@id='s2id_friendship_tags']//ul//li//input")).sendKeys(FRIENDSHIP_TAGS[1]);
        element(by.xpath("//div[@id='select2-drop']")).click();

        element(by.xpath("//textarea[@id='message']")).sendKeys(MESSAGE);

        element(by.xpath("//form[@name='newFriendForm']//button[@type='submit']")).click();

        expect(element(by.xpath("//button[contains(@class,'friendship')]//following::div[contains(@class,'light-modal')]")).isDisplayed()).toBe(false);
        Auth.logOut();
    });
    
});