'use strict';

var path = require('path');

var OWNER = {
        'username': 'ownerVisibility',
        'first_name': 'Owner',
        'last_name': 'Tester',
        'email': 'ownervisibility@mail.com',
        'phone': '+79111225001',
        'age': 30,
        'password': 'hackme'
    },
    USER1 = {
        'username': 'user1Visibility',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1visibility@mail.com',
        'phone': '+79111225002',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user2Visibility',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2visibility@mail.com',
        'phone': '+79111225003',
        'age': 25,
        'password': 'hackme'
    },
    USER3 = {
        'username': 'user3Visibility',
        'first_name': 'Sidr',
        'last_name': 'Tester',
        'email': 'user3visibility@mail.com',
        'phone': '+79111225004',
        'age': 26,
        'password': 'hackme'
    },
    EVENT1 = {
        'name': 'eventvisibility1',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'description': 'Event for test visibility1',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    PRIVATE_EVENT = {
        'name': 'privateevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'description': 'Event for test visibility1',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '0',
        visibility_show_for_all: false
    },
    EVENT2 = {
        'name': 'eventvisibility2',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test visibility2',
        'participants_min': '2',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '1',
        'visibility_users': [USER3.username]
    },
    EVENT3 = {
        'name': 'eventvisibility3',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test visibility3',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '2'
    },
    EVENT4 = {
        'name': 'eventvisibility4',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test visibility4',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '3'
    },
    EVENT5 = {
        'name': 'eventvisibility5',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test visibility5',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT6 = {
        'name': 'eventvisibility6',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test visibility6',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '0',
        'visibility_show_for_all': true
    },
    PLACE1 = {
        'name': 'placevisibility1',
        'visibility': '4'
    },
    PRIVATE_PLACE = {
        'name': 'privateplace',
        'visibility': '0',
        visibility_show_for_all: false

    },
    PLACE2 = {
        'name': 'placevisibility2',
        'visibility': '1',
        'visibility_users': [USER3.username]
    },
    PLACE3 = {
        'name': 'placevisibility3',
        'visibility': '2'
    },
    PLACE4 = {
        'name': 'placevisibility4',
        'visibility': '3'
    },
    PLACE5 = {
        'name': 'placevisibility5',
        'visibility': '4'
    },
    PLACE6 = {
        'name': 'placevisibility6',
        'visibility': '0',
        'visibility_show_for_all': true
    },
    POST1 = {
        'text': 'textpost1',
        'visibility': 4
    },
    PRIVATE_POST = {
        'text': 'private post',
        'visibility': 0
    },
    POST2 = {
        'text': 'textpost2',
        'visibility': 1
        //'visibility_users': [USER3.username],
    },
    POST3 = {
        'text': 'textpost3',
        'visibility': 2
    },
    POST4 = {
        'text': 'textpost4',
        'visibility': 3
    },
    POST5 = {
        'text': 'textpost5',
        'visibility': 4,
    },
    PUBLIC_STREAM = {
        'url': 'stream',
        'visibility': 0
    },
    PUBLIC_ALBUMS = {
        'url': 'albums',
        'visibility': 0
    },
    PUBLIC_EVENTS = {
        'url': 'events',
        'visibility': 1,
        'visibility_users': [USER3.username]
    },
    PUBLIC_INTERESTS = {
        'url': 'interests',
        'visibility': 2,
    },
    PUBLIC_PLACES = {
        'url': 'places',
        'visibility': 2,
    },
    PUBLIC_FRIENDS = {
        'url': 'friends',
        'visibility': 3,
    },
    PUBLIC_STATUSES = {
        'url': 'statuses',
        'visibility': 4,
    },
    ALBUM = {
        'title': 'Test album',
        'tag': 'albumtag',
        'visibility': '4',
        uploadPhotoPath: path.resolve(__dirname, '..', 'test_data', "photo.jpg")
    },
    PRIVATE_ALBUM = {
        'title': 'Private album',
        'tag': 'private',
        'visibility': '0',
        uploadPhotoPath: path.resolve(__dirname, '..', 'test_data', "photo.jpg"),
        visibility_show_for_all: false

    };


var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Signup = require('../utils/signup.js'),
    Comments = require('../utils/comments.js'),
    Visibility = require('../utils/visibility.js'),
    TagSelector = require('../utils/tagSelector.js'),
    Friendship = require('../utils/friendship.js'),
    Profile = require('../utils/profile.js'),
    Albums = require('../utils/albums.js'),
    DateTimePicker = require('../utils/dateTimePicker.js'),
    Settings = require('../utils/settings.js');

var activeModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]")),
    activeModalXP = '//div[contains(@class,"light-modal") and contains(@class ,"active")]';


var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

var addPost = function(user, post) {
    browser.get('/users/' + user.username);
    browser.waitForAngular();
    element(by.id('xPostBody')).sendKeys(post.text);
    //Visibility.setVisibility(post, 'xPost');
    element(by.name('addXPostForm')).submit();

    browser.waitForAngular();

    browser.get('/users/' + user.username);
    browser.waitForAngular();

    var posts = element.all(by.repeater("post in xPosts | orderBy:'-ts_published' track by post.id"));
    posts.first().then(function (p) {
        post.selector = p;

        p.element(by.xpath('(//a[starts-with(@data-ui-sref, "post(")])[1]')).getAttribute("href").then(function(postUrl){
            post.url = postUrl;
        });

    });


};



xdescribe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 
/*
describe("Private objects are hidden in filters", function(){

    OWNER.username = "user1";
    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("Create private event", function(){
        PRIVATE_EVENT.name = "privateevent";
        Events.createNewUnique(PRIVATE_EVENT).then(function(e){
            console.log("Private event url: ", e.url);
            PRIVATE_EVENT.url = e.url;
            PRIVATE_EVENT.name = e.name;
        });
    });

});
*/


describe("Register users: ", function(){
    it("Register OWNER", function(){

        Signup.registerUserUntilDone(OWNER).then(
            function (user) {
                console.log("Owner username: ", user.username);
                OWNER.username = user.username;
                OWNER.email = user.email;
                //Auth.loginAsUser(OWNER.username, OWNER.password);
                //Signup.addPhone(OWNER);
            }
        );
    });
    it("Verify OWNER", function() {
        Signup.verifyEmail(OWNER);
        //Signup.verifyPhone(OWNER);
        //Auth.logOut();
    });

    it("Registrate USER1", function(){
        Signup.registerUserUntilDone(USER1).then(
            function (user) {
                USER1.username = user.username;
                USER1.email = user.email;
                console.log("USER1 username: ", USER1.username);

                Auth.loginAsUser(USER1.username, USER1.password);
                //Signup.addPhone(USER1);
            }
        );
    });
    it("Verify USER1", function() {
        Signup.verifyEmail(USER1);
        //Signup.verifyPhone(USER1);
        //Auth.logOut();
    });
    /*
    xit("Registrate USER2", function(){
        Signup.registerUserUntilDone(USER2).then(
            function (user) {
                USER2.username = user.username;
                USER2.email = user.email;
                Auth.loginAsUser(USER2.username, USER2.password);
                //Signup.addPhone(USER2);
            }
        );
    });
    xit("Verify USER2", function() {
        Signup.verifyEmail(USER2);
        //Signup.verifyPhone(USER2);
        Auth.logOut();
    });
    xit("Registrate USER3", function(){
        Signup.registerUserUntilDone(USER3).then(
            function (user) {
                USER3.username = user.username;
                USER3.email = user.email;
                Auth.loginAsUser(USER3.username, USER3.password);
                //Signup.addPhone(USER3);
            }
        );
    });
    xit("Verify USER3", function() {
        Signup.verifyEmail(USER3);
        //Signup.verifyPhone(USER3);
        Auth.logOut();
    });
    xit("Add OWNER and USER2 as friends of USER1", function() {

        Friendship.beFriends(USER1, OWNER);
        Friendship.beFriends(USER1, USER2);

    });
     */

});

describe("Private objects are hidden in filters", function(){

    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("Create private event", function(){
        PRIVATE_EVENT.name = "privateevent";
        Events.createNewUnique(PRIVATE_EVENT).then(function(e){
            console.log("Private event url: ", e.url);
            PRIVATE_EVENT.url = e.url;
            PRIVATE_EVENT.name = e.name;
        });
    });

    it("Create private place", function(){
        
        PRIVATE_PLACE.name = "privateplace";

        Places.createNewInMoscow(PRIVATE_PLACE).then(function(place){
            console.log("Private place url: ", place.url);
            PRIVATE_PLACE.url = place.url;
        });

    });

    it("Log out", function(){
        Auth.logOut();
    });

    it("Log in as other user", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Go to filters and try to find private event", function(){

        browser.get('/events?show=list');
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="filtersSearch"]')).click();
        element(by.xpath('//div[@data-protractor-id="searchCriteriaBlock"]//input[@type="text"]')).sendKeys(PRIVATE_EVENT.name);
        element(by.xpath('//div[@class="select2-result-label"]')).click();
        element.all(by.repeater('item in dataSource track by item.id')).then(function(results){
            expect(results.length).toBe(0);
        });

    });

    it("Go to filters and try to find private place", function(){

        browser.get('/places?show=list');
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="filtersSearch"]')).click();
        element(by.xpath('//div[@data-protractor-id="searchCriteriaBlock"]//input[@type="text"]')).sendKeys(PRIVATE_PLACE.name);
        element(by.xpath('//div[@class="select2-result-label"]')).click();
        element.all(by.repeater('item in dataSource track by item.id')).then(function(results){
            expect(results.length).toBe(0);
        });


    });

    it("Log out", function(){
        Auth.logOut();
    });

});

describe("Limit available post visibility if post is attached to private event or place", function(){

    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("Create private event", function(){
        PRIVATE_EVENT.name = "privateevent";

        Events.createNewUnique(PRIVATE_EVENT).then(function(e){
            console.log("Private event url: ", e.url);
            PRIVATE_EVENT.url = e.url;
            PRIVATE_EVENT.name = e.name;
        });
    });

    it("Create private place", function(){

        PRIVATE_PLACE.name = "privateplace";

        Places.createNewInMoscow(PRIVATE_PLACE).then(function(place){
            console.log("Private place url: ", place.url);
            PRIVATE_PLACE.url = place.url;
        });

    });

    xit("Create private post", function(){
        addPost(OWNER, PRIVATE_POST);
    });

    it("Create private album", function(){

        Albums.createNew(OWNER, PRIVATE_ALBUM).then(function(album){
            PRIVATE_ALBUM.url = album.albumUrl;
            PRIVATE_ALBUM.photoUrl = album.photoUrl;
        });

    });

    xit("available post visibility on private event wall should be limited", function(){
        browser.get(PRIVATE_EVENT.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="xPostVisibility"]')).click();

        activeModal.element(by.name('visibility')).all(by.tagName('option')).then(function(options){
            expect(options.length).toBe(1);
        });


    });

    xit("available post visibility on private place wall should be limited", function(){
        browser.get(PRIVATE_PLACE.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="xPostVisibility"]')).click();

        activeModal.element(by.name('visibility')).all(by.tagName('option')).then(function(options){
            expect(options.length).toBe(1);
        });

    });
    
    it("Log out", function(){
        Auth.logOut();
    });

    it("Log in as other user", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("All private objects should be unavailable", function(){
        browser.get(PRIVATE_EVENT.url);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');

        browser.get(PRIVATE_PLACE.url);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');

        //browser.get(PRIVATE_POST.url);
        //browser.waitForAngular();
        //expect(browser.getCurrentUrl()).toContain('/403');

        browser.get(PRIVATE_ALBUM.url);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/404');

    });

    it("Log out", function(){
        Auth.logOut();
    });

});

describe("Object with 'show to all' option set must be sent to manual moderation", function(){
    
    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("Create private event", function(){
        PRIVATE_EVENT.name = "privateevent";
        Events.createNewUnique(PRIVATE_EVENT).then(function(e){
            console.log("Private event url: ", e.url);
            PRIVATE_EVENT.url = e.url;
            PRIVATE_EVENT.name = e.name;
        });
    });

    it("Create private place", function(){

        PRIVATE_PLACE.name = "privateplace";
        Places.createNewInMoscow(PRIVATE_PLACE).then(function(place){
            console.log("Private place url: ", place.url);
            PRIVATE_PLACE.url = place.url;
        });

    });

    xit("Create private post", function(){
        addPost(OWNER, PRIVATE_POST);
    });

    it("Create private album", function(){

        Albums.createNew(OWNER, PRIVATE_ALBUM).then(function(album){
            PRIVATE_ALBUM.url = album.albumUrl;
            PRIVATE_ALBUM.photoUrl = album.photoUrl;
        });

    });


    it("update moderation settings", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'false');
        Settings.set('MODERATION_INSTANT_CHECK', 'true');
    });

    it("Change event visibility to 'show_for_all'", function(){
        var showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));
        
        browser.get(PRIVATE_EVENT.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="eventOwnerMegaMenu"]')).click();

        element(by.xpath('//button[@data-protractor-id="eventVisibility"]')).click();
        expect( showToAllChkbox.isDisplayed() ).toBeTruthy();
        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "4"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();
        browser.waitForAngular();
        
    });

    it("Change place visibility to 'show_for_all'", function(){
        var showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));
        
        browser.get(PRIVATE_PLACE.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="placeOwnerMegaMenu"]')).click();

        element(by.xpath('//button[@data-protractor-id="placeVisibility"]')).click();
        expect( showToAllChkbox.isDisplayed() ).toBeTruthy();
        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "4"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();
        browser.waitForAngular();
        
    });

    xit("Change post visibility to 'show_for_all'", function(){

        var editLink = element(by.xpath('//div[contains(text(),"' + PRIVATE_POST.text + '")]/../../../..//button[@data-protractor-id="editPost"]')),
            showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));

        browser.get('/users/' + OWNER.username );
        browser.waitForAngular();

        editLink.click();
        // second visibility button
        element.all(
            by.xpath('//form[@name="addXPostForm"]//button[@data-protractor-id="xPostVisibility"]')
        ).get(1).click();

        expect( showToAllChkbox.isDisplayed() ).toBeTruthy();
        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "4"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();

        element(by.xpath('//li[@data-protractor-id="xPostEntry"]//form[@name="addXPostForm"]')).submit();
        browser.waitForAngular();
        
    });

    it("Change photo visibility to 'show_for_all'", function(){

        var editLink = element(by.xpath('//button[@data-protractor-id="editPhoto"]')),
            showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));

        browser.get( PRIVATE_ALBUM.photoUrl );
        browser.waitForAngular();

        editLink.click();
        
        expect(activeModal.isDisplayed()).toBeTruthy();

        element(by.xpath('//button[@data-protractor-id="editPhotoVisibility2"]')).click();
        expect( showToAllChkbox.isDisplayed() ).toBeTruthy();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();
        element(by.model('entity.title')).sendKeys("Private photo");

        element(by.xpath('//button[@data-protractor-id="savePhoto"]')).click();
        
        browser.waitForAngular();

    });

    it("update moderation settings", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

    it("Log out", function(){
        Auth.logOut();
    });

    it("Log in as other user", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Event should NOT be delisted for moderation #T583", function(){

        browser.get(PRIVATE_EVENT.url);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
    });

    it("Place should NOT be delisted for moderation #T583", function(){

        browser.get(PRIVATE_PLACE.url);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
    });

    it("Photo should be delisted for moderation", function(){

        browser.get(PRIVATE_ALBUM.url);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/404');
    });

    xit("Post should be delisted for moderation", function(){

        browser.get(PRIVATE_POST.url);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');
    });

    
    it("Log out", function(){
        Auth.logOut();
    });

    it("Log in as admin", function(){
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
    });

    it("Go to pending manual tasks", function(){
        browser.get(ADMIN_URL +  '/admin/moderation/pendingmanualstafftask/');

    });

    it("Event manual moderation tasks should be present", function(){
        expect(element(by.xpath('//tr//td[text()="' + PRIVATE_EVENT.name +'"]')).isDisplayed() ).toBeTruthy();
    });

    it("Place manual moderation tasks should be present", function(){
        expect(element(by.xpath('//tr//td[text()="' + PRIVATE_PLACE.name +'"]')).isDisplayed() ).toBeTruthy();
    });

    xit("Post manual moderation tasks should be present", function(){
        expect(element(by.xpath('//tr//td[text()="' + PRIVATE_POST.text +'"]')).isDisplayed() ).toBeTruthy();
    });

    it("Photo manual moderation tasks should be present", function(){
        expect(element(by.xpath('//tr//td[contains(text(),"Private photo")]')).isDisplayed() ).toBeTruthy();
    });

    it("Log out", function(){
        browser.ignoreSynchronization = false;
        Auth.logOut();
    });

});

describe("Impossible to host public event in private place", function(){

    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("Create private place", function(){

        PRIVATE_PLACE.name = "privateplace";

        Places.createNewInMoscow(PRIVATE_PLACE).then(function(place){
            console.log("Private place url: ", place.url);
            PRIVATE_PLACE.url = place.url;
        });

    });

    it("attempt to create an event should show error message", function(){

        browser.get('/new_event');
        browser.waitForAngular();

        element(by.id('name')).sendKeys('visibility test');

        DateTimePicker.selectTomorrow('date1');
        TagSelector.selectFirstTag('s2id_newEvent_tags');
        selectDropdownbyValue(element(by.id('date1_hour')), 12);
        selectDropdownbyValue(element(by.id('date1_minute')), 0);


        // Select private place
        console.log("PRIVATE PLACE NAME: ", PRIVATE_PLACE.name);
        element(by.id('s2id_newEvent_place')).click();
        element(by.xpath('//div[@id="select2-drop"]//div[@class="select2-search"]//input')).sendKeys(PRIVATE_PLACE.name);

        expect(
            element(by.xpath('//div[text()="' + PRIVATE_PLACE.name + '"]')).isPresent()
        ).toBeFalsy();
        //element(by.xpath('//div[text()="' + PRIVATE_PLACE.name + '"]')).click();
        
        //Visibility.setVisibility({visibility: 4}, 'event');

        //element(by.name('eventForm')).submit();
        //browser.waitForAngular();
        
        //expect( element(by.xpath('//em[@data-protractor-id="placeVisibilityError"]')).isDisplayed() ).toBeTruthy();

    });
    
    it("Log out", function(){
        Auth.logOut();
    });

});

describe("Add content: ", function(){

    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("Create events", function(){

        Events.createNewUnique(EVENT1).then(function(e){
            console.log("Event1 url: ", e.url);
            EVENT1.url = e.url;
            EVENT1.name = e.name;
        });

        /*Events.createNewUnique(EVENT2).then(function(e){
            console.log("Event2 url: ", e.url);
            EVENT2.url = e.url;
            EVENT2.name = e.name;
        });

        Events.createNewUnique(EVENT3).then(function(e){
            console.log("Event3 url: ", e.url);
            EVENT3.url = e.url;
            EVENT3.name = e.name;
        });

        //
        Events.createNewUnique(EVENT4).then(function(e){
            console.log("Event4 url: ", e.url);
            EVENT4.url = e.url;
            EVENT4.name = e.name;
        });

        Events.createNewUnique(EVENT5).then(function(e){
            console.log("Event5 url: ", e.url);
            EVENT5.url = e.url;
            EVENT5.name = e.name;
        });

        Events.createNewUnique(EVENT6).then(function(e){
            console.log("Event6 url: ", e.url);
            EVENT6.url = e.url;
            EVENT6.name = e.name;
        });
         */
        //Events.createNew(EVENT1);
        //Events.createNew(EVENT2);
        //Events.createNew(EVENT3);
        //Events.createNew(EVENT4);
        //Events.createNew(EVENT5);
        //Events.createNew(EVENT6);
    });

    it("Create places", function(){
        
        Places.createNewInMoscow(PLACE1).then(function(place){
            console.log("Place1 url: ", place.url);
            PLACE1.url = place.url;
        });
/*
        Places.createNew(PLACE2).then(function(url){
            console.log("Place2 url: ", url);
            PLACE2.url = url;
        });

        Places.createNew(PLACE3).then(function(url){
            console.log("Place3 url: ", url);
            PLACE3.url = url;
        });

        Places.createNew(PLACE4).then(function(url){
            console.log("Place4 url: ", url);
            PLACE4.url = url;
        });

        Places.createNew(PLACE5).then(function(url){
            console.log("Place5 url: ", url);
            PLACE5.url = url;
        });

        Places.createNew(PLACE6).then(function(url){
            console.log("Place6 url: ", url);
            PLACE6.url = url;
        });
*/

        /*
        Places.createNew(PLACE1);
        Places.createNew(PLACE2);
        Places.createNew(PLACE3);
        Places.createNew(PLACE4);
        Places.createNew(PLACE5);
        Places.createNew(PLACE6);
         */
    });
    xit("Create posts", function(){
        addPost(OWNER, POST1);

        //addPost(OWNER, POST2);
        //addPost(OWNER, POST3);
        //addPost(OWNER, POST4);
        //addPost(OWNER, POST5);
    });
    
    it("Create album", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        
        Albums.createNew(OWNER, ALBUM).then(function(album){
            ALBUM.url = album.albumUrl;
            ALBUM.photoUrl = album.photoUrl;
        });
    });

});


describe("Additional fields for visibility types", function(){

    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("user list visibility", function(){
        browser.get(EVENT1.url);
        browser.waitForAngular();

        expect(element(by.xpath('//button[@data-protractor-id="eventOwnerMegaMenu"]')).isDisplayed()).toBeTruthy();
        element(by.xpath('//button[@data-protractor-id="eventOwnerMegaMenu"]')).click();


        element(by.xpath('//button[@data-protractor-id="eventVisibility"]')).click();

        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "1"]')).click();
        
        expect( activeModal.element(by.model('entity.visibility.users')).isDisplayed() ).toBeTruthy();

        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "2"]')).click();
        expect( activeModal.element(by.model('entity.visibility.friendship_tags')).isDisplayed() ).toBeTruthy();

    });


    it("Log out", function(){
        Auth.logOut();
    });

});


describe("Visibility values: ", function(){

    it("should be 5 types of visibility", function(){
        /*
         только мне
         только друзьям
         всем
         друзьям и друзьям друзей
         перечисление юзернеймов пользователей
         */

        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="sectionVisibility"]')).click();

        expect(activeModal.isDisplayed()).toBeTruthy();
        
        activeModal.element(by.name('visibility')).all(by.tagName('option')).then(function(options){
            expect(options.length).toBe(5);
        });

    });

});

describe("Default visibility: ", function(){

    it("Log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it(" of verified user profile sections should be 'Everyone' ", function(){
        var sections = Profile.getUserPublicProfileSections(OWNER);

        for(var i=0; i < sections.length; i++){
            var sectionURL = sections[i],
                visibilityBtn = element(by.xpath('//button[@data-protractor-id="sectionVisibility"]'));

            browser.get(sectionURL).then(function(){
                browser.getCurrentUrl().then(function(url){
                    console.log("Checking profile section: ", url);
                });
                
            });
            browser.waitForAngular();
            expect( visibilityBtn.isDisplayed() ).toBeTruthy();
            visibilityBtn.click();


            expect(activeModal.isDisplayed()).toBeTruthy();

            expect(

                element(
                    by.xpath(activeModalXP + '//select[@name="visibility"]//option[@value="4" and @selected]')
                ).isPresent()

            ).toBeTruthy();

        }
    });

    xit(" of xPost should inherit source object's visibility", function(){

        var addXPostBtn = element(by.xpath('//button[@data-protractor-id="xPostVisibility"]'));
        browser.get(EVENT1.url);
        browser.waitForAngular();
        
        expect( addXPostBtn.isDisplayed() ).toBeTruthy();
        
        addXPostBtn.click();

        expect(
            
            element(
                by.xpath(activeModalXP + '//select[@name="visibility"]//option[@value="' + EVENT1.visibility + '" and @selected]')
            ).isPresent()
            
        ).toBeTruthy();
        
    });


    it(" of new event should be 'to all'", function(){

        var eventVisibilityBtn = element(by.xpath('//button[@data-protractor-id="editEventVisibility"]'));

        browser.get('/new_event');
        browser.waitForAngular();

        expect( eventVisibilityBtn.isDisplayed() ).toBeTruthy();
        
        eventVisibilityBtn.click();

        expect(
            
            element(
                by.xpath(activeModalXP + '//select[@name="visibility"]//option[@value="4" and @selected]')
            ).isPresent()
            
        ).toBeTruthy();
        
    });

    it(" of new place should be 'all'", function(){

        var placeVisibilityBtn = element(by.xpath('//button[@data-protractor-id="editPlaceVisibility"]'));

        browser.get('/new_place');
        browser.waitForAngular();

        expect( placeVisibilityBtn.isDisplayed() ).toBeTruthy();
        
        placeVisibilityBtn.click();

        expect(
            
            element(
                by.xpath(activeModalXP + '//select[@name="visibility"]//option[@value="4" and @selected]')
            ).isPresent()
            
        ).toBeTruthy();
        
    });

    it(" of new album should be 'all'", function(){
        
        var createAlbumBtn = element(by.xpath('//button[@data-protractor-id="addAlbum"]'));
            //albumVisibilityBtn = element(by.xpath('//button[@data-protractor-id="albumVisibility"]'));

        browser.get('/users/' + OWNER.username + '/albums');
        browser.waitForAngular();

        //expect( createAlbumBtn.isDisplayed() ).toBeTruthy();
        //createAlbumBtn.click();

        
        var postForm = browser.findElement( by.name('addXPostForm') ),
            albumVisibilityBtn = browser.findElement( by.xpath('//button[@data-protractor-id="xPostVisibility"]') );
        
        browser.executeScript(scrollIntoView, postForm);

        expect( albumVisibilityBtn.isDisplayed() ).toBeTruthy();
        
        albumVisibilityBtn.click();

        expect(
            
            element(
                by.xpath(activeModalXP + '//select[@name="visibility"]//option[@value="4" and @selected]')
            ).isPresent()
            
        ).toBeTruthy();
        
    });
    
});

describe("Check visibility: ", function(){

    it("every profile section should have button to set it's visibility", function(){

        var sections = Profile.getUserPublicProfileSections(OWNER);
        Auth.loginAsUser(OWNER.username, OWNER.password);

        for(var i=0; i < sections.length; i++){
            var sectionURL = sections[i];
            browser.get(sectionURL).then(function(){
                browser.getCurrentUrl().then(function(url){
                    console.log("Checking profile section: ", url);
                });
                
            });
            browser.waitForAngular();
            expect( element(by.xpath('//button[@data-protractor-id="sectionVisibility"]')).isDisplayed() ).toBeTruthy();
            
            element(by.xpath('//button[@data-protractor-id="sectionVisibility"]')).click();
            expect(activeModal.isDisplayed()).toBeTruthy();

            expect( 
                element(by.xpath('//div[contains(@class,"light-modal") and contains(@class ,"active")]//input[@data-protractor-id="showToAll"]')).isDisplayed()
            ).toBeTruthy();

        }
    });

    it("owner can set event visibility", function(){
        var editLink = element(by.xpath('//button[@data-protractor-id="editEventLink"]'));

        browser.get(EVENT1.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="eventOwnerMegaMenu"]')).click();

        expect(element(by.xpath('//button[@data-protractor-id="eventVisibility"]')).isDisplayed()).toBeTruthy();

        expect( editLink.isDisplayed() ).toBeTruthy();

        editLink.click();

        expect(activeModal.isDisplayed()).toBeTruthy();
        expect(activeModal.element(by.xpath('//button[@data-protractor-id="editEventVisibility"]')).isDisplayed()).toBeTruthy();

        activeModal.element(by.xpath('//button[@data-protractor-id="editEventVisibility"]')).click();
        expect(element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]')).isDisplayed()).toBeTruthy();
        
    });

    it("owner can set place visibility", function(){
        var editLink = element(by.xpath('//button[@data-protractor-id="editPlaceLink"]'));

        browser.get(PLACE1.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="placeOwnerMegaMenu"]')).click();

        expect(element(by.xpath('//button[@data-protractor-id="placeVisibility"]')).isDisplayed()).toBeTruthy();

        expect( editLink.isDisplayed() ).toBeTruthy();

        editLink.click();

        expect(activeModal.isDisplayed()).toBeTruthy();
        expect(activeModal.element(by.xpath('//button[@data-protractor-id="editPlaceVisibility"]')).isDisplayed()).toBeTruthy();
        activeModal.element(by.xpath('//button[@data-protractor-id="editPlaceVisibility"]')).click();

        expect(element(by.xpath('//div[contains(@class,"light-modal") and contains(@class ,"active")]//input[@data-protractor-id="showToAll"]')).isDisplayed()).toBeTruthy();

    });

    xit("owner can set xPost visibility", function(){

        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();
        
        expect( element(by.xpath('//button[@data-protractor-id="xPostVisibility"]')).isDisplayed() ).toBeTruthy();

        element(by.xpath('//button[@data-protractor-id="xPostVisibility"]')).click();
        expect(activeModal.isDisplayed()).toBeTruthy();
        
        expect(activeModal.element(by.xpath('//input[@data-protractor-id="showToAll"]')).isDisplayed()).toBeTruthy();

    });


    it("owner can set photo visibility", function(){

        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();

        expect( element(by.xpath('//button[@data-protractor-id="editPhotoVisibility1"]')).isDisplayed() ).toBeTruthy();

        element(by.xpath('//button[@data-protractor-id="editPhotoVisibility1"]')).click();
        expect(activeModal.isDisplayed()).toBeTruthy();
        
        expect(element(by.xpath('//div[contains(@class,"light-modal") and contains(@class ,"active")]//input[@data-protractor-id="showToAll"]')).isDisplayed()).toBeTruthy();

    });

    it("owner can set album visibility", function(){

        browser.get(ALBUM.url);
        browser.waitForAngular();

        expect( element(by.xpath('//button[@data-protractor-id="albumVisibility"]')).isDisplayed() ).toBeTruthy();

        element(by.xpath('//button[@data-protractor-id="albumVisibility"]')).click();
        expect(activeModal.isDisplayed()).toBeTruthy();
        
        expect(
            element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]//input[@data-protractor-id='showToAll']")).isDisplayed()
        ).toBeTruthy();

    });

    it("owner logout", function(){
        Auth.logOut();
    });



});

describe("Only content owner can change it's visbility: ", function(){

    it("profile sections", function(){

        var sections = Profile.getUserPublicProfileSections(OWNER);
        Auth.loginAsUser(USER1.username, USER1.password);

        for(var i=0; i < sections.length; i++){
            var sectionURL = sections[i];
            browser.get(sectionURL).then(function(){
                browser.getCurrentUrl().then(function(url){
                    console.log("Checking profile section: ", url);
                });
                
            });
            browser.waitForAngular();
            expect( element(by.xpath('//button[@data-protractor-id="sectionVisibility"]')).isPresent() ).toBeFalsy();
            //expect( element(by.xpath('//button[@data-protractor-id="sectionVisibility"]')).isDisplayed() ).toBeFalsy();
            
        }

    });

    it("event", function(){
        browser.get(EVENT1.url);
        browser.waitForAngular();
        element(by.xpath('//*[@data-protractor-id="eventMegaMenu"]')).click();
        expect(element(by.xpath('//*[@data-protractor-id="eventVisibility"]')).isPresent()).toBeFalsy();
    });

    it("place", function(){
        browser.get(PLACE1.url);
        browser.waitForAngular();
        element(by.xpath('//*[@data-protractor-id="placeMegaMenu"]')).click();
        expect(element(by.xpath('//button[@data-protractor-id="placeVisibility"]')).isPresent()).toBeFalsy();
    });

    it("post", function(){

        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        expect(element(by.xpath('//button[@data-protractor-id="editPost"]')).isDisplayed()).toBeFalsy();
    });


    it("photo", function(){

        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();

        expect( element(by.xpath('//button[@data-protractor-id="editPhotoVisibility1"]')).isDisplayed() ).toBeFalsy();

    });

    it("album", function(){

        browser.get(ALBUM.url);
        browser.waitForAngular();

        expect( element(by.xpath('//*[@data-protractor-id="albumVisibility"]')).isPresent() ).toBeFalsy();

    });


});

describe("Content with 'show_for_all' option set to true: ", function(){

    it("log in as owner", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
    });

    it("set place visibility to private and 'show_to_all' to true", function(){

        var placeVisibility = element(by.xpath('//button[@data-protractor-id="placeVisibility"]')),
            showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));

        browser.get(PLACE1.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="placeOwnerMegaMenu"]')).click();

        expect( placeVisibility.isDisplayed() ).toBeTruthy();
        placeVisibility.click();

        expect(activeModal.isDisplayed()).toBeTruthy();
        expect(showToAllChkbox.isDisplayed()).toBeTruthy();

        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "0"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();
        browser.waitForAngular();

    });

    it("set event visibility to private and 'show_to_all' to true", function(){

        var eventVisibility = element(by.xpath('//button[@data-protractor-id="eventVisibility"]')),
            showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));

        browser.get(EVENT1.url);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="eventOwnerMegaMenu"]')).click();
        
        expect( eventVisibility.isDisplayed() ).toBeTruthy();
        eventVisibility.click();

        expect(activeModal.isDisplayed()).toBeTruthy();
        expect(showToAllChkbox.isDisplayed()).toBeTruthy();

        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "0"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();
        browser.waitForAngular();

    });

    xit("set xPost visibility to private and 'show_to_all' to true", function(){

        var ptor = protractor.getInstance();

        var showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]')),
            postLi = element(by.xpath('//div[contains(text(),"' + POST1.text + '")]/../../../..')),
            editLink = element(by.xpath('//div[contains(text(),"' + POST1.text + '")]/../../../..//button[@data-protractor-id="editPost"]'));

        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();

        expect(editLink.isDisplayed()).toBeTruthy();
        editLink.click();

        // second visibility button
        element.all(
            by.xpath('//form[@name="addXPostForm"]//button[@data-protractor-id="xPostVisibility"]')
        ).get(1).click();

        expect( showToAllChkbox.isDisplayed() ).toBeTruthy();
        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "0"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();

        element(by.xpath('//li[@data-protractor-id="xPostEntry"]//form[@name="addXPostForm"]')).submit();
        browser.waitForAngular();

    });


    it("set album visibility to private and 'show_to_all' to true", function(){

        var albumVisibility = element(by.xpath('//button[@data-protractor-id="albumVisibility"]')),
            showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));

        browser.get(ALBUM.url);
        browser.waitForAngular();

        albumVisibility.click();

        expect(showToAllChkbox.isDisplayed()).toBeTruthy();

        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "0"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();
        browser.waitForAngular();

    });

    it("set photo visibility to private and 'show_to_all' to true", function(){

        var photoVisibility = element(by.xpath('//button[@data-protractor-id="editPhotoVisibility1"]')),
            showToAllLabel = element(by.xpath(activeModalXP + '//label[@data-protractor-id="showToAll"]')),
            showToAllChkbox = element(by.xpath(activeModalXP + '//input[@data-protractor-id="showToAll"]'));

        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();

        photoVisibility.click();

        expect(showToAllChkbox.isDisplayed()).toBeTruthy();

        activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "0"]')).click();

        showToAllChkbox.getAttribute('checked').then(function(checked){

            if(!checked){
                showToAllLabel.click();
            }
        });
        element(by.xpath(activeModalXP + '//button[@data-protractor-id="saveVisibility"]')).click();
        browser.waitForAngular();

    });

    it("log out owner and login as another user", function(){
        Auth.logOut();
        Auth.loginAsUser(USER1.username, USER1.password);
    });


    it("private place with 'show_for_all' should stay visibile to others", function(){
        browser.get(PLACE1.url);
        browser.waitForAngular();

        // not 403/404
        expect(browser.getCurrentUrl()).toBe(PLACE1.url);
        
        // Place is readonly - xpost form must be hidden
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeFalsy();

        expect(element(by.xpath('//button[@data-protractor-id="placeCheckInOut"]')).isPresent()).toBeFalsy();

    });

    it("private event with 'show_for_all' should stay visibile to others", function(){
        browser.get(EVENT1.url);
        browser.waitForAngular();

        // not 403/404
        expect(browser.getCurrentUrl()).toBe(EVENT1.url);

        // Event is readonly - xpost form must be hiden
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeFalsy();

        element(by.xpath('//button[@data-protractor-id="eventMegaMenu"]')).click();

        expect(element(by.xpath('//button[@data-protractor-id="eventCheckInOut"]')).isPresent()).toBeFalsy();

    });

    xit("private xPost with 'show_for_all' should stay visibile to others", function(){
        browser.get(POST1.url);
        browser.waitForAngular();

        // not 403/404
        expect(browser.getCurrentUrl()).toBe(POST1.url);
        
        // Post is readonly - xpost form must be hiden
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeFalsy();

    });
    
    it("private album with 'show_for_all' should stay visibile to others", function(){
        browser.get(ALBUM.url);
        browser.waitForAngular();

        // not 403/404
        expect(browser.getCurrentUrl()).toBe(ALBUM.url);
    });

    it("private photo with 'show_for_all' should stay visibile to others", function(){
        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();

        // not 403/404
        expect(browser.getCurrentUrl()).toContain(ALBUM.photoUrl);

        // Photo is readonly - xpost form must be hiden
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeFalsy();

    });

    it("logout other user", function(){
        Auth.logOut();
    });


});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
