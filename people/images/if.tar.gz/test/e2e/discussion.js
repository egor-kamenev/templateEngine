'use strict';

var path = require('path'),
    USER1 = {
        'username': 'user1Discuss',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1complain@mail.com',
        'phone': '+79111223002',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user2Discuss',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2complain@mail.com',
        'phone': '+79111223003',
        'age': 25,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'eventcomplain1',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test complain1',
        'participants_min': '1',
        'age_restrict': '1',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE = {
        'name': 'placecomplain11',
        'visibility': '4'
    }, 
    PRIVATE_PLACE = {
        'name': 'placeprivate',
        'visibility': '0'
    }, 
    ALBUM = {
        'title': 'Test album',
        'tag': 'albumtag',
        'visibility': '4',
        uploadPhotoPath: path.resolve(__dirname, '..', 'test_data', "photo.jpg")
    },
    POST = {
        'body': "Test post body",
        'url': ""
    };

var Auth = require('../utils/auth.js'),
    Settings = require('../utils/settings.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Comments = require('../utils/comments.js'),
    Signup = require('../utils/signup.js'),
    Visibility = require('../utils/visibility.js'),
    Albums = require('../utils/albums.js'),
    TagSelector = require('../utils/tagSelector.js');


describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register users: ", function(){

    it("register USER1", function(){

        Signup.registerUserUntilDone(USER1).then(
            function (user) {
                console.log("USER1 Username: ", user.username);

                USER1.username = user.username;
                USER1.email = user.email;

                //Auth.loginAsUser(USER1.username, USER1.password);
            }
        );
    });

    it("verify USER1", function() {
        Signup.verifyEmail(USER1);
        //Auth.logOut();
    });
    
    it("register USER2", function(){

        Signup.registerUserUntilDone(USER2).then(
            function (user) {
                console.log("USER2 Username: ", user.username);

                USER2.username = user.username;
                USER2.email = user.email;

                //Auth.loginAsUser(USER2.username, USER2.password);
            }
        );
    });

    it("verify USER2", function() {
        Signup.verifyEmail(USER2);
        //Auth.logOut();
    });

});


describe("Create discussable content objects: ", function(){

    it("USER1 (content creator) login", function() {
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Create event", function(){
        Events.createNewUnique(EVENT).then(function(event){
            EVENT.url = event.url;
            EVENT.name = event.name;
            console.log("Event Url: ", EVENT.url);
        });
    });

    it("Create place", function(){
        Places.createNewInMoscow(PLACE).then(function(place){
            console.log("Place url: ", place.url);
            PLACE.url = place.url;
        });
    });

    it("Create private place", function(){
        Places.createNewInMoscow(PRIVATE_PLACE).then(function(place){
            console.log("Private place url: ", place.url);
            PRIVATE_PLACE.url = place.url;
        });
    });

    it("Create album", function() {
        
        Albums.createNew(USER1, ALBUM).then(function(album){
            ALBUM.url = album.albumUrl;
            ALBUM.photoUrl = album.photoUrl;
        });
    });     

    /*it("USER1 (content creator) logout", function() {
        Auth.logOut();
    });*/
    
});

describe("Every discussable content should have xPost form: ", function(){

    it("Check xPost form on event page", function(){
        
        browser.get(EVENT.url);
        browser.waitForAngular();
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeTruthy();

    });

    it("Check xPost form on place page", function(){
        
        browser.get(PLACE.url);
        browser.waitForAngular();
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeTruthy();

    });

    it("Check xPost form on photo page", function(){
        
        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeTruthy();

    });

    it("Check xPost form on user wall", function(){
        
        browser.get('/users/' + USER1.username );
        browser.waitForAngular();
        expect(element(by.name('addXPostForm')).isDisplayed()).toBeTruthy();

    });
});

describe("Posts operations: ", function(){

    it("Empty posts are not allowed", function(){

        element(by.name("addXPostForm")).submit();
        expect(element(by.xpath("//*[@data-protractor-id='xPostBodyRequired']")).isDisplayed()).toBeTruthy();
    });

    it("Expect pnotify after submit", function(){

        element(by.id('xPostBody')).sendKeys("Post: 1");

        element(by.name("addXPostForm")).submit();
        expect(element(by.className('ui-pnotify-title')).isDisplayed()).toBe(true);

    });

    it("posts infinite scrolling", function(){

        var N_POSTS = 15;
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        for(var i = 1; i < N_POSTS; i ++){
            element( by.id('xPostBody') ).sendKeys("Post: " + (i + 1) );
            element( by.name('addXPostForm') ).submit();
        }

        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        element.all(by.xpath('//*[@data-protractor-id="xPostEntry"]')).then(function(elements){
            expect(elements.length).toBe(10);

            browser.executeScript('window.scrollTo(0,document.body.scrollHeight);').then(function () {
                element.all(by.xpath('//*[@data-protractor-id="xPostEntry"]')).then(function(elements){
                    expect(elements.length).toBe(16); // 15 posts + 1 album post
                });
            });
        });
    });

    it("discussion is not available to anonymous users", function(){
        element(by.xpath('//*[@data-protractor-id="discussionLink"]')).getAttribute("href").then(function(discussionUrl){
            console.log("Public discussion url: ", discussionUrl);

            browser.get(discussionUrl);
            browser.waitForAngular();

            expect(element(by.name('addXPostForm')).isDisplayed()).toBeTruthy();

            Auth.logOut();

            browser.get(discussionUrl);
            browser.waitForAngular();

            expect(element(by.name('addXPostForm')).isDisplayed()).toBeFalsy();
        });
    });

    it("private post discussion is not available to everyone", function(){
        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get(PRIVATE_PLACE.url);
        browser.waitForAngular();

        //browser.get('/users/' + USER1.username );

        element( by.id('xPostBody') ).sendKeys("Private post to private place");
        //Visibility.setVisibility({visibility: 0}, 'xPost');
        element( by.name('addXPostForm') ).submit();
        browser.waitForAngular();

        element(by.xpath('//*[@data-protractor-id="discussionLink"]')).getAttribute("href").then(function(discussionUrl){
            console.log("Private discussion url: ", discussionUrl);

            Auth.loginAsUser(USER2.username, USER2.password);

            browser.get(discussionUrl);
            browser.waitForAngular();
            expect(browser.getCurrentUrl()).toContain('/403');

            // Add post to place wall, this will be user in future tests
            browser.get(PLACE.url);
            browser.waitForAngular();

            element( by.id('xPostBody') ).sendKeys("USER2 test post1");
            element( by.name('addXPostForm') ).submit();
            browser.waitForAngular();
            
        });

    });

    // event, place, photo, wall discussion settings
    it("Event discussion settings", function(){

        Auth.loginAsUser(USER1.username, USER1.password);

        browser.get(EVENT.url);
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//*[@data-protractor-id='discussionSettingsLink']")).click();

        expect(element(by.xpath("//*[@data-protractor-id='discussionSettingsModal']")).isDisplayed()).toBeTruthy();
        expect(element(by.xpath("//*[@data-protractor-id='discussionToggle']")).isDisplayed()).toBeTruthy();

        expect(element(by.id("discussion_date1")).isDisplayed()).toBeTruthy();
        expect(element(by.id("discussion_date2")).isDisplayed()).toBeTruthy();

        element(by.xpath("//*[@data-protractor-id='discussionToggle']")).click();
        element(by.name("discussionSettingsForm")).submit();

        browser.get(EVENT.url);
        browser.waitForAngular();

        expect(element(by.name('addXPostForm')).isDisplayed()).toBeFalsy();
    });

    it("Place discussion settings", function(){

        browser.get(PLACE.url);
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//*[@data-protractor-id='discussionSettingsLink']")).click();

        expect(element(by.xpath("//*[@data-protractor-id='discussionSettingsModal']")).isDisplayed()).toBeTruthy();

    });

    it("Photo discussion settings", function(){

        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='discussionSettingsLink']")).click();
        expect(element(by.xpath("//*[@data-protractor-id='discussionSettingsModal']")).isDisplayed()).toBeTruthy();

    });

    it("Wall discussion settings", function(){

        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='discussionSettingsLink']")).click();
        expect(element(by.xpath("//*[@data-protractor-id='discussionSettingsModal']")).isDisplayed()).toBeTruthy();

    });


    it("Answer to a post", function(){
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();
    
        element(by.xpath('//*[@data-protractor-id="discussionLink"]')).getAttribute("href").then(function(discussionUrl){
            console.log("Test answer in discussion url: ", discussionUrl);
            browser.get(discussionUrl);
            browser.waitForAngular();

            element(by.id('xPostBody')).sendKeys("Test answer");
            element(by.name("addXPostForm")).submit();
            browser.waitForAngular();

            browser.sleep(9999999999999);

            element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
                expect(txt).toContain("Test answer");
            });
        });

    });

    it("Owner can remove other posts", function(){
        browser.get(PLACE.url);
        browser.waitForAngular();


        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).element(by.xpath('//*[@data-protractor-id="xPostMenu"]')).click();
        element(by.xpath('//*[@data-protractor-id="deletePost"]')).click();

        element(by.xpath("(//*[@data-protractor-id='confirmYes'])")).click();

        expect( element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).isPresent() ).toBeFalsy();
        /*element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
            expect(txt).not.toContain("USER2 test post1");
        });*/
    });

    it("Owner can edit his own posts", function(){
        browser.get(PLACE.url);
        browser.waitForAngular();
        

        element( by.id('xPostBody') ).sendKeys("Edit me please!");
        element( by.name('addXPostForm') ).submit();
        browser.waitForAngular();

        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
            expect(txt).toContain("Edit me please!");

            element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).element(by.xpath('//*[@data-protractor-id="xPostMenu"]')).click();
            element(by.xpath('//*[@data-protractor-id="editPost"]')).click();

            element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).element( by.id('xPostBody') ).clear();
            element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).element( by.id('xPostBody') ).sendKeys("Done");

            element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).element(by.name("addXPostForm")).submit();
            browser.waitForAngular();

            element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
                expect(txt).toContain("Done");
            });
        });


    });

    it("User1 logout", function(){
        Auth.logOut();
    });

    it("User can remove his own posts", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get(PLACE.url);
        browser.waitForAngular();

        element( by.id('xPostBody') ).sendKeys("USER2 test post2");
        element( by.name('addXPostForm') ).submit();
        browser.waitForAngular();

        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
            expect(txt).toContain("USER2 test post2");
        });

        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).element(by.xpath('//*[@data-protractor-id="xPostMenu"]')).click();
        element(by.xpath('//*[@data-protractor-id="deletePost"]')).click();
        element(by.xpath("(//*[@data-protractor-id='confirmYes'])")).click();


        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
            expect(txt).not.toContain("USER2 test post2");
        });
        
    });
    
    it("User can complain about posts", function(){
        browser.get(PLACE.url);
        browser.waitForAngular();
        element(by.xpath('//*[@data-protractor-id="xPostEntry"]//button[@data-do-complain]')).click();
        browser.waitForAngular();

        expect(
            element(by.xpath('//*[@data-protractor-id="xPostEntry"]//button[@data-do-complain]')).isDisplayed()
        ).toBeFalsy();
    });

});

describe("Posts moderation: ", function(){

    var postText = "Post for moderation",
        banButton = protractor.By.xpath('//tr//td[text()="'+postText+'"]/following-sibling::td[2]//a[@name="ban_button"]');
    
    it("Set moderation settings", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'false');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

    it("New post should be sent to manual moderation and marked as 'being moderated'", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        element( by.id('xPostBody') ).sendKeys("This is for moderation x2");
        element( by.name('addXPostForm') ).submit();
        browser.waitForAngular();
        browser.sleep(5000);
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        expect(element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).element(by.xpath('//*[@data-protractor-id="isBeingModeratedPost"]')).isDisplayed() ).toBeTruthy();
        Auth.logOut();
    });

    /*it("Other user must see the post", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
            expect(txt).toContain(postText);
        });
        Auth.logOut();
    });*/
    
    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

    it("Log in as admin", function(){
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
    });

    it("Admin can ban post", function(){
        browser.get(ADMIN_URL +  '/admin/xpost/xpost/');
        expect(browser.findElement(banButton).isDisplayed()).toBeTruthy();
    });

    it("Ban post", function(){
        browser.findElement(banButton).click();
        expect( element(by.id("banReason")).isDisplayed() ).toBeTruthy();
        element( by.id("banReasonDescription") ).sendKeys("Пост заблокирован");
        element( by.xpath("//button[@onclick='doBan();']") ).click();

    });

    it("Log out admin", function(){
        browser.ignoreSynchronization = false;
        browser.get('/');
        Auth.logOut();
    });

    it("User2 can't see the post on user1 wall now", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
            expect(txt).not.toContain(postText);
        });
        Auth.logOut();
    });

    it("User1 can still see the post on his wall, but it's marked as banned", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/users/' + USER1.username);
        browser.waitForAngular();

        element(by.xpath('//*[@data-protractor-id="xPostEntry"]')).getText().then(function(txt){
            expect(txt).toContain(postText);
        });

        expect(element(by.xpath('//*[@data-protractor-id="xPostEntry"]//*[@data-protractor-id="isBannedPost"]')).isDisplayed() ).toBeTruthy();

        Auth.logOut();
    });


});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
