'use strict';

var path = require('path'),
    uploadPhotoPath = path.resolve(__dirname, '..', 'test_data', "photo.jpg"),
    USER1 = {
        'username': 'user11',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1profile@mail.com',
        'phone': '+79111225002',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user12',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2profile@mail.com',
        'phone': '+79111225003',
        'age': 25,
        'password': 'hackme'
    },
    ALBUM = {
        title: 'Test1 album',
        //tag: 'albumtag',
        visibility: '2',
        description: 'album description',
        uploadPhotoPath: uploadPhotoPath
    },
    ALBUM2 = {
        title: 'Test2 album',
        //tag: 'albumtag2',
        visibility: '2',
        description: 'album2 description',
        uploadPhotoPath: uploadPhotoPath
    },
    Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    Albums = require('../utils/albums.js'),
    Settings = require('../utils/settings.js'),
    albumUrl = "";


var addAlbumBtn = element(by.xpath("//*[@data-protractor-id='addAlbum']")),
    activeModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));

function findVisibleElement(selector){
    return protractor.promise.filter(element.all(selector), function(e) { 
        return e.isDisplayed(); 
    }).then(function(visibleElements) {
        expect(visibleElements.length).toBe(1);
        return visibleElements[0];
    }); 
}

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });
    /*
    it("button should be present", function() {
        USER1.username = "user50";
        
        Auth.loginAsUser(USER1.username, USER1.password);

        Albums.createNew(USER1, ALBUM);
    });
     */


}); 

describe("Register users:", function(){

    it("Register USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;
            console.log('User1:', USER1.username);
            Signup.verifyEmail(USER1);
        });
    });
    
    it("Register USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('User2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

});


describe("User can create album in his profile:", function(){

    it("button should be present", function() {
        
        Auth.loginAsUser(USER1.username, USER1.password);
        
        browser.get( Albums.getUserAlbumsUrl(USER1) );
        browser.waitForAngular();
        

        expect( element(by.name("addXPostForm")).isDisplayed() ).toBeTruthy();
    });
    
});

describe("Album creation:", function(){

    var albumsSectionVisibility = -1;
    it("button should be shown", function() {
        //addAlbumBtn.click();
        element(by.name("addXPostForm")).submit();
        expect(element(by.xpath("//*[@data-protractor-id='addFilesError']")).isDisplayed()).toBeTruthy();
    });

    it("at least 1 photo is enougth to create an album", function() {
        browser.get( Albums.getUserAlbumsUrl(USER1) );
        browser.waitForAngular();
        expect( element(by.name("addXPostForm")).isDisplayed() ).toBeTruthy();
        //addAlbumBtn.click();
        element(by.id('post-form-file-input')).sendKeys(uploadPhotoPath);
        
        element(by.name("addXPostForm")).submit();
    });

    it("check default album title", function() {

        var d = new Date();
        browser.get( Albums.getUserAlbumsUrl(USER1) );
        browser.waitForAngular();

        var newAlbum = element(by.xpath('//a[@data-protractor-id="albumTitle"]'));
        expect( newAlbum.isDisplayed()).toBe(true);
        
        newAlbum.getText().then(function(title){
            expect(title).toContain("Новый альбом");
            expect(title).toContain(d.getFullYear());
            expect(title).toContain(d.getDate());
            
        });

        newAlbum.getAttribute("href").then(function(url){
            albumUrl = url;
        });

    });

    it("get albums section visibility", function() {
        
        //browser.get( Albums.getUserAlbumsUrl(USER1) );
        //browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='sectionVisibility']")).click();

        activeModal.element(by.name('visibility')).element(by.xpath('option[@selected]')).getAttribute('value').then(
            function(visibilityVal){
                albumsSectionVisibility = visibilityVal;
            }
        );

    });


    it("album should have visibility settings, matching section visibility by default", function() {

        var vsBtn = element(by.xpath("//*[@data-protractor-id='albumVisibility']"));
        browser.get( albumUrl );
        browser.waitForAngular();
        expect(vsBtn.isDisplayed()).toBeTruthy();
        vsBtn.click();

        expect(activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "'+ albumsSectionVisibility+'"]')).isSelected()).toBeTruthy();

        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//*[@data-protractor-id='cancelVisibility']")).click();

    });

    it("photo should have visibility settings, matching section visibility by default", function() {

        var vsBtn = browser.findElement( by.xpath("//*[@data-protractor-id='photoVisibility']") );

        browser.executeScript(scrollIntoView, vsBtn);
        //postMenu.click();
        //var vsBtn = element(by.xpath("//*[@data-protractor-id='photoVisibility']"));
        expect(vsBtn.isDisplayed()).toBeTruthy();
        vsBtn.click();

        expect(activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "'+ albumsSectionVisibility +'"]')).isSelected()).toBeTruthy();
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//*[@data-protractor-id='cancelVisibility']")).click();
    });

    it("photos must inherit album visibility", function() {

        Albums.createNew(USER1, ALBUM).then(function(album){
            console.log("ALBUM url: ", album.albumUrl);
            ALBUM.url = album.albumUrl;
            ALBUM.photoUrl = album.photoUrl;
            
            browser.get( ALBUM.photoUrl );
            browser.waitForAngular();
            
            var vsBtn = element(by.xpath("//*[@data-protractor-id='editPhotoVisibility1']"));
            expect(vsBtn.isDisplayed()).toBeTruthy();
            vsBtn.click();
            expect(activeModal.element(by.name('visibility')).element(by.xpath('option[@value = "2"]')).isSelected()).toBeTruthy();
            element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//*[@data-protractor-id='cancelVisibility']")).click();

        });
    });

    it("album title and photo title are required", function() {
        browser.get( ALBUM.url );
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='editAlbum']")).click();

        activeModal.element(by.model('entity.title')).clear();
        expect(element(by.xpath("//*[@data-protractor-id='albumTitleRequired']")).isDisplayed()).toBeTruthy();

        browser.get( ALBUM.photoUrl );
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='editPhoto']")).click();
        element(by.model('entity.title')).clear();

        element(by.name('editPhotoForm')).submit();
        browser.waitForAngular();

        expect(element(by.xpath("//*[@data-protractor-id='photoTitleRequired']")).isDisplayed()).toBeTruthy();

    });

    it("album should be shown on user wall as a post", function() {

        browser.get( '/users/' + USER1.username );
        browser.waitForAngular();
        
        element( by.repeater("post in xPosts") ).getText().then(function(postsText){
            expect(postsText).toContain(ALBUM.description);
        });
    });

    it("clicking on album title should open it", function() {
        browser.get( Albums.getUserAlbumsUrl(USER1) );
        browser.waitForAngular();

        var album = browser.findElement( by.xpath("(//*[@data-protractor-id='albumTitle'])[1]") );
        browser.executeScript(scrollIntoView, album);

        album.click();

        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toEqual(ALBUM.url);
    });

    it("clicking on photo should open slideshow", function() {
        browser.get( Albums.getUserAlbumsUrl(USER1) );
        browser.waitForAngular();

        var photo = browser.findElement( by.xpath("(//*[@data-protractor-id='photoPreview'])[1]") );
        browser.executeScript(scrollIntoView, photo);

        expect( photo.isDisplayed() ).toBeTruthy();

        photo.click();
        browser.waitForAngular();

        expect( element(by.id('blueimp-gallery')).isDisplayed() ).toBeTruthy();

    });

    it("slideshow close", function() {
        //element(by.xpath("(//div[@id='blueimp-gallery']//a[@class='close'])[2]")).click();

        //element(by.xpath("//div[@data-gallery-slideshow]//a[@class='close']")).click();
        element(by.xpath("//a[@class='close']")).click();
        browser.waitForAngular();
        //expect(browser.getCurrentUrl()).toContain(ALBUM.photoUrl);
        
    });
    
    it("move/remove buttons should be present", function() {


        browser.get(ALBUM.url);
        browser.waitForAngular();
        expect(element(by.xpath("//*[@data-protractor-id='moveToAlbum']")).isDisplayed()).toBeTruthy();
        expect(element(by.xpath("//*[@data-protractor-id='removePhoto']")).isDisplayed()).toBeTruthy();

        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();
        //expect(element(by.xpath("//*[@data-protractor-id='moveToAlbum']")).isDisplayed()).toBeTruthy();
        expect(element(by.xpath("//*[@data-protractor-id='removePhoto']")).isDisplayed()).toBeTruthy();

        var editPhotoLink = element(by.xpath("//*[@data-protractor-id='editPhoto']"));
        expect(editPhotoLink.isDisplayed()).toBeTruthy();

        editPhotoLink.click();

        expect(activeModal.isDisplayed()).toBeTruthy();

        expect(element(by.model("entity.title")).isDisplayed()).toBeTruthy();
        expect(element(by.model("entity.description")).isDisplayed()).toBeTruthy();
        expect(element(by.model("entity.tags")).isDisplayed()).toBeTruthy();

    });

    it("photo page should have discussion", function() {
        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();

        expect(element(by.name("addXPostForm")).isDisplayed()).toBeTruthy();
    });

    it("photo page should have likes", function() {
        expect(element(by.xpath("//*[@data-protractor-id='addPhotoLike']")).isDisplayed()).toBeTruthy();
    });

    it("photo page should have visibility settings", function() {
        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();
        expect(element(by.xpath("//*[@data-protractor-id='editPhotoVisibility1']")).isDisplayed()).toBeTruthy();
    });


    xit("Merge 2 albums", function() {

        Albums.createNew(USER1, ALBUM2).then(function(album){

            console.log("ALBUM2 url: ", album.albumUrl);

            ALBUM2.url = album.albumUrl;
            ALBUM2.photoUrl = album.photoUrl;

            browser.get(ALBUM2.url);
            browser.waitForAngular();

            element(by.xpath("//*[@data-protractor-id='openMergeModal']")).click();

            //expect(element(by.id("select_tomerge")).isDisplayed()).toBeTruthy();
            element(by.id("s2id_select_to_merge")).click();
            element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(ALBUM.title);

            element(by.xpath('(//div[@id="select2-drop"]//ul[@class="select2-results"]//div)[1]')).click();

            element(by.name("mergeForm")).submit();
            browser.waitForAngular();

            browser.get(ALBUM2.url);
            browser.waitForAngular();

            expect(browser.getCurrentUrl()).toContain('/404');
            
            browser.get(ALBUM2.url);

            
            browser.get(ALBUM.url);
            browser.waitForAngular();

            expect(element.all(by.xpath('//img[starts-with(@data-ui-sref, "user.photo(")]')).count()).toEqual(2);

        });

    });

    it("photo page should not have visibility settings for anonymous", function() {
        
        Auth.logOut();

        browser.get(ALBUM.photoUrl);
        browser.waitForAngular();


        expect(element(by.xpath("//*[@data-protractor-id='editPhotoVisibility1']")).isDisplayed()).toBeFalsy();

    });


});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
