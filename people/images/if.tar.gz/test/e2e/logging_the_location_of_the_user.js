var USER = {
        'username': 'Santos',
        'first_name': 'Marales',
        'last_name': 'Escabara',
        'email': 'santos@mail.com',
        'phone': '+79111222000',
        'age': 32,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'Santos',
        'first_name': 'Marales',
        'last_name': 'Escabara',
        'email': 'santos@mail.com',
        'phone': '+79111222000',
        'age': 32,
        'password': 'hackme'
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE2 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    };

var Auth = require('../utils/auth.js'),
    Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

var favorite_place = '';

browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users: ", function() {
    
    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

    it("registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

});

describe("Test change user location: ", function(){

    it("create place", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Places.createNewInMoscow(PLACE);
        Auth.logOut();
    });

    it("create place2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        Places.createNewInMoscow(PLACE2);
        Auth.logOut();
    });

    it("add first place to favorite and get place name", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places?tags=' + PLACE2.name + 'show=list');
        browser.waitForAngular(); 
        
        element(by.xpath("//button[contains(@class,'favorite') and contains(@data-do-favorite, '')]")).click();

        element(by.xpath("//h1[@class='content-object__info__title']//a")).getText().then(function(text){
            favorite_place = text;
            Auth.logOut();
        }); 
    });

    it("place name is required and in dropdown must user places and favorite", function() {
        Auth.loginAsUser(USER.username, USER.password);

        element(by.xpath("//button[@data-protractor-id='userProfile']")).click();
        expect(element(by.id("save-location-history")).isPresent()).toBe(true);
        element(by.id("save-location-history")).click();

        browser.driver.sleep(5000); // wait for response 

        expect(element(by.xpath("//form[@name='userPlaceForm']")).isDisplayed()).toBe(true);
        element(by.xpath("//form[@name='userPlaceForm']")).submit()
        expect(element(by.xpath("//form[@name='userPlaceForm']")).isDisplayed()).toBe(true);

        expect(element(by.xpath("//button[contains(@data-select-visibility, '') and contains(@data-entity, 'visibilityEntity')]")).isPresent()).toBe(true);
        
        element(by.xpath("//div[@id='s2id_place']//a")).click();
        browser.driver.sleep(2000);

        expect(element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE.name + "']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//ul[@class='select2-results']//div[text()='" + favorite_place + "']")).isDisplayed()).toBe(true);
        Auth.logOut();

    });

});