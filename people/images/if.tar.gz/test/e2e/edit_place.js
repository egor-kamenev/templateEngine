var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 25,
        'password': 'hackme'
    },
    PLACE = {
        'name': 'place',
        'visibility': '4'
    },
    PLACE2 = {
        'name': 'place',
        'visibility': '4'
    },
    PLACE3 = {
        'name': 'place',
        'visibility': '4'
    },
    PLACE4 = {
        'name': 'place',
        'visibility': '4'
    },
    PLACE5 = {
        'name': 'place',
        'visibility': '4'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(20, 9,20),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12,20),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(35, 8, 20),

        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT4 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(36, 10, 20),

        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT5 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(33, 14, 20),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    };
    

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Bookmarks = require('../utils/bookmarks.js'),
    TagSelector = require('../utils/tagSelector.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js'),
    moment = require('moment'),
    Visibility = require('../utils/visibility.js');

var EVENT_MIN_START_OFFSET = 2;

browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

});

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users:", function(){

    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });
    
    it("Registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);

        });
    });

});

describe("Edit place:", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE);
        Auth.logOut();
    });

    it("only owner can edit place", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places/' + PLACE.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();

        expect(element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).isPresent()).toBeFalsy();
        Auth.logOut();
    });

    it("edit place", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        var map = element(by.xpath('//div[@data-protractor-id="placeFormMap"]'));

        //element(by.xpath("//input[@id='place_name']")).clear();
        //element(by.xpath("//input[@id='place_name']")).sendKeys(PLACE.name);
        element(by.xpath("//textarea[@id='place_description']")).sendKeys('Test description');

        var latitudeBorders = Array(55.61558902526749, 55.89225616635061),
            longitudeBorders = Array(37.437286376953125, 37.79296875);

        function randomInRange(min, max) {
            return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
        }

        PLACE.lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
        PLACE.lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);

        browser.actions().doubleClick(map).perform();

        element(by.model('place_lat')).clear();
        element(by.model('place_lng')).clear();

        element(by.model('place_lat')).sendKeys(PLACE.lat);
        element(by.model('place_lng')).sendKeys(PLACE.lng);

        element(by.xpath("//li[@class='select2-search-choice']/a")).click(); //delete tag
        TagSelector.selectSecondTag('s2id_place_tags');

        PLACE.visibility = '0'; //new visibility

        Visibility.setVisibility(PLACE, 'placeform');

        element(by.name('placeForm')).submit();
        Auth.logOut();
    });

});

describe("Add event to place, and try set lower privacy:", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT);
        console.log('EVENT:', EVENT.name);
    });

    it("create place", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Places.createNewInMoscow(PLACE2);
        Auth.logOut();
    });

    it("add place to event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE2.name);

        //browser.driver.sleep(5000);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE2.name + "']")).click();
        //browser.driver.sleep(2000);
        element(by.xpath("//form[@name='eventForm']")).submit();

        browser.waitForAngular();

        //browser.driver.sleep(2000);
        Auth.logOut();
    });

    /*it("Wait", function(){
        browser.driver.sleep(5000);
    });*/

    it("try edit place and add lower privacy", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places/' + PLACE2.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        PLACE.visibility = '0'; //new visibility

        Visibility.setVisibility(PLACE2, 'placeform');

        element(by.name('placeForm')).submit();
        Auth.logOut();
    });

});

/* in first release user can't change place name
describe("Edited if the place has been carried out in the event it, changing the name of the place should be made to create a new place, and edited the old place should be marked as disebled", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE3);
        Auth.logOut();
    });

    it("create event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        EVENT2.ts_start = moment().add(3, 'm').format("DD.MM.YYYY HH:mm");
        EVENT2.ts_finish = moment().add(5, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT2);
        console.log('EVENT2:', EVENT2.name);
    });

    it("add place to event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT2.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE3.name);

        browser.driver.sleep(5000);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE3.name + "']")).click();
        browser.driver.sleep(2000);
        element(by.xpath("//form[@name='eventForm']")).submit();

        browser.driver.sleep(2000);
        Auth.logOut();
    });

    it("wait event finished", function(){
        browser.driver.sleep(360000);
    });

    it("change place name", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE3.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        PLACE3.newName = PLACE3.name + '9';

        var map = element(by.xpath('//div[@data-protractor-id="placeFormMap"]'));

        element(by.xpath("//input[@id='place_name']")).clear();
        element(by.xpath("//input[@id='place_name']")).sendKeys(PLACE3.newName);

        element(by.name('placeForm')).submit();
        Auth.logOut();
    });

    it("test is new place is created?", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE3.newName);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/places/' + PLACE3.newName);
        Auth.logOut();
    });

    it("disebled place can't add to event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Events.createNew(EVENT3);
        console.log('EVENT3:', EVENT3.name);
       
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE3.name);

        browser.driver.sleep(5000);

        expect(element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE3.name + "']")).isPresent()).toBe(false);
        Auth.logOut();
    });

});
*/

describe("user can't change place name", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE5);
        Auth.logOut();
    });

    it("check readonly on name input", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE5.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        element(by.xpath("//input[@id='place_name']")).getAttribute('readonly').then(function(text){
            expect(text).toEqual('true');  
        });
    });

});

describe("Edited if the place has been carried out in the event it, changing the adress of the place should be marked as disebled: ", function(){

    it("create PLACE4 and EVENT4", function(){

        Auth.loginAsUser(OWNER.username, OWNER.password);

        Places.createNewInMoscow(PLACE4).then(function(place){
            console.log("PLACE4 url: ", place.url);
            console.log("PLACE4 name: ", place.name);
            PLACE4.url = place.url;
            PLACE4.name = place.name;
        }).then(function(){
            Auth.logOut();

            Auth.loginAsUser(USER.username, USER.password);

            EVENT4.ts_start = moment().add(EVENT_MIN_START_OFFSET, 'm').format("DD.MM.YYYY HH:mm");
            EVENT4.ts_finish = moment().add(EVENT_MIN_START_OFFSET+1, 'm').format("DD.MM.YYYY HH:mm");
            
            Events.createNewUnique(EVENT4).then(function(event){
                EVENT4.url = event.url;
                EVENT4.name = event.name;
                
                console.log("EVENT4 url: ", EVENT4.url);
                console.log("EVENT4 name: ", EVENT4.name);
                Auth.logOut();
            });

        });
        
    });

    it("add place to event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE4.name);

        browser.driver.sleep(2000);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE4.name + "']")).click();
        browser.driver.sleep(2000);
        element(by.xpath("//form[@name='eventForm']")).submit();

        browser.driver.sleep(2000);
        Auth.logOut();
    });

    it("wait event finished", function(){
        var timeout = (EVENT_MIN_START_OFFSET+1) * 60000;
        console.log("Waiting ", timeout/1000.0, " seconds for event to complete....");
        browser.sleep(timeout);
    });

    it("change place adress", function(){
        
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE4.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

        var placeForm = element(by.name('placeForm')),
            map = element(by.xpath('//div[@data-protractor-id="placeFormMap"]'));

        element(by.xpath("//textarea[@id='place_description']")).sendKeys('Test description');

        var latitudeBorders = Array(55.61558902526749, 55.89225616635061),
            longitudeBorders = Array(37.437286376953125, 37.79296875);

        function randomInRange(min, max) {
            return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
        }

        PLACE4.lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
        PLACE4.lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);

        browser.actions().doubleClick(map).perform();

        element(by.model('place_lat')).clear();
        element(by.model('place_lng')).clear();

        element(by.model('place_lat')).sendKeys(PLACE4.lat);
        element(by.model('place_lng')).sendKeys(PLACE4.lng);

        browser.driver.sleep(5000);

        placeForm.submit();
        Auth.logOut();
    });

    it("check is new place created", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places/' + PLACE4.name + '-2');
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();
    });

    it("create EVENT5", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Events.createNew(EVENT5);
        console.log('EVENT5:', EVENT5.name);
        Auth.logOut();
    });

    it("add old place to EVENT5 and check in old place linked to new", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT5.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE4.name);

        //browser.driver.sleep(2000);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE4.name + "']")).click();
        //browser.driver.sleep(2000);
        element(by.xpath("//form[@name='eventForm']")).submit();

        browser.waitForAngular();
        browser.sleep(2000);

        element(by.xpath("//a[text()='" + PLACE4.name + "']")).click();

        expect(browser.getCurrentUrl()).toContain('/places/' + PLACE4.name + '-2');
        Auth.logOut();
    });

});



