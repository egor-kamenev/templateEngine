'use strict';

var OWNER = {
        'username': 'ownerBan',
        'first_name': 'Owner',
        'last_name': 'Tester',
        'email': 'ownerban@mail.com',
        'phone': '+79111224000',
        'age': 30,
        'password': 'hackme'
    },
    USER1 = {
        'username': 'user1Ban',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1ban@mail.com',
        'phone': '+79111224001',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user2Ban',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2ban@mail.com',
        'phone': '+79111224002',
        'age': 25,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'eventban' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test userban',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE = {
        'name': 'placeban'  + Math.floor(Math.random()*1000000),
        'visibility': '4'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Signup = require('../utils/signup.js');

var selectDropdownbyNum = function (element, optionNum) {
    if (optionNum) {
        var options = element.all(by.tagName('option')).then(
            function(options) {
                options[optionNum].click();
            }
        );
    }
};

var addComment = function(url, text) {
    browser.get(url);
    browser.waitForAngular();
    element(by.id('xPostBody')).sendKeys(text);
    element(by.name('addXPostForm')).submit();
};

var checkPossibilityToComment = function(url, result) {
    browser.get(url);
    browser.waitForAngular();
    
    browser.driver.sleep(1000);

    expect(browser.getCurrentUrl()).toContain(result);
};

var banUser = function(url, remove_messages) {
    browser.get(url);
    browser.waitForAngular();
    element(by.xpath('//button[@data-add-userban]')).click();
    if (remove_messages) {
        element(by.id('remove_user_messages')).click();
    }
    element(by.name('banUserForm')).submit();
};

var checkCommentExists = function(url, result) {
    browser.get(url);
    browser.waitForAngular();
    expect(element(by.xpath('//li[@class="comment"]')).isPresent()).toBe(result);
};

describe("Register users: ", function() {
    
    it("Registrate OWNER", function(){
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            //Auth.loginAsUser(OWNER.username, OWNER.password);
            //Signup.addPhone(OWNER);
        });
    });

    it("Verify OWNER", function() {
        Signup.verifyEmail(OWNER);
        //Signup.verifyPhone(OWNER);
        //Auth.logOut();
    });
    
    it("Registrate USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;
            console.log('USER1:', USER1.username);
            //Auth.loginAsUser(USER1.username, USER1.password);
            //Signup.addPhone(USER1);
        });
    });

    it("Verify USER1", function() {
        Signup.verifyEmail(USER1);
        //Signup.verifyPhone(USER1);
    });
    
    it("Registrate USER2", function(){
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            //Auth.loginAsUser(USER2.username, USER2.password);
            //Signup.addPhone(USER2);
        });
    });

    it("Verify USER2", function() {
        Signup.verifyEmail(USER2);
        //Signup.verifyPhone(USER2);
        //Auth.logOut();
    });
    
});


describe("Add content: ", function(){
    it("Create event and place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT);
        console.log('Event:', EVENT);
        Places.createNew(PLACE);
        console.log('Place:', PLACE);
        Auth.logOut();
    });
});


describe("Do bans: ", function(){
    
    it("Add comments by USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        addComment('/events/' + EVENT.name, USER1.username + ' comment');
        addComment('/places/' + PLACE.name, USER1.username + ' comment');
        Auth.logOut();
        //browser.sleep(10000);
    });
    
    it("Ban USER1 with delete messages", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        banUser('/events/' + EVENT.name, true);
        banUser('/places/' + PLACE.name, true);
        checkCommentExists('/events/' + EVENT.name, false);
        checkCommentExists('/places/' + PLACE.name, false);
        Auth.logOut();
    });
    
    it("Check ban for USER1", function() {
        Auth.loginAsUser(USER1.username, USER1.password);
        checkPossibilityToComment('/events/' + EVENT.name, '/403');
        checkPossibilityToComment('/places/' + PLACE.name, '/403');
        Auth.logOut();
    });

    it("Check ban message for USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.waitForAngular();

        element(by.xpath("//li[@class='private-mail']//a")).click();
        browser.waitForAngular();

        element(by.xpath("//li[@class='mi']//a[@href='/users/" + USER1.username + "/messages/bans']")).click();
        browser.waitForAngular();

        var elems = element.all(by.repeater('msg in messages'));
        expect(elems.count()).toBe(2);
    });
    
    it("Add comments by USER2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        addComment('/events/' + EVENT.name, USER2.username + ' comment');
        addComment('/places/' + PLACE.name, USER2.username + ' comment');
        Auth.logOut();
        browser.sleep(10000);
    });

    it("Ban USER2 without delete messages", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        banUser('/events/' + EVENT.name, false);
        banUser('/places/' + PLACE.name, false);
        checkCommentExists('/events/' + EVENT.name, true);
        checkCommentExists('/places/' + PLACE.name, true);
        Auth.logOut();
    });

    it("Check ban for USER2", function() {
        Auth.loginAsUser(USER2.username, USER2.password);
        checkPossibilityToComment('/events/' + EVENT.name, '/403');
        checkPossibilityToComment('/places/' + PLACE.name, '/403');
        Auth.logOut();
    });

    it("Check ban message for USER2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.waitForAngular();

        element(by.xpath("//li[@class='private-mail']//a")).click();
        browser.waitForAngular();

        element(by.xpath("//li[@class='mi']//a[@href='/users/" + USER2.username + "/messages/bans']")).click();
        browser.waitForAngular();

        var elems = element.all(by.repeater('msg in messages'));
        expect(elems.count()).toBe(2);
    });
    
    it("Delete bans", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + OWNER.username + '/bans');
        browser.waitForAngular();
        element(by.xpath('//button[@ng-click="removeBan(ban.id)"]')).click();
        element(by.xpath('//button[@ng-click="removeBan(ban.id)"]')).click();
        Auth.logOut();
    });

    it("Check bans", function() {
        Auth.loginAsUser(USER1.username, USER1.password);
        checkPossibilityToComment('/events/' + EVENT.name, '/events/' + EVENT.name);
        checkPossibilityToComment('/places/' + PLACE.name, '/places/' + PLACE.name);
        Auth.logOut();
        Auth.loginAsUser(USER2.username, USER2.password);
        checkPossibilityToComment('/events/' + EVENT.name, '/events/' + EVENT.name);
        checkPossibilityToComment('/places/' + PLACE.name, '/places/' + PLACE.name);
        Auth.logOut();
    });
    
});
