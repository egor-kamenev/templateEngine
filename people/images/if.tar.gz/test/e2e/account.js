'use strict';

var LOGIN_URL = '/auth/login',
	Settings = require('../utils/settings.js'),
	Signup = require('../utils/signup.js'),
    Auth = require('../utils/auth.js'),
    USER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    WORK = {
        'name': 'Пенсионный фонд',
        'start_day': '1'
    },
    WORK2 = {
        'name': 'Министерство обороны',
        'start_day': '3',
        'end_day': '5'
    },
    STUDY = {
        'name': 'Oxford',
        'start_day': '5'
    },
    STUDY2 = {
        'name': 'KHAY',
        'start_day': '1',
        'end_day': '28'
    };

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

browser.driver.manage().window().maximize();

describe("Register user: ", function() {
    
    it("Registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER', USER);
            Signup.verifyEmail(USER);
        });
    });

});

describe("User account: ", function() {
    
    xit("user account must have ", function(){
    	Auth.loginAsUser(USER.username, USER.password);

    	element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	expect(element(by.xpath("//a[@data-protractor-id='userSettings']")).isPresent()).toBe(true);
    	expect(element(by.xpath("//a[@data-protractor-id='userProfile']")).isPresent()).toBe(true);

    	element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        expect(element(by.xpath("//a[@data-protractor-id='userPlaceStudy']")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[@data-protractor-id='userPlaceWork']")).isPresent()).toBe(true);

        Auth.logOut();
    });

    it("check form elements", function(){
    	Auth.loginAsUser(USER.username, USER.password);

        expect(element(by.xpath("//form[@name='profileForm']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='first_name']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='middle_name']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='last_name']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='date_of_birth_date']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='email']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='phone']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='country']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='city']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//input[@id='metro']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//select[@id='gender']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//textarea[@id='about']")).isDisplayed()).toBe(true);
        //expect(element(by.xpath("//select[@id='sex_preference']")).isDisplayed()).toBe(true);
        //expect(element(by.xpath("//select[@id='marital_status']")).isDisplayed()).toBe(true);
        //expect(element(by.xpath("//select[@id='target']")).isDisplayed()).toBe(true);

        Auth.logOut();
    });

    it("check privacy buttons on profile pages", function(){
    	Auth.loginAsUser(USER.username, USER.password);
        var privacyButton = element(by.xpath("//button[contains(@class,'privacy-all') and contains(@type,'button')]"));

        browser.get('/users/'+ USER.username + '/stream');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);
        
        browser.get('/users/'+ USER.username + '/albums');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        browser.get('/users/'+ USER.username + '/events');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        browser.get('/users/'+ USER.username + '/interests');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);
        
        browser.get('/users/'+ USER.username + '/interests');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);
        
        browser.get('/users/'+ USER.username + '/places');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);
        
        browser.get('/users/'+ USER.username + '/friends');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);

        browser.get('/users/'+ USER.username + '/statuses');
        browser.waitForAngular();
        expect(privacyButton.isPresent()).toBe(true);
        Auth.logOut();
    });
    
    it("date of birth can not be changed more than 3 times", function(){
        Auth.loginAsUser(USER.username, USER.password);
        
        expect(element(by.xpath("//*[@data-protractor-id='mayChangeDb']")).isDisplayed()).toBe(true);

        element(by.xpath("//section[@id='date_of_birth']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text(),'16')]")).click();
        element(by.xpath("//form[contains(@name,'profileForm') and contains(@class,'form')]")).submit();

        element(by.xpath("//section[@id='date_of_birth']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text(),'20')]")).click();
        element(by.xpath("//form[contains(@name,'profileForm') and contains(@class,'form')]")).submit();
        
        element(by.xpath("//section[@id='date_of_birth']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text(),'7')]")).click();
        element(by.xpath("//form[contains(@name,'profileForm') and contains(@class,'form')]")).submit();
        
        expect(element(by.xpath("//b[@data-protractor-id='mayChangeDb']")).isDisplayed()).toBe(false);
        expect(element(by.xpath("//b[@data-protractor-id='mayNotChangeDb']")).isDisplayed()).toBe(true);

        element(by.xpath("//section[@id='date_of_birth']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text(),'13')]")).click();
        element(by.xpath("//form[contains(@name,'profileForm') and contains(@class,'form')]")).submit();

        //expect(element(by.xpath("//*[@data-protractor-id='mayNotChangeDb']")).isDisplayed()).toBe(true);

        expect(element(by.xpath("//em[@data-ng-show='profileForm.date_of_birth.$dirty && profileForm.date_of_birth.$invalid && profileForm.date_of_birth.$error.birthdate_changes_limit_hit']")).isDisplayed()).toBe(true);

        Auth.logOut();
    });
    
    it("check addWork form fields", function(){
    	Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeWork');
        browser.waitForAngular();
        
    	// element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceWork']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();

        var addWorkmodal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
        expect(addWorkmodal.isDisplayed()).toBe(true);

        expect(element(by.xpath("//div[@id='s2id_organization']")).isPresent()).toBe(true);
        expect(element(by.xpath("//section[@id='period_begin']")).isPresent()).toBe(true);
        expect(element(by.xpath("//section[@id='period_end']")).isPresent()).toBe(true);

        element(by.xpath("//button[contains(@class,'button') and contains(@data-ng-click ,'close()')]")).click();
        Auth.logOut();
    });
    
    it("add work place only title and start date", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeWork');
        browser.waitForAngular();

        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceWork']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();

        var addWorkmodal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
        expect(addWorkmodal.isDisplayed()).toBe(true);

        element(by.xpath("//div[@id='s2id_organization']")).click();
        element(by.xpath("//input[@id='organization']")).sendKeys(WORK.name);
        element(by.xpath("//div[@id='select2-drop']//ul[@class='select2-results']")).click();

        element(by.xpath("//section[@id='period_begin']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text()," + WORK.start_day + ")]")).click();

        var workForm = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]//form[@name='newOrganizationForm']"));
        workForm.submit();
        Auth.logOut();
    });

    it("Start date is required in addWork", function(){

       	Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeWork');
        browser.waitForAngular();
 
        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceWork']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();

        var addWorkmodal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
        expect(addWorkmodal.isDisplayed()).toBe(true);

        element(by.xpath("//div[@id='s2id_organization']")).click();
        element(by.xpath("//input[@id='organization']")).sendKeys(WORK.name);
        element(by.xpath("//div[@id='select2-drop']//ul[@class='select2-results']")).click();

        var workForm = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]//form[@name='newOrganizationForm']"));
        workForm.submit();

        expect(addWorkmodal.isDisplayed()).toBe(true);
        Auth.logOut();
    });

    it("add work place with start and end date", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeWork');
        browser.waitForAngular();

        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceWork']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();

        var addWorkmodal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
        expect(addWorkmodal.isDisplayed()).toBe(true);

        element(by.xpath("//div[@id='s2id_organization']")).click();
        element(by.xpath("//input[@id='organization']")).sendKeys(WORK2.name);
        element(by.xpath("//div[@id='select2-drop']//ul[@class='select2-results']")).click();

        element(by.xpath("//section[@id='period_begin']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text()," + WORK2.start_day + ")]")).click();

        browser.sleep(1000);

        element(by.xpath("//section[@id='period_end']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text()," + WORK2.end_day + ")]")).click();

        var workForm = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]//form[@name='newOrganizationForm']"));
        workForm.submit();

        Auth.logOut();
    });
    

    it("check addStudy form fields", function(){
        
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeStudy');
        browser.waitForAngular();

        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceStudy']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();
        
        var addStudyModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
        expect(addStudyModal.isDisplayed()).toBe(true);

        expect(element(by.xpath("//div[@id='s2id_organization']")).isPresent()).toBe(true);
        expect(element(by.xpath("//section[@id='period_begin']")).isPresent()).toBe(true);
        expect(element(by.xpath("//section[@id='period_end']")).isPresent()).toBe(true);

        element(by.xpath("//button[contains(@class,'button') and contains(@data-ng-click ,'close()')]")).click();
        Auth.logOut();
    });

    it("add study place only title and start date", function(){

        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeStudy');
        browser.waitForAngular();

        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceStudy']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();
        
        element(by.xpath("//div[@id='s2id_organization']")).click();
        element(by.xpath("//input[@id='organization']")).sendKeys(STUDY.name);
        element(by.xpath("//div[@id='select2-drop']//ul[@class='select2-results']")).click();

        element(by.xpath("//section[@id='period_begin']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text()," + STUDY.start_day + ")]")).click();

        var studyForm = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]//form[@name='newOrganizationForm']"));
        studyForm.submit();
        Auth.logOut();

    });

    it("Start date is required in addStudy", function(){

	Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeStudy');
        browser.waitForAngular();

        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceStudy']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();

        var addStudyModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
        expect(addStudyModal.isDisplayed()).toBe(true);

        element(by.xpath("//div[@id='s2id_organization']")).click();
        element(by.xpath("//input[@id='organization']")).sendKeys(STUDY.name);
        element(by.xpath("//div[@id='select2-drop']//ul[@class='select2-results']")).click();

        var studyForm = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]//form[@name='newOrganizationForm']"));
        studyForm.submit();

        expect(addStudyModal.isDisplayed()).toBe(true);

        element(by.xpath("//button[contains(@class,'button') and contains(@data-ng-click ,'close()')]")).click();
        Auth.logOut();
    });

    it("add study place with start and end date", function(){
        
        Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/placeStudy');
        browser.waitForAngular();

        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

    	// element(by.xpath("//button[@data-protractor-id='userProfileToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userPlaceStudy']")).click();

        // browser.navigate().refresh();

        element(by.xpath("//button[@data-protractor-id='openNewOrganization']")).click();

        var addStudyModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
        expect(addStudyModal.isDisplayed()).toBe(true);

        element(by.xpath("//div[@id='s2id_organization']")).click();
        element(by.xpath("//input[@id='organization']")).sendKeys(STUDY2.name);
        element(by.xpath("//div[@id='select2-drop']//ul[@class='select2-results']")).click();

        element(by.xpath("//section[@id='period_begin']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text()," + STUDY2.start_day + ")]")).click();

        element(by.xpath("//section[@id='period_end']//section//label//input")).click();
        element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text()," + STUDY2.end_day + ")]")).click();

        var studyForm = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]//form[@name='newOrganizationForm']"));
        studyForm.submit();
        Auth.logOut();
    });
    
    it("check settings page", function(){

    	Auth.loginAsUser(USER.username, USER.password);

        browser.get('/users/' + USER.username + '/settings/visible');
        browser.waitForAngular();

    	//element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
    	//element(by.xpath("//a[@data-protractor-id='userSettings']")).click();
    	//browser.navigate().refresh();
    	
        expect(element(by.xpath("//input[@id='is_discoverable']")).isPresent()).toBe(true);
        expect(element(by.xpath("//input[@id='indexable']")).isPresent()).toBe(true);
        expect(element(by.xpath("//form[@name='settingsForm']//input[@type='submit']")).isPresent()).toBe(true);
        
        //browser.driver.sleep(5000);

        /*element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='userSettingsToggle']")).click();
        element(by.xpath("//a[@data-protractor-id='userSettingsSocial']")).click();
        browser.navigate().refresh();
         */

        browser.get('/users/' + USER.username + '/settings/social');
        browser.waitForAngular();

        expect(element(by.xpath("//button[contains(@class,'button') and contains(@class,'vk')]")).isPresent()).toBe(true);
        expect(element(by.xpath("//button[contains(@class,'button') and contains(@class,'facebook')]")).isPresent()).toBe(true);
        expect(element(by.xpath("//button[contains(@class,'button') and contains(@class,'twitter')]")).isPresent()).toBe(true);
        
        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        // element(by.xpath("//button[@data-protractor-id='userSettingsToggle']")).click();
        // element(by.xpath("//a[@data-protractor-id='userSettingsLocale']")).click();
        // browser.navigate().refresh();
        browser.get('/users/' + USER.username + '/settings/locale');
        browser.waitForAngular();

        expect(element(by.xpath("//select[@id='preffered_language']")).isPresent()).toBe(true);
        expect(element(by.xpath("//select[@id='timezone']")).isPresent()).toBe(true);
        
        /*element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='userSettingsToggle']")).click();
        element(by.xpath("//a[@data-protractor-id='userSettingsPassword']")).click();
        browser.navigate().refresh();
         */

        browser.get('/users/' + USER.username + '/settings/password');
        browser.waitForAngular();

        expect(element(by.xpath("//input[@id='id_old_password']")).isPresent()).toBe(true);
        expect(element(by.xpath("//input[@id='passwordinput1']")).isPresent()).toBe(true);
        expect(element(by.xpath("//input[@id='passwordinput2']")).isPresent()).toBe(true); 


        browser.get('/users/' + USER.username + '/settings/remind');
        browser.waitForAngular();
        
        // element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        // element(by.xpath("//button[@data-protractor-id='userSettingsToggle']")).click();

        // element(by.xpath("//a[@data-protractor-id='userSettingsRemind']")).click();

        // browser.navigate().refresh();

        expect(element(by.xpath("//input[@id='remind_checkin_sms']")).isPresent()).toBe(true);

        // T376
        // expect(element(by.xpath("//input[@id='remind_birthdays_sms']")).isPresent()).toBe(true);
        // expect(element(by.xpath("//input[@id='remind_birthdays_message']")).isPresent()).toBe(true);

        expect(element(by.xpath("//input[@id='remind_start_event_sms']")).isPresent()).toBe(true);
        expect(element(by.xpath("//input[@id='remind_checkin_message']")).isPresent()).toBe(true);
        expect(element(by.xpath("//input[@id='remind_start_event_message']")).isPresent()).toBe(true);
        expect(element(by.xpath("//input[contains(@type,'submit') and contains(@class,'button')]")).isPresent()).toBe(true);
        
        Auth.logOut();
    });
    
});    
describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
