'use strict';

var EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'рыбалка',
        'ts_start': evtDate(30, 12, 15),
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4',
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'охота',
        'ts_start': evtDate(30, 11, 0),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': true,
        'visibility': '1',
        'specified_users': []
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30, 11, 0),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': true,
        'visibility': '4'
    },
    EVENT4 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'ts_start': evtDate(30, 11, 0),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '2'
    },
    EVENT5 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'ts_start': evtDate(30, 11, 20),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '3'
    },
    EVENT6 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'ts_start': '',
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT7 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'ts_start': '',
        'ts_finish': '',
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT8 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'ts_start': '',
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT9 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'ts_start': evtDate(30, 11, 25),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': true,
        'visibility': '4'
    },
    EVENT10 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'концерт',
        'ts_start': '',
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 24,
        'password': 'hackme'
    },
    USER3 = {
        'username': 'user',
        'first_name': 'Taras',
        'last_name': 'Bulba',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 32,
        'password': 'hackme'
    },
    USER4 = {
        'username': 'Vasya',
        'first_name': 'Junior',
        'last_name': 'Peskov',
        'email': 'vasyjun@mail.com',
        'phone': '+79111222022',
        'age': 12,
        'password': 'hackme'
    },
    USER5 = {
        'username': 'user',
        'first_name': 'Taras',
        'last_name': 'Bulba',
        'email': 'bigboss@mail.com',
        'phone': '+79111222003',
        'age': 32,
        'password': 'hackme'
    },
    USER6 = {
        'username': 'Vasya',
        'first_name': 'Karas',
        'last_name': 'Peskov',
        'email': 'vasyjun@mail.com',
        'phone': '+79111222027',
        'age': 27,
        'password': 'hackme'
    },
    USER7 = {
        'username': 'Vasya',
        'first_name': 'Karas',
        'last_name': 'Peskov',
        'email': 'vasyjun@mail.com',
        'phone': '+79111222027',
        'age': 27,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Friendship = require('../utils/friendship.js'),
    Settings = require('../utils/settings.js'),
    Participation = require('../utils/participation.js'),
    Signup = require('../utils/signup.js'),
    moment = require('moment');


browser.driver.manage().window().maximize();

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users: ", function() {
    
    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner', OWNER.username);

            Signup.verifyEmail(OWNER);
        });
    });

    it("Registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2', USER2.username);
            EVENT2.specified_users.push(USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

    it("Registrate USER3", function() {
        Signup.registerUserUntilDone(USER3).then(function(userData){
            USER3.username = userData.username;
            USER3.email = userData.email;
            console.log('USER3', USER3.username);
           
            Signup.verifyEmail(USER3);
        });
    });

    it("Registrate USER4", function() {
        Signup.registerUserUntilDone(USER4).then(function(userData){
            USER4.username = userData.username;
            USER4.email = userData.email;
            console.log('USER4', USER4.username);
           
            Signup.verifyEmail(USER4);
        });
    });

    it("Registrate USER5", function() {
        Signup.registerUserUntilDone(USER5).then(function(userData){
            USER5.username = userData.username;
            USER5.email = userData.email;
            console.log('USER5', USER5.username);
           
            Signup.verifyEmail(USER5);
        });
    });

    it("Registrate USER6", function() {
        Signup.registerUserUntilDone(USER6).then(function(userData){
            USER6.username = userData.username;
            USER6.email = userData.email;
            console.log('USER6', USER6.username);
           
            Signup.verifyEmail(USER6);
        });
    });

    it("Registrate USER7", function() {
        Signup.registerUserUntilDone(USER7).then(function(userData){
            USER7.username = userData.username;
            USER7.email = userData.email;
            console.log('USER7', USER7.username);
           
            Signup.verifyEmail(USER7);
        });
    });

});

describe("Create open event:", function(){

    it("Create open event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT);
        console.log('Event:', EVENT.name);

        Auth.logOut();
    });

    it("Try check in user who too young", function() {
        Auth.loginAsUser(USER4.username, USER4.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();
    });
    
    it("Try check in check out..event not started", function(){
        Participation.intendedToGoEvent(USER2, EVENT);
        Participation.eventCountParticipation(USER2, EVENT, 1);

        Participation.intendedNotToGoEvent(USER2, EVENT);
        Participation.eventCountParticipation(USER2, EVENT, 0);
    });

});
    
describe("Create closed event for specified users:", function(){

    it("Create closed event for specified users", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT2);
        console.log('EVENT2:', EVENT2.name);

        Auth.logOut();
    });

    it("Try check in user2 with invitetion..event by invitetion", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/events/' + EVENT2.name);
        browser.waitForAngular();

        Participation.intendedToGoEventByInvitetion(USER2, EVENT2);
        Participation.eventCountParticipation(USER2, EVENT2, 0);
    });

    it("accept invite by owner", function(){
        Participation.eventAcceptUserRequest(OWNER, EVENT2, 0);
    });

    it("check participants", function(){
        Participation.eventCountParticipation(USER2, EVENT2, 1);
    })

    it("Try check in user3 why not in specified users", function(){
        Auth.loginAsUser(USER3.username, USER3.password);
        browser.get('/events/' + EVENT2.name);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();
    });

});
    
describe("Create event by invitetion:", function(){

    it("Create closed event by invitetion:", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT3);
        console.log('EVENT3:', EVENT3.name);
        Auth.logOut();
    });

    it("USER3 send query for owner", function(){
        Participation.intendedToGoEventByInvitetion(USER3, EVENT3);
        Participation.eventCountParticipation(OWNER, EVENT3, 0);
    });

    it("USER2 send query for owner", function(){
        Participation.intendedToGoEventByInvitetion(USER2, EVENT3);
        Participation.eventCountParticipation(OWNER, EVENT3, 0);
    });

    it("Accept USER3 query", function(){
        Participation.eventAcceptUserRequest(OWNER, EVENT3, 0);
        Participation.eventCountParticipation(OWNER, EVENT3, 1);
    });

    it("Reject USER2 query", function(){
        Participation.eventRejectUserRequest(OWNER, EVENT3, 1);
        Participation.eventCountParticipation(OWNER, EVENT3, 1);
    });

});

describe("Create event for friends only:", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT4);
        console.log('Event4:', EVENT4.name);
        Auth.logOut();
    });

    it("beFriends", function(){
        Friendship.beFriends(OWNER, USER2);
    });

    it("try check in if user not friend", function(){
        Auth.loginAsUser(USER3.username, USER3.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();
    });

    it("try check in if user friend", function(){
        Participation.intendedToGoEvent(USER2, EVENT4);
        Participation.eventCountParticipation(USER2, EVENT4, 1);
    });

});

describe("Create event for friend my friends:", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT5);
        console.log('Event5:', EVENT5.name);
        Auth.logOut();
    });

    it("beFriends OWNER --> USER5", function(){
        Friendship.beFriends(OWNER, USER5);
    });

    it("beFriends USER5 --> USER6", function(){
        Friendship.beFriends(USER5, USER6);
    });

    it("try check in if user not friend of my friend:", function(){
        Auth.loginAsUser(USER7.username, USER7.password);
        browser.get('/events/' + EVENT5.name);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();
    });

    it("try check in if user friend of my friend:", function(){
        Participation.intendedToGoEvent(USER6, EVENT5);
        Participation.eventCountParticipation(USER6, EVENT5, 1);
    });

});

describe("Test indent to go after event started:", function(){

    it("Create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT6.ts_start = moment().add(3, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT6);
        console.log('EVENT6:', EVENT6.name);
        browser.waitForAngular();
        Auth.logOut();
    });

    it("Wait for event to get started", function(){
        browser.driver.sleep(180000); // 3 minutes wait
    });

    it("indent to go", function(){
        Participation.intendedToGoEvent(USER2, EVENT6);
        Participation.eventCountParticipation(USER2, EVENT6, 1);
    })

});

describe("Test check in after event finished:", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT7.ts_start = moment().add(3, 'm').format("DD.MM.YYYY HH:mm");
        EVENT7.ts_finish = moment().add(5, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT7);
        console.log('EVENT7:', EVENT7.name);
        browser.waitForAngular();
        Auth.logOut();
    });

    it("wait for event started and ended", function(){
        browser.driver.sleep(360000); // 3 minutes wait
    });

    it("check in and check count participants", function(){
        Participation.iWasThere(USER2, EVENT7)
        Participation.eventCheckIn(USER2, EVENT7);
        Participation.eventCountParticipation(USER2, EVENT7, 1);
    });

});

describe("Test check in after event started:", function(){

    it("Create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT8.ts_start = moment().add(3, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT8);
        console.log('EVENT8:', EVENT8.name);
        browser.waitForAngular();
        Auth.logOut();
    });

    it("indent to go", function(){
        Participation.intendedToGoEvent(USER2, EVENT8);
        Participation.eventCountParticipation(USER2, EVENT8, 1);
    });

    it("wait for event started", function(){
        browser.driver.sleep(200000); 
    });

    it("check in", function(){
        Participation.eventCheckIn(USER2, EVENT8);
    });

    it("check out", function(){
        Participation.eventCheckOut(USER2, EVENT8);
    })

});

describe("Test i want to go event:", function(){

    it("Create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT9);
        console.log('EVENT9:', EVENT9.name);
        browser.waitForAngular();
        Auth.logOut();
    });

    it("test i want to go", function(){
        Participation.iWantTogo(USER2, EVENT9);
    });

});

describe("Test i was not where:", function(){

    it("Create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT10.ts_start = moment().add(3, 'm').format("DD.MM.YYYY HH:mm");
        EVENT10.ts_finish = moment().add(5, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT10);
        console.log('EVENT10:', EVENT10.name);
        browser.waitForAngular();
        Auth.logOut();
    });

    it("wait for event started", function(){
        browser.driver.sleep(200000); 
    });

    it("check in", function(){
        Participation.eventCheckIn(USER2, EVENT10);
    });

    it("wait for event ended", function(){
        browser.driver.sleep(180000); 
    });

    it("test i want to go", function(){
        Participation.iWasNotThere(USER2, EVENT10);
    });

});



