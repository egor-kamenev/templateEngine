'use strict';

var REG_USER = {
        'username': 'TestRegUser',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'test@mail.com',
        'phone': '+79111223001',
        'age': 30,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user12',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2profile@mail.com',
        'phone': '+79111225003',
        'age': 25,
        'password': 'hackme'
    },
    EVENT_AGE_RESTRICT = {
        'name': 'test',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for permissions test',
        'participants_min': '1',
        'age_restrict': '5', //21+
        'by_invitation': false,
        'visibility': '0'
    },
    EVENT_PUBLIC = {
        'name': 'test',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for permissions test',
        'participants_min': '1',
        'age_restrict': '0', //0+
        'by_invitation': false,
        'visibility': '4'
    },
    INCOMPLETED_LOGIN = REG_USER.username,
    INCOMPLETED_PASS = REG_USER.password,
    INCOMPLETED_EMAIL = REG_USER.email,
    createPlaceURL = '/new_place',
    createEventURL = '/new_event',
    eventsURL = '/events?show=list',
    eventURL = '',
    usersURL = '/users?show=list',
    targetFriendUrl = '',
    newEmail = "incompleted_user_new@mail.com",
    newPhone = '79123456666',
    incompletedProfileURL = '/users/' + INCOMPLETED_LOGIN + '/profile',
    ageHiddenEventUrl = '',
    publicEventUrl = '',
    privatePlaceUrl = '',
    POST = {
        'body': "Test post body",
        'url': ""
    };

//UDPServer.start('127.0.0.1', 5555);
var Signup = require('../utils/signup.js'),
    DateTimePicker = require('../utils/dateTimePicker.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    TagSelector = require('../utils/tagSelector.js'),
    Settings = require('../utils/settings.js'),
    Auth = require('../utils/auth.js');

function getUserProfileSectionUrls(username){
    return [
        '/users/' + username,
        '/users/' + username + '/stream',
        '/users/' + username + '/albums',
        '/users/' + username + '/events',
        '/users/' + username + '/interests',
        '/users/' + username + '/places',
        '/users/' + username + '/friends',
        '/users/' + username + '/statuses'
    ];
}

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("User with incompleted role ", function(){
    
    it("can register", function(){
        Signup.registerUserUntilDone(REG_USER).then(function(userData){

            console.log("incompleted user username: ", userData.username);
            REG_USER.email = userData.email;
            REG_USER.username = userData.username;
            INCOMPLETED_LOGIN = userData.username;
            INCOMPLETED_EMAIL = userData.email;
            newEmail = userData.email;
            incompletedProfileURL = '/users/' + INCOMPLETED_LOGIN + '/profile';
        });
    });

    it("Register USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('User2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

    
    it("can login'", function(){
        Auth.loginAsUser(INCOMPLETED_LOGIN, INCOMPLETED_PASS);
    });
    
    it("can't create places", function(){

        browser.get(createPlaceURL);
        browser.waitForAngular();
        
        // Form should not be present on the page
        expect(element(by.name('placeForm')).isDisplayed()).toBeFalsy();

        // Warning message should be displayed
        expect(element(by.id("add-place-permissions-denied")).isDisplayed()).toBeTruthy();
        
    });

    it("can't create events", function(){

        browser.get(createEventURL);
        browser.waitForAngular();
        
        // Form should not be present on the page
        expect(element(by.name('eventForm')).isDisplayed()).toBeFalsy();

        // Warning message should be displayed
        expect(element(by.id("add-event-permissions-denied")).isDisplayed()).toBeTruthy();
        
    });

    it("can view events", function(){
        browser.get(eventsURL);
        browser.waitForAngular();

        var firstEvent = element(by.xpath('(//a[contains(@data-ui-sref,"event_alias")])[1]'));
        expect(firstEvent.isDisplayed()).toBeTruthy();

        firstEvent.getAttribute('href').then(function(url){
            console.log("Event URL: ", url);
            eventURL = url;
        });
        
    });

    it("can't add posts", function(){

        var ownWallUrl = '/users/' + INCOMPLETED_LOGIN;
        browser.get(ownWallUrl);
        browser.waitForAngular();

        // Form should not be present on the page
        expect(element(by.id('xPostBody')).isDisplayed()).toBeFalsy();
        expect(element(by.id("add-xpost-permissions-denied")).isDisplayed()).toBeTruthy();

    });

    it("can view users", function(){
        browser.get(usersURL);
        browser.waitForAngular();

        var firstUser = element(by.xpath('(//a[contains(@data-ui-sref,"user")])[1]'));
        expect(firstUser.isDisplayed()).toBeTruthy();
        /*
        firstUser.getAttribute('href').then(function(url){
            targetFriendUrl = url;
            console.log("Friend url: ", targetFriendUrl);

        });
         */
    });

    it("can't add friends", function(){

        browser.get('/users/' + USER2.username);
        browser.waitForAngular();
        
        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();
        element(by.xpath('//button[@data-protractor-id="sendFriendshipRequest"]')).click();

        // Form should not be present on the page
        expect(element(by.name('newFriendForm')).isDisplayed()).toBeFalsy();

        //expect(element(by.id("add-friend-permissions-denied")).isDisplayed()).toBeTruthy();
        
        //element(by.id('cancel-friendship-permission-denied')).click();


    });

    it("can't send messages", function(){

        browser.get('/users/' + USER2.username);
        browser.waitForAngular();

        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();

        element(by.xpath('//button[@data-protractor-id="sendUserMessage"]')).click();

        // Form should not be present on the page
        expect(element(by.name('messageForm')).isDisplayed()).toBeFalsy();
    });

    it("can't subscribe to users", function(){
        browser.get('/users/' + USER2.username);
        browser.waitForAngular();

        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();
        element(by.xpath('//button[@data-protractor-id="subscribeUser"]')).click();
        // Form should not be present on the page
        expect(element(by.name('subscriptionForm')).isDisplayed()).toBeFalsy();
    });


    it("can toggle user bookmarks", function(){

        browser.get('/users/' + USER2.username);
        browser.waitForAngular();
        
        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();
        element(by.xpath('//button[@data-protractor-id="bookmarkUser"]')).click();
        browser.waitForAngular();

        expect( element(by.xpath('//button[@data-protractor-id="bookmarkUser"]')).getAttribute('class') ).toMatch('bookmarked');

        // Css class toggle, not working for now
        //expect(element(by.css(".bookmarked")).isDisplayed()).toBeTruthy();
        element(by.xpath('//button[@data-protractor-id="bookmarkUser"]')).click();
        browser.waitForAngular();

        expect( element(by.xpath('//button[@data-protractor-id="bookmarkUser"]')).getAttribute('class') ).not.toMatch('bookmarked');
        //expect(element(by.css(".bookmarked")).isDisplayed()).toBeTruthy();
        
    });

    it("can't add likes", function(){

        browser.get('/users/' + USER2.username);
        browser.waitForAngular();

        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();
        
        var likeButton = element(by.xpath('//*[@data-protractor-id="likeUser"]'));

        expect(likeButton.getText()).toContain("0");
        likeButton.click();
        expect(likeButton.getText()).toContain("0");

    });

    it("can't complain", function(){
    
        var complainButtonLocator = by.xpath('//button[@data-do-complain]'),
            //complainButton = element.all(complainButtonLocator).get(0);
            complainButton = element(complainButtonLocator);

        browser.get(eventURL);
        browser.waitForAngular();
        
        expect(complainButton.isDisplayed()).toBeFalsy();

    });

    it("can set profile sections visibility to 'private' only", function(){

        getUserProfileSectionUrls(INCOMPLETED_LOGIN).map(function(sectionURL){

            var visibilityModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
            browser.get(sectionURL);
            browser.waitForAngular();

            element(by.xpath('//*[@data-protractor-id="sectionVisibility"]')).click();

            expect(visibilityModal.isDisplayed()).toBe(true);
            
            visibilityModal.element(by.model("entity.visibility.value")).all(by.tagName('option')).then(
                function(options) {
                    // Only one visibility type available
                    expect(options.length).toEqual(1);
                }
            );
        });

    });

    it("can't save location history", function(){

        var saveLocationBtn = element(by.id('save-location-history'));
        browser.get(incompletedProfileURL);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="userProfile"]')).click();
        expect(saveLocationBtn.isDisplayed()).toBe(true);

        saveLocationBtn.click();

        expect(element(by.name('userPlaceForm')).isDisplayed()).toBeFalsy();
    });

    it("can't set status", function(){

        var statusUrl = '/users/' + INCOMPLETED_LOGIN + '/statuses',
            statusModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));

        browser.get(statusUrl);
        browser.waitForAngular();
        
        element(by.xpath("//button[@id='add-status']")).click();

        expect(element(by.name('statusForm')).isDisplayed()).toBeFalsy();

    });

    it("can't add albums", function(){

        var statusUrl = '/users/' + INCOMPLETED_LOGIN + '/albums',
            modal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));

        browser.get(statusUrl);
        browser.waitForAngular();
        
        element(by.xpath("//button[@id='add-album']")).click();

        expect(element(by.name('addXPostForm')).isDisplayed()).toBeFalsy();

        //expect(modal.isDisplayed()).toBe(true);
        //expect(element(by.id("add-album-permissions-denied")).isDisplayed()).toBeTruthy();
    });


    it("can change profile email", function(){

        var emailInput = element(by.model('profile.email.value')),
            profileForm = element(by.name('profileForm'));

        browser.get(incompletedProfileURL);
        browser.waitForAngular();

        expect(profileForm.isDisplayed()).toBeTruthy();
        
        expect(emailInput.isDisplayed()).toBeTruthy();
        expect(element(by.model('profile.phone.value')).isDisplayed()).toBeTruthy();

        emailInput.clear();
        emailInput.sendKeys(newEmail);
        profileForm.submit();
        expect(element(by.className('ui-pnotify-title')).isDisplayed()).toBe(true);
        browser.waitForAngular();
    });

    it("gets email verification code", function(){

        Signup.verifyEmail(REG_USER);
    });

    it("can change profile phone", function(){
        Signup.addPhone(REG_USER);
    });

    it("gets SMS verification code", function(){

        Signup.verifyPhone(REG_USER);
    });

    it("can set profile sections visibility to any after verification is complete", function(){

        getUserProfileSectionUrls(INCOMPLETED_LOGIN).map(function(sectionURL){

            var visibilityModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));
            browser.get(sectionURL);
            browser.waitForAngular();
            element(by.xpath("//button[@data-entity='section_visibility']")).click();

            expect(visibilityModal.isDisplayed()).toBe(true);
            
            visibilityModal.element(by.model("entity.visibility.value")).all(by.tagName('option')).then(
                function(options) {
                    // All visibility types are shown
                    expect(options.length).toBeGreaterThan(1);
                }
            );
        });

    });

    it("can create events after verification is complete", function(){

        Events.createNewUnique(EVENT_AGE_RESTRICT).then(function(e){
            console.log("21+ event url: ", e.url);
            ageHiddenEventUrl = e.url;


        });

        Events.createNewUnique(EVENT_PUBLIC).then(function(e){
            console.log("public event url: ", e.url);
            publicEventUrl = e.url;
        });

    });
    
    it("can create places after verification is complete", function(){

        var place = {
            name: Math.random().toString(36).substring(2),
            visibility: '0',
            lat: '55.75408337131602',
            lng: '37.6205188035965'
        };
        
        Places.createNew(place).then(function(place){
            privatePlaceUrl = place.url;
        });

    });


    it("can save location history after verification is complete", function(){

        var saveLocationBtn = element(by.id('save-location-history')),
            locationModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));

        browser.get(incompletedProfileURL);
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="userProfile"]')).click();

        //element(by.css('.user-avatar')).click();
        expect(saveLocationBtn.isDisplayed()).toBe(true);

        saveLocationBtn.click();
        browser.waitForAngular();
        browser.sleep(2000);
        
        expect(
            locationModal.isDisplayed()
        ).toBe(true);
        
        expect(
            element(by.name("userPlaceForm")).isDisplayed()
        ).toBeTruthy();

    });

    it("can set status after verification is complete", function(){

        var statusUrl = '/users/' + INCOMPLETED_LOGIN + '/statuses',
            statusModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));

        browser.get(statusUrl);
        browser.waitForAngular();
        
        element(by.xpath("//button[@id='add-status']")).click();

        expect(statusModal.isDisplayed()).toBe(true);

        expect(statusModal.element(by.name("statusForm")).isDisplayed()).toBeTruthy();

    });

    it("can add albums after verification is complete", function(){
        
        var albumsUrl = '/users/' + INCOMPLETED_LOGIN + '/albums',
            statusModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]"));

        browser.get(albumsUrl);
        browser.waitForAngular();
        
        element(by.xpath("//button[@id='add-album']")).click();

        expect(statusModal.isDisplayed()).toBe(true);

        expect(element(by.name("addXPostForm")).isDisplayed()).toBeTruthy();

        element(by.xpath('//*[@data-protractor-id="cancelPost"]')).click();
    });


    it("logout to test the next batch of tests", function(){
        Auth.logOut();
    });
    
});

describe("anonymous user ", function(){

    // can't add likes (nothing happens)
    // can't add friends (no button)
    // can't add bookmarks (no button)
    // can't subscribe (no button)


    it("can't add posts", function(){
        browser.get(eventsURL);
        browser.waitForAngular();

        var firstEvent = element(by.xpath('(//a[contains(@data-ui-sref,"event_alias")])[1]'));
        expect(firstEvent.isDisplayed()).toBeTruthy();

        firstEvent.getAttribute('href').then(function(url){

            console.log("Test event url: ", url);
            eventURL = url;
            browser.get(eventURL);
            browser.waitForAngular();
            
            // Form should not be present on the page
            expect(element(by.id('xPostBody')).isDisplayed()).toBeFalsy();
            
            /*
            expect(
                element(by.id("add-xpost-permissions-denied")).isDisplayed()
            ).toBeTruthy();
            
            // Link to signup must be present
            expect(element(by.xpath("//div[@id='add-xpost-permissions-denied']//a[@data-ui-sref='signup']")).isDisplayed()).toBeTruthy();
            
            // Link to login must be present
            expect(element(by.xpath("//div[@id='add-xpost-permissions-denied']//a[@data-ui-sref='auth.login']")).isDisplayed()).toBeTruthy();
             */
            
        });

    });

    it("can't complain", function(){
        expect(element(by.xpath("//button[@data-do-complain='']")).isDisplayed()).toBeFalsy();
    });


    xit("can see event creation link, but has no permission to create one", function(){
        var createEventLink = element(by.xpath("//a[@data-ui-sref='new_event']"));

        browser.get("/");
        browser.waitForAngular();

        element(by.xpath('//button[@data-protractor-id="mainMenuToggle"]')).click();

        expect(createEventLink.isDisplayed()).toBeTruthy();
        createEventLink.click();
        browser.waitForAngular();

        // Form should not be present on the page
        expect(element(by.name('eventForm')).isDisplayed()).toBeFalsy();

        // Warning message should be displayed
        expect(element(by.id("add-event-permissions-denied")).isDisplayed()).toBeTruthy();

        // Link to signup must be present
        expect(element(by.xpath("//div[@id='add-event-permissions-denied']//a[@data-ui-sref='signup']")).isDisplayed()).toBeTruthy();
        
        // Link to login must be present
        expect(element(by.xpath("//div[@id='add-event-permissions-denied']//a[@data-ui-sref='auth.login']")).isDisplayed()).toBeTruthy();
                
    });

    xit("can see place creation link, but has no permission to create one", function(){

        var createPlaceLink = element(by.xpath("//a[@data-ui-sref='new_place']"));

        browser.get("/");
        browser.waitForAngular();

        //element(by.xpath("//li[@data-ng-toggle-popup='#three-lines-container']")).click();
        element(by.xpath('//button[@data-protractor-id="mainMenuToggle"]')).click();

        expect(createPlaceLink.isDisplayed()).toBeTruthy();
        createPlaceLink.click();
        browser.waitForAngular();

        // Form should not be present on the page
        expect(element(by.name('placeForm')).isDisplayed()).toBeFalsy();

        // Warning message should be displayed
        expect(element(by.id("add-place-permissions-denied")).isDisplayed()).toBeTruthy();

        // Link to signup must be present
        expect(element(by.xpath("//div[@id='add-place-permissions-denied']//a[@data-ui-sref='signup']")).isDisplayed()).toBeTruthy();
        
        // Link to login must be present
        expect(element(by.xpath("//div[@id='add-place-permissions-denied']//a[@data-ui-sref='auth.login']")).isDisplayed()).toBeTruthy();
                
    });

    it("events with 12+ age limit are hidden", function(){
        browser.get(ageHiddenEventUrl);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');
    });

    it("private places are hidden", function(){
        browser.get(privatePlaceUrl);
        browser.waitForAngular();
        expect(browser.getCurrentUrl()).toContain('/403');
    });

    it("Permissions tests finished - log out", function(){
        Auth.logOut();
    });

});
