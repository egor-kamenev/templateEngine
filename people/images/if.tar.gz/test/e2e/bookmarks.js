var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 25,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 31,
        'password': 'hackme'
    },
    USER3 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 29,
        'password': 'hackme'
    },
    USER4 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 26,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4',
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE2 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    };
    

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Bookmarks = require('../utils/bookmarks.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users:", function(){

    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });
    
    it("Registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);

        });
    });

    it("Registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);

        });
    });

    it("Registrate USER3", function() {
        Signup.registerUserUntilDone(USER3).then(function(userData){
            USER3.username = userData.username;
            USER3.email = userData.email;
            console.log('USER3:', USER3.username);
            Signup.verifyEmail(USER3);

        });
    });

    it("Registrate USER4", function() {
        Signup.registerUserUntilDone(USER4).then(function(userData){
            USER4.username = userData.username;
            USER4.email = userData.email;
            console.log('USER4:', USER4.username);
            Signup.verifyEmail(USER4);

        });
    });

});

describe("Test bookmarks event:", function(){

    it("create event", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT);
        console.log('EVENT:', EVENT.name);
        Auth.logOut();
    });

    it("create event2", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT2);
        console.log('EVENT2:', EVENT2.name);
        Auth.logOut();
    });

    it("add to bookmarks on object page", function(){
        Bookmarks.addEventToBookmarks(USER, EVENT);
    });

    it("add to bookmarks filtered events", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events?tags=' + EVENT2.name + '&show=list');
        browser.waitForAngular();

        element(by.xpath("//button[contains(@class,'bookmark') and contains(@data-entity,'item')]")).click();
        Auth.logOut();
    });

    it("check count event bookmarks", function(){
        Bookmarks.checkEventsBookmarkedCount(USER, 2);
    });

    it("remove from bookmarks event", function(){
        Bookmarks.removeEventFromBookmarks(USER, EVENT);
    });

    it("remove from bookmarks event2", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events?tags=' + EVENT2.name + '&show=list');
        browser.waitForAngular();

        element(by.xpath("//button[contains(@class,'bookmark') and contains(@data-entity,'item')]")).click();
        Auth.logOut();
    });

    it("check count event bookmarks", function(){
        Bookmarks.checkEventsBookmarkedCount(USER, 0);
    });

});

describe("Test bookmarks user:", function(){

    it("add to bookmarks on object page", function(){
        Bookmarks.addUserToBookmarks(USER2, USER3);
    });

    it("add to bookmarks filtered users", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users?tags=' + USER4.username + '&show=list');
        browser.waitForAngular();

        element(by.xpath("//button[contains(@class,'bookmark') and contains(@data-entity,'item')]")).click();
        Auth.logOut();
    });

    it("check count users bookmarks", function(){
        Bookmarks.checkUsersBookmarkedCount(USER2, 2);
    });

    it("remove from bookmarks user", function(){
        Bookmarks.removeUserFromBookmarks(USER2, USER3);
    });

    it("remove from bookmarks user4", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/users?tags=' + USER4.username + '&show=list');
        browser.waitForAngular();

        element(by.xpath("//button[contains(@class,'bookmark') and contains(@data-entity,'item')]")).click();
        Auth.logOut();
    });

    it("check count users bookmarks", function(){
        Bookmarks.checkUsersBookmarkedCount(USER2, 0);
    });

});

describe("Test bookmarks place:", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE);
        Auth.logOut();
    });

    it("create place2", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE2);
        Auth.logOut();
    });

    it("add to bookmarks on object page", function(){
        Bookmarks.addPlaceToBookmarks(USER, PLACE);
    });

    it("add to bookmarks filtered places", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places?tags=' + PLACE2.name + '&show=list');
        browser.waitForAngular();

        element(by.xpath("//button[contains(@class,'bookmark') and contains(@data-entity,'item')]")).click();
        Auth.logOut();
    });

    it("check count users bookmarks", function(){
        Bookmarks.checkPlaceBookmarkedCount(USER, 2);
    });

    it("remove from bookmarks user", function(){
        Bookmarks.removePlaceFromBookmarks(USER, PLACE);
    });

    it("remove from bookmarks user4", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places?tags=' + PLACE2.name + '&show=list');
        browser.waitForAngular();

        element(by.xpath("//button[contains(@class,'bookmark') and contains(@data-entity,'item')]")).click();
        Auth.logOut();
    });

    it("check count event bookmarks", function(){
        Bookmarks.checkPlaceBookmarkedCount(USER, 0);
    });

});
