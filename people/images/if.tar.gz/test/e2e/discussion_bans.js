'use strict';

var USER1 = {
    'username': 'userdbans1',
    'first_name': 'Ivan',
    'last_name': 'Tester',
    'email': 'user1profile@mail.com',
    'phone': '+79111225002',
    'age': 30,
    'password': 'hackme'
},
    USER2 = {
        'username': 'userdbans2',
        'first_name': 'Pete',
        'last_name': 'Tester',
        'email': 'user3profile@mail.com',
        'phone': '+79111225004',
        'age': 30,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'testevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '0',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE = {
        'name': 'placetest',
        'visibility': '4'
    },
    Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Friendship = require('../utils/friendship.js'),
    Settings = require('../utils/settings.js'),
    Visibility = require('../utils/visibility.js');


describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 


describe("Register users:", function(){

    it("Register USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;
            console.log('User1:', USER1.username);
            Signup.verifyEmail(USER1);
        });
    });

    it("Register USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('User2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

});


function findReactElement(selector){
    return protractor.promise.filter(element.all(selector), function(e) { 
        return e.isDisplayed(); 
    }).then(function(visibleElements) {
        expect(visibleElements.length).toBe(1);
        return visibleElements[0];
    }); 
}

/*
describe("Test bans:", function(){

    
    it("Log in as USER1", function(){

        USER1.username = "userdbans1576786";
        USER2.username = "userdbans2933630";

        Auth.loginAsUser(USER2.username, USER2.password);

        browser.get('/users/' + USER2.username + '/messages/notice');
        browser.waitForAngular();

        console.log("//*[@data-protractor-id='banFrom" + USER1.username +"Active']");
        //browser.sleep(9999999);

        findReactElement(by.xpath("//*[@data-protractor-id='banFrom" + USER1.username +"Active']")).then(function(e){
            e.getText().then(function(text){
                console.log("ELEM TEXT: ", text);
            });

        });
        //var elements = element.all().then(function(elements){

    });

});
*/
describe("Test bans:", function(){

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });
    
    it("USER1 creates event for discussion", function() {
        
        Events.createNewUnique(EVENT).then(function(event){
            EVENT.url = event.url;
            EVENT.name = event.name;
            console.log("Event url: ", EVENT.url);
            console.log("Event name: ", EVENT.name);
        });

    });

    it("USER1 makes a post to the event wall", function() {

        browser.get(EVENT.url);
        browser.waitForAngular();


        element(by.id('xPostBody')).sendKeys("User1 post");
        element(by.name('addXPostForm')).submit();

    });

    it("USER1 logout", function(){
        Auth.logOut();
    });

    it("Log in as USER2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
    });

    it("USER2 can't ban USER1 on the event wall", function() {

        browser.get(EVENT.url);
        browser.waitForAngular();

        expect(
            element(
                by.xpath('//div[text()="User1 post"]/../..')
            ).element(
                by.xpath('./button[@data-protractor-id="xPostMenu"]')
            ).isPresent()
        ).toBeFalsy();

    });

    it("USER2 makes a post to the event wall", function() {

        browser.get(EVENT.url);
        browser.waitForAngular();
        expect(
            element(by.id('xPostBody')).isDisplayed()
        ).toBeTruthy();
        
        element(by.id('xPostBody')).sendKeys("User2 post");
        element(by.name('addXPostForm')).submit();

    });

    it("USER2 logout", function(){
        Auth.logOut();
    });

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("USER1 can ban USER2 on the event wall", function() {

        var banPost = element(by.xpath('//div[text()="User2 post"]/../..//*[@data-protractor-id="userPostBan"]'));
        browser.get(EVENT.url);
        browser.waitForAngular();

        var postMenu = browser.findElement( by.xpath('//div[text()="User2 post"]/../..//*[@data-protractor-id="xPostMenu"]') );

        browser.executeScript(scrollIntoView, postMenu);
        postMenu.click();

        expect(
            banPost.isDisplayed()
        ).toBeTruthy();
        
        banPost.click();

    });

    it("ban modal with options should be displayed", function() {

        var banAndRemoveMessages = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//*[@data-protractor-id='banRemovesUserMessages']")),
            banComment = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//*[@data-protractor-id='banComment']")),
            expireDays = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//*[@data-protractor-id='banExpireDays']")),
            confirmBan = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//*[@data-protractor-id='confirmBan']"));

        expect(
            element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active') and @data-protractor-id='userBanModal']")).isDisplayed()
        ).toBeTruthy();

        expect(
            banAndRemoveMessages.isDisplayed()
        ).toBeTruthy();

        expect(
            banComment.isDisplayed()
        ).toBeTruthy();

        expect(
            expireDays.element(by.xpath('option[text() = "навсегда"]')).isPresent()
        ).toBeTruthy();

        expect(
            expireDays.element(by.xpath('option[contains(text(), "1 ")]')).isPresent()
        ).toBeTruthy();

        expect(
            expireDays.element(by.xpath('option[contains(text(), "3 ")]')).isPresent()
        ).toBeTruthy();

        expect(
            expireDays.element(by.xpath('option[contains(text(), "7 ")]')).isPresent()
        ).toBeTruthy();

        expect(
            expireDays.element(by.xpath('option[contains(text(), "21 ")]')).isPresent()
        ).toBeTruthy();

        banAndRemoveMessages.click();
        banComment.sendKeys("Hey, " + USER2.username + ", stop spamming me!");
        expireDays.click();
        expireDays.element(by.xpath('option[@value="0"]')).click();

        confirmBan.click();
        browser.waitForAngular();

    });

    it("USER2 post should dissapear from the wall after ban", function(){
        
        expect(
            element(by.xpath('//div[text()="User2 post"]')).isPresent()
        ).toBeFalsy();

    });

    it("USER1 logout", function(){
        Auth.logOut();
    });

    it("Log in as USER2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
    });

    it("USER2 should get notice about the ban", function(){
        browser.get('/users/' + USER2.username + '/messages/notice');
        browser.waitForAngular();

        findReactElement(by.xpath("//*[@data-protractor-id='banFrom" + USER1.username +"Active']")).then(function(banFromUser1){

            
            expect(
                banFromUser1.isPresent()
            ).toBeTruthy();
            
            expect(
                banFromUser1.getText()
            ).toContain("Hey, " + USER2.username + ", stop spamming me!");
            
            expect(
                banFromUser1.getText()
            ).toContain("Создан");
            
            expect(
                banFromUser1.getText()
            ).toContain("Истекает");
            
            /*banFromUser1.getText().then(function(text){
                console.log("ELEM TEXT: ", text);
            });*/

        });

        
        /*banFromUser1Comment.getText().then(function(text){
            console.log("BAN2 TEXT: ", text);
        });*/

        

    });

    it("USER2 should see the ban from USER1 in his profile", function(){

        browser.get('/users/' + USER2.username + '/bans/to');
        browser.waitForAngular();

        console.log("Bans addr: ", '/users/' + USER2.username + '/bans/to');

        var bannedUser = element(by.xpath("//*[@data-protractor-id='bannedUser']"));

        expect(
            bannedUser.getText()
        ).toContain(USER1.username);

        expect(
            bannedUser.getText()
        ).toContain("Дата создания");

        expect(
            bannedUser.getText()
        ).toContain("Дата окончания");
        
        expect(
            bannedUser.getText()
        ).toContain("Hey, " + USER2.username + ", stop spamming me!");


    });


    it("USER2 logout", function(){
        Auth.logOut();
    });

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("USER1 cancels USER2 ban", function(){

        var bannedUser = element(by.xpath("//*[@data-protractor-id='bannedUser']"));
        browser.get('/users/' + USER1.username + '/bans/from');
        browser.waitForAngular();
        

        expect(
            bannedUser.getText()
        ).toContain(USER2.username);

        expect(
            bannedUser.getText()
        ).toContain("Дата создания");

        expect(
            bannedUser.getText()
        ).toContain("Дата окончания");

        expect(
            bannedUser.getText()
        ).toContain("Hey, " + USER2.username + ", stop spamming me!");
        
        element(by.xpath("//*[@data-protractor-id='removeBan" + USER2.username + "']")).click();

        
    });

    it("USER1 logout", function(){
        Auth.logOut();
    });

    it("Log in as USER2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
    });


    it("USER2 should get notice about the ban cancellation", function(){

        browser.get('/users/' + USER2.username + '/messages/notice');
        browser.waitForAngular();

        findReactElement(by.xpath("//*[@data-protractor-id='banFrom" + USER1.username +"Cancelled']")).then(function(banFromUser1){
            
            expect(
                banFromUser1.isDisplayed()
            ).toBeTruthy();
            
            expect(
                banFromUser1.getText()
            ).toContain("Hey, " + USER2.username + ", stop spamming me!");
            
            expect(
                banFromUser1.getText()
            ).toContain("Создан");
            
            expect(
                banFromUser1.getText()
            ).toContain("Истекает");
            
            expect(
                banFromUser1.getText()
            ).toContain("не забанен");
        });
    });

    
    it("Discussion tests finished - log out", function(){
        Auth.logOut();
    });

});
