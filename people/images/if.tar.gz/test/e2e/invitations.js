'use strict';

var OWNER = {
        'username': 'owner',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79121222000',
        'age': 30,
        'password': 'hackme'
    },
    INVITOR_USER1_TEST = {
        'username': 'test1' + Math.floor(Math.random()*1000000),
        'first_name': 'John',
        'last_name': 'Smyth',
        'email': 'test1' + Math.floor(Math.random()*1000000) + '@mail.ru',
        'phone': '+79111223000',
        'age': 32,
        'password': 'hackme'
    },
    INVITOR_USER2_TEST = {
        'username': 'test2' + Math.floor(Math.random()*1000000),
        'first_name': 'John',
        'last_name': 'Smyth',
        'email': 'test2' + Math.floor(Math.random()*1000000) + '@mail.ru',
        'phone': '+79111223000',
        'age': 29,
        'password': 'hackme'
    },
    INVITOR_USER3_TEST = {
        'username': 'test3' + Math.floor(Math.random()*1000000),
        'first_name': 'John',
        'last_name': 'Smyth',
        'email': 'test3' + Math.floor(Math.random()*1000000) + '@mail.ru',
        'phone': '+79111223000',
        'age': 27,
        'password': 'hackme'
    };
   

var Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    Settings = require('../utils/settings.js'),
    UserMail = require('../utils/userMail.js');

var selectDropdownbyNum = function (element, optionNum) {
    if (optionNum) {
        var options = element.all(by.tagName('option')).then(
            function(options) {
                options[optionNum].click();
            }
        );
    }
};

var fillField = function (field_name, value) {
    var field = element(by.id(field_name));
    field.clear();
    field.sendKeys(value);
};

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register main user and send invitetions: ", function() {
    
    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner', OWNER);
            Signup.verifyEmail(OWNER);
        });
    });

    it("send letters to invited users", function(){
        
        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get('/users/' + OWNER.username + "/friends");
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='inviteFriends']")).click();

        var email_list = INVITOR_USER1_TEST.email + "\n" + INVITOR_USER2_TEST.email + "\n" + INVITOR_USER3_TEST.email;
        console.log('email list - ', email_list);

        element(by.id('new_invitations')).sendKeys(email_list);
        element(by.name('addInvitationForm')).submit();

        browser.waitForAngular();
        browser.driver.sleep(5000); // every 5 seconds refferal get letter
        Auth.logOut();

    });

    it("register INVITOR_USER1_TEST by invitetion link", function(){
        var mailerUSer1 = new UserMail(INVITOR_USER1_TEST.email, null),
            flow = protractor.promise.controlFlow(),
            urlPattern = /\b(?:https?|ftp):\/\/[a-z0-9-+&@#\/%?=~_|!:,.;]*[a-z0-9-+&@#\/%=~_|]/gim;

        flow.execute(mailerUSer1.getAllMail).then(function(value){
            var token = value[0].body.match(urlPattern)[0].split('=')[1];
            console.log('INVITOR_USER1_TEST LETTER', token);
            
            browser.get('/signup?token=' + token);
            browser.waitForAngular();

            expect(element(by.xpath("//input[@id='username']")).getAttribute('value')).toBe(INVITOR_USER1_TEST.email.split('@')[0]);
            expect(element(by.xpath("//input[@id='email']")).getAttribute('value')).toBe(INVITOR_USER1_TEST.email);
            
            fillField('first_name', INVITOR_USER1_TEST.first_name);
            fillField('last_name', INVITOR_USER1_TEST.last_name);
            selectDropdownbyNum(element(by.id('day_of_birth')), '2');
            selectDropdownbyNum(element(by.id('month_of_birth')), '4');
            selectDropdownbyNum(element(by.id('year_of_birth')), INVITOR_USER1_TEST.age);

            fillField('password', INVITOR_USER1_TEST.password);
            fillField('password2', INVITOR_USER1_TEST.password);
           
            element(by.xpath('//input[@id="eula"]/following-sibling::i')).click();

            element(by.xpath("//form[@name='signupForm']")).submit();
            browser.waitForAngular();

        });
    });
    
    it("register INVITOR_USER2 by invitation link", function(){
        var mailer = new UserMail(INVITOR_USER2_TEST.email, null),
            flow = protractor.promise.controlFlow(),
            urlPattern = /\b(?:https?|ftp):\/\/[a-z0-9-+&@#\/%?=~_|!:,.;]*[a-z0-9-+&@#\/%=~_|]/gim;

        flow.execute(mailer.getAllMail).then(function(value){
            var token = value[0].body.match(urlPattern)[0].split('=')[1];
            console.log('INVITOR_USER2_TEST LETTER',token);
            
            browser.get('/signup?token=' + token);
            browser.waitForAngular();

            expect(element(by.xpath("//input[@id='username']")).getAttribute('value')).toBe(INVITOR_USER2_TEST.email.split('@')[0]);
            expect(element(by.xpath("//input[@id='email']")).getAttribute('value')).toBe(INVITOR_USER2_TEST.email);
            
            fillField('first_name', INVITOR_USER2_TEST.first_name);
            fillField('last_name', INVITOR_USER2_TEST.last_name);
            selectDropdownbyNum(element(by.id('day_of_birth')), '2');
            selectDropdownbyNum(element(by.id('month_of_birth')), '4');

            selectDropdownbyNum(element(by.id('year_of_birth')), INVITOR_USER2_TEST.age);
            fillField('password', INVITOR_USER2_TEST.password);
            fillField('password2', INVITOR_USER2_TEST.password);

            element(by.xpath('//input[@id="eula"]/following-sibling::i')).click();

            element(by.xpath("//form[@name='signupForm']")).submit();
            browser.waitForAngular();

        });
    });
    
    it("register INVITOR_USER3", function(){
        Signup.registerUser(INVITOR_USER3_TEST).then(function(value){
            expect(value).toBe(true);
        });
    });
    
    it("check referrals", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + OWNER.username + '/settings/referrals');
        browser.waitForAngular();

        console.log("Ref page: ", '/users/' + OWNER.username + '/settings/referrals');
        console.log("Check username: ", INVITOR_USER1_TEST.email.split('@')[0]);
        console.log("Check username: ", INVITOR_USER2_TEST.email.split('@')[0]);
        console.log("Check username: ", INVITOR_USER3_TEST.email.split('@')[0]);
        expect(element(by.xpath("//a[contains(@href,'/users/" + INVITOR_USER1_TEST.email.split('@')[0] + "')]")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[contains(@href,'/users/" + INVITOR_USER2_TEST.email.split('@')[0] + "')]")).isPresent()).toBe(true);
        expect(element(by.xpath("//a[contains(@href,'/users/" + INVITOR_USER3_TEST.email.split('@')[0] + "')]")).isPresent()).toBe(false);
        Auth.logOut();
    });   
    
});


