var USER = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 25,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222067',
        'age': 35,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js');

describe("Register users: ", function() {
  
    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

    it("registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

});

describe("Ban user:", function(){

    it("ban user", function(){
        
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        browser.get(ADMIN_URL + '/admin/users/user/');
        
        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        ptor.driver.findElement(protractor.By.id('searchbar')).sendKeys(USER.username);
        ptor.driver.findElement(protractor.By.id('changelist-search')).submit();

        ptor.driver.findElement(protractor.By.xpath('//table[@id="result_list"]//a[text()="' + USER.username +'"]')).click();

        ptor.driver.findElement(protractor.By.xpath("//a[@class='ban_button']")).click();
        
        driver.switchTo().alert().accept();

        browser.ignoreSynchronization = false;

    });

    it("baned user try login ", function(){
        //Auth.logOut();

        Auth.loginAsUser(USER.username, USER.password);
        expect(browser.getCurrentUrl()).toContain('/401');
        Auth.logOut();
        
    });

});

describe("Blocked users should not get in the sample lists and not and have page: ", function(){

    it("check list", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        
        browser.get('/users?tags=' + USER.username + '&show=list');
        browser.waitForAngular();

        expect(element(by.xpath("//a[text()='" + USER.username + "']")).isPresent()).toBe(false);
        Auth.logOut();

    });

    it("check user page", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        expect(element(by.xpath("//div[@data-protractor-id='profileUsername']")).isPresent()).toBe(false);
        Auth.logOut();

    });
      
});

describe("Unban user:", function(){

    it("unban user", function(){
        
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        browser.get(ADMIN_URL + '/admin/users/user/?q=' +USER.username+ '&all=');
        
        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        ptor.driver.findElement(protractor.By.xpath('//table[@id="result_list"]//a[text()="' + USER.username +'"]')).click();

        ptor.driver.findElement(protractor.By.xpath("//a[@class='unban_button']")).click();
        
        driver.switchTo().alert().accept();

        browser.ignoreSynchronization = false;

    });

});


describe("Blocked users should get in the sample lists and have page: ", function(){

    it("check list", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        
        browser.get('/users?tags=' + USER.username + '&show=list');
        browser.waitForAngular();

        expect(element(by.xpath("//a[text()='" + USER.username + "']")).isPresent()).toBe(true);
        Auth.logOut();

    });

    it("check user page", function(){

        Auth.loginAsUser(USER2.username, USER2.password);
        
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        expect(element(by.xpath("//div[@data-protractor-id='profileUsername']")).isPresent()).toBe(true);
        Auth.logOut();

    });
      
});




