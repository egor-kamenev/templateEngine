'use strict';

var path = require('path');

var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    OWNER_FRIEND = {
        'username': 'Kiko',
        'first_name': 'Sanchezzz',
        'last_name': 'Barakanos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 37,
        'password': 'hackme'
    },
    FRIEND_OWNER_FRIEND = {
        'username': 'Raul',
        'first_name': 'Sanchezzz',
        'last_name': 'Barakanos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 37,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 25,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'корпоратив',
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4',
    },
    EVENT1 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'корпоратив',
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '0',
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'корпоратив',
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '1',
        'specified_users': []
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'корпоратив',
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '2'
    },
    EVENT4 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'корпоратив',
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '3'
    },
    EVENT5 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'корпоратив',
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4',
        lat: '55.75408337131602',
        lng: '37.6205188035965'
    },
    ALBUM = {
        'title': 'Test album',
        'tag': 'albumtag',
        'visibility': '4',
        uploadPhotoPath: path.resolve(__dirname, '..', 'test_data', "photo.jpg")
    },
    postMenu = element(
        by.xpath('//button[@data-protractor-id="xPostMenu"]')
    );


var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Comments = require('../utils/comments.js'),
    Places = require('../utils/places.js'),
    Friendship = require('../utils/friendship.js'),
    Signup = require('../utils/signup.js'),
    Settings = require('../utils/settings.js'),
    Albums = require('../utils/albums.js');

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register users: ", function() {
    
    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
            
        });
    });
    
    it("Registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            EVENT2.specified_users.push(USER.username);
            console.log('User:', USER.username);
            Signup.verifyEmail(USER);
            
        });
    });
    
    it("Registrate OWNER_FRIEND", function() {
        Signup.registerUserUntilDone(OWNER_FRIEND).then(function(userData){
            OWNER_FRIEND.username = userData.username;
            OWNER_FRIEND.email = userData.email;
            EVENT2.specified_users.push(OWNER_FRIEND.username);
            console.log('OWNER_FRIEND:', OWNER_FRIEND.username);
            Signup.verifyEmail(OWNER_FRIEND);
            
        });
    });

    it("Registrate FRIEND_OWNER_FRIEND", function() {
        Signup.registerUserUntilDone(FRIEND_OWNER_FRIEND).then(function(userData){
            FRIEND_OWNER_FRIEND.username = userData.username;
            FRIEND_OWNER_FRIEND.email = userData.email;
            console.log('FRIEND_OWNER_FRIEND:', FRIEND_OWNER_FRIEND.username);
            Signup.verifyEmail(FRIEND_OWNER_FRIEND);
            
        });
    });
    
});

describe("Should have wall:", function(){
    
    it("Event", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT);
        console.log('Event:', EVENT.name);

        expect(element(by.xpath("//form[@name='addXPostForm']")).isDisplayed()).toBe(true);
        Auth.logOut();
    });
    
    it("Place", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewUnique(PLACE).then(function(place){
            console.log("PLACE url: ", place.url);
            PLACE.url = place.url;

            browser.waitForAngular();
            expect(element(by.xpath("//form[@name='addXPostForm']")).isDisplayed()).toBe(true);
        });
        Auth.logOut();
    });
    
    it("User", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/users/' + OWNER.username);
        browser.waitForAngular();
        expect(element(by.xpath("//form[@name='addXPostForm']")).isDisplayed()).toBe(true);

        Auth.logOut();
    });
    
});

describe("Check post all types privacy:", function() {
    
    it("Privacy only me", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT1);
        console.log('Event:', EVENT1.name);
        Auth.logOut();
    });
    
    it("Login user and try look xwall", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get("/events/" + EVENT1.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();
    });
    
    it("Privacy specified users", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNewUnique(EVENT2).then(function(event){
            EVENT2.url = event.url;
            EVENT2.name = event.name;
            console.log("Event2 Url: ", EVENT2.url);
        });

        console.log('Event2:', EVENT2.name);
    });

    it("Owner comment event", function(){
        Comments.addComment(EVENT2.url, null, OWNER.username + '-->comment');
        Comments.checkCountComments(1);
        Auth.logOut();
    });
    
    it("Login user try look xwall and add comment", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get(EVENT2.url);
        browser.waitForAngular();

        Comments.checkCountComments(1);
        Comments.addComment(EVENT2.url, null, USER.username + ' WTF');
        Comments.checkCountComments(2);
        Auth.logOut();
    });
    
    it("Privacy only friends", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT3);
        console.log('Event3:', EVENT3.name);
        Auth.logOut();
    });
    
    it("beFriends OWNER and OWNER_FRIEND", function(){
        Friendship.beFriends(OWNER, OWNER_FRIEND);
    });
    
    it("Login user try look xwall", function(){
        Auth.loginAsUser(USER.username, USER.password);

        browser.get("/events/" + EVENT3.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();
    });

    it("Login owner friend try look xwall", function(){
        Auth.loginAsUser(OWNER_FRIEND.username, OWNER_FRIEND.password);

        Comments.addComment("/events/" + EVENT3.name, null, OWNER_FRIEND.username + 'YEEEEEEEEEEE');
        Auth.logOut();
    });
    
    it("Privacy only friends or my friends", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT4);
        console.log('Event4:', EVENT4.name);
        Auth.logOut();
    });

    it("beFriends OWNER_FRIEND and FRIEND_OWNER_FRIEND", function(){
        Friendship.beFriends(OWNER_FRIEND, FRIEND_OWNER_FRIEND);
    });

    it("Login owner friend try look xwall", function(){
        Auth.loginAsUser(FRIEND_OWNER_FRIEND.username, FRIEND_OWNER_FRIEND.password);

        Comments.addComment("/events/" + EVENT4.name, null, FRIEND_OWNER_FRIEND.username + '- friend of my friend');
        Auth.logOut();
    });
    
    it("Privacy everyone", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT5);
        console.log('Event4:', EVENT5.name);
        Auth.logOut();
    });
    
    it("Try comment event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Comments.addComment('/events/' + EVENT5.name, null, USER.username + '-->comment');
        Comments.checkCountComments(1);
        Auth.logOut();
    });
    
});

// Post have no privacy setting anymore
xdescribe("Comment by default have wall privacy", function(){

    it("should have only me privacy", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-entity='xPost']")).click();
        expect(element(by.xpath("//select[@data-ng-model='entity.visibility.value']/option[1]")).getText()).toEqual('Only me');
    });

});


describe("Test post page:", function(){
    
    it("check event post page", function(){
        Auth.loginAsUser(USER.username, USER.password);

        var commentEvent = USER.username + ' comment';

        Comments.addComment('/events/' + EVENT.name, EVENT.tag, commentEvent);

        Comments.isEditable(commentEvent, EVENT.tag);
        
        element(by.xpath("//*[@data-protractor-id='discussionLink']")).getAttribute('href').then(function(href){
            browser.get(href);
            browser.waitForAngular();

            expect(element(by.xpath("//div[@data-can-post='canAddXPosts']")).isPresent()).toBe(true);
            Auth.logOut();
        });
    });
    
    it("check place post page", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        var commentPlace = OWNER.username + ' comment';
        PLACE.name = PLACE.url.split('/').slice(4)[0];
        
        Comments.addComment('/places/' + PLACE.name, null, commentPlace);
        
        Comments.isEditable(commentPlace, null);

        element(by.xpath("//*[@data-protractor-id='discussionLink']")).getAttribute('href').then(function(href){
            browser.get(href);
            browser.waitForAngular();

            expect(element(by.xpath("//div[@data-can-post='canAddXPosts']")).isPresent()).toBe(true);
            Auth.logOut();
        });
        
    });
    
    
    it("check user post page", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        var commentUser = OWNER.username + ' comment';

        Comments.addComment('/users/' + OWNER.username, null, commentUser);

        Comments.isEditable(commentUser, null);

        element(by.xpath("//*[@data-protractor-id='discussionLink']")).getAttribute('href').then(function(href){

            browser.get(href);
            browser.waitForAngular();

            expect(element(by.xpath("//div[@data-can-post='canAddXPosts']")).isPresent()).toBe(true);
            Auth.logOut();
        });
        
    });
    
});

describe("Owner can delete comments and ban user:", function(){
   
    it("check delete event comment", function(){

        var deletePost = element(by.xpath('//*[@data-protractor-id="deletePost"]'));

        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        postMenu.click();
        
        expect(deletePost.isDisplayed()).toBe(true);
        deletePost.click();

        element(by.xpath("(//*[@data-protractor-id='confirmYes'])")).click();
        browser.waitForAngular();

        Comments.checkCountComments(0);
        Auth.logOut();
    });
    
    it("Add new comment by USER", function(){
        Auth.loginAsUser(USER.username, USER.password);
        var commentEvent = USER.username + ' comment';
        Comments.addComment('/events/' + EVENT.name, EVENT.tag, commentEvent);
        Auth.logOut();
    });
    
    it("Ban USER , check form visibility and comments is deleted", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        postMenu.click();

        var banPost = element(by.xpath('//*[@data-protractor-id="userPostBan"]'));

        expect(banPost.isDisplayed()).toBe(true);
        banPost.click();



        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//input[@id='remove_user_messages']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//input[@id='comment']")).sendKeys('Spam');
        selectDropdownbyValue(element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//select[@id='expire']")), '2');
        
        element(by.xpath("//form[@name='banUserForm']")).submit();
        browser.navigate().refresh();

        Comments.checkCountComments(0);

        expect(element(by.xpath("//div[@class='post-message']//form[@name='addXPostForm']")).isPresent()).toBe(false);
        Auth.logOut();
    });
    
});

describe("Users (even friends) can not post comments to each other on the wall:", function(){

    it("try owner post comment on user wall", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        //expect(element(by.name("addXPostForm")).isDisplayed()).toBe(true);

        expect(
            element(by.name("addXPostForm")).isDisplayed()
        ).toBe(false);

        //expect(element(by.xpath("//div[@class='post-message']//form[@name='addXPostForm']")).isDisplayed()).toBe(false);

        Auth.logOut();
    });

});

describe("Test user albums:", function(){

    it("create album", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Albums.createNew(USER, ALBUM);
    });

    it("check album", function(){
        browser.get('/users/' + USER.username + '/albums');
        browser.waitForAngular();

        element.all(by.repeater('album in userAlbums')).then(function(events){
            expect(events.length > 0).toBe(true);
            Auth.logOut();
        });

    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
