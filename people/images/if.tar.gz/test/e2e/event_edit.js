'use strict';

var EVENT1 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '7',
        'by_invitation': false,
        'visibility': '4'
    },
    OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER1 = {
        'username': 'user1Test',
        'first_name': 'John',
        'last_name': 'Tester',
        'email': 'user1test@mail.com',
        'phone': '+79111222001',
        'age': 30,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user1Test',
        'first_name': 'John',
        'last_name': 'Tester',
        'email': 'user1test@mail.com',
        'phone': '+79111222001',
        'age': 18,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Settings = require('../utils/settings.js'),
    Comments = require('../utils/comments.js'),
    Participation = require('../utils/participation.js'),
    Signup = require('../utils/signup.js');

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};


describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 


describe("Register users: ", function() {
    
    it("Registrate and verify OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;

            console.log('Owner', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });
    
    it("Registrate and verify USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;

            console.log('USER1', USER1.username);
            Signup.verifyEmail(USER1);
        });
    });
    
    it("Registrate and verify USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;

            console.log('USER2', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });
    
});

describe("Create and check buttons and menu:", function(){
    
    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT1);
        console.log('Event1', EVENT1.name);
        Auth.logOut();
    });

    it("check owner privacy button and menu", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT1.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();

        expect(element(by.xpath("//button[@data-protractor-id='eventVisibility']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//button[@data-protractor-id='editEventLink']")).isDisplayed()).toBe(true);
        Auth.logOut();
    });

    it("user1 can't edit event created by owner", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/events/' + EVENT1.name);
        browser.waitForAngular();
        
        expect(element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).isPresent()).toBe(false);
        expect(element(by.xpath("//button[@data-protractor-id='eventVisibility']")).isPresent()).toBe(false);
        expect(element(by.xpath("//button[@data-protractor-id='editEventLink']")).isPresent()).toBe(false);
        Auth.logOut();
    });
    
    it("check user2 privacy button and menu", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/events/' + EVENT1.name);
        browser.waitForAngular();
            
        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();
    });
    
});

describe("Change event properties", function(){
   
    it("edit event age", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT1.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        selectDropdownbyValue(element(by.model('event.age_restriction')), '2');
        
        element(by.name('eventForm')).submit();
        Auth.logOut();
    });

    it("intended-to-go to event", function(){
        Participation.intendedToGoEvent(USER1, EVENT1);
    });

    it("count participation to event", function(){
        Participation.eventCountParticipation(USER1, EVENT1, 2);
    });

    it("edit event privacy", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        browser.get('/events/' + EVENT1.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//button[contains(@data-entity,'event')]")).click();

        var privacy = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//select[contains(@data-ng-model, 'entity.visibility.value') and contains(@name, 'visibility')]"));
        
        selectDropdownbyValue(privacy, '0');
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//button[@data-ng-click='saveVisibility()']")).click();

        element(by.name('eventForm')).submit();
        Auth.logOut();
    });
    
    it("test privacy changes", function(){
        Participation.eventCountParticipation(OWNER, EVENT1, 1);
    });
    
});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
