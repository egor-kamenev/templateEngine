'use strict';

var USER1 = {
        'username': 'userfltr1',
        'first_name': 'Ivan',
        'last_name': 'Tester',
        'email': 'user1profile@mail.com',
        'phone': '+79111225002',
        'age': 30,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'userfltr2',
        'first_name': 'Pete',
        'last_name': 'Tester',
        'email': 'user3profile@mail.com',
        'phone': '+79111225004',
        'age': 30,
        'password': 'hackme'
    },
    USER3= {
        'username': 'userfltr3',
        'first_name': 'Andy',
        'last_name': 'Tester',
        'email': 'user4profile@mail.com',
        'phone': '+79111225005',
        'age': 35,
        'password': 'hackme'
    },
    YOUNG_USER = {
        'username': 'userfltr2',
        'first_name': 'Petr',
        'last_name': 'Tester',
        'email': 'user2profile@mail.com',
        'phone': '+79111225003',
        'age': 16,
        'password': 'hackme'
    },
    FUTURE_EVENT = {
        'name': 'eventfuture',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '0',
        'by_invitation': false,
        'visibility': '4'
    },
    AGE_RESTRICTED_EVENT = {
        'name': 'eventagerestr',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '6',
        'by_invitation': false,
        'visibility': '4'
    },
    CHECKIN_EVENT = {
        'name': 'eventcheckin',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '0',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE = {
        'name': 'placeftlts',
        'visibility': '4',
        'description': 'униктекст',
        'tag': 'театр'
    },
    PLACE_WITH_POST = {
        'name': 'placeftlts',
        'visibility': '4'
    },
    PLACE_SUBSCRIBED = {
        'name': 'placeftlts',
        'visibility': '4'
    },
    PITER_PLACE = {
        'name': 'placeftltspiter',
        'visibility': '4'
    },
    Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Friendship = require('../utils/friendship.js'),
    Visibility = require('../utils/visibility.js'),
    Settings = require('../utils/settings.js'),
    fSearch = element(by.xpath("//button[@data-protractor-id='filtersSearch']")),
    resetSearch = element(by.xpath("//button[@data-protractor-id='resetFilters']")),
    fSearchText = element(by.xpath('//div[@data-protractor-id="searchCriteriaBlock"]//input[@type="text"]')),
    fSearchTag = element(by.xpath('//div[@data-protractor-id="searchCriteriaBlock"]//ul[@class="select2-choices"]//div')),
    
    moment = require('moment'),
    EVENT_MIN_START_OFFSET = 2,
    yesterday = moment().subtract(1, 'd'),
    tomorrow = moment().add(1, 'd');

function selectDropdownbyValue(element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

function findEntityByText(tag, e, url, ptorID){
    browser.get(url);
    browser.waitForAngular();
    
    fSearch.click();
    fSearchText.sendKeys(tag);
    element(by.xpath('//div[@class="select2-result-label"]')).click();
    browser.waitForAngular();

    expect(
        element(by.xpath("//a[@data-protractor-id='"+ptorID+"' and @href='" + e.shortURL + "']")).isDisplayed()
    ).toBeTruthy();
}

function findEntity(tag, e, url, ptorID){

    browser.get(url);
    browser.waitForAngular();
    fSearch.click();
    resetSearch.click();
    
    fSearchText.click();
    browser.waitForAngular();
    element(by.xpath("//div[@class='select2-result-label' and text()='" + tag + "']")).click();
    
    expect(
        element(by.xpath("//a[@data-protractor-id='"+ptorID+"' and @href='" + e.shortURL + "']")).isDisplayed()
    ).toBeTruthy();
}

function findEvent(tag, e){
    return findEntity(tag, e,'/events?&show=list', 'sidebarEventLink');
}

function findPlace(tag, p){
    return findEntity(tag, p,'/places?&show=list', 'sidebarPlaceLink');
}

function findPlaceByText(tag, p){
    return findEntityByText(tag, p,'/places?&show=list', 'sidebarPlaceLink');
}

function findEventByText(tag, p){
    return findEntityByText(tag, p,'/events?&show=list', 'sidebarEventLink');
}

function focusOnMoscowPlaces(){

    browser.get("/places?centerPlace=55.72014932919687:37.643280029296875:55.9922367329393:38.3642578125:55.446153059266905:36.92230224609375:10&show=map");
    browser.waitForAngular();
}

function focusOnMoscowUsers(){

    browser.get("/users?centerPlace=55.72014932919687:37.643280029296875:55.9922367329393:38.3642578125:55.446153059266905:36.92230224609375:10&show=map");
    browser.waitForAngular();

}

function findPlaceByURL(elements, placeURL){

    var d = protractor.promise.defer(),
        i, e, j = 0;
    
    for(i = 0; i < elements.length; i++){
        e = elements[i];
        e.element(by.xpath(".//*[@data-protractor-id='sidebarPlaceLink']")).getAttribute('href').then(function(href){
            if(href === placeURL){
                d.fulfill(true);
            }
            // Loop over all elements finished, nothing found
            if(j == (elements.length -1)){
                d.fulfill(false);
            }
            j += 1;

        });
    }

    return d;
}


describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register users:", function(){

    it("Register USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;
            console.log('User1:', USER1.username);
            Signup.verifyEmail(USER1);
        });
    });

    it("Register USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('User2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });

    it("Register USER3", function() {
        Signup.registerUserUntilDone(USER3).then(function(userData){
            USER3.username = userData.username;
            USER3.email = userData.email;
            console.log('User3:', USER3.username);
            Signup.verifyEmail(USER3);
        });
    });
    
    it("Register YOUNG_USER", function() {
        Signup.registerUserUntilDone(YOUNG_USER).then(function(userData){
            YOUNG_USER.username = userData.username;
            YOUNG_USER.email = userData.email;
            console.log('Young User :', YOUNG_USER.username);
            Signup.verifyEmail(YOUNG_USER);
        });
    });

});

describe("Filters age restriction:", function(){

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("USER1 creates age restricted event", function() {

        Events.createNewUnique(AGE_RESTRICTED_EVENT).then(function(event){
            AGE_RESTRICTED_EVENT.url = event.url;
            AGE_RESTRICTED_EVENT.name = event.name;
            AGE_RESTRICTED_EVENT.shortURL = event.url.substr(event.url.indexOf('/events/'));

            console.log("Age restricted event url: ", AGE_RESTRICTED_EVENT.url);
            console.log("Age restricted event name: ", AGE_RESTRICTED_EVENT.name);
        });

    });

    it("USER1 can see his age restricted event", function(){
        browser.get('/events?&show=list');
        browser.waitForAngular();

        fSearch.click();
        fSearchText.sendKeys(AGE_RESTRICTED_EVENT.name);
        element(by.xpath('//div[@class="select2-result-label"]')).click();
        browser.waitForAngular();
        
        expect(
            element(by.xpath("//a[@data-protractor-id='sidebarEventLink' and @href='" + AGE_RESTRICTED_EVENT.shortURL + "']")).isDisplayed()
        ).toBeTruthy();
        
    });
   
    it("Log out USER1", function(){
        Auth.logOut();
    });

    it("Log in as YOUNG_USER", function(){
        Auth.loginAsUser(YOUNG_USER.username, YOUNG_USER.password);
    });

    it("YOUNG_USER can't see age restricted event", function(){
        browser.get('/events?&show=list');
        browser.waitForAngular();

        fSearch.click();

        fSearchText.sendKeys(AGE_RESTRICTED_EVENT.name);
        element(by.xpath('//div[@class="select2-result-label"]')).click();
        browser.waitForAngular();

        expect(
            element(by.xpath("//a[@data-protractor-id='sidebarEventLink' and @href='" + AGE_RESTRICTED_EVENT.shortURL + "']")).isPresent()
        ).toBeFalsy();
        
    });

    it("Log out YOUNG_USER", function(){
        Auth.logOut();
    });
     
});

describe("Filters general tests:", function(){


    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Filters should be on the main page", function(){
        browser.get('/');
        browser.waitForAngular();
        
        expect(fSearch.isDisplayed()).toBeTruthy();
    });


    it("Filters pannel can be hidden without resetting the filters", function(){
        browser.get('/');
        browser.waitForAngular();
        
        expect(fSearch.isDisplayed()).toBeTruthy();
        fSearch.click();
        
        expect(
            element(by.xpath("//*[@data-protractor-id='filtersSearchContainer']")).isDisplayed()
        ).toBeTruthy();
       
        fSearchText.sendKeys("TESTKEYS");
        
       
        element(by.xpath('//div[@class="select2-result-label"]')).click();
        expect(fSearchTag.getText()).toContain("TESTKEYS");
        browser.refresh();
        // show
        fSearch.click();
        expect(fSearchTag.getText()).toContain("TESTKEYS");

        // hide
        fSearch.click();

        // show
        fSearch.click();
        expect(fSearchTag.getText()).toContain("TESTKEYS");

        resetSearch.click();
        expect(fSearchTag.isPresent()).toBeFalsy();
    });

    it("Filters can be switched by content type", function(){
        expect(
            element(by.xpath("//button[@data-protractor-id='contentTypeUsers']")).isDisplayed()
        ).toBeTruthy();

        expect(
            element(by.xpath("//button[@data-protractor-id='contentTypePlaces']")).isDisplayed()
        ).toBeTruthy();

        expect(
            element(by.xpath("//button[@data-protractor-id='contentTypeEvents']")).isDisplayed()
        ).toBeTruthy();
    });

    it("Filters can be switched by display mode", function(){

        expect(
            element(by.xpath("//button[@data-protractor-id='contentModeMap']")).isDisplayed()
        ).toBeTruthy();

        expect(
            element(by.xpath("//button[@data-protractor-id='contentModeList']")).isDisplayed()
        ).toBeTruthy();

        expect(
            element(by.xpath("//button[@data-protractor-id='contentModeStream']")).isDisplayed()
        ).toBeTruthy();

    });

    it("Events should have datetime filter, test special conditions", function(){
        browser.get('/events?&show=list');
        browser.waitForAngular();

        fSearch.click();

        expect(
            element(by.xpath("//button[@data-protractor-id='filtersDatetimeFilter']")).isDisplayed()
        ).toBeTruthy();

        fSearchText.click();
        expect(
            element(by.xpath('//div[@class="select2-result-label" and text()="участвовал"]')).isDisplayed() 
        ).toBeTruthy();

    });

    it("Places should not have datetime filter, test special conditions", function(){
        browser.get('/places?&show=list');
        browser.waitForAngular();

        fSearch.click();

        expect(
            element(by.xpath("//button[@data-protractor-id='filtersDatetimeFilter']")).isPresent()
        ).toBeFalsy();

        fSearchText.click();

        expect(
            element(by.xpath('//div[@class="select2-result-label" and text()="посещал"]')).isDisplayed() 
        ).toBeTruthy();

    });

    it("Users should not have datetime filter, test special conditions", function(){
        browser.get('/users?&show=list');
        browser.waitForAngular();

        fSearch.click();

        expect(
            element(by.xpath("//button[@data-protractor-id='filtersDatetimeFilter']")).isPresent()
        ).toBeFalsy();

        fSearchText.click();

        expect(
            element(by.xpath('//div[@class="select2-result-label" and text()="мои друзья"]')).isDisplayed() 
        ).toBeTruthy();

    });

    it("Log out USER1", function(){
        Auth.logOut();
    });

});

describe("test sidebar:", function(){

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Create place", function(){
        Places.createNewInMoscow(PLACE).then(function(place){
            console.log("Place url: ", place.url);
            PLACE.url = place.url;
        });
    });

    it("Toggle sidebar", function(){

        browser.get('/places?&show=map');
        browser.waitForAngular();

        var zoomOut = element(by.css('.leaflet-control-zoom-out'));

        expect(
            zoomOut.isDisplayed()
        ).toBeTruthy();

        zoomOut.click();
        zoomOut.click();
        zoomOut.click();
        zoomOut.click();

        element(by.xpath("//*[@data-protractor-id='contentSidebar']")).getSize().then(function(size){
            expect(size.height).not.toBe(0);
        });

        element(by.xpath("//*[@data-protractor-id='hideSidebar']")).click();

        element(by.xpath("//*[@data-protractor-id='contentSidebar']")).getSize().then(function(size){
            expect(size.height).toBe(0);
        });
    });

    it("Create place", function(){
        Places.createNewInMoscow(PLACE).then(function(place){
            console.log("Place url: ", place.url);
            PLACE.url = place.url;
        });
    });

    it("Toggle sidebar", function(){

        browser.get('/places?&show=map');
        browser.waitForAngular();

        var zoomOut = element(by.css('.leaflet-control-zoom-out'));
        zoomOut.click();
        zoomOut.click();
        zoomOut.click();
        zoomOut.click();

        element(by.xpath("//*[@data-protractor-id='contentSidebar']")).getSize().then(function(size){
            expect(size.height).not.toBe(0);
        });

        element(by.xpath("//*[@data-protractor-id='hideSidebar']")).click();

        element(by.xpath("//*[@data-protractor-id='contentSidebar']")).getSize().then(function(size){
            expect(size.height).toBe(0);
        });

        element(by.xpath("//*[@data-protractor-id='hideSidebar']")).click();

    });


    it("Create place in Piter", function(){
        Places.createNewInPiter(PITER_PLACE).then(function(place){
            console.log("Place url: ", place.url);
            PITER_PLACE.url = place.url;
        });
    });

    it("Piter place should be not visible when map is focused on Moscow", function(){
        
        focusOnMoscowPlaces();

        var zoomOut = element(by.css('.leaflet-control-zoom-out'));

        expect(
            zoomOut.isDisplayed()
        ).toBeTruthy();

        zoomOut.click();
        zoomOut.click();
        zoomOut.click();
        zoomOut.click();

        expect(
            element(by.repeater('item in dataSource track by item.id')).isDisplayed()
        ).toBeTruthy();

        element.all(by.repeater('item in dataSource track by item.id')).then(function(elements){

            findPlaceByURL(elements, PLACE.url).then(function(found){
                expect(found).toBeTruthy();
            });

            findPlaceByURL(elements, PITER_PLACE.url).then(function(found){
                expect(found).toBeFalsy();
            });

        });
    });

    it("Moscow place should be not visible when map is focused on Piter", function(){
        // Piter
        browser.get("/places?centerPlace=59.94142779110383:30.358657836914062:60.02541222138017:30.907974243164062:59.85723009946356:29.809341430664062:11&show=map");
        browser.waitForAngular();

        var zoomOut = element(by.css('.leaflet-control-zoom-out'));

        expect(
            zoomOut.isDisplayed()
        ).toBeTruthy();

        zoomOut.click();
        zoomOut.click();
        zoomOut.click();
        zoomOut.click();

        element.all(by.repeater('item in dataSource track by item.id')).then(function(elements){

            findPlaceByURL(elements, PITER_PLACE.url).then(function(found){
                expect(found).toBeTruthy();
            });

            findPlaceByURL(elements, PLACE.url).then(function(found){
                expect(found).toBeFalsy();
            });

        });
    });

    it("Map mode must have geo search", function(){
        browser.get('/events?&show=map');
        browser.waitForAngular();

        fSearch.click();
        
        expect(
            element(by.xpath("//*[@data-protractor-id='centerPlaceAddress']")).isDisplayed()
        ).toBeTruthy();

        fSearch.click();
    });

    it("User location button", function(){
        var locBtn = element(by.css('.icon-location'));
        expect(
            locBtn.isDisplayed()
        ).toBeTruthy();

        locBtn.click();

        expect(
            element(by.css('.pin--user-location')).isDisplayed()
        ).toBeTruthy();

    });

    it("Display info window on map marker click", function(){

        focusOnMoscowPlaces();

        var zoomOut = element(by.css('.leaflet-control-zoom-out'));

        expect(
            zoomOut.isDisplayed()
        ).toBeTruthy();

        zoomOut.click();
        zoomOut.click();
        zoomOut.click();
        zoomOut.click();

        browser.actions().mouseMove(
            element(by.css(".leaflet-marker-icon.pin--place.leaflet-clickable"))
        ).click().perform();


        expect(
            element(by.css('.leaflet-popup-content')).isDisplayed()
        ).toBeTruthy();

    });


    it("Log out USER1", function(){
        Auth.logOut();
    });

    
});

describe("Test user location:", function(){

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Save User1 location - visible to friends", function(){

        element(by.xpath("//button[@data-protractor-id='userProfile']")).click();
        element(by.xpath("//button[@id='save-location-history']")).click();
        
        browser.sleep(2000);
        browser.waitForAngular();

        expect(
            element(by.name("userPlaceForm")).isDisplayed()
        ).toBeTruthy();

        element(by.xpath("//div[@id='s2id_place']//a")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE.name);
        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();

        Visibility.setVisibility({visibility: '2'}, 'visibilityEntity');

        element(by.name("userPlaceForm")).submit();
        Auth.logOut();

    });

    it("USER1 and USER2 make friendship", function(){
        Friendship.beFriends(USER1, USER2);
    });

    it("USER1 must be shown on Moscow map to USER2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        focusOnMoscowUsers();
        expect(
            element(by.xpath('//*[@data-protractor-id="contentSidebar"]//a[text()="' +USER1.username+ '"]')).isPresent()
        ).toBeTruthy();
        Auth.logOut();
    });

    it("USER1 must be hidden on Moscow map to USER3", function(){
        Auth.loginAsUser(USER3.username, USER3.password);
        focusOnMoscowUsers();

        expect(
            element(by.xpath('//*[@data-protractor-id="contentSidebar"]//a[text()="' +USER1.username+ '"]')).isPresent()
        ).toBeFalsy();

        Auth.logOut();
    });
});

describe("Test search parameters:", function(){

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Create place", function(){
        Places.createNewInMoscow(PLACE).then(function(place){
            console.log("Place url: ", place.url);
            console.log("Place name: ", place.name);
            PLACE.url = place.url;
            PLACE.shortURL = place.url.substr(place.url.indexOf('/places/'));
            PLACE.address = place.address;
        });
    });


    it("USER1 logout", function(){
        Auth.logOut();
    });

    it("Log in as USER2", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
    });

    it("Create place for post from user1", function(){
        
        Places.createNewInMoscow(PLACE_WITH_POST).then(function(place){
            console.log("Place with post url: ", place.url);
            console.log("Place with post name: ", place.name);
            PLACE_WITH_POST.url = place.url;
            PLACE_WITH_POST.name = place.name;
            PLACE_WITH_POST.shortURL = place.url.substr(place.url.indexOf('/places/'));
            CHECKIN_EVENT.place_name = PLACE_WITH_POST.name;
        }).then(function(){

            CHECKIN_EVENT.ts_start = moment().add(EVENT_MIN_START_OFFSET, 'm').format("DD.MM.YYYY HH:mm");

            yesterday = moment().subtract(1, 'd');
            tomorrow = moment().add(1, 'd');

            Events.createNewUnique(CHECKIN_EVENT).then(function(event){
                CHECKIN_EVENT.url = event.url;
                CHECKIN_EVENT.name = event.name;
                CHECKIN_EVENT.shortURL = event.url.substr(event.url.indexOf('/events/'));
                console.log("Checkin event url: ", CHECKIN_EVENT.url);
                console.log("Checkin event name: ", CHECKIN_EVENT.name);
            });
            
        });
    });

    it("create future (tomorrow) event", function(){

        FUTURE_EVENT.ts_start = moment().add(1, 'd').format("DD.MM.YYYY HH:mm");

        Events.createNewUnique(FUTURE_EVENT).then(function(event){
            FUTURE_EVENT.url = event.url;
            FUTURE_EVENT.name = event.name;
            FUTURE_EVENT.shortURL = event.url.substr(event.url.indexOf('/events/'));
            console.log("Future event url: ", FUTURE_EVENT.url);
            console.log("Future event name: ", FUTURE_EVENT.name);
        });
    });

    it("Wait for checkin event to get started", function(){
        browser.driver.sleep(EVENT_MIN_START_OFFSET * 60000);
    });

    it("Event can be found by association: created by me", function(){
        findEvent('создавал', CHECKIN_EVENT);
    });

    it("Create place for user1 subscription", function(){
        
        Places.createNewInMoscow(PLACE_SUBSCRIBED).then(function(place){
            console.log("Place subscribe url: ", place.url);
            console.log("Place subscribe name: ", place.name);
            PLACE_SUBSCRIBED.url = place.url;
            PLACE_SUBSCRIBED.shortURL = place.url.substr(place.url.indexOf('/places/'));
        });
    });


    it("USER2 logout", function(){
        Auth.logOut();
    });

    it("Log in as USER1", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
    });

    it("Subscribe to event", function(){

        browser.get(CHECKIN_EVENT.url);
        browser.waitForAngular();

        element(by.xpath("//*[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//*[@data-protractor-id='subscribeEvent']")).click();

        expect(
            element(by.xpath("//button[@data-protractor-id='confirmSubscription']")).isDisplayed()
        ).toBeTruthy();

        element(by.xpath("//button[@data-protractor-id='confirmSubscription']")).click();
    });

    it("Check in at CHECKIN_EVENT event", function(){
        browser.get(CHECKIN_EVENT.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();

        element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).click();

    });

    it("Leave a post on event page", function(){
        
        browser.get(CHECKIN_EVENT.url);
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys("Test event post");
        element(by.name('addXPostForm')).submit();

    });


    it("Leave a post on the PLACE_WITH_POST page", function(){
        
        browser.get(PLACE_WITH_POST.url);
        browser.waitForAngular();

        element(by.id('xPostBody')).sendKeys("Test post");
        element(by.name('addXPostForm')).submit();

    });

    it("Subscribe to PLACE_SUBSCRIBED place", function(){
        
        browser.get(PLACE_SUBSCRIBED.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='subscribePlace']")).click();

        expect(
            element(by.xpath("//button[@data-protractor-id='confirmSubscription']")).isDisplayed()
        ).toBeTruthy();

        element(by.xpath("//button[@data-protractor-id='confirmSubscription']")).click();
    });


    it("Place1 can be found by tag", function(){
        findPlaceByText(PLACE.tag, PLACE);
    });

    it("Place can be found by text: by name", function(){

        findPlaceByText(PLACE.name, PLACE);
    });

    it("Place can be found by text: by address", function(){

        findPlaceByText(PLACE.address, PLACE);
    });

    it("Place can be found by text: by description", function(){

        findPlaceByText(PLACE.description, PLACE);
    });

    it("Place can be found by association: created by me", function(){
        findPlace('создавал', PLACE);
    });


    it("Place can be found by association: checked in", function(){
        
        findPlace('посещал', PLACE_WITH_POST);
    });


    it("PLACE_WITH_POST can be found by association: discussed", function(){

        findPlace('обсуждал', PLACE_WITH_POST);
    });

    it("PLACE_SUBSCRIBED can be found by association: subscribed", function(){

        findPlace('подписан', PLACE_SUBSCRIBED);
    });

    it("Event can be found by tag", function(){

        findEventByText(CHECKIN_EVENT.tag, CHECKIN_EVENT);
    });

    it("Event can be found by association: checked in", function(){

        findEvent('участвовал', CHECKIN_EVENT);
    });


    it("Event can be found by association: discussed", function(){
        findEvent('обсуждал', CHECKIN_EVENT);
    });

    it("Event can be found by association: subscribed", function(){

        findEvent('подписан', CHECKIN_EVENT);
    });

    it("Event can be found by association: started", function(){

        findEvent('проходят сейчас', CHECKIN_EVENT);
    });

    it("Event can be found by association: today", function(){
        findEvent('сегодня', CHECKIN_EVENT);
    });

    it("Event can be found by association: not started", function(){
        findEvent('не начались', FUTURE_EVENT);
    });


    it("Event can be found by association: tomorrow", function(){
        findEvent('завтра', FUTURE_EVENT);
    });

    it("Event can be found by date range", function(){

        browser.get('/events?&show=list');
        browser.waitForAngular();
        
        fSearch.click();
        element(by.xpath("//button[@data-protractor-id='filtersDatetimeFilter']")).click();
        
        var yearSelector = element(by.xpath('//select[@class="ui-datepicker-year"]')),
            monthSelector = element(by.xpath('//select[@class="ui-datepicker-month"]')),
            datePicker1 = element(by.id('date_from_date')),
            datePicker2 = element(by.id('date_to_date'));

        datePicker1.click();
        selectDropdownbyValue(yearSelector, yesterday.year());
        selectDropdownbyValue(monthSelector, yesterday.month());
        element(by.xpath('//a[text()="' + yesterday.date() + '"]')).click();

        fSearch.click();

        selectDropdownbyValue(element(by.id('date_from_hour')), 0);
        selectDropdownbyValue(element(by.id('date_from_minute')), 0);
        
        datePicker2.click();
        selectDropdownbyValue(yearSelector, tomorrow.year());
        selectDropdownbyValue(monthSelector, tomorrow.month());
        element(by.xpath('//a[text()="' + tomorrow.date() + '"]')).click();

        fSearch.click();

        selectDropdownbyValue(element(by.id('date_to_hour')), 23);
        selectDropdownbyValue(element(by.id('date_to_minute')), 59);
        
        expect(
            element(by.xpath("//a[@data-protractor-id='sidebarEventLink' and @href='" + CHECKIN_EVENT.shortURL + "']")).isDisplayed()
        ).toBeTruthy();

    });

});


describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
