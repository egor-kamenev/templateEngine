var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 25,
        'password': 'hackme'
    },
    PLACE = {
        'name': 'place',
        'visibility': '4'
    },
    PLACE2 = {
        'name': 'place',
        'visibility': '4'
    };
    

var Auth = require('../utils/auth.js'),
    Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

browser.driver.manage().window().maximize();

function findReactElement(selector){
    return protractor.promise.filter(element.all(selector), function(e) { 
        return e.isDisplayed(); 
    }).then(function(visibleElements) {
        expect(visibleElements.length).toBe(1);
        return visibleElements[0];
    }); 
}

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

});

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users:", function(){

    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });
    
    it("Registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

});


describe("Test favorite:", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE);
        Auth.logOut();
    });

    it("create place2", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE2);
        Auth.logOut();
    });

    it("add place to favorites", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places?tags=' + PLACE.name + '&show=list');
        browser.waitForAngular();

        element(by.name('add-to-favorite')).click();
        expect( element(by.name('add-to-favorite')).getAttribute('class') ).toMatch(/favorite--used/);

        //Auth.logOut();
    });

    it("add to favorite place2", function(){

        browser.get('/places/' + PLACE2.name);
        browser.waitForAngular();

        element(
            by.xpath("//*[@data-protractor-id='placeMegaMenu']")
        ).click();

        expect(
            element(by.xpath("//*[@data-protractor-id='favoritePlace']")).isDisplayed() 
        ).toBeTruthy();

        expect(
            element(by.xpath("//*[@data-protractor-id='favoritePlace']")).getText()
        ).toBe('В избранное');
       
        var favBtn = browser.findElement( 
            by.xpath("//*[@data-protractor-id='favoritePlace']") 
        );

        browser.executeScript(scrollIntoView, favBtn);

        favBtn.click();
        browser.waitForAngular();

        expect(
            element(by.xpath("//button[@data-protractor-id='favoritePlace']")).getText()
        ).toBe('Убрать из избранного');

    });

    it("check the number of places in favorites", function(){

        browser.get('/users/' + USER.username);
        browser.waitForAngular();
        
        var menuBtn = browser.findElement( 
            by.xpath("//*[@data-protractor-id='userOwnerMegaMenu']")
        );

        browser.executeScript(scrollIntoView, menuBtn);

        menuBtn.click();

        findReactElement(by.xpath("//a[@data-protractor-id='userPlaceFavorites']")).then(function(favBtn){
            favBtn.click();
            browser.waitForAngular();

            expect(element.all(by.repeater("item in dataSource track by item.id")).count()).toBe(2);
        });

    });

    it("delete favorite place", function(){

        //Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places?tags=' + PLACE.name + '&show=list');
        browser.waitForAngular();

        element(by.name('add-to-favorite')).click();
        //element(by.xpath("//button[contains(@data-do-favorite,'') and contains(@class,'favorite--used')]")).click();

        //Auth.logOut();
    });

    it("delete favorite place2", function(){

        browser.get('/places/' + PLACE2.name);
        browser.waitForAngular();


        element(
            by.xpath("//*[@data-protractor-id='placeMegaMenu']")
        ).click();

        expect(
            element(by.xpath("//*[@data-protractor-id='favoritePlace']")).isDisplayed() 
        ).toBeTruthy();

        expect(
            element(by.xpath("//*[@data-protractor-id='favoritePlace']")).getText()
        ).toBe('Убрать из избранного');
       
        var favBtn = browser.findElement( 
            by.xpath("//*[@data-protractor-id='favoritePlace']") 
        );

        browser.executeScript(scrollIntoView, favBtn);

        favBtn.click();
        browser.waitForAngular();

        expect(
            element(by.xpath("//button[@data-protractor-id='favoritePlace']")).getText()
        ).toBe('В избранное');


    });

    it("check count places in favorites", function(){
        Auth.loginAsUser(USER.username, USER.password);
        
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();

        findReactElement(by.xpath("//a[@data-protractor-id='userPlaceFavorites']")).then(function(favBtn){
            favBtn.click();
            browser.waitForAngular();

            expect(element.all(by.repeater("item in dataSource track by item.id")).count()).toBe(0);

        });


    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
