'use strict';

var EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    USER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'simple',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 22,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 


describe("Register users: ", function() {
    
    it("Registrate and verify USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;

            console.log('User', USER.username);

            Auth.loginAsUser(USER.username, USER.password);
            Signup.verifyEmail(USER);
            Auth.logOut();
        });
    });

    it("Registrate and verify USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;

            console.log('User2', USER2.username);

            Auth.loginAsUser(USER2.username, USER2.password);
            Signup.verifyEmail(USER2);
            Auth.logOut();
        });
    });

});

describe("Create, delete event and check:", function(){

    it("create event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Events.createNew(EVENT);
        console.log('Event', EVENT);
    });

    it("check visibility delete button if user not owner", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='deleteEvent']")).isPresent()).toBe(false);
        Auth.logOut();
    });

    it("delete event and check event exist", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Events.deleteEvent(EVENT);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/404');

        browser.get('/events?tags=' + EVENT.name + '&show=list');
        browser.waitForAngular();

        expect(element.all(by.xpath("//div[@class='list-entry']")).count()).toBe(0);
        Auth.logOut();
    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
