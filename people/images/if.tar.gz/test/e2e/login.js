'use strict';
var LOGIN_URL = '/auth/login',
    TEST_LOGIN = "",
    TEST_PASS = "",
    Auth = require('../utils/auth.js'),
    REG_USER = {
        'username': 'TestRegUser',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'test@mail.com',
        'age': 30,
        'password': 'hackme'
    };

var Signup = require('../utils/signup.js');


describe("Login ", function(){

    it("create test user", function(){
        Signup.registerUserUntilDone(REG_USER).then(function(userData){
            TEST_LOGIN = userData.username;
            TEST_PASS = REG_USER.password;
            console.log("Test login: ", TEST_LOGIN);
        });
    });

    
    it("login url should display login form", function(){

        browser.get(LOGIN_URL);
        browser.waitForAngular();
        
        var loginFormEl = element(by.name('loginForm')),
            usernameEl = element(by.model('credentials.username')),
            passwdEl = element(by.model('credentials.password')),
            loginButton = element(by.xpath('//form[@name="loginForm"]//button[@type="submit"]'));
                                  
        expect(loginFormEl.isDisplayed()).toBeTruthy();
        expect(usernameEl.isDisplayed()).toBeTruthy();
        expect(passwdEl.isDisplayed()).toBeTruthy();
        expect(loginButton.isDisplayed()).toBeTruthy();
    });

    it("registered user can login", function(){
        Auth.loginAsUser(TEST_LOGIN, TEST_PASS);
        Auth.logOut();
    });

    it("not registered user can't login", function(){

        var invalidLoginEl = element(by.xpath('//div[@ng-show="loginForm.$dirty && loginForm.$invalid && loginForm.$error.invalid_login"]'));

        browser.get(LOGIN_URL);
        browser.waitForAngular();
        
        element(by.id('id_username')).sendKeys("jafasdfsadf");
        element(by.id('id_password')).sendKeys("dsafj;dfhas;df");
        element(by.name('loginForm')).submit();

        expect(invalidLoginEl.isDisplayed()).toBe(true);
        

    });

    it("admin block user", function(){
        
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        browser.get(ADMIN_URL + '/admin/users/user/');
        
        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        ptor.driver.findElement(protractor.By.id('searchbar')).sendKeys(TEST_LOGIN);
        ptor.driver.findElement(protractor.By.id('changelist-search')).submit();

        ptor.driver.findElement(protractor.By.xpath('//table[@id="result_list"]//a[text()="' + TEST_LOGIN +'"]')).click();

        ptor.driver.findElement(protractor.By.xpath("//a[@class='ban_button']")).click();
        
        driver.switchTo().alert().accept();

        browser.ignoreSynchronization = false;

    });

    it("blocked user can't login", function(){
        Auth.logOut();
        var invalidLoginEl = element(by.xpath('//div[@ng-show="loginForm.$dirty && loginForm.$invalid && loginForm.$error.inactive"]'));

        browser.get(LOGIN_URL);
        browser.waitForAngular();
        
        element(by.id('id_username')).sendKeys(TEST_LOGIN);
        element(by.id('id_password')).sendKeys(TEST_PASS);
        element(by.name('loginForm')).submit();
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/401');

    });

    it("Login tests finished - log out", function(){
        Auth.logOut();
    });
    
});
