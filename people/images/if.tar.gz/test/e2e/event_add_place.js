'use strict';

var moment = require('moment'),
    https = require('https');

var EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'рыбалка',
        'description': 'Event for test invitations without invitations',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4',
        'place': {
            'visibility': '4',
            'name': 'Aloxa' + Math.random().toString(36).substring(2)
        }
    },
    OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'Kaki',
        'first_name': 'Mutaki',
        'last_name': 'Hironi',
        'email': 'bigboss@mail.com',
        'phone': '+79111222001',
        'age': 24,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'Uran',
        'first_name': 'Bakinskiu',
        'last_name': 'Petrovich',
        'email': 'bigboss@mail.com',
        'phone': '+79111222001',
        'age': 32,
        'password': 'hackme'
    };   

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

var EVENT_MIN_START_OFFSET = 2;

var newPlaceName = '';

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Register users: ", function() {
    
    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('OWNER:', OWNER.username);

            Signup.verifyEmail(OWNER);
        });
    });

    it("Registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);

            Signup.verifyEmail(USER);
        });
    });

});

describe("Only owner can add place after event starts:", function(){

    it("Create event", function(){
        //OWNER.username = 'BigBoss374509';
        Auth.loginAsUser(OWNER.username, OWNER.password);
        EVENT.ts_start = moment().add(EVENT_MIN_START_OFFSET, 'm').format("DD.MM.YYYY HH:mm");
        Events.createNew(EVENT);
        console.log('EVENT:', EVENT.name);
        //browser.driver.sleep(240000);
        //Auth.logOut();
    });

    it("wait for event to start", function(){
        var timeout = (EVENT_MIN_START_OFFSET) * 60000;
        console.log("Waiting ", timeout/1000.0, " seconds for event to start....");
        browser.sleep(timeout);
    });

    it("Owner can change event place", function(){
        //Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventRoute']")).click();
        browser.waitForAngular();
        
        element(by.xpath("//button[@data-protractor-id='placeChanges']")).click();
        
        element(by.xpath('//div[@id="s2id_place"]//a')).click();

        element(by.xpath('(//div[@id="select2-drop"]//ul[@class="select2-results"]//div)[1]')).click();
        
        //browser.driver.sleep(5000);
        element(by.xpath('//div[@id="s2id_place"]//input')).sendKeys(protractor.Key.ESCAPE);

        element(by.xpath('//div[@id="s2id_place"]//a[@class="select2-choice"]')).getText().then(function(value){
            newPlaceName = value;
            element(by.name("placeChangeForm")).submit();
        });
    });

    it("Check the list of places and chronology", function(){
        //Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT.name);
        browser.waitForAngular();

        element(by.xpath("//a[@href='/events/" + EVENT.name + "/route']")).click();
        
        expect(element.all(by.repeater("item in places")).count()).toBe(2);

        expect(element(by.repeater('item in places').row(0)).element(by.xpath("//a[text()='" + newPlaceName + "']")).isPresent()).toBe(true);
    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
