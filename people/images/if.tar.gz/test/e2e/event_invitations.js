'use strict';



var EVENT2 = {
        'name': 'testevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '0',
        'by_invitation': true,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'testevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '6',
        'by_invitation': true,
        'visibility': '0'
    },
    EVENT4 = {
        'name': 'testevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '6',
        'by_invitation': true,
        'visibility': '0'
    },
    EVENT5 = {
        'name': 'testevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '6',
        'by_invitation': true,
        'visibility': '0'
    },
    EVENT6 = {
        'name': 'testevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '6',
        'by_invitation': true,
        'visibility': '0'
    },
    OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER1 = {
        'username': 'user1Test',
        'first_name': 'John',
        'last_name': 'Tester',
        'email': 'user1test@mail.com',
        'phone': '+79111222001',
        'age': 15,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user2Test',
        'first_name': 'John',
        'last_name': 'Tester',
        'email': 'user2test@mail.com',
        'phone': '+79111222002',
        'age': 30,
        'password': 'hackme'
    },
    USER3 = {
        'username': 'user3Test',
        'first_name': 'John',
        'last_name': 'Tester',
        'email': 'user3test@mail.com',
        'phone': '+79111222003',
        'age': 30,
        'password': 'hackme'
    },
    USER4 = {
        'username': 'user3Test',
        'first_name': 'John',
        'last_name': 'Tester',
        'email': 'user3test@mail.com',
        'phone': '+79111222003',
        'age': 30,
        'password': 'hackme'
    },
    USER5 = {
        'username': 'user3Test',
        'first_name': 'John',
        'last_name': 'Tester',
        'email': 'user3test@mail.com',
        'phone': '+79111222003',
        'age': 35,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Settings = require('../utils/settings.js'),
    Participation = require('../utils/participation.js'),
    Comments = require('../utils/comments.js'),
    Signup = require('../utils/signup.js');

var getInvitation = function (username, action) {
    browser.get('/users/' + username + '/messages/buns');
    browser.waitForAngular();
    browser.findElements(by.xpath('//div[contains(@class,"new")]')).then(
        function (elements) {
            elements.map(function (bun, index) {
                bun.findElement(by.xpath('div/button[@ng-click="' + action + '(bun)"]')).click();
            });
        }
    );
};

var selectDropdownbyValue = function (element, optionValue) {
    element.all(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

browser.driver.manage().window().maximize();

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users: ", function() {
    
    it("Registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner', OWNER);
             Signup.verifyEmail(OWNER);
        });
    });

    xit("Registrate USER1", function() {
        Signup.registerUserUntilDone(USER1).then(function(userData){
            USER1.username = userData.username;
            USER1.email = userData.email;
            console.log('USER1', USER1);
            Signup.verifyEmail(USER1);
        });
    });

    xit("Registrate USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2', USER2);
            Signup.verifyEmail(USER2);
        });
    });

    xit("Registrate USER3", function() {
        Signup.registerUserUntilDone(USER3).then(function(userData){
            USER3.username = userData.username;
            USER3.email = userData.email;
            console.log('USER3', USER3);
            Signup.verifyEmail(USER3);
        });
    });

    xit("Registrate USER4", function() {
        Signup.registerUserUntilDone(USER4).then(function(userData){
            USER4.username = userData.username;
            USER4.email = userData.email;
            console.log('USER4', USER4);
            Signup.verifyEmail(USER4);
        });
    });

    xit("Registrate USER5", function() {
        Signup.registerUserUntilDone(USER5).then(function(userData){
            USER5.username = userData.username;
            USER5.email = userData.email;
            console.log('USER5', USER5);
            Signup.verifyEmail(USER5);
        });
    });

});

xdescribe("Test event by invitation. Ask and give invitations: ", function(){
    
    it("Create not open event", function() {

        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNewUnique(EVENT2).then(function(event){
            EVENT2.url = event.url;
            EVENT2.name = event.name;
            console.log("EVENT2 url: ", EVENT2.url);
            console.log("EVENT2 name: ", EVENT2.name);
            Auth.logOut();
        });
    });
    
    it("Ask invitations", function(){
        Participation.intendedToGoEventByInvitetion(USER1, EVENT2);
        
        Participation.intendedToGoEventByInvitetion(USER2, EVENT2);

        Participation.intendedToGoEventByInvitetion(USER3, EVENT2);
    });
    
    it("Give invitations", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.giveInvitations(EVENT2.name, [USER2.username, USER3.username]);
        Auth.logOut();
    });
    
    it("Check participants", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Participation.eventUserInParticipation(OWNER, EVENT2, USER1, false);
        Participation.eventUserInParticipation(OWNER, EVENT2, USER2, true);
        Participation.eventUserInParticipation(OWNER, EVENT2, USER3, true);
        Participation.eventCountParticipation(OWNER, EVENT2, 2);
    });

});

xdescribe("Test event by invitation. Owner give invitations by username: ", function(){
    
    it("Create not open event", function() {
        
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNewUnique(EVENT3).then(function(event){
            EVENT3.url = event.url;
            EVENT3.name = event.name;
            console.log("EVENT3 url: ", EVENT3.url);
            console.log("EVENT3 name: ", EVENT3.name);
            Auth.logOut();
        });

    });

    xit("Give invitations", function(){
       
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT3.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggelResources']")).click();
        element(by.xpath("//a[@data-protractor-id='Invitation']")).click();
        
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();

        element(by.xpath("//a[@data-protractor-id='giveResource']")).click();

        // try give invi to young user 

        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).click();
        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).sendKeys(USER1.username);
        browser.driver.sleep(2000);
        expect(element(by.xpath("//ul[@class='select2-results']//li[text()='No matches found']")).isPresent()).toBe(true);
        
        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).clear();

        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).sendKeys(USER2.username);
        browser.driver.sleep(2000);
        element(by.xpath("//ul[@class='select2-results']//li/div[text()='" + USER2.username + "']")).click();

        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).click();
        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).sendKeys(USER3.username);
        browser.driver.sleep(2000);
        element(by.xpath("//ul[@class='select2-results']//li/div[text()='" + USER3.username + "']")).click();

        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).click();
        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).sendKeys(USER4.username);
        browser.driver.sleep(2000);
        element(by.xpath("//ul[@class='select2-results']//li/div[text()='" + USER4.username + "']")).click();

        element(by.xpath("//textarea[@id='defaultComment']")).sendKeys('Aloha!');

        element(by.xpath("//input[@id='defaultAmount']")).clear();
        element(by.xpath("//input[@id='defaultAmount']")).sendKeys(3);

        element(by.xpath("//button[@data-protractor-id='sendResources']")).click();

        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='sendForAll']")).click();

        Auth.logOut();
    });

    xit("check invi", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/events/' + EVENT3.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/events/' + EVENT3.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();

        Auth.loginAsUser(USER3.username, USER3.password);
        browser.get('/events/' + EVENT3.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();

        Auth.loginAsUser(USER4.username, USER4.password);
        browser.get('/events/' + EVENT3.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();
    });

    xit("check recipient invi buttons(accept, reject, ban) accept", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggleMessages']")).click();
        element(by.xpath("//a[@data-protractor-id='messagesInvite']")).click();

        browser.navigate().refresh();

        expect(element(by.xpath("//a[@href='/events/" +  EVENT3.name + "']")).isDisplayed()).toBe(true);

        expect(element(by.xpath("//a[@data-ng-show='canBeAccepted(request)']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-ng-show='canBeRejected(request)']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-ng-show='canBeBanned(request)']")).isDisplayed()).toBe(true);

        element(by.xpath("//a[@data-ng-show='canBeAccepted(request)']")).click();
        expect(element(by.xpath("//span[@data-ng-show='request.current_state==states.accepted']")).isDisplayed()).toBe(true);
        
        expect(element(by.xpath("//a[@data-ng-show='canBeAccepted(request)']")).isDisplayed()).toBe(false);
        expect(element(by.xpath("//a[@data-ng-show='canBeRejected(request)']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-ng-show='canBeBanned(request)']")).isDisplayed()).toBe(false);

        Auth.logOut();
    });

    xit("check recipient invi buttons(accept, reject, ban) rejected", function(){
        Auth.loginAsUser(USER3.username, USER3.password);
        
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggleMessages']")).click();
        element(by.xpath("//a[@data-protractor-id='messagesInvite']")).click();

        browser.navigate().refresh();

        expect(element(by.xpath("//a[@href='/events/" +  EVENT3.name + "']")).isDisplayed()).toBe(true);

        expect(element(by.xpath("//a[@data-ng-show='canBeAccepted(request)']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-ng-show='canBeRejected(request)']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-ng-show='canBeBanned(request)']")).isDisplayed()).toBe(true);

        element(by.xpath("//a[@data-ng-show='canBeRejected(request)']")).click();
        expect(element(by.xpath("//span[@data-ng-show='request.current_state==states.rejected']")).isDisplayed()).toBe(true);
        
        Auth.logOut();
    });

    xit("check recipient invi buttons(accept, reject, ban) ban", function(){
        Auth.loginAsUser(USER4.username, USER4.password);
        
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggleMessages']")).click();
        element(by.xpath("//a[@data-protractor-id='messagesInvite']")).click();

        browser.navigate().refresh();

        expect(element(by.xpath("//a[@href='/events/" +  EVENT3.name + "']")).isDisplayed()).toBe(true);

        expect(element(by.xpath("//a[@data-ng-show='canBeAccepted(request)']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-ng-show='canBeRejected(request)']")).isDisplayed()).toBe(true);
        expect(element(by.xpath("//a[@data-ng-show='canBeBanned(request)']")).isDisplayed()).toBe(true);

        element(by.xpath("//a[@data-ng-show='canBeBanned(request)']")).click();

        expect(element(by.xpath("//a[@href='/events/" +  EVENT3.name + "']")).isDisplayed()).toBe(false);
        
        Auth.logOut();
    });  /// ????

});

xdescribe("Test event by invitation. Owner give invitations by email: ", function(){
    
    it("Create not open event", function() {
        
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNewUnique(EVENT4).then(function(event){
            EVENT4.url = event.url;
            EVENT4.name = event.name;
            console.log("EVENT4 url: ", EVENT4.url);
            console.log("EVENT4 name: ", EVENT4.name);
            Auth.logOut();
        });

    });

    it("Give invitations", function(){
       
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggelResources']")).click();
        element(by.xpath("//a[@data-protractor-id='Invitation']")).click();
        
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();

        element(by.xpath("//a[@data-protractor-id='giveResource']")).click();

        // try give invi to young user

        var emails = USER1.email + "\n" + USER2.email + "\n" + USER3.email;

        element(by.xpath("//textarea[@id='invitedEmails']")).sendKeys(emails);

        element(by.xpath("//button[@data-protractor-id='sendResources']")).click();
        browser.driver.sleep(5000);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='sendForAll']")).click();

        Auth.logOut();
    });

    it("check invi", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();

        Auth.loginAsUser(USER3.username, USER3.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();
    });

});

xdescribe("Test event by invitation. Owner give invitations by friends tags: ", function(){
    
    it("Create not open event", function() {
        
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNewUnique(EVENT5).then(function(event){
            EVENT5.url = event.url;
            EVENT5.name = event.name;
            console.log("EVENT5 url: ", EVENT5.url);
            console.log("EVENT5 name: ", EVENT5.name);
            Auth.logOut();
        });

    });

    it("Give invitations", function(){
       
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT5.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggelResources']")).click();
        element(by.xpath("//a[@data-protractor-id='Invitation']")).click();
        
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();

        element(by.xpath("//a[@data-protractor-id='giveResource']")).click();

        element(by.xpath("//div[@id='s2id_friendshipTags']/ul/li/input")).click();
        element(by.xpath("//ul[@class='select2-results']//li/div[text()='друзья']")).click();

        browser.driver.sleep(2000);

        element(by.xpath("//button[@data-protractor-id='sendResources']")).click();
        browser.driver.sleep(5000);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='sendForAll']")).click();

        Auth.logOut();
    });

    xit("check invi", function(){
        Auth.loginAsUser(USER1.username, USER1.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');
        Auth.logOut();

        Auth.loginAsUser(USER2.username, USER2.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();

        Auth.loginAsUser(USER3.username, USER3.password);
        browser.get('/events/' + EVENT4.name);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).not.toContain('/403');
        Auth.logOut();
    }); /// ????

});

xdescribe("Can't send invi to blocked user, if user register in invitor.com, send to user email invi", function(){

    it("block user", function(){
        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        browser.get(ADMIN_URL + '/admin/users/user/');
        
        var ptor = protractor.getInstance(),
            driver = ptor.driver;

        ptor.driver.findElement(protractor.By.id('searchbar')).sendKeys(USER5.username);
        ptor.driver.findElement(protractor.By.id('changelist-search')).submit();

        ptor.driver.findElement(protractor.By.xpath('//table[@id="result_list"]//a[text()="' + USER5.username +'"]')).click();

        ptor.driver.findElement(protractor.By.xpath("//a[@class='ban_button']")).click();
        
        driver.switchTo().alert().accept();

        browser.ignoreSynchronization = false;
    });

    it("Create not open event", function() {
        
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNewUnique(EVENT6).then(function(event){
            EVENT6.url = event.url;
            EVENT6.name = event.name;
            console.log("EVENT5 url: ", EVENT6.url);
            console.log("EVENT5 name: ", EVENT6.name);
            Auth.logOut();
        });

    });

    it("can't add blocked user", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/events/' + EVENT6.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggelResources']")).click();
        element(by.xpath("//a[@data-protractor-id='Invitation']")).click();
        
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();

        element(by.xpath("//a[@data-protractor-id='giveResource']")).click();

        // try give invi to young user 

        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).click();
        element(by.xpath("//div[@id='s2id_specifiedUsers']/ul/li/input")).sendKeys(USER5.username);
        browser.driver.sleep(2000);
        expect(element(by.xpath("//ul[@class='select2-results']//li[text()='No matches found']")).isPresent()).toBe(true);
        

        Auth.logOut();
    });

});

