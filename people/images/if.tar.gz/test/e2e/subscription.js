'use strict';

var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 10, 0),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 14, 0),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT4 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 5),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT5 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 5),
        'tag': 'встреча',
        'description': 'Event for test4',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT6 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': '',
        'ts_finish': '',
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT7 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'дом',
        'ts_start': evtDate(30, 12, 15),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4',
        'place': {
            'name': 'place' + + Math.floor(Math.random()*1000000),
            'visibility': '4'
        }
    },
    EVENT8 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30, 12, 15),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT9 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30, 12, 15),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT10 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30, 12, 13),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT11 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'tag': 'встреча',
        'ts_start': evtDate(30, 12, 13),
        'description': 'Event description',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4',
        'age_restrict': '6'

    },
    PLACE2 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE3 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE4 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE5 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE6 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE7 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 25,
        'password': 'hackme'
    },
    USER2 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222001',
        'age': 25,
        'password': 'hackme'
    },
    USER3 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222002',
        'age': 32,
        'password': 'hackme'
    },
    USER4 = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222001',
        'age': 22,
        'password': 'hackme'
    },
    USER5 = {
        'username': 'small',
        'first_name': 'boby',
        'last_name': 'kakakos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 10,
        'password': 'hackme'
    },
    USER6 = {
        'username': 'Xulio',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 30,
        'password': 'hackme'
    },
    USER7 = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 30,
        'password': 'hackme'
    },
    USER8 = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 30,
        'password': 'hackme'
    },
    USER_P = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 30,
        'password': 'hackme'
    },
    USER2_P = {
        'username': 'smallKarlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 12,
        'password': 'hackme'
    },
    USER3_P = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 45,
        'password': 'hackme'
    },
    USER4_P = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 29,
        'password': 'hackme'
    },
    USER5_P = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 25,
        'password': 'hackme'
    },
    USER6_P = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 25,
        'password': 'hackme'
    },
    USER7_P = {
        'username': 'Karlos',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 29,
        'password': 'hackme'
    },
    USER_U = {
        'username': 'Merals',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 28,
        'password': 'hackme'
    },
    USER2_U = {
        'username': 'Tehero',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 29,
        'password': 'hackme'
    },
    USER3_U = {
        'username': 'Merals',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 31,
        'password': 'hackme'
    },
    USER4_U = {
        'username': 'Tehero',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 32,
        'password': 'hackme'
    },
    USER5_U = {
        'username': 'Merals',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 31,
        'password': 'hackme'
    },
    USER6_U = {
        'username': 'Tehero',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 32,
        'password': 'hackme'
    },
    USER7_U = {
        'username': 'Merals',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 31,
        'password': 'hackme'
    },
    USER8_U = {
        'username': 'Tehero',
        'first_name': 'Eskabares',
        'last_name': 'Diegos',
        'email': 'bigboss@mail.com',
        'phone': '+79111222061',
        'age': 32,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Mailer =  require('../utils/userMail.js'),
    Friendship = require('../utils/friendship.js'),
    Subscription = require('../utils/subscription.js'),
    Settings = require('../utils/settings.js'),
    TagSelector = require('../utils/tagSelector.js'),
    Visibility = require('../utils/visibility.js'),
    Places = require('../utils/places.js'),
    Comments = require('../utils/comments.js'),
    Signup = require('../utils/signup.js'),
    moment = require('moment'),
    EVENT_MIN_START_OFFSET = 2;

function checkMail(u, n){

    // Wait for celery to deliver mail
    browser.driver.sleep(5000);

    var userMail = new Mailer(u.email),
        flow = protractor.promise.controlFlow();
    
    flow.execute(userMail.getAllMail).then(function(value){
        //for(var i = 0; i < value.length; i++){
        //    console.log("Mail: ", i, value[i]);
        //}
        expect(value.length).toBeGreaterThan(n-1);
    });
}
var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

describe("Set moderation settings to default", function(){


    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 
 
describe("Register users:", function(){

    it("Register OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });


    });
    
    it("Register USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);

        });
    });

    it("Register USER2", function() {
        Signup.registerUserUntilDone(USER2).then(function(userData){
            USER2.username = userData.username;
            USER2.email = userData.email;
            console.log('USER2:', USER2.username);
            Signup.verifyEmail(USER2);
        });
    });
    
    it("Register USER3", function() {
        Signup.registerUserUntilDone(USER3).then(function(userData){
            USER3.username = userData.username;
            USER3.email = userData.email;
            console.log('USER3:', USER3.username);
            Signup.verifyEmail(USER3);
        });


    });

    it("Register USER4", function() {
        Signup.registerUserUntilDone(USER4).then(function(userData){
            USER4.username = userData.username;
            USER4.email = userData.email;
            console.log('USER4:', USER4.username);
            Signup.verifyEmail(USER4);
        });
    });

    it("Register USER5", function() {
        Signup.registerUserUntilDone(USER5).then(function(userData){
            USER5.username = userData.username;
            USER5.email = userData.email;
            console.log('USER5:', USER5.username);
            Signup.verifyEmail(USER5);
        });
    });

    it("Register USER6", function() {
        Signup.registerUserUntilDone(USER6).then(function(userData){
            USER6.username = userData.username;
            USER6.email = userData.email;
            console.log('USER6:', USER6.username);
            Signup.verifyEmail(USER6);
        });
    });

    it("Register USER7", function() {
        Signup.registerUserUntilDone(USER7).then(function(userData){
            USER7.username = userData.username;
            USER7.email = userData.email;
            console.log('USER7:', USER7.username);
            Signup.verifyEmail(USER7);
        });
    });

    it("Register USER8", function() {
        Signup.registerUserUntilDone(USER8).then(function(userData){
            USER8.username = userData.username;
            USER8.email = userData.email;
            console.log('USER8:', USER8.username);
            Signup.verifyEmail(USER8);
        });
    });

    it("Register USER_P", function() {
        Signup.registerUserUntilDone(USER_P).then(function(userData){
            USER_P.username = userData.username;
            USER_P.email = userData.email;
            console.log('USER_P:', USER_P.username);
            Signup.verifyEmail(USER_P);
        });
    });

    it("Register USER2_P", function() {
        Signup.registerUserUntilDone(USER2_P).then(function(userData){
            USER2_P.username = userData.username;
            USER2_P.email = userData.email;
            console.log('USER2_P:', USER2_P.username);
            Signup.verifyEmail(USER2_P);
        });
    });

    it("Register USER3_P", function() {
        Signup.registerUserUntilDone(USER3_P).then(function(userData){
            USER3_P.username = userData.username;
            USER3_P.email = userData.email;
            console.log('USER3_P:', USER3_P.username);
            Signup.verifyEmail(USER3_P);
        });
    });

    it("Register USER4_P", function() {
        Signup.registerUserUntilDone(USER4_P).then(function(userData){
            USER4_P.username = userData.username;
            USER4_P.email = userData.email;
            console.log('USER4_P:', USER4_P.username);
            Signup.verifyEmail(USER4_P);
        });
    });

    it("Register USER5_P", function() {
        Signup.registerUserUntilDone(USER5_P).then(function(userData){
            USER5_P.username = userData.username;
            USER5_P.email = userData.email;
            console.log('USER5_P:', USER5_P.username);
            Signup.verifyEmail(USER5_P);
        });
    });

    it("Register USER6_P", function() {
        Signup.registerUserUntilDone(USER6_P).then(function(userData){
            USER6_P.username = userData.username;
            USER6_P.email = userData.email;
            console.log('USER6_P:', USER6_P.username);
            Signup.verifyEmail(USER6_P);
        });
    });

    it("Register USER7_P", function() {
        Signup.registerUserUntilDone(USER7_P).then(function(userData){
            USER7_P.username = userData.username;
            USER7_P.email = userData.email;
            console.log('USER7_P:', USER7_P.username);
            Signup.verifyEmail(USER7_P);
        });
    });

    it("Register USER_U", function() {
        Signup.registerUserUntilDone(USER_U).then(function(userData){
            USER_U.username = userData.username;
            USER_U.email = userData.email;
            console.log('USER_U:', USER_U.username);
            Signup.verifyEmail(USER_U);
        });
    });

    it("Register USER2_U", function() {
        Signup.registerUserUntilDone(USER2_U).then(function(userData){
            USER2_U.username = userData.username;
            USER2_U.email = userData.email;
            console.log('USER2_U:', USER2_U.username);
            Signup.verifyEmail(USER2_U);
        });
    });

    it("Register USER3_U", function() {
        Signup.registerUserUntilDone(USER3_U).then(function(userData){
            USER3_U.username = userData.username;
            USER3_U.email = userData.email;
            console.log('USER3_U:', USER3_U.username);
            Signup.verifyEmail(USER3_U);
        });
    });

    it("Register USER4_U", function() {
        Signup.registerUserUntilDone(USER4_U).then(function(userData){
            USER4_U.username = userData.username;
            USER4_U.email = userData.email;
            console.log('USER4_U:', USER4_U.username);
            Signup.verifyEmail(USER4_U);
        });
    });

    it("Register USER5_U", function() {
        Signup.registerUserUntilDone(USER5_U).then(function(userData){
            USER5_U.username = userData.username;
            USER5_U.email = userData.email;
            console.log('USER5_U:', USER5_U.username);
            Signup.verifyEmail(USER5_U);
        });
    });

    it("Register USER6_U", function() {
        Signup.registerUserUntilDone(USER6_U).then(function(userData){
            USER6_U.username = userData.username;
            USER6_U.email = userData.email;
            console.log('USER6_U:', USER6_U.username);
            Signup.verifyEmail(USER6_U);
        });
    });

    it("Register USER7_U", function() {
        Signup.registerUserUntilDone(USER7_U).then(function(userData){
            USER7_U.username = userData.username;
            USER7_U.email = userData.email;
            console.log('USER7_U:', USER7_U.username);
            Signup.verifyEmail(USER7_U);
        });
    });

    it("Register USER8_U", function() {
        Signup.registerUserUntilDone(USER8_U).then(function(userData){
            USER8_U.username = userData.username;
            USER8_U.email = userData.email;
            console.log('USER8_U:', USER8_U.username);
            Signup.verifyEmail(USER8_U);
        });
    });

});

describe("Create event and subscribe:", function() {

    it("create event", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNew(EVENT).then(function(event){
            EVENT.url = event.url;
            EVENT.name = event.name;
            console.log('Event url:', EVENT.url);
            console.log('Event name:', EVENT.name);
        });

        Auth.logOut();
    });

    it("subscribe user to event", function() {
        Subscription.subscribeToEvent(USER, EVENT);
    });

    it("subscribe user to event who does not fit the age limit", function() {
        Auth.loginAsUser(USER5.username, USER5.password);
        browser.get(EVENT.url);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');

        Auth.logOut();
    });

});

describe("Edit event and check notification:", function(){

    it("create event", function() {
       
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT2).then(function(event){
            EVENT2.url = event.url;
            EVENT2.name = event.name;
            console.log('Event2 url:', EVENT2.url);
            console.log('Event2 name:', EVENT2.name);
        });
        Auth.logOut();
    });

    it("subscribe user2 to event2", function() {
        Subscription.subscribeToEvent(USER2, EVENT2);
    });
    
    it("owner change event name", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get(EVENT2.url);
        browser.waitForAngular();
        
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.model("event.description")).clear();
        element(by.model("event.description")).sendKeys("New description"); // change description
        element(by.xpath("//form[@name='eventForm']")).submit();
        browser.waitForAngular();
        
        Auth.logOut();
    });

    it("Subscribed user shoul get an email about event change", function(){
        checkMail(USER2, 2);
    });

    it("Subscribed user shoul get a notice about event change", function(){
        Auth.loginAsUser(USER2.username, USER2.password);
        
        browser.get("/users/" + USER2.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_changed']")
            ).isPresent()
        ).toBeTruthy();
    });

});

describe("Add comment to event and check discussion notification:", function(){
    
    it("create event", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT3).then(function(event){
            EVENT3.url = event.url;
            EVENT3.name = event.name;
            console.log('Event3 url:', EVENT3.url);
            console.log('Event3 name:', EVENT3.name);
        });
        Auth.logOut();

    });

    it("subscribe user to event", function() {
        Subscription.subscribeToEvent(USER3, EVENT3);
    });
    
    it("add comment", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Comments.addComment(EVENT3.url, null, 'Comment to event');
        Auth.logOut();
    });

    it("check notice in email", function(){
        checkMail(USER3, 2);
        /*
        var userMail = new Mailer(USER3.email),
            flow = protractor.promise.controlFlow();
            
        flow.execute(userMail.getAllMail).then(function(value){
            expect(value.length).toBe(2);
        });*/
    });

    it("check notice in messages", function(){
        Auth.loginAsUser(USER3.username, USER3.password);
        
        browser.get("/users/" + USER3.username + "/messages/notice");
        browser.waitForAngular();

        element.all(by.css('.list-entry')).then(function(events){
            expect(events.length).toBeGreaterThan(0);
            Auth.logOut();
        });
    });

});


/* 
 TODO: Subscriptions settig were removed from sbscription directive and moved to settings
 */

describe("Subscription without discussion notification:", function(){

    it("create event", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNew(EVENT4).then(function(event){
            EVENT4.url = event.url;
            EVENT4.name = event.name;
            console.log('Event4 url:', EVENT4.url);
            console.log('Event4 name:', EVENT4.name);
        });
        Auth.logOut();
    });


    it("subscribe user to event without discussion notification", function() {
        Subscription.subscribeToEventWithoutNotification(USER3, EVENT4);
    });

    it("owner add comment", function(){
        Auth.loginAsUser(USER3.username, USER3.password);
        Comments.addComment(EVENT4.url, null, 'Comment to event4');
        Auth.logOut(); 
    });

    it("check email", function(){
        checkMail(USER3, 1);
    });

    it("check subscription in private messages", function(){
        Auth.loginAsUser(USER3.username, USER3.password);
        
        browser.get("/users/" + USER3.username + "/messages/notice");
        browser.waitForAngular();

        element.all(by.css('.list-entry')).then(function(events){
            expect(events.length).toBe(0);
            Auth.logOut();
        });

    });

});

describe("Create, delete event and check notification:", function(){

    it("create event", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNew(EVENT5).then(function(event){
            EVENT5.url = event.url;
            EVENT5.name = event.name;
            console.log('Event5 url:', EVENT5.url);
            console.log('Event5 name:', EVENT5.name);
        });
        Auth.logOut();
    });

    it("subscribe user to event", function() {
        Subscription.subscribeToEvent(USER6, EVENT5);
    });

    it("delete event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get(EVENT5.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-ng-click='deleteEvent()']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//button[@data-ng-click='yes()']")).click();
        browser.waitForAngular();

        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER6, 2);
        /*
        var userMail = new Mailer(USER6.email),
            flow = protractor.promise.controlFlow();
            
        flow.execute(userMail.getAllMail).then(function(value){
            expect(value.length).toBe(2);
        });*/

    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER6.username, USER6.password);

        browser.get("/users/" + USER6.username + "/messages/notice");
        browser.waitForAngular();
        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_deleted']")
            ).isPresent()
        ).toBeTruthy();

    });

});

describe("Check notification when event starts/finishes:", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        EVENT6.ts_start = moment().add(EVENT_MIN_START_OFFSET, 'm').format("DD.MM.YYYY HH:mm");
        EVENT6.ts_finish = moment().add(EVENT_MIN_START_OFFSET+1, 'm').format("DD.MM.YYYY HH:mm");

        Events.createNew(EVENT6).then(function(event){
            EVENT6.url = event.url;
            EVENT6.name = event.name;
            console.log('Event6 url:', EVENT6.url);
            console.log('Event6 name:', EVENT6.name);
        });
        Auth.logOut();
    });

    it("subscribe user to event", function() {
        Subscription.subscribeToEvent(USER7, EVENT6);
    });

    it("wait for event to complete", function(){
        var timeout = (EVENT_MIN_START_OFFSET+2) * 60000;
        console.log("Waiting ", timeout/1000.0, " seconds for event to complete....");
        browser.sleep(timeout);
    });

    it("check email", function(){
        checkMail(USER7, 3);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER7.username, USER7.password);

        browser.get("/users/" + USER7.username + "/messages/notice");
        browser.waitForAngular();
        
        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_started']")
            ).isPresent()
        ).toBeTruthy();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_finished']")
            ).isPresent()
        ).toBeTruthy();

    });

});

describe("Check notification when event place changed:", function(){

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT7).then(function(event){
            EVENT7.url = event.url;
            EVENT7.name = event.name;
            console.log('Event7 url:', EVENT7.url);
            console.log('Event7 name:', EVENT7.name);
        });
        Auth.logOut();
    });

    it("subscribe user to event", function() {
        Subscription.subscribeToEvent(USER8, EVENT7);
    });

    it("change event place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get(EVENT7.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath('//ul[@class="select2-results"]//div[text()="Создать новое место"]')).click();

        var latitudeBorders = Array(55.61558902526749, 55.89225616635061),
            longitudeBorders = Array(37.437286376953125, 37.79296875);

        function randomInRange(min, max) {
            return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
        }
         
        EVENT7.place.lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
        EVENT7.place.lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);
        
        var placeForm = element(by.name('placeForm')),
            map = element(by.xpath('//div[@data-protractor-id="placeFormMap"]'));

        browser.actions().doubleClick(map).perform();

        element(by.model('place_lat')).clear();
        element(by.model('place_lng')).clear();

        element(by.model('place_lat')).sendKeys(EVENT7.place.lat);
        element(by.model('place_lng')).sendKeys(EVENT7.place.lng);

        var newName = EVENT7.place.name + '9';

        element(by.model('placeform.name')).sendKeys(newName);

        TagSelector.selectFirstTag('s2id_place_tags');

        Visibility.setVisibility(EVENT7.place, 'placeform');
        selectDropdownbyValue(element(by.model('placeform.age_restriction')), '0');
        placeForm.submit();

        element(by.name('eventForm')).submit();

        browser.waitForAngular();

        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER8, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER8.username, USER8.password);

        browser.get("/users/" + USER8.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_changed']")
            ).isPresent()
        ).toBeTruthy();
    });

});

describe("Create place and subscribe:", function() {

    it("create place", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Places.createNewInMoscow(PLACE).then(function(place){
            console.log("Place url: ", place.url);
            PLACE.url = place.url;
        });
        Auth.logOut();
    });

    it("subscribe user to place", function() {
        Subscription.subscribeToPlace(USER_P, PLACE);
    });

    it("subscribe user to place who not fit the age limit", function() {
        Auth.loginAsUser(USER2_P.username, USER2_P.password);
        browser.get(PLACE.url);
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/403');

        Auth.logOut();
    });

    it("is subscribed", function(){
        Subscription.isSubscribedPlace(USER_P, PLACE);
    });

});

describe("Edit place lat and lng and check notification:", function() {

    it("create place6", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE6).then(function(place){
            console.log("Place6 url: ", place.url);
            PLACE6.url = place.url;
        });

        Auth.logOut();
    });

    it("subscribe user to place", function() {
        Subscription.subscribeToPlace(USER7_P, PLACE6);
    });

    it("edit place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get(PLACE6.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();

         var latitudeBorders = new Array(55.61558902526749, 55.89225616635061),
                longitudeBorders = new Array(37.437286376953125, 37.79296875);

        function randomInRange(min, max) {
            return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
        }
         

        var lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
        var lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);

        console.log('New lat:', lat);
        console.log('New lng:', lng);

        element(by.model('place_lat')).clear();
        element(by.model('place_lng')).clear();

        element(by.model('place_lat')).sendKeys(lat);
        element(by.model('place_lng')).sendKeys(lng);

        element(by.name('placeForm')).submit();

        browser.waitForAngular();
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER7_P, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER7_P.username, USER7_P.password);

        browser.get("/users/" + USER7_P.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-place_changed']")
            ).isPresent()
        ).toBeTruthy();

    });
    
});

describe("Edit place name and check notification:", function() {

    it("create place3", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Places.createNewInMoscow(PLACE3).then(function(place){
            console.log("Place3 url: ", place.url);
            PLACE3.url = place.url;
        });
        Auth.logOut();
    });

    it("subscribe user to place", function() {
        Subscription.subscribeToPlace(USER3_P, PLACE3);
    });

    it("edit place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get(PLACE3.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editPlaceLink']")).click();
        
        element(by.model('placeform.description')).sendKeys("New description");
        element(by.name('placeForm')).submit();
        browser.waitForAngular();
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER3_P, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER3_P.username, USER3_P.password);

        browser.get("/users/" + USER3_P.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-place_changed']")
            ).isPresent()
        ).toBeTruthy();

    });
    
});

describe("Create, subscribe and delete place:", function() {

    it("create place", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Places.createNewInMoscow(PLACE2).then(function(place){
            console.log("Place2 url: ", place.url);
            PLACE2.url = place.url;
        });
        Auth.logOut();
    });

    it("subscribe user to place", function() {
        Subscription.subscribeToPlace(USER6_P, PLACE2);
    });

    it("delete place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get(PLACE2.url);
        browser.waitForAngular();
        
        var menuBtn = browser.findElement(
            by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")
        );

        browser.executeScript(scrollIntoView, menuBtn);

        menuBtn.click();

        //element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='deletePlace']")).click();
        element(by.xpath("//button[@data-ng-click='yes()']")).click();
        browser.waitForAngular();
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER6_P, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER6_P.username, USER6_P.password);

        browser.get("/users/" + USER6_P.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-userplace_deleted']")
            ).isPresent()
        ).toBeTruthy();

    });

});

describe("Add place to some event:", function() { // not worked

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT8).then(function(event){
            EVENT8.url = event.url;
            EVENT8.name = event.name;
            console.log('Event8 url:', EVENT8.url);
            console.log('Event8 name:', EVENT8.name);
        });
        Auth.logOut();
    });

    it("create place4", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Places.createNewInMoscow(PLACE4).then(function(place){
            console.log("Place4 url: ", place.url);
            PLACE4.url = place.url;
            PLACE4.name = place.name;
        });
        Auth.logOut();
    });

    it("subscribe user to place", function() {
        Subscription.subscribeToPlace(USER4_P, PLACE4);
    });

    it("add place to event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        
        browser.get(EVENT8.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE4.name);
        browser.waitForAngular();

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE4.name + "']")).click();
        element(by.xpath("//form[@name='eventForm']")).submit();
        browser.waitForAngular();
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER4_P, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER4_P.username, USER4_P.password);

        browser.get("/users/" + USER4_P.username + "/messages/notice");
        browser.waitForAngular();


        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-userplace_changed']")
            ).isPresent()
        ).toBeTruthy();
    });
    
});

describe("Add comment to place and check notification:", function() {

    it("create place", function() {
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Places.createNewInMoscow(PLACE4).then(function(place){
            console.log("Place4 url: ", place.url);
            PLACE4.url = place.url;
        });
        Auth.logOut();
    });

    it("subscribe user to place", function() {
        Subscription.subscribeToPlace(USER5_P, PLACE4);
    });

    it("add comment to place", function(){
        Auth.loginAsUser(USER4_P.username, USER4_P.password);
        Comments.addComment(PLACE4.url, null, 'Comment to place!');
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER5_P, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER5_P.username, USER5_P.password);

        browser.get("/users/" + USER5_P.username + "/messages/notice");
        browser.waitForAngular();

        element.all(by.repeater('msg in messages')).then(function(events){
            expect(events.length > 0).toBe(true);
            Auth.logOut();
        });
    });

});

describe("Subscription to user test create event:", function() {

    it("subrcibe to user", function(){
        Subscription.subscribeToUser(USER_U, USER2_U);
    });

    it("is subscribed to user", function(){
        Subscription.isSubscribedUser(USER_U, USER2_U);
    });

    it("create event", function() {
        Auth.loginAsUser(USER2_U.username, USER2_U.password);
        Events.createNew(EVENT9).then(function(event){
            EVENT9.url = event.url;
            EVENT9.name = event.name;
            console.log('Event9 url:', EVENT9.url);
            console.log('Event9 name:', EVENT9.name);
        });
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER_U, 2);
    });

    it("check notice messages", function(){

        Auth.loginAsUser(USER_U.username, USER_U.password);

        browser.get("/users/" + USER_U.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_created']")
            ).isPresent()
        ).toBeTruthy();

    });

});

describe("Subscription to user test create place:", function() {
    
    it("subrcite to user", function(){
        Subscription.subscribeToUser(USER3_U, USER4_U);
    });

    it("create place", function() {
        Auth.loginAsUser(USER4_U.username, USER4_U.password);

        Places.createNewInMoscow(PLACE7).then(function(place){
            console.log("Place7 url: ", place.url);
            PLACE7.url = place.url;
        });
        Auth.logOut();
    });

    it("check email", function(){

        checkMail(USER3_U, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER3_U.username, USER3_U.password);

        browser.get("/users/" + USER3_U.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-userplace_created']")
            ).isPresent()
        ).toBeTruthy();
    });

});

describe("Subscription to user test check in / check out:", function() {

    it("subrcite to user", function(){
        Subscription.subscribeToUser(USER5_U, USER6_U);
    });

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNew(EVENT10).then(function(event){
            EVENT10.url = event.url;
            EVENT10.name = event.name;
            console.log('Event10 url:', EVENT10.url);
            console.log('Event10 name:', EVENT10.name);
        });
        Auth.logOut();
    });

    it("check in/check out to event", function() {
        Auth.loginAsUser(USER6_U.username, USER6_U.password);
        browser.get(EVENT10.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).click();
        browser.waitForAngular();
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER5_U, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER5_U.username, USER5_U.password);

        browser.get("/users/" + USER5_U.username + "/messages/notice");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='protractor-event_user_state_created']")
            ).isPresent()
        ).toBeTruthy();
    }); 

});

describe("Subscription to user test add comment event:", function() {

    it("subsrcibe to user", function(){
        Subscription.subscribeToUser(USER7_U, USER8_U);
    });

    it("create event", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);

        Events.createNew(EVENT11).then(function(event){
            EVENT11.url = event.url;
            EVENT11.name = event.name;
            console.log('Event11 url:', EVENT11.url);
            console.log('Event11 name:', EVENT11.name);
        });
        Auth.logOut();
    });

    it("add comment", function() {
        Auth.loginAsUser(USER8_U.username, USER8_U.password);
        Comments.addComment(EVENT11.url, null, 'Comment wtf!');
        Auth.logOut();
    });

    it("check email", function(){
        checkMail(USER7_U, 2);
    });

    it("check notice messages", function(){
        Auth.loginAsUser(USER7_U.username, USER7_U.password);

        browser.get("/users/" + USER7_U.username + "/messages/notice");
        browser.waitForAngular();

        element.all(by.css('.list-entry')).then(function(events){
            expect(events.length).toBeGreaterThan(0);
            Auth.logOut();
        });

    });

});

describe("Friendship should automatically creates subscription:", function(){

    it("created friendship", function(){
        Friendship.beFriends(USER3, USER4);
    });

    it("check that user3 is subscribed to user4", function(){
        Auth.loginAsUser(USER4.username, USER4.password);

        browser.get("/users/" + USER4.username + "/subscriptions/subscribers");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='userBlock:" + USER3.username + "']")
            ).isPresent()
        ).toBeTruthy();

        

        //element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        //element(by.xpath("//button[@data-protractor-id='toggleSubscribers']")).click();
        //element(by.xpath("//a[@data-protractor-id='userSubscriptionsUsers']")).click();
        /*
        element.all(by.repeater('item in dataSource track by item.id')).then(function(users){
            expect(users.length > 0).toBe(true);
            expect(element(by.xpath("//a[@href='/users/" + USER3.username + "']")).isPresent()).toBe(true);
            Auth.logOut();
        });*/
        Auth.logOut();

    });
    
    // TODO: Unsubscribe button was removed after 
    // frieds page was rewritten with Reactjs components
    it("User can unsubscribe friend on friends page", function(){
        Auth.loginAsUser(USER3.username, USER3.password);

        browser.get("/users/" + USER3.username + "/friends");
        browser.waitForAngular();

        expect(
            element(
                by.xpath("//*[@data-protractor-id='userBlock:" + USER4.username + "']")
            ).isPresent()
        ).toBeTruthy();

        Auth.logOut();
    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
