'use strict';

var REG_USER1 = {
        'username': 'TestRegUser',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'test@mail.com',
        'age': 30,
        'password': 'hackme'
    },
    REG_USER2 = {
        'username': 'TestRegUser1',
        'first_name': 'Ivan',
        'last_name': 'Petrov',
        'email': 'test1@mail.com',
        'phone': '+79221234567',
        'age': 25,
        'password': 'hackme'
    },
    REG_USER3 = {
        'username': 'user',
        'first_name': 'Taras',
        'last_name': 'Bulba',
        'email': 'test1@mail.com',
        'phone': '+79221234561',
        'age': 55,
        'password': 'hackme'
    },
    REG_USER4 = {
        'username': 'TestRegUser1',
        'first_name': 'Ivan',
        'last_name': 'Petrov',
        'email': 'test1@mail.com',
        'phone': '+79221234567',
        'age': 25,
        'password': 'hackme'
    },
    REG_USER5 = {
        'username': 'user',
        'first_name': 'Taras',
        'last_name': 'Bulba',
        'email': 'test1@mail.com',
        'phone': '+79221234561',
        'age': 55,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    eula = element(by.xpath('//input[@id="eula"]/following-sibling::i'));

var checkError = function (dataNgShow) {
    expect(element(by.xpath('//em[@data-ng-show="' + dataNgShow + '"]')).isDisplayed()).toBe(true);
};

var fillField = function (field_name, value) {
    var field = element(by.id(field_name));
    field.clear();
    field.sendKeys(value);
};

var fillAndCheckField = function (field_name, value, dataNgShow) {
    fillField(field_name, value);
    element(by.name('signupForm')).submit();
    checkError(dataNgShow);
};

var selectDropdownbyNum = function (element, optionNum) {
    if (optionNum) {
        var options = element.all(by.tagName('option')).then(
            function(options) {
                options[optionNum].click();
            }
        );
    }
};

var FillAllExceptUsername = function() {
    browser.navigate().refresh();
    fillField('first_name', REG_USER1.first_name);
    fillField('last_name', REG_USER1.last_name);
    fillField('email', REG_USER1.email);
    selectDropdownbyNum(element(by.id('day_of_birth')), '1');
    selectDropdownbyNum(element(by.id('month_of_birth')), '3');
    selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER1.age);
    fillField('password', REG_USER1.password);
    fillField('password2', REG_USER1.password);
    //element(by.id('eula')).click();
    eula.click();

};

var FillAllExceptFirstname = function() {
    browser.navigate().refresh();
    fillField('username', REG_USER1.username + Math.floor(Math.random()*1000000));
    fillField('last_name', REG_USER1.last_name);
    fillField('email', Math.floor(Math.random()*1000000) + REG_USER1.email);
    selectDropdownbyNum(element(by.id('day_of_birth')), '1');
    selectDropdownbyNum(element(by.id('month_of_birth')), '3');
    selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER1.age);
    fillField('password', REG_USER1.password);
    fillField('password2', REG_USER1.password);
    //element(by.id('eula')).click();
    eula.click();
    
};

var FillAllExceptLastname = function() {
    browser.navigate().refresh();
    fillField('username', REG_USER1.username + Math.floor(Math.random()*1000000));
    fillField('first_name', REG_USER1.last_name);
    fillField('email', Math.floor(Math.random()*1000000) + REG_USER1.email);
    selectDropdownbyNum(element(by.id('day_of_birth')), '1');
    selectDropdownbyNum(element(by.id('month_of_birth')), '3');
    selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER1.age);
    fillField('password', REG_USER1.password);
    fillField('password2', REG_USER1.password);
    //element(by.id('eula')).click();
    eula.click();

};

var FillAllExceptEmail = function() {
    browser.navigate().refresh();
    fillField('username', REG_USER1.username + Math.floor(Math.random()*1000000));
    fillField('first_name', REG_USER1.last_name);
    fillField('last_name', REG_USER1.last_name);
    selectDropdownbyNum(element(by.id('day_of_birth')), '1');
    selectDropdownbyNum(element(by.id('month_of_birth')), '3');
    selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER1.age);
    fillField('password', REG_USER1.password);
    fillField('password2', REG_USER1.password);
    //element(by.id('eula')).click();
    eula.click();

};

var FillAllExceptPhone = function() {
    browser.navigate().refresh();
    fillField('username', REG_USER1.username + Math.floor(Math.random()*1000000));
    fillField('first_name', REG_USER1.last_name);
    fillField('last_name', REG_USER1.last_name);
    fillField('email', Math.floor(Math.random()*1000000) + REG_USER1.email);
    selectDropdownbyNum(element(by.id('day_of_birth')), '1');
    selectDropdownbyNum(element(by.id('month_of_birth')), '3');
    selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER1.age);
    fillField('password', REG_USER1.password);
    fillField('password2', REG_USER1.password);
    //element(by.id('eula')).click();
    eula.click();
    
};

var FillAllExceptAge = function() {
    browser.navigate().refresh();
    fillField('username', REG_USER1.username + Math.floor(Math.random()*1000000));
    fillField('first_name', REG_USER1.last_name);
    fillField('last_name', REG_USER1.last_name);
    fillField('email', Math.floor(Math.random()*1000000) + REG_USER1.email);
    selectDropdownbyNum(element(by.id('day_of_birth')), '1');
    selectDropdownbyNum(element(by.id('month_of_birth')), '3');
    fillField('password', REG_USER1.password);
    fillField('password2', REG_USER1.password);
    //element(by.id('eula')).click();
    eula.click();

};

var FillAllExceptPassword = function() {
    browser.navigate().refresh();
    fillField('username', REG_USER1.username + Math.floor(Math.random()*1000000));
    fillField('first_name', REG_USER1.last_name);
    fillField('last_name', REG_USER1.last_name);
    fillField('email', Math.floor(Math.random()*1000000) + REG_USER1.email);
    selectDropdownbyNum(element(by.id('day_of_birth')), '1');
    selectDropdownbyNum(element(by.id('month_of_birth')), '3');
    selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER1.age);
    //element(by.id('eula')).click();
    eula.click();

};

describe("Check inability to register with errors: ", function(){

    it("Register without phone and try login", function(){
        browser.get('/signup/');
        browser.waitForAngular();
        
        Signup.registerUserUntilDone(REG_USER1).then(function(userData){
            REG_USER1.username = userData.username;
            REG_USER1.email = userData.email;

            Auth.loginAsUser(REG_USER1.username, REG_USER1.password);
            Auth.logOut();

        });
    });
    
    it("should not register with wrong username", function() {
        browser.get('/signup/');
        browser.waitForAngular();

        FillAllExceptUsername();
        fillAndCheckField('username', '', "signupForm.username.$dirty && signupForm.username.$invalid && signupForm.username.$error.required");
        
        FillAllExceptUsername();
        fillAndCheckField('username', 'fucker', "hasCustomError(signupForm.username, 'username_stopwords')");
        
        FillAllExceptUsername();
        fillAndCheckField('username', 'fuck', "hasCustomError(signupForm.username, \'min_length\')");
        
        FillAllExceptUsername();
        fillAndCheckField('username', 'user1234567890abcdefghijklmnopqrstu', "hasCustomError(signupForm.username, \'max_length\')");
        
        FillAllExceptUsername();
        fillAndCheckField('username', 'user__new', "hasCustomError(signupForm.username, 'invalid')");
        
        FillAllExceptUsername();
        fillAndCheckField('username', '1user25', "hasCustomError(signupForm.username, 'username_startswith_digit')");
        
        FillAllExceptUsername();
        fillAndCheckField('username', 'user10', "hasCustomError(signupForm.username, 'username_exists')");
        
        FillAllExceptUsername();
        fillAndCheckField('username', 'Пользователь', "hasCustomError(signupForm.username, 'invalid')");
        
    });
    
    it("should not register with wrong first_name", function(){
        browser.get('/signup/');
        browser.waitForAngular();

        FillAllExceptFirstname();
        fillAndCheckField('first_name', '', 'signupForm.first_name.$dirty && signupForm.first_name.$invalid && signupForm.first_name.$error.required');

        FillAllExceptFirstname();
        fillAndCheckField('first_name', new Array(260).join('a'), "hasCustomError(signupForm.first_name, 'max_length')");
        
        FillAllExceptFirstname();
        fillAndCheckField('first_name', 'John#%$', "hasCustomError(signupForm.first_name, 'name_invalid')");
        
        FillAllExceptFirstname();
        fillAndCheckField('first_name', 'John--', "hasCustomError(signupForm.first_name, 'name_invalid')");
        
        FillAllExceptFirstname();
        fillAndCheckField('first_name', 'Johnfuck', "hasCustomError(signupForm.first_name, 'name_stopwords')");
       
    });
    
    it("should not register with wrong last_name", function(){
        browser.get('/signup/');
        browser.waitForAngular();

        FillAllExceptLastname();
        fillAndCheckField('last_name', '', "signupForm.last_name.$dirty && signupForm.last_name.$invalid && signupForm.last_name.$error.required");

        FillAllExceptLastname();
        fillAndCheckField('last_name', new Array(260).join('a'), "hasCustomError(signupForm.last_name, 'max_length')");
        
        FillAllExceptLastname();
        fillAndCheckField('last_name', 'Smith#%$', "hasCustomError(signupForm.last_name, 'name_invalid')");
        
        FillAllExceptLastname();
        fillAndCheckField('last_name', 'Smith--', "hasCustomError(signupForm.last_name, 'name_invalid')");
        
        FillAllExceptLastname();
        fillAndCheckField('last_name', 'Smithfuck', "hasCustomError(signupForm.last_name, 'name_stopwords')");
    });
    
    
    it("should not register with wrong email", function(){
        browser.get('/signup/');
        browser.waitForAngular();

        FillAllExceptEmail();
        fillAndCheckField('email', '', "signupForm.email.$dirty && signupForm.email.$invalid && signupForm.email.$error.required");

        FillAllExceptEmail();
        fillAndCheckField('email', 'user1@mail.com', "hasCustomError(signupForm.email, 'email_exists')");

        
        FillAllExceptEmail();
        fillAndCheckField('email', 'testemailmail@com', "(signupForm.email.$dirty && signupForm.email.$invalid && (signupForm.email.$error.invalid || signupForm.email.$error.email)) || signupForm.email.$error.pattern");

        FillAllExceptEmail();
        fillAndCheckField('email', new Array(70).join('a') + '@mail.com', "hasCustomError(signupForm.email, 'max_length')");
        
    });

    it("should not register with wrong phone", function(){
        browser.get('/signup/');
        browser.waitForAngular();

        FillAllExceptPhone();
        fillAndCheckField('phone', '68665265952', "signupForm.phone.$dirty && signupForm.phone.$invalid && signupForm.phone.$error.phone_number_incorrect");
        
    });

    it("should not register with wrong age", function(){
        browser.get('/signup/');
        browser.waitForAngular();

        FillAllExceptAge();
        selectDropdownbyNum(element(by.id('year_of_birth')), 4);
        element(by.name('signupForm')).submit();

        expect(element(by.xpath('//em[@data-ng-show="signupForm.$error.date_of_birth.date_of_birth_invalid_range"]')).isDisplayed()).toBe(true);

    });
    

    it("should not register with wrong passwords", function(){
        browser.get('/signup/');
        browser.waitForAngular();

        FillAllExceptPassword();
        fillAndCheckField('password', '', "signupForm.password.$dirty && signupForm.password.$invalid && signupForm.password.$error.required");

        FillAllExceptPassword();
        fillField('password', '1234567890abcde');
        fillAndCheckField('password2', '1234567890abcde', "hasCustomError(signupForm.password, 'password_invalid_length')");

        FillAllExceptPassword();
        fillField('password', REG_USER1.password);
        fillAndCheckField('password2', '', "signupForm.password2.$dirty && signupForm.password2.$invalid && signupForm.password2.$error.required");

        FillAllExceptPassword();
        fillField('password', REG_USER1.password);
        fillAndCheckField('password2', REG_USER1.password + '123', "(signupForm.password2.$dirty && signupForm.password2.$invalid && signupForm.password2.$error.notequal) || signupForm.$error[\'passwords_mismatch\']");
        
    });
    
});

describe("Register user with phone: ", function(){

    it("register REG_USER2", function(){
        browser.get('/signup/');
        browser.waitForAngular();
        
        Signup.registerUserUntilDone(REG_USER2).then(function(userData){
            REG_USER2.username = userData.username;
            REG_USER2.email = userData.email;

            console.log("REG_USER2 username: ", REG_USER2.username);
            Auth.loginAsUser(REG_USER2.username, REG_USER2.password);
            Signup.addPhone(REG_USER2);
        });
    });

    it("REG_USER2 should wait sms and login", function(){
        Signup.verifyPhone(REG_USER2);
    });

    it("REG_USER2 logout", function(){
        Auth.logOut();
    });
    
});

describe("Register user with phone show verify form: ", function(){

    it("register REG_USER3", function(){
        browser.get(Signup.SIGNUP_URL);
        browser.waitForAngular();
        Signup.registerUserWithPhoneUntilDone(REG_USER3);
    });

    it("Tests finished - log out", function(){
        Auth.logOut();
    });

});
