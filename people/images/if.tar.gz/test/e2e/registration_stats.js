'use strict';
var Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js');



describe("Registration stats ", function(){
    var ptor = protractor.getInstance(),
        driver = ptor.driver;

    it("admin page should have registration stats section", function(){

        browser.ignoreSynchronization = true;
        Auth.loginAsAdmin();
        browser.get(ADMIN_URL + '/admin/statistics/registrationstatistic/');
        

        //ptor.driver.findElement(protractor.By.xpath('(//table[@id="result_list"]//a[contains(@href, "/admin/users/user/")])[1]')).click();
        expect(
            ptor.driver.findElement(protractor.By.xpath('//h1[text()="Statistics User Registration"]')).isDisplayed()
        ).toBeTruthy();

        expect(
            ptor.driver.findElement(protractor.By.id('id_date_from')).isDisplayed()
        ).toBeTruthy();

        expect(
            ptor.driver.findElement(protractor.By.id('id_date_to')).isDisplayed()
        ).toBeTruthy();

    });

    it("IP & login stats should be present", function(){
        ptor.driver.findElement(
            protractor.By.xpath("//table//a[starts-with(@href, '/admin/statistics/registrationstatistic/')]")
        ).click();

        expect(
            ptor.driver.findElement(protractor.By.xpath('//th[text()="ip"]')).isDisplayed()
        ).toBeTruthy();

        expect(
            ptor.driver.findElement(protractor.By.xpath('//th[text()="users"]')).isDisplayed()
        ).toBeTruthy();
        
    });

});
