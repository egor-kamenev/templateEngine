'use strict';

var REG_USER = {
        'username': 'user',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'test@mail.com',
        'phone': '+79111111232',
        'age': 30,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Signup = require('../utils/signup.js'),
    Settings = require('../utils/settings.js'),
    UserMail = require('../utils/userMail.js');

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

function checkPrivacy(section) {
    element(by.xpath("//a[@data-protractor-id='" + section + "']")).click();

    browser.navigate().refresh();

    element(by.xpath("//button[contains(@data-select-visibility, '') and contains(@data-entity, 'section_visibility')]")).click();
    element.all(by.repeater("v.id as v.text for v in visibilities")).then(function(elements){
        expect(element.length).toBe(1);
    });
    expect(element(by.xpath("//select[contains(@name, 'visibility') and contains(@data-ng-model,'entity.visibility.value')]/option[text()='Only me']")).isPresent()).toBe(true);
    element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//button[@data-ng-click='closeForm()']")).click();
}

browser.driver.manage().window().maximize();

describe("Register users: ", function(){

    it("register test user", function(){
        Signup.registerUserUntilDone(REG_USER).then(function(userData){
            console.log('REG_USER.username', userData.username);
            REG_USER.username = userData.username;
            REG_USER.email = userData.email;
        });
    });

});

describe("User profile should have email and phone: ", function(){

    it("Check not verified email hint and user privacy", function(){

        Auth.loginAsUser(REG_USER.username, REG_USER.password);

        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//a[@data-protractor-id='userProfile']")).click();

        expect(element(by.xpath("//b[@data-protractor-id='needVerify']")).isDisplayed()).toBe(true);

        //stream 
        checkPrivacy('userStream');

        //albums
        checkPrivacy('userAlbums');
        
        //events
        checkPrivacy('userEvents');

        element(by.xpath("//li[contains(@class,'overflow-expander') and contains(@class, 'megamenu__item--with-submenu')]//button")).click();
        
        //places
        checkPrivacy('userPlaces');

        //interests
        checkPrivacy('userInterests');
        
        //friends
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        checkPrivacy('userFriends');

        //statuses
        element(by.xpath("//li[contains(@class,'megamenu__item--with-submenu') and contains(@class,'overflow-expander')]//button")).click();
        checkPrivacy('userStatuses');

        Auth.logOut();

    });

    it("verify email and look hint", function(){

        Signup.verifyEmail(REG_USER);

        Auth.loginAsUser(REG_USER.username, REG_USER.password);

        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//a[@data-protractor-id='userProfile']")).click();

        browser.navigate().refresh();
       
        expect(element(by.xpath("//b[@data-protractor-id='needVerify']")).isDisplayed()).toBe(false);

        Auth.logOut();

    });

    it("check not verified phone hint", function(){

        Auth.loginAsUser(REG_USER.username, REG_USER.password);
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//a[@data-protractor-id='userProfile']")).click();

        browser.navigate().refresh();

        Signup.addPhone(REG_USER);
        expect(element(by.id("verify_phone_button")).isDisplayed()).toBe(true);
        Auth.logOut();

    });

    it("verified phone", function(){
        
        Auth.loginAsUser(REG_USER.username, REG_USER.password);
        Signup.verifyPhone(REG_USER);
        Auth.logOut();

    });

    it("check hint", function(){

        Auth.loginAsUser(REG_USER.username, REG_USER.password);
        expect(element(by.xpath("//button[@id='verify_phone_button']")).isDisplayed()).toBe(true);
        Auth.logOut();

    });
 
});
