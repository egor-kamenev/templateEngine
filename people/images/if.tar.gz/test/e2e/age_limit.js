var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER_9_age = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 9,
        'password': 'hackme'
    },
    USER_11_age = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 11,
        'password': 'hackme'
    },
    USER_13_age = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 13,
        'password': 'hackme'
    },
    USER_15_age = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 15,
        'password': 'hackme'
    },
    USER_17_age = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 17,
        'password': 'hackme'
    },
    USER_19_age = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 19,
        'password': 'hackme'
    },
    USER_22_age = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 22,
        'password': 'hackme'
    },
    EVENT_0_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '0',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT_8_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '1',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT_10_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '2',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT_12_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '3',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT_14_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT_16_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '5',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT_18_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '6',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT_21_plus = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 50),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '7',
        'by_invitation': false,
        'visibility': '4'
    },
    PLACE_0_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '0'
    },
    PLACE_8_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '1'
    },
    PLACE_10_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '2'
    },
    PLACE_12_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '3'
    },
    PLACE_14_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '4'
    },
    PLACE_16_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '5'
    },
    PLACE_18_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '6'
    },
    PLACE_21_plus = {
        'name': 'place',
        'visibility': '4',
        'age_restrict': '7'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Visibility = require('../utils/visibility.js'),
    Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

var isDenied = function(){
    expect(browser.getCurrentUrl()).toContain('/403');
};

var isNotDenied = function(){
    expect(browser.getCurrentUrl()).not.toContain('/403');
};

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
}); 

describe("Register users: ", function() {
    
    it("register OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });
    
    it("register USER_9_age", function() {
        Signup.registerUserUntilDone(USER_9_age).then(function(userData){
            USER_9_age.username = userData.username;
            USER_9_age.email = userData.email;
            console.log('USER_9_age:', USER_9_age.username);
            Signup.verifyEmail(USER_9_age);
        });
    });

    it("register USER_11_age", function() {
        Signup.registerUserUntilDone(USER_11_age).then(function(userData){
            USER_11_age.username = userData.username;
            USER_11_age.email = userData.email;
            console.log('USER_11_age:', USER_11_age.username);
            Signup.verifyEmail(USER_11_age);
        });
    });

    it("register USER_13_age", function() {
        Signup.registerUserUntilDone(USER_13_age).then(function(userData){
            USER_13_age.username = userData.username;
            USER_13_age.email = userData.email;
            console.log('USER_13_age:', USER_13_age.username);
            Signup.verifyEmail(USER_13_age);
        });
    });

    it("register USER_15_age", function() {
        Signup.registerUserUntilDone(USER_15_age).then(function(userData){
            USER_15_age.username = userData.username;
            USER_15_age.email = userData.email;
            console.log('USER_15_age:', USER_15_age.username);
            Signup.verifyEmail(USER_15_age);
        });
    });

    it("register USER_17_age", function() {
        Signup.registerUserUntilDone(USER_17_age).then(function(userData){
            USER_17_age.username = userData.username;
            USER_17_age.email = userData.email;
            console.log('USER_17_age:', USER_17_age.username);
            Signup.verifyEmail(USER_17_age);
        });
    });

    it("register USER_19_age", function() {
        Signup.registerUserUntilDone(USER_19_age).then(function(userData){
            USER_19_age.username = userData.username;
            USER_19_age.email = userData.email;
            console.log('USER_19_age:', USER_19_age.username);
            Signup.verifyEmail(USER_19_age);
        });
    });

    it("register USER_22_age", function() {
        Signup.registerUserUntilDone(USER_22_age).then(function(userData){
            USER_22_age.username = userData.username;
            USER_22_age.email = userData.email;
            console.log('USER_22_age:', USER_22_age.username);
            Signup.verifyEmail(USER_22_age);
        });
    });

});

describe("Create events:", function(){ 

    it("create EVENT_0_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_0_plus);
        console.log('EVENT_0_plus:', EVENT_0_plus.name);
        Auth.logOut();
    });

    it("create EVENT_8_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_8_plus);
        console.log('EVENT_8_plus:', EVENT_8_plus.name);
        Auth.logOut();
    });

    it("create EVENT_10_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_10_plus);
        console.log('EVENT_10_plus:', EVENT_10_plus.name);
        Auth.logOut();
    });

    it("create EVENT_12_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_12_plus);
        console.log('EVENT_12_plus:', EVENT_12_plus.name);
        Auth.logOut();
    });

    it("create EVENT_14_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_14_plus);
        console.log('EVENT_14_plus:', EVENT_14_plus.name);
        Auth.logOut();
    });

    it("create EVENT_16_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_16_plus);
        console.log('EVENT_16_plus:', EVENT_16_plus.name);
        Auth.logOut();
    });

    it("create EVENT_18_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_18_plus);
        console.log('EVENT_18_plus:', EVENT_18_plus.name);
        Auth.logOut();
    });

    it("create EVENT_21_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Events.createNew(EVENT_21_plus);
        console.log('EVENT_21_plus:', EVENT_21_plus.name);
        Auth.logOut();
    });

});

describe("Test events age limit:", function(){

    it("USER_9_age test EVENT_10_plus,EVENT_8_plus,EVENT_0_plus", function(){
        Auth.loginAsUser(USER_9_age.username, USER_9_age.password);

        browser.get('/events/' + EVENT_0_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_8_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_10_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_11_age EVENT_10_plus and EVENT_12_plus", function(){
        Auth.loginAsUser(USER_11_age.username, USER_11_age.password);

        browser.get('/events/' + EVENT_10_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_12_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_13_age EVENT_12_plus and EVENT_14_plus", function(){
        Auth.loginAsUser(USER_13_age.username, USER_13_age.password);

        browser.get('/events/' + EVENT_12_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_14_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_15_age EVENT_14_plus and EVENT_16_plus", function(){
        Auth.loginAsUser(USER_15_age.username, USER_15_age.password);

        browser.get('/events/' + EVENT_14_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_16_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_17_age EVENT_16_plus and EVENT_18_plus", function(){
        Auth.loginAsUser(USER_17_age.username, USER_17_age.password);

        browser.get('/events/' + EVENT_16_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_18_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_19_age EVENT_18_plus and EVENT_21_plus", function(){
        Auth.loginAsUser(USER_19_age.username, USER_19_age.password);

        browser.get('/events/' + EVENT_18_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_21_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_22_age EVENT_21_plus", function(){
        Auth.loginAsUser(USER_22_age.username, USER_22_age.password);

        browser.get('/events/' + EVENT_21_plus.name);
        browser.waitForAngular();
        isNotDenied();

        Auth.logOut();
    });

});

describe("Anonymous event age limit:", function(){

    it("test age limit(setting)", function(){
        browser.get('/events/' + EVENT_0_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_8_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/events/' + EVENT_14_plus.name);
        browser.waitForAngular();
        isDenied();
    });

});

describe("Create places:", function(){

    it("create PLACE_0_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_0_plus);
        Auth.logOut();
    });

    it("create PLACE_8_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_8_plus);
        Auth.logOut();
    });

    it("create PLACE_10_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_10_plus);
        Auth.logOut();
    });

    it("create PLACE_12_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_12_plus);
        Auth.logOut();
    });

    it("create PLACE_14_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_14_plus);
        Auth.logOut();
    });

    it("create PLACE_16_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_16_plus);
        Auth.logOut();
    });

    it("create PLACE_18_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_18_plus);
        Auth.logOut();
    });

    it("create PLACE_21_plus", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE_21_plus);
        Auth.logOut();
    });

});

describe("Test places age limit:", function(){

    it("USER_9_age test PLACE_10_plus, PLACE_8_plus, PLACE_0_plus", function(){
        Auth.loginAsUser(USER_9_age.username, USER_9_age.password);

        browser.get('/places/' + PLACE_0_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_8_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_10_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_11_age PLACE_10_plus and PLACE_12_plus", function(){
        Auth.loginAsUser(USER_11_age.username, USER_11_age.password);

        browser.get('/places/' + PLACE_10_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_12_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_13_age PLACE_12_plus and PLACE_14_plus", function(){
        Auth.loginAsUser(USER_13_age.username, USER_13_age.password);

        browser.get('/places/' + PLACE_12_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_14_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_15_age PLACE_14_plus and PLACE_16_plus", function(){
        Auth.loginAsUser(USER_15_age.username, USER_15_age.password);

        browser.get('/places/' + PLACE_14_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_16_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_17_age PLACE_16_plus and PLACE_18_plus", function(){
        Auth.loginAsUser(USER_17_age.username, USER_17_age.password);

        browser.get('/places/' + PLACE_16_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_18_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_19_age PLACE_18_plus and PLACE_21_plus", function(){
        Auth.loginAsUser(USER_19_age.username, USER_19_age.password);

        browser.get('/places/' + PLACE_18_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_21_plus.name);
        browser.waitForAngular();
        isDenied();

        Auth.logOut();
    });

    it("USER_22_age PLACE_21_plus", function(){
        Auth.loginAsUser(USER_22_age.username, USER_22_age.password);

        browser.get('/places/' + PLACE_21_plus.name);
        browser.waitForAngular();
        isNotDenied();

        Auth.logOut();
    });

});

describe("Anonymous place age limit:", function(){

    it("test age limit(setting)", function(){
        browser.get('/places/' + PLACE_0_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_8_plus.name);
        browser.waitForAngular();
        isNotDenied();

        browser.get('/places/' + PLACE_14_plus.name);
        browser.waitForAngular();
        isDenied();
    });

});


describe("Set settings back", function(){

    it("Set moderation settings back", function(){
        Settings.set('MODERATION_AUTO_APPROVE', 'true');
        Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 
