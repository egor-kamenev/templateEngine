var OWNER = {
        'username': 'BigBoss',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 30,
        'password': 'hackme'
    },
    USER = {
        'username': 'Santiago',
        'first_name': 'Begemor',
        'last_name': 'Darades',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 25,
        'password': 'hackme'
    },
    PLACE = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE2 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    PLACE3 = {
        'name': 'place'+ Math.floor(Math.random()*1000000),
        'visibility': '4'
    },
    EVENT = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30),

        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT2 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 10, 45),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    },
    EVENT3 = {
        'name': 'event' + Math.floor(Math.random()*1000000),
        'ts_start': evtDate(30, 12, 45),
        'tag': 'встреча',
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '4',
        'by_invitation': false,
        'visibility': '4'
    };

var Auth = require('../utils/auth.js'),
    Events = require('../utils/events.js'),
    Places = require('../utils/places.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js'),
    TagSelector = require('../utils/tagSelector.js'),
    Visibility = require('../utils/visibility.js'),
    moment = require('moment');

var selectDropdownbyValue = function (element, optionValue) {
    element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
};

browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

});

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Register users: ", function() {
    
    it("registrate OWNER", function() {
        Signup.registerUserUntilDone(OWNER).then(function(userData){
            OWNER.username = userData.username;
            OWNER.email = userData.email;
            console.log('Owner:', OWNER.username);
            Signup.verifyEmail(OWNER);
        });
    });

    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('USER:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

});

describe("Only owner can delete place", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE);
        Auth.logOut();
    });

    it("Another user can't delete place created by owner", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/places/' + PLACE.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='deletePlace']")).isPresent()).toBe(false);

        Auth.logOut();
    });

    it("owner check delete button and delete place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE.name);
        browser.waitForAngular();

        var menuBtn = browser.findElement(
            by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")
        );

        browser.executeScript(scrollIntoView, menuBtn);

        menuBtn.click();
        expect(element(by.xpath("//button[@data-protractor-id='deletePlace']")).isDisplayed()).toBe(true);
        element(by.xpath("//button[@data-protractor-id='deletePlace']")).click();
        element(by.xpath("//button[@data-ng-click='yes()']")).click();
        
        Auth.logOut();
    });

    it("deleted place should not be in filter", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places?tags=' + PLACE.name + '&show=list');
        browser.waitForAngular();

        element.all(by.repeater('item in dataSource track by item.id')).then(function(events){
            expect(events.length == 0).toBe(true);
            Auth.logOut();
        });

        Auth.logOut();
    });

});

describe("You can't add to event deleted place", function(){

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE3);
        Auth.logOut();
    });

    it("delete place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE3.name);
        browser.waitForAngular();

        var menuBtn = browser.findElement(
            by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")
        );

        browser.executeScript(scrollIntoView, menuBtn);

        menuBtn.click();
        //element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();

        expect(element(by.xpath("//button[@data-protractor-id='deletePlace']")).isDisplayed()).toBe(true);
        element(by.xpath("//button[@data-protractor-id='deletePlace']")).click();
        element(by.xpath("//button[@data-ng-click='yes()']")).click();
        
        Auth.logOut();
    });

    it("create event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Events.createNew(EVENT3);
        console.log('EVENT3:', EVENT3);
        Auth.logOut();
    });


    it("try add deleted place to event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT3.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE3.name);

        browser.driver.sleep(5000);

        expect(element(by.xpath("//ul[@class='select2-results']//li[text()='No matches found']")).isDisplayed()).toBe(true);

        Auth.logOut();
    });

});

xdescribe("place becomes disabled when added to event:", function(){

    it("create event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        Events.createNew(EVENT2);
        console.log('EVENT2:', EVENT2);
        Auth.logOut();
    });

    it("create place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        Places.createNewInMoscow(PLACE2);
        Auth.logOut();
    });

    it("add place to event", function(){
        Auth.loginAsUser(USER.username, USER.password);
        browser.get('/events/' + EVENT2.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='editEventLink']")).click();

        element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
        element(by.xpath("//div[@id='select2-drop']//input")).sendKeys(PLACE2.name);

        browser.driver.sleep(5000);

        element(by.xpath("//ul[@class='select2-results']//div[text()='" + PLACE2.name + "']")).click();
        browser.driver.sleep(2000);
        element(by.xpath("//form[@name='eventForm']")).submit();

        browser.driver.sleep(2000);
        Auth.logOut();
    });

    it("delete place", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places/' + PLACE2.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeOwnerMegaMenu']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='deletePlace']")).isDisplayed()).toBe(true);
        element(by.xpath("//button[@data-protractor-id='deletePlace']")).click();
        element(by.xpath("//button[@data-ng-click='yes()']")).click();
        
        Auth.logOut();
    });

    it("check disabled place3 in filter after place deleted", function(){
        Auth.loginAsUser(OWNER.username, OWNER.password);
        browser.get('/places?tags=' + PLACE2.name + '&show=list');
        browser.waitForAngular();

        element(by.repeater('item in dataSource track by item.id').row(0)).getAttribute('class').then(function(value){
            expect(value).toMatch(/disabled/);
        });

    });

});
