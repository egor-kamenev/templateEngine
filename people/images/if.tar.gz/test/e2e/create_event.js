'use strict';

var REG_USER = {
        'username': 'TestRegUser',
        'first_name': 'Petr',
        'last_name': 'Ivanov',
        'email': 'test@mail.com',
        'age': 30,
        'password': 'hackme'
    },
    EVENT = {
        'name': 'testevent',
        'tag': 'встреча',
        'ts_start': evtDate(30),
        'ts_finish': evtDate(35),
        'description': 'Event for test',
        'participants_min': '1',
        'age_restrict': '6',
        'by_invitation': true,
        'visibility': '0'
    };

var Events = require('../utils/events.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js'),
    Auth = require('../utils/auth.js');

browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("Set setting", function(){
    Settings.set('MODERATION_INSTANT_CHECK', 'true');
});

describe("Create event ", function(){

    it("register test user", function(){
        Signup.registerUserUntilDone(REG_USER).then(function(userData){
            REG_USER.username = userData.username;
            REG_USER.email = userData.email;
            console.log('REG_USER', REG_USER);
            Signup.verifyEmail(REG_USER);
        });
    });

    it("create event", function(){
        Auth.loginAsUser(REG_USER.username, REG_USER.password);
        Events.createNewUnique(EVENT).then(function(event){
            EVENT.url = event.url;
            EVENT.name = event.name;
            console.log("EVENT url: ", EVENT.url);
            console.log("EVENT name: ", EVENT.name);
            Auth.logOut();
        });

    });
    
});
