'use strict';
var TEST_STATUS = "happy",
    TEST_STATUS2 = "bored",
    TEST_TAG = ["home", "rest"],
    TEST_TAG2 = ["dark", "rain"],
    USER = {
        'username': 'user',
        'first_name': 'Viktor',
        'last_name': 'Petrov',
        'email': 'bigboss@mail.com',
        'phone': '+79111222000',
        'age': 25,
        'password': 'hackme'
    };

var Auth = require('../utils/auth.js'),
    Settings = require('../utils/settings.js'),
    Signup = require('../utils/signup.js');

browser.driver.manage().window().maximize();

describe("Set moderation settings to default", function(){

    it("Set moderation settings back", function(){
       Settings.set('MODERATION_AUTO_APPROVE', 'true');
       Settings.set('MODERATION_INSTANT_CHECK', 'false');
    });

}); 

describe("User status: ", function() {
    
    it("registrate USER", function() {
        Signup.registerUserUntilDone(USER).then(function(userData){
            USER.username = userData.username;
            USER.email = userData.email;
            console.log('User:', USER.username);
            Signup.verifyEmail(USER);
        });
    });

    it("status must be < 256 characters", function(){
        expect(TEST_STATUS.length < 256).toBe(true);
        expect(TEST_STATUS2.length < 256).toBe(true);
    });

    it("add status 1", function(){
        Auth.loginAsUser(USER.username, USER.password);

        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();
        element(by.xpath("//*[@data-protractor-id='userStatuses']")).click();

        expect(element(by.xpath("//button[@id='add-status']")).isDisplayed()).toBe(true);
        element(by.tagName('body')).click();
        
        element(by.xpath("//button[@id='add-status']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@id='s2id_status']//a")).click();
        element(by.xpath("//div[@id='select2-drop']//div[@class='select2-search']//input")).sendKeys(TEST_STATUS);

        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();

        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")).sendKeys(TEST_TAG[0]);

        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();
        
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")).sendKeys(TEST_TAG[1]);

        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//form[@name='statusForm']")).submit();

    });

    it("check status1 data on page and in list", function(){

        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        expect(element(by.xpath("//button[@data-protractor-id='userStatus']")).getText()).toBe(TEST_STATUS);
        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();
        element(by.xpath("//a[@data-protractor-id='userStatuses']")).click();
        element.all(by.repeater('s in statusHistory')).then(function(statuses){
            expect(statuses.length == 1).toBe(true);
        });

    });

    it("add status 2", function(){
        browser.get('/users/' + USER.username);
        browser.waitForAngular();

        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();
        element(by.xpath("//a[@data-protractor-id='userStatuses']")).click();
        element(by.xpath("//button[@id='add-status']")).click();

        element(
            by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//div[@id='s2id_status']//a")
        ).click();
        element(by.xpath("//div[@id='select2-drop']//div[@class='select2-search']//input")).sendKeys(TEST_STATUS2);
        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();

        element(
            by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")
        ).click();

        element(
            by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")
        ).sendKeys(TEST_TAG2[0]);

        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();

        element(
            by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")
        ).click();

        element(
            by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//div[@id='s2id_tags']//input")
        ).sendKeys(TEST_TAG2[1]);

        element(by.xpath("//ul[@class='select2-results']//li[1]")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class, 'active')]//form[@name='statusForm']")).submit();
    });

    it("check status2 data on page and in list", function(){

        browser.get('/users/' + USER.username);
        browser.waitForAngular();
        
        expect(element(by.xpath("//button[@data-protractor-id='userStatus']")).getText()).toBe(TEST_STATUS2);

        element( by.xpath('//*[@data-protractor-id="userSubMenu"]') ).click();

        element(by.xpath("//a[@data-protractor-id='userStatuses']")).click();
        
        element.all(by.repeater('s in statusHistory')).then(function(statuses){
            expect(statuses.length == 2).toBe(true);
        });

    });

});

describe("Test finished ", function(){

    it("Log out", function(){
        Auth.logOut();
    });

});
