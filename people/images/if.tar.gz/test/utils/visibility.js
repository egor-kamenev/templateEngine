var Visibility = function(){

    var selectDropdownbyValue = function (element, optionValue) {
        element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
    };

    function findVisibleElement(selector){
        return protractor.promise.filter(element.all(selector), function(e) {
            return e.isDisplayed();
        }).then(function(visibleElements) {
            expect(visibleElements.length).toBe(1);
            return visibleElements[0];
        });
    }

    this.setVisibility = function (obj, entity) {
        if (obj.visibility != null) {

            var btn = browser.findElement( 
                by.xpath('//button[@data-select-visibility and @data-entity="' + entity + '"]') 
            );
            btn.click();
            //element(by.xpath('//button[@data-select-visibility and @data-entity="' + entity + '"]')).click();
            var form = element(by.xpath('//div[@class="light-modal ng-scope active"]//h3[text()="Настройка приватности"]/../..'));
            selectDropdownbyValue(form.element(by.name('visibility')), obj.visibility);
           
            if (obj.visibility == '1' && obj.visibility_users) {
                form.element(by.xpath('//div[@id="s2id_selected_users"]//input')).click();
                for (var i = 0; i < obj.visibility_users.length; i++) {
                    form.element(by.xpath('//div[@id="s2id_selected_users"]//input')).sendKeys(obj.visibility_users[i]);
                    form.element(by.xpath('//ul[@class="select2-results"]//div[text()="' + obj.visibility_users[i] + '"]')).click();
                }
            }

            findVisibleElement(by.xpath("//*[@data-protractor-id='showToAll']//input")).then(function(e){
                e.getAttribute('checked').then(function(val){

                    if(obj.visibility_show_for_all!=null){
                        val = val != null;
                        if(val != obj.visibility_show_for_all){
                            
                            findVisibleElement(by.xpath("//*[@data-protractor-id='showToAll']//i")).then(function(e){
                                e.click();
                            });
                        }
                        
                    }

                });
            });

            /*if (obj.visibility_show_for_all) {
                element.all(by.xpath("//section[@class='control-group']")).get(3).element(by.xpath("//label[contains(@class,'checkbox') and contains(@class,'controls')]")).click();
            }*/
            
            if (obj.visibility == '1' && obj.specified_users) {

                element(by.xpath("//div[@id='s2id_selected_users']//input[contains(@type,'text') and contains(@class,'select2-input')]")).click();
                element(by.xpath("//div[@id='s2id_selected_users']//input[contains(@type,'text') and contains(@class,'select2-input')]")).sendKeys(obj.specified_users[0]);
                browser.driver.sleep(7000);

                form.element(by.xpath('//ul[@class="select2-results"]//div[text()="' + obj.specified_users[0] + '"]')).click();
                
                if(typeof obj.specified_users[1] !== 'undefined') {
                    element(by.xpath("//div[@id='s2id_selected_users']//input[contains(@type,'text') and contains(@class,'select2-input')]")).click();
                    element(by.xpath("//div[@id='s2id_selected_users']//input[contains(@type,'text') and contains(@class,'select2-input')]")).sendKeys(obj.specified_users[1]);
                    browser.driver.sleep(7000);

                    form.element(by.xpath('//ul[@class="select2-results"]//div[text()="' + obj.specified_users[1] + '"]')).click();
                
                }
                
            }
            
            form.element(by.xpath('footer/button[text()="OK"]')).click();
        }
    };

};

module.exports = new Visibility();
