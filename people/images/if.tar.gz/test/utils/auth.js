var Auth = function(){

    var LOGIN_URL = '/auth/login',
        ADMIN_LOGIN = "admin",
        ADMIN_PASS = "admin";

    this.loginAsAdmin = function(login, password){

        var ptor = protractor.getInstance(),
            driver = ptor.driver;
      
        var findByName = function(name) {
            return driver.findElement(protractor.By.name(name));
        };
    
        browser.get(ADMIN_URL + "/admin/");

        findByName('username').sendKeys(login || ADMIN_LOGIN);
        findByName('password').sendKeys(password || ADMIN_LOGIN);

        driver.findElement(protractor.By.id('login-form')).submit();

    };

    this.loginAsUser = function(login, password){

        //var deferred = protractor.promise.defer();

        browser.get(LOGIN_URL);
        browser.waitForAngular();
        
        element(by.id('id_username')).sendKeys(login);
        element(by.id('id_password')).sendKeys(password);
        element(by.name('loginForm')).submit();
        browser.waitForAngular();

        /*element(by.xpath('//a[@class="logout"]')).isDisplayed().then(function(displayed){
            deferred.fulfill(displayed);
        });
         */
        //expect(element(by.xpath('//li[@class="private-mail"]')).isDisplayed()).toBe(true);

//        expect(element(by.xpath('//a[@class="logout"]')).isDisplayed()).toBe(true);
        
        //return deferred.promise;

    };

    this.logOut = function(){

        //var logoutLink = element(by.xpath('//a[@data-ui-sref="auth.logout"]'));

        //var logoutLink = element(by.xpath('//ul[@class="nav"]//a[@data-ui-sref="auth.logout"]'));
        
        //var logoutLink = element(by.xpath('//li[contains(concat(" ", normalize-space(@class), " "), " logout ")]//a[@data-ui-sref="auth.logout"]'));
        //expect(logoutLink.isDisplayed).toBeTruthy();


        // Wait for pnotify to close (if it's present)
        // pnotify window overlaps with profile button
       
       // browser.wait(function() {
        //    return element(by.className('ui-pnotify')).isPresent().then(function(result){
        //        return !result;
        //    });
       // }, 20000);

        //logoutLink.click();


        /*browser.executeScript('window.scrollTo(0,0);').then(function () {
            //browser.actions().mouseMove(element(by.xpath('//span[contains(@class,"avatar")]') )).perform();

            //element(by.xpath('//span[contains(@class,"avatar")]')).click();
            element(by.xpath('//button[@data-protractor-id="userProfile"]')).click();

            expect(logoutLink.isDisplayed()).toBe(true);
            logoutLink.click();
            browser.waitForAngular();
            expect( element(by.xpath('//a[@data-ui-sref="auth.login"]') ).isDisplayed()).toBe(true);
        });
         */

        // That's not working
        //browser.get('/auth/logout');
        //browser.waitForAngular();
        //        element(by.xpath('//a[@class="logout"]')).click();


        //element(by.xpath('//*[@data-protractor-id="userTopMenu"]')).click();
        //element(by.xpath('//*[@data-protractor-id="userTopMenuLogout"]')).click();
        

        // That's not working
        browser.get('/auth/logout');
        browser.waitForAngular();

        //expect(element(by.xpath('//a[@data-ui-sref="auth.login"]')).isDisplayed()).toBe(true);


    };

};

module.exports = new Auth();

