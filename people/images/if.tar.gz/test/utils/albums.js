var TagSelector = require('../utils/tagSelector.js'),
    Visibility = require('../utils/visibility.js');

var Albums = function(){
    
    this.getUserAlbumsUrl = function(user){
        return "/users/" + user.username + "/albums";
    };
    
    this.createNew = function(user, album){
        var 
        //uploadModal = element(by.xpath("//div[contains(@class,'light-modal') and contains(@class ,'active')]")),
        albumForm = element( by.name("addXPostForm") ),
        albumsUrl = '/users/' + user.username + '/albums',
        d = protractor.promise.defer();
        
        browser.get(albumsUrl);
        browser.waitForAngular();

        //element(by.id('add-album')).click();

        //expect(uploadModal.isDisplayed()).toBe(true);

        expect( albumForm.isDisplayed() ).toBeTruthy();

        if(album.tag){
            console.log("SETTING TAGS");
            TagSelector.setTextTag('s2id_msg_tags', album.tag);
        }
        albumForm.element(by.id('post-form-file-input')).sendKeys(album.uploadPhotoPath);
        albumForm.element(by.model('xPost.title')).sendKeys(album.title);

        if(album.description){
            albumForm.element(by.model('xPost.body')).sendKeys(album.description);
        }
        
        var title = browser.findElement( 
            by.model('xPost.title')
        );

        browser.executeScript(scrollIntoView, title);

        Visibility.setVisibility(album, 'xPost');

        element(by.name("addXPostForm")).submit();
        
        browser.driver.sleep(5000);

        browser.get(albumsUrl);
        browser.waitForAngular();
        
        var newAlbum = element(by.xpath('//a[@data-protractor-id="albumTitle"]'));

        //var newAlbum = element(by.xpath('(//a[starts-with(@data-ui-sref, "user.album(")])[1]'));
        expect(newAlbum.isDisplayed()).toBe(true);

        newAlbum.getAttribute("href").then(function(albumUrl){
            console.log("Album URL: ", albumUrl);
            album.url = albumUrl;
            browser.get(album.url);
            browser.waitForAngular();
            
            //var newPhoto = element(by.xpath('(//img[starts-with(@data-ui-sref, "user.photo(")])[1]'));
            var newPhoto = element(by.xpath("//img[@data-protractor-id='albumPhotoLink']"));

            newPhoto.click();

            browser.getCurrentUrl().then(function(photoUrl) {
                d.fulfill({
                    albumUrl: albumUrl,
                    photoUrl: photoUrl
                });
            });

            /*
            newPhoto.getAttribute("href").then(function(photoUrl){
                album.photoUrl = photoUrl;
                console.log("Photo URL: ", photoUrl);
                d.fulfill({
                    albumUrl: albumUrl,
                    photoUrl: photoUrl
                });
            });
             */
            
        });     

        return d;

    };
};

module.exports = new Albums();

