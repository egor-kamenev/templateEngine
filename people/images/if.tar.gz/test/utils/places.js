var TagSelector = require('../utils/tagSelector.js'),
    Visibility = require('../utils/visibility.js');

var Places = function(){

    var NEW_PLACE_URL = '/new_place';

    var selectDropdownbyValue = function (element, optionValue) {
        element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
    };

    this.createNewUnique = function (place) {
        place.name = place.name + Math.random().toString(36).substring(2);
        console.log('New place name:', place.name);
        return this.createNew(place);
    };

    this.createNewInMoscow = function (place) {

        var latitudeBorders = Array(55.61558902526749, 55.89225616635061),
            longitudeBorders = Array(37.437286376953125, 37.79296875);

        function randomInRange(min, max) {
            return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
        }

        place.lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
        place.lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);
        return this.createNewUnique(place);
    };

    this.createNewInPiter = function (place) {

        var latitudeBorders = Array(59.94142779110383, 60.02541222138017),
            longitudeBorders = Array(30.358657836914062, 30.907974243164062);

        function randomInRange(min, max) {
            return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
        }

        place.lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
        place.lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);
        return this.createNewUnique(place);
    };


    this.createNew = function (place) {

        var d = protractor.promise.defer(),
            map = element(by.xpath('//div[@data-protractor-id="placeFormMap"]')),
            //map = element(by.xpath('//div[@data-id="map_canvas"]')),
            placeForm = element(by.name('placeForm'));

        browser.get(NEW_PLACE_URL);
        browser.waitForAngular();

        expect(map.isDisplayed()).toBeTruthy();

        // Form should be present on the page
        expect(placeForm.isDisplayed()).toBeTruthy();

        expect(map.isDisplayed()).toBeTruthy();

        // Form should be present on the page
        expect(placeForm.isDisplayed()).toBeTruthy();

        if(place.lat && place.lng){
            browser.actions().doubleClick(map).perform();

            element(by.model('place_lat')).clear();
            element(by.model('place_lng')).clear();

            element(by.model('place_lat')).sendKeys(place.lat);
            element(by.model('place_lng')).sendKeys(place.lng);
        }
        else{
            // Move around a little bit
            
            for(var i = 0; i < Math.round(Math.random() * (3 - 1) + 1); i++){
                
                map.sendKeys(protractor.Key.ARROW_LEFT);
                
                for(var j = 0; j < Math.round(Math.random() * (3 - 1) + 1); j++){
                    map.sendKeys(protractor.Key.ARROW_UP);
                }
                
            }
            // Double click sets place marker on the map
            browser.actions().doubleClick(map).perform();
        }
        browser.waitForAngular();

        browser.wait(function() {
            
            return element(by.id('address-geolocation-complete')).isDisplayed().then(function(displayed){
                return displayed;
            });
            /*
            return element(by.repeater('post in xPosts track by post.id')).getText().then(function(result){
                return result.indexOf("Reply to post: " + i) >= 0;
            });*/
        }, 30000);

        expect(element(by.id('address-geolocation-complete')).isDisplayed()).toBeTruthy();


        element(by.model('placeform.name')).sendKeys(place.name);

        if(place.description){
            element(by.model('placeform.description')).sendKeys(place.description);
        }

        if(place.tag){
            element(by.xpath('//div[@id="s2id_place_tags"]//input')).click();
            element(by.xpath('//ul[@class="select2-results"]//div[text()="' + place.tag + '"]')).click();
            element(by.xpath('//div[@id="s2id_place_tags"]//input')).sendKeys(protractor.Key.ESCAPE);
        } else {
            TagSelector.selectFirstTag('s2id_place_tags');
            //TagSelector.selectFirstTag('s2id_newEvent_tags');
        }

        


        Visibility.setVisibility(place, 'placeform');
//        if (place.visibility) {
////            element(by.xpath('//button[@data-select-visibility=""]')).click();
////            var visibilityEl = element(by.model('entity.visibility.value'));
////            expect(visibilityEl.isDisplayed()).toBeTruthy();
////            visibilityEl.click();
////            visibilityEl.element(by.xpath('option[@value="'+ place.visibility +'"]')).click();
////            element(by.xpath('//button[@data-ng-click="saveVisibility()"]')).click();
//            element(by.xpath('//button[@data-select-visibility]')).click();
//            var form = element(by.xpath('//div[@class="light-modal ng-scope active"]//h3[text()="Настройка приватности"]/../..'));
//            selectDropdownbyValue(form.element(by.name('visibility')), place.visibility);
//            form.element(by.xpath('footer/button[text()="OK"]')).click();
//        }
        
        if (place.age_restrict) {
            selectDropdownbyValue(element(by.model('placeform.age_restriction')), place.age_restrict);
        }

        placeForm.submit();
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/places/');

        browser.getCurrentUrl().then(function(url){

            element(by.xpath("//*[@data-protractor-id='formattedAddress']")).getText().then(function(address){
                d.fulfill({
                    name: place.name,
                    url: url,
                    lat: place.lat,
                    lng: place.lng,
                    address: address
                });

            });
        });

        return d;

    };
};

module.exports = new Places();

