var TagSelector = function(){

    this.selectFirstTag = function(sel2ID){

        element(by.xpath('//div[@id="' + sel2ID + '"]//input')).click();
        expect( element(by.css('.select2-drop-active')).isPresent() ).toBeTruthy();
        expect( element(by.id('select2-drop')).isDisplayed() ).toBeTruthy();
        
        element(by.xpath('(//div[@id="select2-drop"]//ul[@class="select2-results"]//div)[1]')).click();
        element(by.xpath('//div[@id="' + sel2ID + '"]//input')).sendKeys(protractor.Key.ESCAPE);
         
    };

    this.selectSecondTag = function(sel2ID){

        element(by.xpath('//div[@id="' + sel2ID + '"]//input')).click();
        expect( element(by.css('.select2-drop-active')).isPresent() ).toBeTruthy();
        expect( element(by.id('select2-drop')).isDisplayed() ).toBeTruthy();
        
        element(by.xpath('(//div[@id="select2-drop"]//ul[@class="select2-results"]//div)[2]')).click();
        element(by.xpath('//div[@id="' + sel2ID + '"]//input')).sendKeys(protractor.Key.ESCAPE);
         
    };

    this.setTextTag = function(sel2ID, text){

        element(by.xpath('//div[@id="' + sel2ID + '"]//input')).sendKeys(text);
        element(by.xpath('(//ul[@class="select2-results"]//div)[1]')).click();
        //element(by.xpath('//div[@id="' + sel2ID + '"]//input')).sendKeys(protractor.Key.ESCAPE);
         
    };
    
};

module.exports = new TagSelector();
