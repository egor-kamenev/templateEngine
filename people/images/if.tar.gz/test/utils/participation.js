var Auth = require('./auth.js');

var Participation = function(){

    this.intendedToGoEvent = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я пойду');
        element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).click();
        Auth.logOut();
    };

    this.intendedNotToGoEvent = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        expect(element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я не пойду');
        element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).click();
        Auth.logOut();
    };

    this.intendedToGoEventByInvitetion = function(user, event){
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();
        
        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я хочу пойти');
        element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).click();
        Auth.logOut();
    };

    this.eventCheckIn = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get(event.url);
        browser.waitForAngular();
        element(by.xpath("//*[@data-protractor-id='eventMegaMenu']")).click();
        expect(element(by.xpath("//*[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я пойду');
        element(by.xpath("//*[@data-protractor-id='eventCheckInOut']")).click();
        Auth.logOut();
    };

    this.eventCheckOut = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get(event.url);
        browser.waitForAngular();
        element(by.xpath("//*[@data-protractor-id='eventMegaMenu']")).click();

        expect(element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я не пойду');
        element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).click();
        Auth.logOut();
    };

    this.eventCountParticipation = function(user, event, count) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventParticipants']")).click();
        //browser.sleep(9999999);
        //expect(element.all(by.repeater("item in eventParticipants track by item.id")).count()).toBe(count);
        expect(element.all(by.repeater("item in dataSource")).count()).toBe(count);

        Auth.logOut();
    };

    this.eventUserInParticipation = function(user, event, target, status) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventParticipants']")).click();
        expect(element(by.xpath("//a[@href='/users/" + target.username + "']")).isPresent()).toBe(status);
        Auth.logOut();
    };

    this.eventAcceptUserRequest = function(owner, event, index){
        Auth.loginAsUser(owner.username, owner.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventInviteRequest']")).click();

        browser.navigate().refresh();
        element(by.repeater('request in requests').row(index)).element(by.xpath("//button[@data-ng-click='accept(request)']")).click();
        element(by.repeater('request in requests').row(index)).element(by.xpath("//button[@data-ng-click='accept(request)']")).click();
        Auth.logOut();
    };

    this.eventRejectUserRequest = function(owner, event, index){
        Auth.loginAsUser(owner.username, owner.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        element(by.xpath("//a[@data-protractor-id='eventInviteRequest']")).click();

        browser.navigate().refresh();
        element(by.repeater('request in requests').row(index)).element(by.xpath("//button[@data-ng-click='reject(request.id)']")).click();
        Auth.logOut();
    };

    this.iWasThere = function(user, event){
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        expect(element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я там был');
        Auth.logOut();
    };

    this.iWasNotThere = function(user, event){
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        expect(element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я там не был');
        Auth.logOut();
    };

    this.iWantTogo = function(user, event){
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        expect(element(by.xpath("//button[@data-protractor-id='eventCheckInOut']")).getText()).toBe('Я хочу пойти');
        element(by.xpath("//a[@data-protractor-id='eventParticipants']")).click();
        Auth.logOut();
    };

};

module.exports = new Participation();
