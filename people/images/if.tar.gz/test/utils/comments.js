var Comments = function(){

    this.addComment = function (url, tag, text) {
        if (url) {
            browser.get(url);
            browser.waitForAngular();
        }
        if (tag != null) {
            element(by.xpath("//div[@id='s2id_msg_tags']")).click();
            element(by.xpath("//div[@id='s2id_msg_tags']//input")).sendKeys(tag);
            element(by.xpath("//div[@id='select2-drop']")).click();
        }
        element(by.model('xPost.body')).sendKeys(text);
        element(by.name('addXPostForm')).submit();
 
        browser.waitForAngular();

        expect(
            element(by.css(".ui-pnotify-container.alert-success")).isDisplayed()
        ).toBeTruthy();

    };

    this.isEditable = function(text, tag) {

        var post = element(
                by.xpath('//div[text()="' + text + '"]/../..')
            ),
            postMenu = post.element(
                by.xpath('//button[@data-protractor-id="xPostMenu"]')
            );
        
        expect(
            postMenu.isDisplayed()
        ).toBeTruthy();

        postMenu.click();
        
        //expect(element(by.xpath("//li[@class='comment']//button[@data-ng-click='startEditPost(post)']")).isDisplayed()).toBe(true);
        element(by.xpath("//*[@data-protractor-id='editPost']")).click();

        //browser.driver.sleep(900000000);
        if( tag != null) {
            expect(
                //element(by.css('.edited')).element(by.xpath("//ul[@class='select2-choices']//div")).getText()
                element(by.xpath("//*[contains(@class, 'edited')]//ul[@class='select2-choices']//div")).getText()
            ).toBe(tag);
        }
        
        expect(
            element(by.xpath("//*[contains(@class, 'edited')]//textarea[@id='xPostBody']")).getAttribute('value')
        ).toBe(text);
        browser.navigate().refresh();
    };

    this.checkCountComments = function(count) {
        browser.navigate().refresh();
        expect(element.all(by.xpath("//*[@data-protractor-id='xPostEntry']")).count()).toBe(count);
    };

    this.checkPosibility = function (url, result) {
        if (url) {
            browser.get(url);
            browser.waitForAngular();
        }
        expect(element(by.id('xPostBody')).isDisplayed()).toBe(result);
    };

};

module.exports = new Comments();

