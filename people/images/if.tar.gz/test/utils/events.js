var DateTimePicker = require('../utils/dateTimePicker.js'),
    TagSelector = require('../utils/tagSelector.js'),
    Visibility = require('../utils/visibility.js');

var Events = function(){

    var NEW_EVENT_URL = '/new_event';

    var selectDropdownbyValue = function (element, optionValue) {
        element.element(by.xpath('option[@value = "' + optionValue + '"]')).click();
    };

    this.createNewUnique = function (event) {
        event.name = event.name + Math.random().toString(36).substring(2);
        return this.createNew(event);
    };

    this.createNew = function (event) {
        
        //  event should have a structure
        //    {
        //  // required
        //        name: 'event1',
        //        ts_start: '01.05.2014 12:15',
        //        tag: 'праздник',
        //        participants_min: 0,
        //  // not required
        //        ts_finish: null,
        //        description: '',
        //        participants_max: null,
        //        age_restrict: '3',
        //        by_invitation: true,
        //        visibility: '4'
        //    }

        var d = protractor.promise.defer();

        browser.get(NEW_EVENT_URL);
        browser.waitForAngular();
        element(by.id('name')).sendKeys(event.name);

        if(event.ts_start){
            
            var date, time, day, month, year, hour, minute,
                datePicker = element(by.id('date1_date')),
                datePickerDiv = element(by.id('ui-datepicker-div')),
                yearSelector = element(by.xpath('//select[@class="ui-datepicker-year"]')),
                monthSelector = element(by.xpath('//select[@class="ui-datepicker-month"]'));

            //element(by.xpath("//table[@class='ui-datepicker-calendar']//a[contains(text(),'20')]")).click();
            
            expect(datePicker.isDisplayed()).toBeTruthy();
            
            datePicker.click();

            expect(datePickerDiv.isDisplayed()).toBeTruthy();
            expect(yearSelector.isDisplayed()).toBeTruthy();
            expect(monthSelector.isDisplayed()).toBeTruthy();

            date = event.ts_start.split(' ')[0];
            time = event.ts_start.split(' ')[1];
            day = parseInt(date.split('.')[0]);
            month = parseInt(date.split('.')[1]) - 1;
            year = date.split('.')[2];
                            

            selectDropdownbyValue(yearSelector, year);
            selectDropdownbyValue(monthSelector, month);
            element(by.xpath('//a[text()="' + day + '"]')).click();
            //if (time) {
            hour = time ? parseInt(time.split(':')[0]) : 12;
            minute = time ? parseInt(time.split(':')[1]) : 0;
            selectDropdownbyValue(element(by.id('date1_hour')), hour);
            selectDropdownbyValue(element(by.id('date1_minute')), minute);
            //}

        }
        else{
            DateTimePicker.selectTomorrow('date1');
        }

        if (event.ts_finish) {
            element(by.id('date2_date')).click();
            date = event.ts_finish.split(' ')[0];
            time = event.ts_finish.split(' ')[1];
            day = parseInt(date.split('.')[0]);
            month = parseInt(date.split('.')[1]) - 1;
            year = date.split('.')[2];
            selectDropdownbyValue(element(by.xpath('//select[@class="ui-datepicker-year"]')), year);
            selectDropdownbyValue(element(by.xpath('//select[@class="ui-datepicker-month"]')), month);
            element(by.xpath('//a[text()="' + day + '"]')).click();

            hour = time ? parseInt(time.split(':')[0]) : 12;
            minute = time ? parseInt(time.split(':')[1]) : 0;
            selectDropdownbyValue(element(by.id('date2_hour')), hour);
            selectDropdownbyValue(element(by.id('date2_minute')), minute);

        }
        
        if (event.age_restrict) {
            selectDropdownbyValue(element(by.model('event.age_restriction')), event.age_restrict);
        }
        
        /*if (event.participants_min) {
            element(by.name('participants_min')).click();
            for (var i = 0; i < event.participants_min; i++) {
                element(by.name('participants_min')).sendKeys(protractor.Key.UP);
            }
//            element(by.name('participants_min')).sendKeys(event.participants_min);
        }
        
        if (event.participants_max) {
            element(by.name('participants_max')).click();
            for (var i = 0; i < event.participants_max; i++) {
                element(by.name('participants_max')).sendKeys(protractor.Key.UP);
            }
//            element(by.name('participants_max')).sendKeys(event.participants_max);
        }
        */

        if (event.description) {
            element(by.id('description')).sendKeys(event.description);
        }


        if (event.by_invitation) {
            element.all(by.xpath("//div[@class='row']")).get(0).element(by.xpath("//label[@class='checkbox']")).click();
        }
        
        if(event.tag){
            element(by.xpath('//div[@id="s2id_newEvent_tags"]//input')).click();
            element(by.xpath('//ul[@class="select2-results"]//div[text()="' + event.tag + '"]')).click();
            element(by.xpath('//div[@id="s2id_newEvent_tags"]//input')).sendKeys(protractor.Key.ESCAPE);
        } else {
            TagSelector.selectFirstTag('s2id_newEvent_tags');
        }

        if(event.place) {
            element(by.xpath("//div[@id='s2id_newEvent_place']")).click();
            element(by.xpath('//ul[@class="select2-results"]//div[text()="Создать новое место"]')).click();

            var latitudeBorders = Array(55.61558902526749, 55.89225616635061),
                longitudeBorders = Array(37.437286376953125, 37.79296875);

            function randomInRange(min, max) {
                return Math.random() < 0.5 ? ((1-Math.random()) * (max-min) + min) : (Math.random() * (max-min) + min);
            }
             

            event.place.lat = randomInRange(latitudeBorders[0], latitudeBorders[1]);
            event.place.lng = randomInRange(longitudeBorders[0], longitudeBorders[1]);
            
            var placeForm = element(by.name('placeForm')),
                map = element(by.xpath('//div[@data-protractor-id="placeFormMap"]'));

            browser.actions().doubleClick(map).perform();

            element(by.model('place_lat')).clear();
            element(by.model('place_lng')).clear();

            element(by.model('place_lat')).sendKeys(event.place.lat);
            element(by.model('place_lng')).sendKeys(event.place.lng);
            console.log('EVENT PLACE NAME:', event.place.name);
            element(by.model('placeform.name')).sendKeys(event.place.name);

            TagSelector.selectFirstTag('s2id_place_tags');

            Visibility.setVisibility(event.place, 'placeform');

            selectDropdownbyValue(element(by.xpath("//select[@data-protractor-id='placeFormAgeRestriction']")), '0');
            
            placeForm.submit();
        }
        else if(event.place_name) {
            element(by.xpath('//div[@id="s2id_newEvent_place"]/a')).click();
            element(by.xpath('//div[@class="select2-search"]//input[@aria-activedescendant]')).sendKeys(event.place_name);
            element(by.xpath('//div[@class="select2-result-label"]')).click();
        }
        // Virtual event
        //else{
        //element(by.xpath('//div[@id="s2id_newEvent_place"]/a')).click();
        //element(by.xpath('//div[text()="Виртуальное событие"]')).click();
        //}

        Visibility.setVisibility(event, 'event');

        
        element(by.name('eventForm')).submit();
        browser.waitForAngular();
        
        // Event url contains event alias, not the full name
        // alias may be shorter, so here we check first 47 characters only
        // (50 characters total - suffix length such as '-2' if alias is not unique)
        expect(browser.getCurrentUrl()).toContain(browser.baseUrl + 'events/' + event.name.substring(0,47));

        browser.getCurrentUrl().then(function(url) {
            d.fulfill({
                name: event.name,
                url: url
            });
        });


        return d;
        
    };

    this.checkParticipants = function (event_alias, username) {
        browser.get('/events/' + event_alias);
        browser.waitForAngular();

        expect(element(by.xpath("//a[contains(@href,'/users/" + username + "') and contains(@class,'intended-to-go')]")).isPresent()).toBe(true);
    };

    
    this.giveInvitations = function (event, users) {
        var username, state;
        browser.get(event.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='userMessages']")).click();
        element(by.xpath("//*[@data-protractor-id='sendInvitations']")).click();
        
        browser.waitForAngular();
        element(by.xpath("//*[@data-protractor-id='toggleInvitationsModal']")).click();

        expect(
            element(
                by.model("targetUsers.specifiedUsers")
            ).isDisplayed()
        ).toBeTruthy();

        element(by.xpath('//div[@id="s2id_specifiedUsers"]//input')).sendKeys(users[0]);
        element(by.xpath('(//ul[@class="select2-results"]//div)[1]')).click();


        if(typeof users[1] != 'undefined') {
            element(by.xpath('//div[@id="s2id_specifiedUsers"]//input')).sendKeys(users[1]);
            element(by.xpath('(//ul[@class="select2-results"]//div)[1]')).click();
        }

        element(
            by.name('addUsersForm')
        ).submit();

        element(by.xpath("//*[@data-protractor-id='realSendInvitations']")).click();
        browser.waitForAngular();
        

    };

    this.deleteEvent = function(event) {
        browser.get('/events/' + event.name);
        browser.waitForAngular();
        
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='deleteEvent']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//button[@data-ng-click='yes()']")).click();
    };

    this.disableEvent = function(event) {
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        browser.driver.sleep(5000);
        element(by.xpath("//button[@data-protractor-id='eventOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='disableEvent']")).click();
        element(by.xpath("//div[contains(@class,'light-modal') and contains(@class,'active')]//button[@data-ng-click='yes()']")).click();
    };
    
};

module.exports = new Events();

