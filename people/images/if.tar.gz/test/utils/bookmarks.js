var Auth = require('./auth.js');

var Bookmarks = function(){

    this.addEventToBookmarks = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='bookmarkEvent']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='bookmarkEvent']")).getText()).toBe('Убрать из закладок');
        Auth.logOut();
    };

    this.removeEventFromBookmarks = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/events/' + event.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='bookmarkEvent']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='bookmarkEvent']")).getText()).toBe('Добавить в закладки');
        Auth.logOut();
    };

    this.checkEventsBookmarkedCount = function(user, count) {
        Auth.loginAsUser(user.username, user.password);
        
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggleUserBookmarks']")).click();
        element(by.xpath("//a[@data-protractor-id='userBookmarksEvents']")).click();

        expect(element.all(by.repeater("item in dataSource track by item.id")).count()).toBe(count);
        Auth.logOut();
    };

    this.addUserToBookmarks = function (user, target) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/users/' + target.username);
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='userMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='bookmarkUser']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='bookmarkUser']")).getText()).toBe('Убрать из закладок');
        Auth.logOut();
    };

    this.checkUsersBookmarkedCount = function(user, count) {
        Auth.loginAsUser(user.username, user.password);
        
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggleUserBookmarks']")).click();
        element(by.xpath("//a[@data-protractor-id='userBookmarksUsers']")).click();

        expect(element.all(by.repeater("item in dataSource track by item.id")).count()).toBe(count);
        Auth.logOut();
    };

    this.removeUserFromBookmarks = function (user, target) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/users/' + target.username);
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='userMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='bookmarkUser']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='bookmarkUser']")).getText()).toBe('Добавить в закладки');
        Auth.logOut();
    };

    this.addPlaceToBookmarks = function (user, target) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/places/' + target.name);
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='bookmarkPlace']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='bookmarkPlace']")).getText()).toBe('Убрать из закладок');
        Auth.logOut();
    };

    this.checkPlaceBookmarkedCount = function(user, count) {
        Auth.loginAsUser(user.username, user.password);
        
        element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='toggleUserBookmarks']")).click();
        element(by.xpath("//a[@data-protractor-id='userBookmarksPlaces']")).click();

        expect(element.all(by.repeater("item in dataSource track by item.id")).count()).toBe(count);
        Auth.logOut();
    };

    this.removePlaceFromBookmarks = function (user, target) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/places/' + target.name);
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='bookmarkPlace']")).click();
        expect(element(by.xpath("//button[@data-protractor-id='bookmarkPlace']")).getText()).toBe('Добавить в закладки');
        Auth.logOut();
    };

};

module.exports = new Bookmarks();