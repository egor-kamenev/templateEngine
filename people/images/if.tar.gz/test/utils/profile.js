var Profile = function(){

    this.publicProfileSections = Array(
        '/',
        '/stream',
        '/albums',
        '/events',
        '/interests',
        '/places',
        '/friends',
        '/statuses'
    );

    this.privateProfileSections = Array(
        '/calendar',
        '/favorites',
        '/messages/private',
        '/messages/notice',
        '/messages/invite',
        '/messages/friendship',
        '/subscriptions/subscribers',
        '/subscriptions/events',
        '/subscriptions/places',
        '/subscriptions/users',
        '/subscriptions/friends',
        '/bans/to',
        '/bans/from',
        '/bookmarks/events',
        '/bookmarks/places',
        '/bookmarks/users',
        '/profile',
        '/placeStudy',
        '/placeWork',
        '/settings/ban',
        '/settings/social',
        '/settings/visible',
        '/settings/remind',
        '/settings/locale',
        '/settings/password',
        '/settings/notice',
        '/settings/display'
    );

    this.getUserPublicProfileSections = function(user){

        var ret = Array();

        for(var i=0; i < this.publicProfileSections.length; i++){

            var section = this.publicProfileSections[i],
                url = '/users/' + user.username + section;
            ret.push(url);
        }
        return ret;

    };

    this.getUserPrivateProfileSections = function(user){

        var ret = Array();

        for(var i=0; i < this.privateProfileSections.length; i++){

            var section = this.privateProfileSections[i],
                url = '/users/' + user.username + section;
            ret.push(url);
        }
        return ret;

    };

    this.getAllProfileSections = function(user){
        return this.getUserPublicProfileSections(user).concat(this.getUserPrivateProfileSections(user));
    };

    this.setDiscoverable = function(login, val){

        val = !val;
        browser.get('/users/' + login + '/settings/visible');
        browser.waitForAngular();

        expect(browser.getCurrentUrl()).toContain('/settings/visible');
        element(by.id("is_discoverable")).isSelected().then(function(selected){
            var needToSwitch = selected != val;
            if(needToSwitch){
                element(by.xpath("//input[@id='is_discoverable']//..")).click();
                expect(element(by.id("is_discoverable")).isSelected()).toBe(val);

                element(by.xpath('//*[@data-protractor-id="saveSettings"]')).click();

                expect(element(by.className('ui-pnotify-title')).isDisplayed()).toBe(true);
                
                // Wait for pnotify to close
                browser.wait(function() {
                    return element(by.className('ui-pnotify')).isPresent().then(function(result){
                        return !result;
                    });
                }, 40000);
                                                            
            }
        });

    };



};

module.exports = new Profile();

    
