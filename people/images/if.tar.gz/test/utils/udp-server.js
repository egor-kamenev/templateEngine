var dgram = require("dgram");
var server = dgram.createSocket("udp4");
var inbox = {
    sms: [],
    email: []
};

server.on("error", function (err) {
    console.log("UDPServer ERROR:\n" + err.stack);
//        server.close();
});

server.on("message", function (msg, rinfo) {
    var obj = msg.toString();
    obj = obj.substring(obj.indexOf('>') + 1, obj.length - 1);
    json_obj = JSON.parse(obj);
    inbox[json_obj.type].push(json_obj);
    console.log('UDPServer got message: ', obj);
});

server.on("listening", function () {
    console.log("UDPServer listening ", server.address());
});

//server.bind(5555, '127.0.0.1');

function UDPSyslogServer() {
}

UDPSyslogServer.prototype.getMessages = function(type) {
    return inbox[type];
}

UDPSyslogServer.prototype.getEmail = function(email) {
    for (var i = 0; i < inbox.email.length; i++) {
        if (inbox.email[i].to.indexOf(email) > -1) {
            return inbox.email[i];
        }
    }
}

UDPSyslogServer.prototype.getSMS = function(phone) {
    if (phone[0] == '+') {
        phone = phone.substring(1, phone.length);
    }
    for (var i = 0; i < inbox.sms.length; i++) {
        if (inbox.sms[i].recipients.indexOf(phone) > -1) {
            return inbox.sms[i];
        }
    }
}

UDPSyslogServer.prototype.start = function(host, port) {
    server.bind(port, host);
};

UDPSyslogServer.prototype.stop = function() {
    console.log("UDPServer stopped");
    server.close();
};

exports = module.exports = UDPSyslogServer;
