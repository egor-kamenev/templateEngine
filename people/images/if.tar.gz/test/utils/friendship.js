var Auth = require('./auth.js');

function findReactElement(selector){
    return protractor.promise.filter(element.all(selector), function(e) {
        return e.isDisplayed();
    }).then(function(visibleElements) {
        expect(visibleElements.length).toBe(1);
        return visibleElements[0];
    });
}

var Friendship = function(){

    this.beFriends = function (sender, recipient) {
       
        Auth.loginAsUser(sender.username, sender.password);
        browser.get('/users/' + recipient.username);
        browser.waitForAngular();

        //element(by.xpath('//button[@data-protractor-id="userMegaMenu"]')).click();
        element(by.xpath('//button[@data-protractor-id="sendFriendshipRequest"]')).click();

        element(by.xpath("//div[@id='s2id_friendship_tags']//input")).sendKeys('друзья');
        element(by.xpath("//div[@id='select2-drop']")).click();
        element(by.xpath("//textarea[@id='message']")).sendKeys('Привет!');

        element(by.xpath("//form[@name='newFriendForm']")).submit();
        Auth.logOut();

        Auth.loginAsUser(recipient.username, recipient.password);

        browser.get('/users/' + recipient.username + '/messages/friendship');
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        //element(by.xpath("//button[@data-protractor-id='toggleMessages']")).click();

        expect(
            element(by.xpath("//*[@data-protractor-id='friendship-request-to-me-" + sender.username + "']")).isPresent()
        ).toBeTruthy();

        findReactElement(by.xpath("//*[@data-protractor-id='acceptFriendshipRequest']")).then(function(accept){
            accept.click();
        });
        //element(by.xpath("//a[@data-protractor-id='acceptFriendshipRequest']")).click();

        /*element(by.xpath("//a[@data-protractor-id='userMessagesFriendship']")).getText().then(function(value){

            //expect(value).toMatch(/1/); // не во всех тестах так получается что ровно 1 сообщение

            element(by.xpath("//a[@data-protractor-id='userMessagesFriendship']")).click();

            browser.navigate().refresh();
        
            expect(element(by.repeater('r in messages | filter:{from_me: false}').row(0)).element(by.xpath("//div[@id='s2id_tags']//input")).isPresent()).toBe(true);
            //expect(element(by.repeater('r in messages | filter:{from_me: false}').row(0)).element(by.xpath("//button[contains(@class,'accept-request') and contains(@data-ng-click,'acceptRequest(r)')]")).isPresent()).toBe(true);
            expect(element(by.repeater('r in messages | filter:{from_me: false}').row(0)).element(by.xpath("//*[@data-protractor-id='acceptFriendshipRequest']")).isPresent()).toBe(true);

            //expect(element(by.repeater('r in messages | filter:{from_me: false}').row(0)).element(by.xpath("//button[contains(@class,'reject-request') and contains(@data-ng-click,'rejectRequest(r)')]")).isPresent()).toBe(true);
            expect(element(by.repeater('r in messages | filter:{from_me: false}').row(0)).element(by.xpath("//*[starts-with(@data-protractor-id, 'rejectFriendshipRequest')]")).isPresent()).toBe(true);
            
            element(by.repeater('r in messages | filter:{from_me: false}').row(0)).element(by.xpath("//*[@data-protractor-id='acceptFriendshipRequest']")).click(); // last request
            Auth.logOut();
        });
         */

        Auth.logOut();

    };

};

module.exports = new Friendship();
