var DateTimePicker = function(){

    this.selectToday = function(dateTimePickerID){

        element(by.id(dateTimePickerID + '_date')).click();
        // Select today
        element(by.xpath('//td[contains(@class, "ui-datepicker-today")]//a')).click();

    };

    this.selectTomorrow = function(dateTimePickerID){

        element(by.id(dateTimePickerID + '_date')).click();
        // Select tomorrow
        element(by.xpath('//td[contains(@class, "ui-datepicker-today")]//following-sibling::td')).click();
    };
};

module.exports = new DateTimePicker();
