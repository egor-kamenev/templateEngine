var Auth = require('../utils/auth.js'),
    UserMail = require('./userMail.js'),
    moment = require('moment');

var Signup = function(){

    var SIGNUP_URL = '/signup',
        SIGNUP_COMPLETE_URL = '/settings/profile';

    this.SIGNUP_URL = SIGNUP_URL;

    var fillField = function (field_name, value) {
        expect( element(by.id(field_name)).isDisplayed() ).toBeTruthy();
        var field = element(by.id(field_name));
        field.clear();
        field.sendKeys(value);
    };

    var selectDropdownbyText = function (element, text) {
        element.element(by.xpath('option[text() = "' + text + '"]')).click();
    };

    var selectDropdownbyNum = function (element, optionNum) {
        if (optionNum) {
            var options = element.all(by.tagName('option')).then(
            //var options = element.elements(by.tagName('option')).then(
            
                function(options) {
                    options[optionNum].click();
                }
            );
        }
    };

    this.registerUserUntilDone = function(REG_USER){
        var d = protractor.promise.defer(),
            counter = 0,
            LIMIT = 5;


        function regUser(){

            browser.get(SIGNUP_URL);
            browser.waitForAngular();
            
            counter ++;
            var index = Math.floor(Math.random()*1000000),
                arr = REG_USER.email.split('@'),
                newEmail = arr[0] + index + '@' + arr[1],
                newUsername = REG_USER.username + index,
                mmnt = moment();

            fillField('username', newUsername);
            fillField('first_name', REG_USER.first_name);
            fillField('last_name', REG_USER.last_name);
            fillField('email', newEmail);

            if(typeof REG_USER.day === 'undefined') {
                selectDropdownbyNum(element(by.id('day_of_birth')), mmnt.date());
            } else {
                selectDropdownbyNum(element(by.id('day_of_birth')), REG_USER.day);
            }
            
            if(typeof REG_USER.month === 'undefined') {
                selectDropdownbyNum(element(by.id('month_of_birth')), mmnt.month() + 1);
            } else {
                selectDropdownbyNum(element(by.id('month_of_birth')), REG_USER.month);
            }


            //selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER.age);
            selectDropdownbyText(element(by.id('year_of_birth')), mmnt.year() - REG_USER.age);

            fillField('password', REG_USER.password);
            fillField('password2', REG_USER.password);
            //element(by.id('eula')).click();

            element(by.xpath('//input[@id="eula"]/following-sibling::i')).click();


            element(by.name('signupForm')).submit();
            browser.waitForAngular();

            browser.getCurrentUrl().then(function(url){
                
                var redirectedToProfile = url && (url.indexOf(SIGNUP_COMPLETE_URL) > -1);
                if(redirectedToProfile){
                    Auth.logOut();
                    d.fulfill({
                        username: newUsername, 
                        email: newEmail,
                        index: index
                    });
                }
                else{
                    if(counter >= LIMIT){
                        d.reject();
                    }
                    else{
                        regUser();
                    }
                }
            });
        }

        regUser(REG_USER);
        return d;
    };

    this.registerUserWithPhoneUntilDone = function(REG_USER){
        browser.get(SIGNUP_URL);

        var index = Math.floor(Math.random()*1000000),
            arr = REG_USER.email.split('@'),
            newEmail = arr[0] + index + '@' + arr[1],
            newUsername = REG_USER.username + index;

        fillField('username', newUsername);
        fillField('first_name', REG_USER.first_name);
        fillField('last_name', REG_USER.last_name);
        fillField('email', newEmail);
        element(by.model('new_user.phone')).sendKeys(REG_USER.phone);
        selectDropdownbyNum(element(by.id('day_of_birth')), '2');
        selectDropdownbyNum(element(by.id('month_of_birth')), '4');
        selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER.age);
        fillField('password', REG_USER.password);
        fillField('password2', REG_USER.password);
        //element(by.id('eula')).click();
        element(by.xpath('//input[@id="eula"]/following-sibling::i')).click();

        element(by.name('signupForm')).submit();
        browser.waitForAngular();

        expect(element(by.xpath("//form[@name='verificationCode']")).isDisplayed()).toBe(true);
    };

    this.registerUser = function(REG_USER){
        var d = protractor.promise.defer();
        browser.get(SIGNUP_URL);
        browser.waitForAngular();

        fillField('username', REG_USER.username);
        fillField('first_name', REG_USER.first_name);
        fillField('last_name', REG_USER.last_name);
        fillField('email', REG_USER.email);
        selectDropdownbyNum(element(by.id('day_of_birth')), '2');
        selectDropdownbyNum(element(by.id('month_of_birth')), '4');
        selectDropdownbyNum(element(by.id('year_of_birth')), REG_USER.age);
        fillField('password', REG_USER.password);
        fillField('password2', REG_USER.password);
        //element(by.id('eula')).click();
        element(by.xpath('//input[@id="eula"]/following-sibling::i')).click();
        element(by.name('signupForm')).submit();
        browser.waitForAngular();
        browser.getCurrentUrl().then(function(url){

            var redirectedToComplete = url && (url.indexOf(SIGNUP_COMPLETE_URL) > -1);
            if(redirectedToComplete){
                d.fulfill(true);
            }
            else{
                d.fulfill(false);
            }
        });
        return d;
    };

    this.addPhone = function(REG_USER){
        browser.get('/users/' + REG_USER.username + '/settings/profile');
        browser.waitForAngular();
        var phoneInput = element(by.model('profile.phone.value'));
        phoneInput.clear();
        phoneInput.sendKeys(REG_USER.phone);
        element(by.name('profileForm')).submit();
        browser.waitForAngular();
    };

    this.verifyPhone = function(userData){

        var mailer = new UserMail(null, userData.phone),
            flow = protractor.promise.controlFlow();

        browser.get('/users/' + userData.username + '/settings/profile');
        browser.waitForAngular();
            
        flow.execute(mailer.getAllSms).then(function(value){

            var scrollIntoView = function () {
                arguments[0].scrollIntoView();
            };

            var code = value[0].msg.match(/\d+/g)[0];
            expect( element(by.id('verify_phone_button')).isDisplayed()).toBe(true);
            var btn = browser.findElement(by.id('verify_phone_button'));
            
            browser.executeScript(scrollIntoView, btn ).then(function(){
                
                element(by.id('verify_phone_button')).click();
                element(by.id('verification_code')).sendKeys(code);
                element(by.name('verifyContactForm')).submit();
                
            });

        });

        /*

        var sms = UDPServer.getSMS(REG_USER.phone);
        expect(sms != null).toBe(true);
        if (sms != null) {
            var i = sms.msg.indexOf(':') + 2,
                code = sms.msg.substring(i, i + 6);
            element(by.id('verify_phone_button')).click();
            element(by.id('verification_code')).sendKeys(code);
            element(by.name('verifyContactForm')).submit();
        }
         */
    };

    this.verifyEmail = function(userData){

        var mailer = new UserMail(userData.email, null),
            flow = protractor.promise.controlFlow(),
            urlPattern = /\b(?:https?|ftp):\/\/[a-z0-9-+&@#\/%?=~_|!:,.;]*[a-z0-9-+&@#\/%=~_|]/gim;

        flow.execute(mailer.getAllMail).then(function(value){

            var key = value[0].body.match(urlPattern)[0].split('/')[7];
            var verifyPath = '/contacts/verify_email/' + userData.email + '/' + key;

            console.log('verify path:', verifyPath);

            browser.get(verifyPath);
            browser.waitForAngular();
        });

        /* OLD API
        var email = UDPServer.getEmail(REG_USER.email);
        expect(email != null).toBe(true);

        var link = email.body.substring(email.body.indexOf('http://'), email.body.length - 1).split(',')[0];
        browser.get(link);
        browser.waitForAngular();
         */
    };
};

module.exports = new Signup();

