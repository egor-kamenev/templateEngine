var Auth = require('./auth.js');

var Subscription = function(){

    this.subscribeToEvent = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get(event.url);
        browser.waitForAngular();
        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='subscribeEvent']")).click();
        //element(by.xpath("//form[@name='subscriptionForm']")).submit();
        Auth.logOut();
    };

    this.subscribeToEventWithoutNotification = function (user, event) {
        Auth.loginAsUser(user.username, user.password);
        browser.get(event.url);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='eventMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='subscribeEvent']")).click();

        //element(by.xpath("//label[@data-protractor-id='recieveNotifications']")).click();
        
        //element(by.xpath("//form[@name='subscriptionForm']")).submit();
        Auth.logOut();
    };

    this.subscribeToPlace = function(user, place) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/places/' + place.name);
        browser.waitForAngular();

        element(by.xpath("//button[@data-protractor-id='placeMegaMenu']")).click();
        element(by.xpath("//button[@data-protractor-id='subscribePlace']")).click();
        //element(by.xpath("//form[@name='subscriptionForm']")).submit();
        Auth.logOut();
    };

    this.isSubscribedPlace = function(user, place){
        Auth.loginAsUser(user.username, user.password);
       
        browser.get('/users/' + user.username + '/subscriptions/places');
        browser.waitForAngular();
        
        //http://local.webpasta.ru:5000/users/user1Complain426081/subscriptions/events

        //element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        //element(by.xpath("//button[@data-protractor-id='toggleSubscribers']")).click();
        //element(by.xpath("//a[@data-protractor-id='userSubscriptionsPlaces']")).click();
        
        expect(element(by.xpath("//a[@href='/places/" + place.name + "']")).isPresent()).toBe(true);
        Auth.logOut();
    };

    this.subscribeToUser = function(user, recipient) {
        Auth.loginAsUser(user.username, user.password);
        browser.get('/users/' + recipient.username);
        browser.waitForAngular();

        //browser.sleep(20000000);
        //element(by.xpath("//button[@data-protractor-id='userMegaMenu']")).click();
        element( by.xpath('//*[@data-protractor-id="userSubMenu2"]') ).click();
        element(by.xpath("//button[@data-protractor-id='subscribeUser']")).click();
        //element(by.xpath("//form[@name='subscriptionForm']")).submit();
        Auth.logOut();
    };

    this.isSubscribedUser = function(user, subscribed){
        Auth.loginAsUser(user.username, user.password);
       
        browser.get('/users/' + user.username + '/subscriptions/users');
        browser.waitForAngular();

        //element(by.xpath("//button[@data-protractor-id='userOwnerMegaMenu']")).click();
        //element(by.xpath("//button[@data-protractor-id='toggleSubscribers']")).click();
        //element(by.xpath("//a[@data-protractor-id='userSubscriptionsUsers']")).click();
        
        expect(element(by.xpath("//a[@href='/users/" + subscribed.username + "']")).isPresent()).toBe(true);
        Auth.logOut();
    };

};

module.exports = new Subscription();
