var Settings = function(){

    this.set = function(setting, val){
        browser.ignoreSynchronization = true;
        browser.get(ADMIN_URL + '/api/test/settings/'+setting+'/?value=' + val);
        browser.ignoreSynchronization = false;
    };
};

module.exports = new Settings();
