var https = require('https'),
    http = require('http');


function getJSON(type, data) {
    var defer = protractor.promise.defer();
    var url = '/api/test/' + type + '/' + encodeURIComponent(data) +  '/',
        httpService = http;
    
    console.log("Calling", url);
    if(TEST_API.protocol == 'https'){
        httpService = https;
    }
    var data = '';
    httpService.get({
                path: url,
                host: TEST_API.host,
                port: TEST_API.post,
                agent: false,
                rejectUnauthorized: false, 
                ca: TEST_API.caFile
            }, function(res) {
        res.on('data', function (chunk) {
            data += chunk;
        });
        res.on('end', function () {
            var result = JSON.parse(String(data));
            defer.fulfill(result);
        });
    }).on('err', function(err){
        defer.reject({ error : err });
    });
    return defer.promise;
}

module.exports = function(email, phone) {

    this.getAllMail = function() {
        return getJSON('mailer', email);
    },

    this.getAllSms = function() {
        return getJSON('sms', phone);
    };
};
