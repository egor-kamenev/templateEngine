var udp = require('./utils/udp-server'),
    fs = require('fs'),
    moment = require('moment');


exports.config = {
    allScriptsTimeout: 11000,

    specs: [
        
        'e2e/login.js',
        'e2e/reset_password.js',
        'e2e/registration.js',
        'e2e/permissions.js',
        'e2e/invitations.js',
        'e2e/handmade_ban_user_account.js',
        'e2e/discussion_bans.js',
        'e2e/age_limit.js',
        'e2e/albums_and_photos.js',
        'e2e/age_limit.js',
        'e2e/friendship.js',
        //'e2e/visibility.js',
        //'e2e/user_status.js',
        //'e2e/contacts.js',
        //'e2e/logging_the_location_of_the_user.js',
        'e2e/create_place.js',
        'e2e/favorite_places.js',
        'e2e/edit_place.js',
        'e2e/delete_place.js',
        'e2e/create_event.js',
        'e2e/event_edit.js',
        'e2e/event_delete.js',
        //'e2e/event_add_place.js',
        //'e2e/moderation.js',
        //'e2e/complains.js',
        //'e2e/subscription.js',
        
        //'e2e/calendar.js',
        //'e2e/personal_mail.js',
        //'e2e/bookmarks.js',
        'e2e/account.js',
        'e2e/user_profile.js',
        'e2e/interests.js',
        'e2e/likes.js',

        //'e2e/xwall.js',
        //'e2e/discussion.js',
        'e2e/tape.js',
        'e2e/tape.js',
        'e2e/registration_stats.js',
        //'e2e/filters.js',


    ],

    capabilities: {
        'browserName': 'chrome'
        //    'browserName': 'phantomjs'
        //    'browserName': 'firefox'
    },

    //baseUrl: 'http://127.0.0.1:8000/',
    //baseUrl: 'http://local.webpasta.ru:5000/',
    baseUrl: 'https://111:111@ai1.webpasta.ru/',


    framework: 'jasmine',

    jasmineNodeOpts: {
        defaultTimeoutInterval: 400000
    },
    seleniumAddress: 'http://127.0.0.1:4444/wd/hub',
    allScriptsTimeout: 60000,

    onPrepare: function(){

        browser.driver.manage().window().maximize();
        
        var welcome = element(by.xpath("//*[@data-protractor-id='hideWelcome']"));
        browser.get('/auth/login');
        browser.waitForAngular();
        
        browser.driver.manage().window().maximize();
        
        welcome.isPresent().then(function(present){
            if(present){
                welcome.isDisplayed().then(function(displayed){
                    if(displayed){
                        welcome.click();
                    }
                });
            }
        });

        global.UDPServer = new udp();
        global.ADMIN_URL = 'https://ai1.webpasta.ru';
        global.TEST_API = {
            protocol: 'https',
            host: 'ai1.webpasta.ru',
            post: 443,
            caFile: [ fs.readFileSync('./phabricator.whiteteam.pem') ]
        };
        
        global.evtDate = function(daysOffset){
            if(typeof hour === 'undefined'){
                hour = 12;
            }
            if(typeof minute === 'undefined'){
                minute = 0;
            }
            return moment().add(daysOffset, 'days').hour(hour).minute(minute).seconds(0).format("DD.MM.YYYY HH:MM");
        };
        
        /* For local backend
         global.TEST_API = {
         protocol: 'http',
         host: 'local.webpasta.ru',
         post: 8000,
         caFilePath: null
         };
         */
        
    }
};

