echo ">>> installing php"
sudo apt-get install -y php5-curl php5-cli --no-install-recommends
echo ">>> downloading arcanist"
mkdir ~/.phab
git clone git://github.com/facebook/libphutil.git ~/.phab/libphutil
git clone git://github.com/facebook/arcanist.git ~/.phab/arcanist
echo ">>> updating PATH"
echo 'export PATH=$PATH:~/.phab/arcanist/bin' >> ~/.bashrc
echo ">>> installing bash completion"
echo 'source ~/.phab/arcanist/resources/shell/bash-completion' >> ~/.bashrc
echo ">>> updating your session"
source ~/.bashrc
echo ">>> installing certificate, follow the steps bellow:"
cp phabricator.whiteteam.pem ~/.phab/libphutil/resources/ssl/custom.pem
~/.phab/arcanist/bin/arc install-certificate
echo ">>> done"
