(function () {
    'use strict';

    var del = require('del'),
        gulp = require('gulp'),
        g = require("gulp-load-plugins")({
            pattern: ['gulp-*', 'gulp.*', 'main-bower-files'],
            replaceString: /\bgulp[\-.]/
        }),
        _ = require("lodash"),
        path = require('path'),
        fs = require('fs'),
        sass = require('gulp-ruby-sass'),
        express = require('express'),
        compression = require('compression'),
        gutil = require('gulp-util'),
        lr = require('gulp-livereload'),
        runSequence = require("run-sequence"),
        options = {},
        app = express(),
        httpPort = 5000,
        staticUrl = "/static",
        http = require('http'),
        https = require('https'),
        mergeStream = require('merge-stream');

    var postcss_processors = [
        require('autoprefixer-core')({browsers: ['last 3 version']}),
        require('css-mqpacker'),
        require('csswring')
    ];

    var merge = function (origin, source) {
        for (var key in source) {
            origin[key] = source[key];
        }
        return origin;
    };

    var sslCredentials = {
        key: fs.readFileSync('./ssl/server.key'),
        cert: fs.readFileSync('./ssl/server.crt')
    };


    var try_merge = function (filename) {
        var config = require(filename);
        options = merge(DEFAULT_CONFIG, config);
    };

    var DEFAULT_CONFIG = {
        json_rpc_endpoint: "http://127.0.0.1:8000/jsonrpc/",
        restangular_base_url: "http://127.0.0.1:8000/",
        mapbox_id: "invitor.l35hn41b",
        use_browser_geolocation_api: true,
        nokia_api_app_id: "uc9ijEHtpJo1slBPFvs3",
        nokia_api_app_code: "BJ5FvZ13ehZ7gD--Ks1mqA"
    };

    var argv = require('minimist')(process.argv.slice(2)),
        production = !!argv.production,
        debug = !!argv.debug;

    var buildRoot = ".build/";
    var staticRoot = buildRoot + (production ? "release" : "debug") + "/";

    if (argv.settings) {
        if (!fs.existsSync(argv.settings)) {
            gutil.log("Settings file does not exist: ", gutil.colors.red(argv.settings));
            process.exit(1);
        } else {
            try_merge(argv.settings);
            gutil.log("Using settings: ", gutil.colors.magenta(argv.settings));
        }
    } else {
        if (fs.existsSync('./local_settings.json')) {
            try_merge('./local_settings.json');
            gutil.log("Using settings: ", gutil.colors.magenta('./local_settings.json'));
        } else {
            options = DEFAULT_CONFIG;
            gutil.log("Using default settings", gutil.colors.green('./local_settings.json'));
        }
    }

    function startExpress(withHttps, staticRoot, livereload) {

        app.use(compression());

        if (livereload) {
            app.use(require('connect-livereload')());
        }

        app.use(staticUrl, express.static(staticRoot))
            .get('/*', function (req, res) {
                res.sendFile(__dirname + "/" + staticRoot + "index.html");
            });

        if (withHttps) {
            https
                .createServer(sslCredentials, app)
                .listen(httpPort);

            console.log('Start listen (use ssl):', httpPort);
        }
        else {
            http
                .createServer(app)
                .listen(httpPort);

            console.log('Start listen:', httpPort);
        }
    }

    function injectDeps(glob, path, tag) {
        return g.inject(
            gulp.src(glob, {
                cwd: "."
            }), {
                starttag: '<!-- inject:' + tag + ':{{ext}} -->',
                addPrefix: staticUrl,
                ignorePath: path
            }
        );
    }

    var foreach = require('gulp-foreach');

    gulp.task('bower:styles', function (cb) {
        return gulp.src(g.mainBowerFiles({
            filter: /.*\.css$/i
        }))
            .pipe(g.plumber())
            .pipe(g.if(debug, g.size({title: "Components styles total", showFiles: true})))
            .pipe(g.if(!production, g.sourcemaps.init()))
            .pipe(g.concat("lib.css"))
            .pipe(g.postcss(postcss_processors))
            .pipe(g.if(!production, g.sourcemaps.write(".")))
            .pipe(g.if(production && debug, g.size({title: "Components styles total minified"})))
            .pipe(g.if(production && debug, g.size({
                title: "Components styles total minified",
                gzip: true
            })))
            .pipe(g.if(production, g.rev()))
            .pipe(gulp.dest(staticRoot + "css"));
    });

    gulp.task('bower:scripts', function (cb) {
        return gulp.src(g.mainBowerFiles({
            filter: /.*\.js$/i
        }))
            .pipe(g.plumber())
            .pipe(g.if(debug, g.size({title: "Components js total", showFiles: true})))
            .pipe(g.if(!production, g.sourcemaps.init()))
            .pipe(g.concat('lib.js'))
            .pipe(g.if(production, g.uglify({mangle: true})))
            .pipe(g.if(production, g.rev()))
            .pipe(g.if(!production, g.sourcemaps.write(".")))
            .pipe(g.if(production && debug, g.size({title: "Components js total minified"})))
            .pipe(g.if(production && debug, g.size({title: "Components js total minified", gzip: true})))
            .pipe(gulp.dest(staticRoot + "js"));
    });

    gulp.task('bower:images', function (cb) {
        return gulp.src(g.mainBowerFiles({
            filter: /(.*)\.(png|jpg|gif|svg|ico)$/
        }))
            .pipe(g.plumber())
            .pipe(g.if(debug, g.size({title: "Component images total", showFiles: true})))
            .pipe(g.if(production, g.imagemin({progressive: true})))
            .pipe(g.if(production && debug, g.size({title: "Components images total", gzip: true})))
            .pipe(gulp.dest(staticRoot + "css"));
    });

    gulp.task("bower", ["bower:scripts", "bower:styles", "bower:images"]);

    gulp.task('assets:flash', function (cb) {
        return gulp.src('./app/flash/**')
            .pipe(gulp.dest(staticRoot + "flash"));
    });

    gulp.task('assets:fonts', function (cb) {
        return gulp.src('./app/fonts/**')
            .pipe(gulp.dest(staticRoot + "fonts"));
    });

    gulp.task('assets:images', function (cb) {
        return gulp.src('./app/i/**')
            .pipe(g.plumber())
            .pipe(g.if(production, g.imagemin({progressive: true})))
            .pipe(gulp.dest(staticRoot + "i"));
    });

    gulp.task("assets", ["assets:flash", "assets:fonts", "assets:images"]);

    gulp.task('jshint', function () {
        return gulp.src(['./app/js/**/*.js'])
            .pipe(g.plumber())
            .pipe(g.react())
            .pipe(g.jshint())
            .pipe(g.jshint.reporter('jshint-stylish'));
    });

    gulp.task('app:i18n:backup', function (cb) {

        return gulp.src('./app/languages/*.json')
            .pipe(g.rename(function (path) {
                path.dirname += "/old";
                path.extname = ".bak";
            }))
            .pipe(gulp.dest('./app/languages'));
    });

    gulp.task('app:i18n', ["app:i18n:backup"], function () {
        var regexp = /\[\[\s*(?:'|")(\w+)(?:'|")\s*\|\s*translate\s*\]\]/gim;

        function jsonToStream(filename, value) {
            var stream = require('stream').Readable({objectMode: true});
            stream._read = function () {
                this.push(new gutil.File({
                    cwd: "",
                    base: "",
                    path: filename,
                    contents: new Buffer(JSON.stringify(value, null, 4))
                }));
                this.push(null);
            };
            return stream;
        }

        function loadCurrentTranslations() {
            var langs = Array.prototype.slice.call(arguments);
            return _.zipObject(langs, _.map(langs, function (lang) {
                try {
                    return require("./app/languages/" + lang + ".json");
                }
                catch (err) {
                    gutil.log("Translations doesn't exist: ", lang, ", will create one");
                    return {};
                }
            }));
        }

        var phrases = {};
        // load json from current translations
        var translations = loadCurrentTranslations("ru", "en");
        return gulp.src('./app/**/*.html')
            // load to be translated ids
            .pipe(foreach(function (stream, file) {
                if (!file._contents) {
                    return;
                }

                var matches;
                while ((matches = regexp.exec(file._contents.toString('utf8'))) !== null) {
                    var phrase = matches[1];
                    if (phrase) {
                        phrases[phrase] = phrase;
                    }
                }

                return stream;
            })).on("end", function () {
                // merge untranslated data with current translation file and save it
                var tasks = mergeStream();
                _.forEach(translations, function (trans, lang) {
                    var langTask = jsonToStream(lang + ".json", _.defaults(trans, phrases))
                        .pipe(g.plumber())
                        .pipe(gulp.dest('./app/languages'))
                        .pipe(g.if(debug, g.size({
                            title: "Translations dict total",
                            showFiles: true
                        })))
                        .pipe(g.if(production, g.jsonminify()))
                        .pipe(g.if(debug, g.size({title: "Translations dict total minified"})))
                        .pipe(g.if(debug, g.size({title: "Translations dict total minified", gzip: true})))
                        .pipe(gulp.dest(staticRoot + "languages"));

                    tasks.add(langTask);
                });

                return tasks;
            });
    });

    gulp.task('app:styles', function () {
        var cssFiles = g.filter("*.css");
        return sass('app/styles/app.scss', {
                sourcemap: production,
                trace: true,
                precision: 6,
                debugInfo: !production
            })
            .pipe(g.if(!production, g.sourcemaps.init({loadMaps: true})))
            .pipe(g.if(debug, g.size({title: "App styles total", showFiles: true})))
            .pipe(cssFiles)
            .pipe(g.postcss(postcss_processors))
            .pipe(g.if(!production, g.sourcemaps.write(".")))
            .pipe(cssFiles.restore())
            .pipe(g.if(production && debug, g.size({
                title: "App styles total minified",
                showFiles: true
            })))
            .pipe(g.if(production && debug, g.size({
                title: "App styles total minified",
                gzip: true,
                showFiles: true
            })))
            .pipe(g.if(production, g.rev()))
            .pipe(gulp.dest(staticRoot + "css"));
    });

    gulp.task('app:scripts', function (cb) {
        var templates = gulp.src(['./app/partials/**/*.html', './app/js/**/*.html'])
            .pipe(g.plumber())
            .pipe(g.if(debug, g.size({title: "App templates total", showFiles: true})))
            .pipe(g.if(production, g.minifyHtml({quotes: true, empty: true})))
            .pipe(g.angularTemplatecache({
                module: 'templates',
                standalone: true,
                root: '/static/partials'
            }))
            .pipe(g.rename("templates.js"))
            .pipe(g.if(production && debug, g.size({
                title: "App templates total minified",
                showFiles: true
            })))
            .pipe(g.if(production && debug, g.size({
                title: "App templates total minified",
                gzip: true,
                showFiles: true
            })));

        var js = gulp.src(['./app/js/**/*.js'])
            .pipe(g.plumber())
            .pipe(g.react())
            .pipe(g.if(production, g.ngAnnotate()))
            .pipe(g.if(debug, g.jshint()))
            .pipe(g.if(debug, g.jshint.reporter('jshint-stylish')))
            .pipe(g.if(debug, g.jshint.reporter('fail')))
            .pipe(g.if(debug, g.size({title: "App js total", showFiles: true})));

        return mergeStream(templates, js)
            .pipe(g.if(!production, g.sourcemaps.init()))
            .pipe(g.concat('app.js'))
            .pipe(g.if(production, g.uglify({mangle: true})))
            .pipe(g.if(production, g.rev()))
            .pipe(g.if(!production, g.sourcemaps.write(".")))
            .pipe(g.if(production && debug, g.size({title: "App js total minified"})))
            .pipe(g.if(production && debug, g.size({title: "App js total minified", gzip: true})))
            .pipe(gulp.dest(staticRoot + "js"));
    });

    gulp.task("app", ["app:i18n", "app:styles", "app:scripts"]);

    gulp.task('index', ['app', 'assets', 'bower'], function (cb) {
        function buildTpl(host, config) {
            var opts = DEFAULT_CONFIG;
            var fname = (host) ? 'index_' + host + '.html' : "index.html";

            if (config) {
                opts = merge(DEFAULT_CONFIG, config || {});
            }

            if (opts.hasOwnProperty('json_rpc_endpoint') && opts.hasOwnProperty('restangular_base_url')) {
                return gulp.src('app/index.html')
                    .pipe(injectDeps(staticRoot + 'css/lib*.css', staticRoot, 'lib'))
                    .pipe(injectDeps(staticRoot + 'css/app*.css', staticRoot, 'app'))
                    .pipe(injectDeps(staticRoot + 'js/lib*.js', staticRoot, 'lib'))
                    .pipe(injectDeps(staticRoot + 'js/app*.js', staticRoot, 'app'))
                    .pipe(g.preprocess({context: opts}))
                    .pipe(g.rename(fname))
                    .pipe(g.if(production, g.minifyHtml({quotes: true, empty: true})))
                    .pipe(gulp.dest(staticRoot));
            }
        }

        var streams = mergeStream(buildTpl());
        if (production && options.hasOwnProperty('hosts')) {
            for (var key in options.hosts) {
                streams.add(buildTpl(key, options.hosts[key]));
            }
        }

        return streams;
        //streams.on('end', cb || gutil.noop);
        //return streams.on('end', gutil.noop);
    });

    gulp.task("clean", function (cb) {
        del("*", {cwd: staticRoot, force: true}, cb || gutil.noop);
    });

    gulp.task('default', function () {
        runSequence("clean", "index", function () {
            lr.listen(argv.withHttps && sslCredentials || {});
            gulp.watch([
                'app/styles/**/*.scss'
            ], ['app:styles']);

            gulp.watch([
                'app/js/**/*.js',
                './app/partials/**/*.html',
                './app/js/**/*.html'
            ], ['app:scripts']);

            gulp.watch(['app/index.html'], ['index']);

            gulp.watch([
                buildRoot + 'debug/js/*.js',
                buildRoot + 'debug/css/*.css',
                buildRoot + 'debug/index.html'
            ]).on('change', lr.changed);

            startExpress(argv.withHttps, staticRoot, true);
        });
    });

    gulp.task('serve', function () {
        startExpress(argv.withHttps, staticRoot, false);
    });

    gulp.task('build', function () {
        runSequence("clean", "index");
    });

})();
